import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';


@Component({
  selector: 'app-bank-available',
  templateUrl: './bank-available.component.html'
})
export class BankAvailableComponent implements OnDestroy {
	hidePageTitle = false;
  changePlan = false;
 planNumber: string;
 private sub: any;

 selectedPlan : any;
 planTitle : string;
 pageTitle:string;
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit(params) {
  //this.pageTitle = "Bank Information";
  PayAdminGlobalState.previousPage = "/home";
  PayAdminGlobalState.currentPage = "/bankInfo";
  this.hidePageTitle = false;

  
   this.pageTitle = "Bank Information";
       this.planNumber =  PayAdminGlobalState.planNumber; 
     
      this.planTitle = this.planNumber + "-" + "Bank Information";
    
  }
  navToBack(){
    this.router.navigate([PayAdminGlobalState.previousPage]);

  }

  ngOnDestroy() {
    //this.sub.unsubscribe();
  }


}
