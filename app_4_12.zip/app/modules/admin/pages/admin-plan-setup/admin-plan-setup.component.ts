import { Component, OnDestroy, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { AgGridNg2 } from 'ag-grid-angular';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ModalService } from 'src/app/shared/services/modal.service';

import { FormBuilder, FormControl, FormGroup } from '../../../../../../node_modules/@angular/forms';
import {
  CatchUpOptions,
  DivLocationOptons,
  EmailDEOptions,
  EntrollmentOptions,
  ParticipantUpdateOptions,
  PinLenthOptions,
} from '../../../../shared/config/plan-options.config';
import { ADMIN_CONFIG, APP_CONST, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';
import { IListItem } from '../../../../shared/interfaces/list-item.interface';
import { ToastrService } from '../../../../shared/services/toastr.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { getVoyaSelectItem } from '../../../../shared/utils/pay-admin.utils';
import { AdminDataService } from '../../services/admin-data.service';
import { AdminPlanSetupService } from '../../services/admin-plan-setup.service';

@Component({
  selector: 'app-admin-plan-setup',
  templateUrl: './admin-plan-setup.component.html',
  styleUrls: ['./admin-plan-setup.component.scss']
})
export class AdminPlanSetupComponent implements OnInit, OnDestroy {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  planNumber: string;
  pageTitle: string;
  planSetupResponse: any;
  moneySources: any;
  investments: any;
  context: any;
  moneySourcesColumnDefs: any;
  investmentsColumnDefs: any;
  planUpdateForm: FormGroup;
  isCustomMask: boolean;
  nameChangeAllowed: boolean;
  ssnTypeItems: any;
  loanMatching: boolean;
  moneySourceData: any;
  investmentData: any;
  initialMoneySourceData: any;
  initailInvestmentData: any;
  private gridApi;
  shouldDisabled = false;
  modelId: string;
  participantsItmes: any;
  pinLengthItems: any;
  emailIDItems: any;
  enrollmentOptions: any;
  enrollStatusItems: any;
  divLocItems: any;
  catchUpItems: any;
  frameworkComponents: any;
  planOptions: any;
  enrollmentStatusCodeItems: IListItem[];
  emailIDEItems: any;
  popupTitle: string;
  private gridColumnApi;
  pageLoaded= false;
  style;

  constructor(
    private planSetupService: AdminPlanSetupService,
    private fb: FormBuilder,
    private router: Router,
    private adminDataService: AdminDataService,
    private modalService: ModalService,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
  vcr: ViewContainerRef,
  ) {
    this.toastrService.toastr.setRootViewContainerRef(vcr);
    this.style = { width: '94%' };
    this.pageTitle = SUB_TITLE.UPDATE_PLAN;
    this.moneySourcesColumnDefs =
      GRID_CONFIG.PLAN_UPDATE.COLUMN_DEFS_MONEY_SOURCES;
    this.investmentsColumnDefs =
      GRID_CONFIG.PLAN_UPDATE.COLUMN_DEFS_INVESTMENTS;
    this.ssnTypeItems = ADMIN_CONFIG.SSN_ITEMS;
  }

  ngOnInit() {
    this.participantsItmes = ParticipantUpdateOptions;
    this.pinLengthItems = PinLenthOptions;
    this.emailIDItems = EmailDEOptions;
    this.enrollmentOptions = EntrollmentOptions;
    this.divLocItems = DivLocationOptons;
    this.catchUpItems = CatchUpOptions;
    this.planNumber = PayAdminGlobalState.planNumber;

    this.spinner.show();
    this.getPlanSetup();

  }

  onRadioClick(value: string) {
    this.isCustomMask = value === ADMIN_CONFIG.CUSTOM_MASK_VALUE ? true : false;
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  createFormGroup(form) {
    console.log(form,'forms')
    this.shouldDisabled = !form.loanMatching;

    this.planUpdateForm = this.fb.group({
      loanMatching: new FormControl(form.loanMatching),
      loanPayoffs: new FormControl({
        value: form.loanPayoffs,
        disabled: !form.loanMatching
      }),
      nonACH: new FormControl(form.nonACH),
      copyPayroll: new FormControl(form.copyPayroll),
      crossCalendarPayroll: new FormControl(form.crossCalendarPayroll),
      negativeContrib: new FormControl(form.negativeContrib),
      disActPartWContrib: new FormControl(form.disActPartWContrib),
      maskSSN: new FormControl(form.maskSSN),
      customMask: new FormControl(form.customMask),
      nameChange: new FormControl(form.nameChange),
      submitBatchesInAdvance: new FormControl(form.submitBatchesInAdvance),
      catchUp: new FormControl(form.catchUp),
      participantUpdate: new FormControl(form.participantUpdate),
      emailDE: new FormControl(form.emailDE),
      divLocFunc: new FormControl(form.divLocFunc),
      enrollment: new FormControl(form.enrollment),
      leaveOfAbsence: new FormControl(form.leaveOfAbsence),
      lastChangedBy: new FormControl(form.lastChangedBy),
      pinLength: new FormControl(form.pinLength),
      enrollmentStatusCode: new FormControl(form.enrollmentStatusCode),
      reportsFolder: new FormControl(form.reportsFolder)
    });
    if (form.maskSSN === ADMIN_CONFIG.CUSTOM_MASK_VALUE) {
      this.isCustomMask = true;
    }
  }
  toggleCustomMask(value) {
    if (value) {
      this.isCustomMask = true;
    } else {
      this.isCustomMask = false;
    }
  }
  enableLoanPayoff(value: any) {
    this.shouldDisabled = !value;
    this.planUpdateForm.controls['loanPayoffs'].setValue(false);
  }
  getPlanSetup() {
    this.planSetupService.getPlanSetup(this.planNumber).subscribe(
      planSetup => {
        if (planSetup.status === APP_CONST.SUCCESS) {
          this.planSetupResponse = planSetup.data;
          this.createFormGroup(planSetup.data);
          this.getMoneySource();
        }
      },
      err => {
        console.log('Error in plan setup load', err);
        this.toastrService.showError(err.error.error.msg, err.error.error.status + ' !');
        this.spinner.hide();
      }
    );
  }
  getMoneySource() {
    this.planSetupService.getMoneySource(this.planNumber).subscribe(
      money => {
        if (money.status === APP_CONST.SUCCESS) {
          this.moneySources = money.data;
          this.getInvestments();
        }
      },
      err => {
        console.log('Error in money source load', err);
        this.toastrService.showError(err.error.error.msg, err.error.error.status + ' !');
        this.spinner.hide();
      }
    );
  }
  getInvestments() {
    this.planSetupService.getInvestments(this.planNumber).subscribe(
      investments => {
        if (investments.status === APP_CONST.SUCCESS) {
          this.investments = investments.data;
          this.moneySourceData = this.generateMoneySourceTableData();
          this.investmentData = this.genereateInvestmentTableData();
          this.initialMoneySourceData = JSON.parse( JSON.stringify( this.moneySourceData ) );
          this.initailInvestmentData = JSON.parse( JSON.stringify( this.investmentData ) );
          PayAdminGlobalState.moneySource = this.moneySourceData;
          PayAdminGlobalState.investments = this.investmentData;
          this.getOptions();
        }
      },
      err => {
        this.toastrService.showError(err.error.error, err.error.error.status + ' !');
        console.log('Error in money source load', err);
        this.spinner.hide();
      }
    );
  }
  getOptions() {
    this.planSetupService.getOptions(this.planNumber).subscribe(
      options => {
        if (options.status === APP_CONST.SUCCESS) {
          this.planOptions = options.data;
          PayAdminGlobalState.isCatchUp = this.planOptions.showCatchUpOptions;
          this.emailIDEItems = this.getEmailDEItems(this.planOptions.rsd);
          this.getEnrollmentList();
            this.spinner.hide();
            this.pageLoaded = true;
        }
      },
      err => {
        this.toastrService.showError(err.error.error.msg, err.error.error.status + ' !');
        console.log('Error in Plan option call', err);
        this.spinner.hide();
      }
    );
  }
  getEnrollmentList() {
    this.planSetupService.getEnrollmentList(this.planNumber).subscribe(
      enrollments => {
        if (enrollments.status === APP_CONST.SUCCESS) {
          this.enrollmentStatusCodeItems = getVoyaSelectItem(enrollments.data);
          this.spinner.hide();
          this.pageLoaded = true;
        }
      },
      err => {
        this.toastrService.showError(err.error.error.msg, err.error.error.status + ' !');
        console.log('Error in Plan option call', err);
        this.spinner.hide();
      }
    );
  }
  getEmailDEItems(isRsa: boolean): any {
    let _emailOptions: { value: string; displayText: string }[];
    if (isRsa) {
      _emailOptions = [_.find(EmailDEOptions, ['value', 'VR151'])];
    } else {

      _emailOptions = [_.find(EmailDEOptions, ['value', 'PH155'])];
    }
    _emailOptions.push({ value: '', displayText: 'No Email' });
    return _emailOptions;
  }
  onSubmit() {
    let isValidForm = true;
    let updatedSources = [];
    let updatedInvestments = [];
    let planSetupData = this.planUpdateForm.value;
    // updated moneysource details will attach to the main object
     _.forEach(PayAdminGlobalState.moneySource, function(source) {
      updatedSources.push(_.omit(source, ['longName', 'shortName']));
    });
if(this.planOptions.showCatchUpOptions && planSetupData.catchUp !== 'N'){
   const hasCatchup = _.find(updatedSources, ['deferralCatchUp', true]);
   if(!hasCatchup)
   {
    isValidForm = false;
    this.toastrService.showError('Select a Catch-up Deferral Source or select No Catch-up elections in the Catch-up Option', 'Validation failed' + '!');
   }
}
if(isValidForm){
// updated investments details will attach to the main object
    _.forEach(PayAdminGlobalState.investments, function(investment) {
      updatedInvestments.push(_.omit(investment, ['longName']));
    });
    _.assign(planSetupData, { moneySources: updatedSources });
    _.assign(planSetupData, { investments: updatedInvestments });
    console.log('planSetupData', planSetupData);
    this.spinner.show();
    this.planSetupService
      .savePlanSetup(this.planNumber, planSetupData)
      .subscribe(
        saveStatus => {
          this.spinner.hide();
          if (saveStatus.status === APP_CONST.SUCCESS) {
            planSetupData = null;
            updatedSources = null;
            updatedInvestments = null;
            AdminDataService.successMsg = 'Plan General Information successfully updated';
            this.router.navigate(['/admin']);
          } else {

            this.toastrService.showError(saveStatus.error.msg, saveStatus.status + ' !')
          }
        },
        err => {
          console.log('Error in plan save', err.error.error.msg);
          this.toastrService.showError(err.error.error.msg, err.error.error.status + ' !')
          this.spinner.hide();
        }
      );
      }
  }
  generateMoneySourceTableData() {
    return this.planSetupService.mergeObjects(
      this.planSetupResponse.moneySources,
      this.moneySources
    );
  }
  genereateInvestmentTableData() {
    return this.planSetupService.mergeObjects(
      this.planSetupResponse.investments,
      this.investments
    );
  }
  gotoBack() {
    this.router.navigate(['/admin']);
  }
  ngOnDestroy() {
    PayAdminGlobalState.bankinfo = null;
  }
  showParticipantPopup() {
    this.modelId = 'participant';
    this.popupTitle = 'Participant Update Option';
    this.modalService.open('plansteup');
  }
  showCatchupPopup() {
    this.modelId = 'catchup';
    this.popupTitle = 'Catch-up Option';
    this.modalService.open('plansteup');
  }
  showEnrollPopup() {
    this.popupTitle = 'Enrollment Option';
    this.modelId = 'enroll';
    this.modalService.open('plansteup');
  }
  clearFields(){
    console.log('this.initialMoneySourceData', this.initialMoneySourceData)
    this.enrollmentStatusCodeItems = JSON.parse( JSON.stringify( this.enrollmentStatusCodeItems ) );
    this.planSetupResponse = JSON.parse( JSON.stringify( this.planSetupResponse) );
    this.createFormGroup(this.planSetupResponse);
    this.moneySourceData = JSON.parse( JSON.stringify( this.initialMoneySourceData ) );
    this.investmentData =  JSON.parse( JSON.stringify( this.initailInvestmentData ) );
    PayAdminGlobalState.moneySource =  this.moneySourceData;
    PayAdminGlobalState.investments =   this.investmentData;
  }
}
