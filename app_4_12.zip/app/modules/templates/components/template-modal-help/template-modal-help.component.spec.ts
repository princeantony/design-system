import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModalHelpComponent } from './template-modal-help.component';

describe('TemplateModalHelpComponent', () => {
  let component: TemplateModalHelpComponent;
  let fixture: ComponentFixture<TemplateModalHelpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModalHelpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModalHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
