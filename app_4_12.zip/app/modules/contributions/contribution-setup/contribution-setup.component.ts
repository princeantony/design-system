import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contribution-setup',
  templateUrl: './contribution-setup.component.html',
  styleUrls: ['./contribution-setup.component.scss']
})
export class ContributionSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
