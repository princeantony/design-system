export interface ParticipantMorningStar {
  headers: string[];
  rows: Array<string[]>;
}

// Admin Settings
export class ParticipantOptionSetting {
  servicePayLoad: boolean;
  displayQDIA: boolean;
  displayMorningStar: boolean;
  displayEnrollParticipant: boolean;
  disableQDIA: boolean;
  disableMorningStar: boolean;
  morningStarError: boolean;
  enableEnrollParticipant: boolean;
  displayEmail: boolean;
  canLoadOptionalDataElements: boolean;
  participantMinAge: number;
  participantMaxAge: number;
  salaryDataElement?: string;
  salaryEffectiveDateDataElement?: string;
  statusCode?: string;
  authDivSub: Option[];
  otherDivSub: Option[];
  allDivSubOptionMaxLength: number;
  displayLOA: boolean;
  loaStartDateDataElement?: string;
  loaStartReasonDataElement?: string;
  loaEndDateDataElement?: string;
  loaEndReasonDataElement?: string;
  allowNameChange?: boolean;

  constructor() {
    this.servicePayLoad = false;
    this.displayQDIA = false;
    this.displayMorningStar = false;
    this.enableEnrollParticipant = false;
    this.displayQDIA = false;
    this.disableMorningStar = false;
    this.morningStarError = false;
    this.enableEnrollParticipant = true;
    this.displayEmail = true;
    this.canLoadOptionalDataElements = false;
    this.participantMinAge = 0;
    this.participantMaxAge = 100;
    this.salaryDataElement = '';
    this.salaryEffectiveDateDataElement = '';
    this.statusCode = '';
    this.authDivSub = [];
    this.otherDivSub = [];
    this.allowNameChange = true;

    this.displayLOA = false;
    this.loaStartDateDataElement = '';
    this.loaStartReasonDataElement = '';
    this.loaEndDateDataElement = '';
    this.loaEndReasonDataElement = '';
  }
}
// Participant
export interface ParticipantItem {
  ssn: string;
  name: string;
}

// Participant Required Data
export interface IParticipantRequiredData {
  ssn?: string;
  email?: string;
  lastName: string;
  firstName: string;
  middleInitial?: string;
  address1: string;
  address2?: string;
  city: string;
  zipCode: string;
  state: string;
  country: string;
  birthDate: string;
  hireDate: string;
  rehireDate?: string;
  termCode?: string;
  termDate?: string;
  makeParticipantActive?: string;
  absenceStartDate?: string;
  absenceStartDateReason?: string;
  absenceEndDate?: string;
  absenceEndDateReason?: string;
  termReadOnlyFlag?: boolean;
  displayMakeActive?: boolean;
  enrollFlag: boolean;
  mstarFlag: boolean;
  qdiaFlag: boolean;
  statusCode?: string;
}

// Particaipant Optional Field Data

export interface Option {
  value: string;
  displayText: string;
}

export interface ParticipantOptionalField {
  label: string;
  componentType: string;
  value: string;
  readOnly: boolean;
  disabled: boolean;
  option: Option[];
  required: boolean;
  type: string;
  key: string;
  length: number;
  accumulate?: boolean;
}

// Participant Contribution Screen
export interface ParticipantContributionElectionItem {
  label: string;
  value: string;
  readOnly: boolean;
  key: string;
  type: string;
}
export interface ParticipantContribution {
  // **** contribution Election section ****
  contribElectionOptions?: Option[]; // This contains the values "Percent" or "Amount" in a dropdown
  contribElection?: ParticipantContributionElectionItem[]; // This field will contains the contribution elections
  // contribMixedDeferrals : If true, then user can enter either P or A. Display a error message mentioned in Action/Message column.
  // If false the user can either enter Amount Or Percent.
  contribMixedDeferrals?: boolean;
  contribDeferralType?: string; // This can either me "P" or "A" (Percent or Amount)
  // If true, then check for min and max Percent Or Amount field values, if false, validate value for greater than 0.
  // Also if false, if defType is "Percent", value should be <= 100%, if "Amount", the value should be < 10,000,000.00
  customEdit?: boolean;
  contribTotalMaxDefPct?: number;
  contribTotalMaxDefAmt?: number;
  // **** catchup contribution Election section ****
  catchupContribElectionOptions?: Option[]; // This contains the values "Percent" or "Amount" in a dropdown
  catchupContribElection?: ParticipantContributionElectionItem[]; // This field will contains the contribution elections
  // catchupContribMixedDeferrals : If true, then user can enter either P or A. Display a error message mentioned in Action/Message column.
  // If false the user can either enter Amount Or Percent.
  catchupContribMixedDeferrals?: boolean;
  catchupDeferralType?: string; // This can either me "P" or "A" (Percent or Amount)
  catchupContribTotalMaxDefPct?: number; // If catchUpDefType is "Percent" and total is greater than this value, then throw erorr.
  catchupContribTotalMinDefPct?: number; // If catchUpDefType is "Percent" and total is greater than this value, then throw erorr.
  catchupContribTotalMaxDefAmt?: number; // If catchUpDefType is Amount and total is greater than this value, then throw erorr.
  catchupContribTotalMinDefAmt?: number; // If catchUpDefType is "Amount" and total is greater than this value, then throw erorr.
  // **** Investment Election section ****
  investmentElection?: ParticipantContributionElectionItem[];
  allowAcrossAllSources?: boolean;
  invElectChangeAllowed?: boolean;
  sameAsSource?: string;
  sameAssourceId?: string;
}

// Participant Contribution Investment Screen
export interface ParticipantFundSourceItem {
  investmentId: string;
  sourceId: string;
  currentPercent: string;
  readOnly: boolean;
}
export interface ParticipantFundSource {
  fundName: string;
  showFundName?: string;
  percents: ParticipantFundSourceItem[];
}
export interface ParticipantSourceMapItem {
  sourceId: string;
  sourceName: string;
}
export interface IParticipantFundSources {
  fundSources: ParticipantFundSource[];
  sourceMap: ParticipantSourceMapItem[];
  invElectChangeAllowed: boolean;
  readOnlyFieldsExist: boolean;
}

export class ParticipantData {
  requiredData: IParticipantRequiredData;
  optionalData: ParticipantOptionalField[];
  participantContribution: ParticipantContribution;
  participantContributionInvestmentData: IParticipantFundSources;
  constructor() {
    //  Set Participant Required Data
    this.requiredData = {} as IParticipantRequiredData;
    this.requiredData.ssn = '';
    this.requiredData.firstName = '';
    this.requiredData.lastName = '';
    this.requiredData.middleInitial = '';
    this.requiredData.email = '';
    this.requiredData.address1 = '';
    this.requiredData.address2 = '';
    this.requiredData.city = '';
    this.requiredData.state = '';
    this.requiredData.zipCode = '';
    this.requiredData.country = '';
    this.requiredData.birthDate = '';
    this.requiredData.hireDate = '';
    this.requiredData.rehireDate = '';
    this.requiredData.enrollFlag = false;
    this.requiredData.mstarFlag = false;
    this.requiredData.qdiaFlag = false;
    this.requiredData.displayMakeActive = false;
    this.optionalData = [] as ParticipantOptionalField[];
    this.participantContribution = {} as ParticipantContribution;
    this.participantContributionInvestmentData = {} as IParticipantFundSources;
  }
}

export interface ParticipantSubmitData {
  participantInfo: ParticipantInfo;
  optionalDataElement: ParticipantCodeValue[];
  contributionElections: ParticipantCodeValue[];
  catchUpContributionElections: ParticipantCodeValue[];
  investmentElectionsList: PariticantInvestmentElectionItemSubmit[];
}

export interface ParticipantInfo {
  partSSN: string;
  firstName: string;
  lastName: string;
  middleInitial: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  email: string;
  statusCode: string;
  backupStatusCode: string;
  birthDate: string;
  hireDate: string;
  rehireDate: string;
  termDate: string;
  termCode: string;
  defType: string;
  catchupDefType: string;
  planId: string;
  enrollFlag: boolean;
  newDivsubUpdated: string;
  sameAsSource: string;
  mstarFlag: boolean;
  qdiaFlag: boolean;
}

export interface ParticipantCodeValue {
  code: string;
  value: string;
}

export interface PariticantInvestmentElectionItemSubmit {
  investmentId: string;
  sourceId: string;
  newPercent: string;
}
