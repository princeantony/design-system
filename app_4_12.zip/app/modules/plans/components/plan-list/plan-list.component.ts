import { Component, Injectable, OnInit, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from 'src/app/shared/services/common.service';

import { APP_CONST } from '../../../../shared/constants/app.constants';
import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';
import { ToastrService } from '../../../../shared/services/toastr.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { AuthService } from '../../../login/services/auth.service';
import { PlanService } from '../../services/plan.service';

@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss']
})
@Injectable()
export class PlanListComponent implements OnInit {
  columnDefs: any;
  planData: any;
  width;
  errorCount = 0;
  planListItem: any;
  constructor(
    private planService: PlanService,
    private commonService: CommonService,
    private authService: AuthService,
    private spinner: NgxSpinnerService,
    private router: Router,
    private toastrService: ToastrService,
    private vcr: ViewContainerRef
  ) {
    this.toastrService.toastr.setRootViewContainerRef(vcr);
  }
  ngOnInit() {
    this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
    this.width = GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
    this.planListItem = PayAdminGlobalState.planListState;
    if (!PayAdminGlobalState.loginUser && !PayAdminGlobalState.loginStatus) {
      this.router.navigate(['/']);
    } else {
      if (!PayAdminGlobalState.planListState) {
        this.getPlans();
      } else {
        this.planData = PayAdminGlobalState.planListState;
      }
    }
  }
  getPlans(): void {
    this.spinner.show();
    this.planService.getPlans().subscribe(
      plans => {
        this.spinner.hide();
        if (plans.status === APP_CONST.SUCCESS) {
          this.planData = plans.data;
          PayAdminGlobalState.planListState = this.planData; // will enable if we use local state
        } else {
          this.errorCount++;
          if (this.errorCount < 4) {
            this.getPlans();
          } else {
            this.toastrService.showError(plans.error.msg, plans.status + '!');
          }
        }
      },
      err => {
        this.spinner.hide();
        this.errorCount++;
        if (err.error && err.error.text) {
          if (this.errorCount < 4) {
            this.getPlans();
          }
        } else {
          this.spinner.hide();
          this.toastrService.showError('Error while fetching Plans. Try again!', 'Error!');
        }
      }
    );
  }

  onRowClicked(params) {
    const planId = params.data.planNumber;
    this.commonService.planChanged.next(params.data.planNumber);
    PayAdminGlobalState.planNumber = planId;
    PayAdminGlobalState.homeFlagState = null;
    this.router.navigate(['/home']);
  }
}
