import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ParticipantsService } from 'src/app/modules/participants/service/participants.service';
import { ParticipantStore } from 'src/app/modules/participants/store/participant.store';

@Component({
    selector: "app-batch-grid-link",
    templateUrl: "./batch-grid-link.component.html"
})
export class BatchGridLinkComponent implements ICellRendererAngularComp {

    private params: any;
    public link : string;

    agInit(params: any): void {
        this.params = params;
    }

    constructor(private router: Router,  private participantService: ParticipantsService) { }


    public invokeRouteTo() {
        console.log(this.params.data.ssn);
            // Clear store on selecting a participant
            this.participantService.resetParticipantStore();
            console.log(this.params.data.ssn);
            // TODO: get required data and update store Got to required data component and fill the form
            this.participantService
              .getParticipantBySSN$(this.params.data.ssn)
              .subscribe(res => {
                if (res.status === 'SUCCESS') {
                  // TODO: Handle type checking here
                  ParticipantStore.ParticipantData.requiredData = res.data;
                  ParticipantStore.ParticipantData.requiredData.ssn = this.params.data.ssn;
                  this.router.navigate(['UpdateParticipant']);
                }
              });
            this.router.navigate(['UpdateParticipant']);

    }
    refresh(): boolean {
        return false;
    }
}
