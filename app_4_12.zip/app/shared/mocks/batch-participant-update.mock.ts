export const BatchParticipantCheckList =
{
    "status": "SUCCESS",

    "data": {
        "divsubEnabled": true,
        "divsubId": "1006",
        "fields": [
            {
                key: "PTEPH11",
                label: "Name",
                inqOnly: ""
            },
            {
                key: "PTEPH12",
                label: "Address",
                inqOnly: ""
            },
            {
                key: "PTEPH13",
                label: "Employee status ",
                inqOnly: "Inquiry Only"
            },
            {
                key: "PTEPH14",
                label: "Date of Birth",
                inqOnly: ""
            },
            {
                key: "PTEPH15",
                label: "Date of Hire",
                inqOnly: ""
            },
            {
                key: "PTEPH16",
                label: "Termination Date/Reason",
                inqOnly: ""
            },
            {
                key: "PTEPH17",
                label: "Email Address",
                inqOnly: "Inquiry Only"
            },
            {
                key: "PTEPH18",
                label: "Eligible Hours Anniversary",
                inqOnly: ""
            },
            {
                key: "PTEPH19",
                label: "Division/Location",
                inqOnly: ""
            },
            {
                key: "PTEPH20",
                label: "Federal Maritial Status",
                inqOnly: ""
            },
            {
                key: "PTEPH21",
                label: "Employee Number",
                inqOnly: ""
            },
        ]
    }
}
