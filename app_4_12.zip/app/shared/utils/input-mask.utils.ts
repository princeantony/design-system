class MaskType {
  type: string;
  mask: string;
  constructor(type,mask){
      this.type = type;
      this.mask = mask;
  }
}
export class MaskInput {
  pattern: MaskType[];
  constructor(el, type, options = {}) {
    this.pattern = [new MaskType("ssn", "(!^d{3}-d{2}-d{4}$"),
                    new MaskType("","")];
  }

  maskInput(type) {}
}
