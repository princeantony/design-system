import { Directive, ElementRef, HostListener } from '@angular/core';
import { VoyaDatePipe } from '../pipes/voya-date.pipe';

@Directive({
  selector: '[appDate]'
})
export class DateDirective {
  private el: any;
  private today = new Date();
  private date = {} as Date;
  constructor(private elementRef: ElementRef, private datePipe: VoyaDatePipe) {
    this.el = this.elementRef.nativeElement;
  }
  ngOnInit() {
    this.el.value = this.datePipe.transform(this.el.value);
  }

  @HostListener('blur', ['$event.target.value'])
  onBlur(value) {
    // this.el.value = this.datePipe.transform(this.el.value);
  }
  @HostListener('keypress', ['$event.target.value', '$event'])
  onkeypress(value, event) {
    const e = <KeyboardEvent>event;
    const len = value.length;
    if (e.keyCode < 47 || e.keyCode > 57) {
      e.preventDefault();
    }
    // If we're at a particular place, let the user type the slash
    // i.e., 12/12/1212
    if (len !== 1 || len !== 3) {
      if (e.keyCode === 47) {
        e.preventDefault();
      }
    }
    if (e.keyCode !== 8) {

      // If they don't add the slash, do it for them...
      if (len === 2) {
        this.el.value += '/';
      }

      // If they don't add the slash, do it for them...
      if (len === 5) {
        this.el.value += '/';
      }
    }
  }
  @HostListener('keydown', ['$event', '$event.target.value'])
  onKeyDown(event, value) {
    const e = <KeyboardEvent>event;
    if (
      [46, 8, 9, 27, 13, 110, 190].indexOf(e.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (e.keyCode === 65 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+C
      (e.keyCode === 67 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+V
      (e.keyCode === 86 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+X
      (e.keyCode === 88 && (e.ctrlKey || e.metaKey)) ||
      // Allow: home, end, left, right
      (e.keyCode >= 35 && e.keyCode <= 39) ||
      // Allow : / key for date format
      (e.keyCode === 191 || e.keyCode === 111)
    ) {
      // let it happen, don't do anything
      return;
    }
    // Ensure that it is a number and stop the keypress
    if (
      (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) &&
      (e.keyCode < 96 || e.keyCode > 105)
    ) {
      e.preventDefault();
    }

    if (value.length >= 10) {
      e.preventDefault();
    }

    // const pattern =
    //   '^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(19|20)\\d\\d$' +
    //   '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(19|20)\\d$' +
    //   '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(19|20)$' +
    //   '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[12]$' +
    //   '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$' +
    //   '|^(0[1-9]|1[012])([0-3])$' +
    //   '|^(0[1-9]|1[012])$' +
    //   '|^[01]$';
    // const regexp = new RegExp(pattern);
    // const key = event.charCode ? event.charCode : event.keyCode;

    // const character = String.fromCharCode(event.which);
    // const start = value[0].selectionStart;
    // const end = value[0].selectionEnd;
    // const testValue = (
    //   value.valamParse().slice(0, start) +
    //   character +
    //   value.val().slice(end)
    // ).replace(/\s|\//g, '');
    // if (!regexp.test(testValue)) {
    //   event.preventDefault();
    // }
  }

  validatedate(dateString) {
    const dateformat = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;
    // Match the date format through regular expression
    if (dateString.value.match(dateformat)) {
      // Test which seperator is used '/' or '-'
      const opera1 = dateString.value.split('/');
      const opera2 = dateString.value.split('-');
      const lopera1 = opera1.length;
      const lopera2 = opera2.length;
      let pdate;
      // Extract the string into month, date and year
      if (lopera1 > 1) {
        pdate = dateString.value.split('/');
      } else if (lopera2 > 1) {
        pdate = dateString.value.split('-');
      }
      const mm = parseInt(pdate[0], 10);
      const dd = parseInt(pdate[1], 10);
      const yy = parseInt(pdate[2], 10);
      // Create list of days of a month [assume there is no leap year by default]
      const ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      if (mm === 1 || mm > 2) {
        if (dd > ListofDays[mm - 1]) {
          alert('Invalid date format!');
          return false;
        }
      }
      let lyear = false;
      if (mm === 2) {
        lyear = false;
        if ((!(yy % 4) && yy % 100) || !(yy % 400)) {
          lyear = true;
        }
        if (lyear === false && dd >= 29) {
          return false;
        }
        if (lyear === true && dd > 29) {
          return false;
        }
      }
    } else {
      return false;
    }
  }
}
