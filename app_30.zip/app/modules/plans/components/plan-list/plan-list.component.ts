import { Component, Injectable, OnInit, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr/ng2-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from 'src/app/shared/services/common.service';

import { APP_CONST } from '../../../../shared/constants/app.constants';
import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { AuthService } from '../../../login/services/auth.service';
import { PlanService } from '../../services/plan.service';

@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss']
})
@Injectable()
export class PlanListComponent implements OnInit {
  columnDefs: any;
  planData: any;
  width;
  errorCount = 0;
  planListItem: any;
  constructor(
    private planService: PlanService,
    private commonService: CommonService,
    private authService: AuthService,
    private spinner: NgxSpinnerService,
    private router: Router,
    public toastr: ToastsManager,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }
  ngOnInit() {
    this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
    this.width = GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
    this.planListItem = PayAdminGlobalState.planListState;
    if (!PayAdminGlobalState.loginUser && !PayAdminGlobalState.loginStatus) {
      this.router.navigate(['/']);
    } else {
      if (!PayAdminGlobalState.planListState) {
        this.getPlans();
      } else {
        this.planData = PayAdminGlobalState.planListState;
      }
    }
  }
  getPlans(): void {
    this.spinner.show();
    this.planService.getPlans().subscribe(
      plans => {
        this.spinner.hide();
        if (plans.status === APP_CONST.SUCCESS) {
          this.planData = plans.data;
          PayAdminGlobalState.planListState = this.planData; // will enable if we use local state
        } else {
          this.errorCount++;
          if (this.errorCount < 4) {
            this.getPlans();
          } else {
            this.toastr.error(plans.error.msg, plans.status + ' !', {
              showCloseButton: true
            });
          }
        }
      },
      err => {
        this.spinner.hide();
        this.errorCount++;
        if (err.error && err.error.text) {
          if (this.errorCount < 4) {
            this.getPlans();
          }
        } else {
          this.spinner.hide();
          this.toastr.error(
            'Error while fetching Plans. Try again!',
            err.error.status + ' !',
            { showCloseButton: true }
          );
        }
      }
    );
  }

  onRowClicked(params) {
    const planId = params.data.planNumber;
    this.commonService.planChanged.next(params.data.planNumber);
    PayAdminGlobalState.planNumber = planId;
    this.router.navigate(['/home']);
  }
}
