import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from 'src/app/shared/services/common.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html'
})
export class LoginPageComponent implements OnInit {
  constructor(
    private commonService: CommonService,
    private toastr: ToastsManager,
    private spinner: NgxSpinnerService,
    private router: Router
  ) {}
  ngOnInit() {
    if (PayAdminGlobalState.loginUser && PayAdminGlobalState.loginStatus) {
      this.router.navigate(['/plans']);
    }
  }

}
