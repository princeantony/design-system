import { Component, ElementRef, OnInit, ViewContainerRef } from '@angular/core';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr/ng2-toastr';
import { NgxSpinnerService } from 'ngx-spinner';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { APP_CONST, ENV } from '../../../../shared/constants/app.constants';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { BankInfoService } from '../../services/bank-info.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html'
})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub: any;
  updateTime: any;
  updateDate: any;
  bankDetails: any;
  accType: string;
  divSubs: any;
  divSub: string;
  hidePageTitle: boolean;
  print = false;
  printBtn = false;
  subTitle: string;
  planNumber: string;
  payAdminGlobalState: PayAdminGlobalState;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private printForm: ElementRef,
    private spinner: NgxSpinnerService,
    private modalService: ModalService,
    private bankInfoService: BankInfoService,
    public toastr: ToastsManager,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
    PayAdminGlobalState.currentPage = '/bankInfo/confirm';

    this.hidePageTitle = false;
    this.subTitle = 'Bank Information';
    this.planNumber = PayAdminGlobalState.planNumber;
    this.bankDetails = PayAdminGlobalState.bankDetails;
    if (PayAdminGlobalState.divsubId !== '') {
      this.divSubs = PayAdminGlobalState.subDiv;
      this.divSub = _.filter(this.divSubs, [
        'divsub',
        PayAdminGlobalState.divsubId
      ])[0].textOnly;
    }
    if (this.bankDetails.bankInfo.accountType === 'C') {
      this.accType = 'Checking';
    } else {
      this.accType = 'Savings';
    }
    this.route.url.subscribe(value => {
      if(_.find(value, ['path', 'print']))
      {
        this.printBtn = true;
        this.print = true;
      }
    });
  }
  onPrint() {
    window.print();
    PayAdminGlobalState.successMsg = '';
  }

  onSubmit() {
    const planId = PayAdminGlobalState.planNumber;
    this.spinner.show();
    this.updateDate = new Date().toLocaleDateString();
    this.updateTime = new Date().toLocaleTimeString();
   const urls =  _.split(PayAdminGlobalState.previousPage, '/');

    if (ENV.TEST) {
      this.onMockSubmit();
    } else {
      if (_.includes(PayAdminGlobalState.previousPage, 'edit')) {
        this.bankInfoService
          .updateBankInfo(
            this.bankDetails,
            planId,
            PayAdminGlobalState.divsubId
          )
          .subscribe(
            bankInfo => {
              this.spinner.hide();
              if (bankInfo.status === APP_CONST.SUCCESS) {
                PayAdminGlobalState.successMsg = 'Bank Information successfully updated on ' +
                  this.updateDate +
                  ' at ' +
                  this.updateTime +
                  '. For more information,';
                this.router.navigate(['/home/success']);
              } else {
                this.toastr.error(bankInfo.error.msg, bankInfo.status + ' !', {
                  showCloseButton: true
                });
              }
            },
            err => {
              this.spinner.hide();
              this.toastr.error(err.error.error.msg, err.error.status + ' !', {
                showCloseButton: true
              });
            }
          );
      } else {
        this.bankInfoService
          .postBankInfo(this.bankDetails, planId, PayAdminGlobalState.divsubId)
          .subscribe(
            bankInfo => {
              this.spinner.hide();
              if (bankInfo.status === APP_CONST.SUCCESS) {
                PayAdminGlobalState.successMsg =
                  'Bank Information successfully created11 on ' +
                  this.updateDate +
                  ' at ' +
                  this.updateTime +
                  '. For more information,';
                this.router.navigate(['/home/success']);
              } else {
                console.log("bankInfor", bankInfo)
                this.toastr.error(bankInfo.error.msg, bankInfo.status + ' !', {
                  showCloseButton: true
                });
              }
            },
            err => {
              this.spinner.hide();
              console.log("err.error", err.error)
              const errMessage = (err.error.error.code === 400 ?  err.error.error.msg : err.error.error.cause);
                this.toastr.error(errMessage, err.error.status + ' !', {
                  showCloseButton: true
                });
            }
          );
      }
    }
  }
  onMockSubmit() {
    if (_.split(PayAdminGlobalState.previousPage, '/')[2] === 'edit') {
      PayAdminGlobalState.successMsg =
        'Bank Information successfully updated on ' +
        this.updateDate +
        ' at ' +
        this.updateTime +
        '. For more information,';

    } else {
      PayAdminGlobalState.successMsg =
        'Bank Information successfully created on ' +
        this.updateDate +
        ' at ' +
        this.updateTime +
        '. For more information,';
    }
    this.router.navigate(['/home/success']);
  }
  onEdit() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
  gotoHome() {
    this.router.navigate(['/home']);
  }
}
