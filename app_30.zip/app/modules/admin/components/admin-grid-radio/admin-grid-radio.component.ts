import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';

import { AdminDataService } from '../../services/admin-data.service';

@Component({
  selector: "app-admin-grid-radio",
  templateUrl: "./admin-grid-radio.component.html",
  // styleUrls: ["./admin-grid-radio-button.component.scss"]
})

export class AdminGridRadioComponent implements ICellRendererAngularComp {

  private params: any;

  agInit(params: any): void {
    this.params = params;

  }

  refresh(params): boolean {
    return false;
  }

  handleChange(value) {
    try{
      if(this.params.data.optionalElementID)
      {
    AdminDataService.dataElementId = this.params.data.optionalElementID;
    this.params.context.componentParent.selectedItem(AdminDataService.dataElementId);
      }
      if(this.params.data.valueCode)
      {
      AdminDataService.optionCode = this.params.data.valueCode;
      this.params.context.componentParent.selectedItem(AdminDataService.optionCode);
      }

    } catch (ex) {}

  }
}

