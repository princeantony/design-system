import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { Router } from '../../../../../../node_modules/@angular/router';
import { NgxSpinnerService } from '../../../../../../node_modules/ngx-spinner';
import { APP_CONST, ENV, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { IPageList } from '../../../../shared/interfaces/page-list.interface';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { AdminDataService } from '../../services/admin-data.service';
import { AdminPageSetupService } from '../../services/admin-page-setup.service';

@Component({
  selector: 'app-admin-page-security',
  templateUrl: './admin-page-security.component.html',
  styleUrls: ['./admin-page-security.component.scss']
})
export class AdminPageSecurityComponent implements OnInit {
  planNumber: string;
  subTitle: string;
  pageList: Partial<IPageList>[];
  pageFlags: any;
  showPrint = false;
  enrollDisable: boolean;
  element: HTMLElement;
  pageSecurityForm: FormGroup;
  constructor(
    private pageSetupService: AdminPageSetupService,
    private spinner: NgxSpinnerService,
    private router: Router
  ) {}

  ngOnInit() {
    PayAdminGlobalState.previousPage = 'admin';
    PayAdminGlobalState.currentPage = 'admin/pageSecurity';
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.PAGE_SECURITY;
    this.enrollDisable = false;
    this.getPageSettings();
  }
  getMockPageSettings() {
    this.pageSetupService
      .getMockPageSettings(this.planNumber)
      .subscribe(flags => {
        if (flags.status === APP_CONST.SUCCESS) {
          this.pageList = this.pageSetupService.getPageList(flags.data);
          this.pageSecurityForm = this.buildFormGroup(this.pageList);
          this.spinner.hide();
        }
      });
  }
  getPageSettings() {
    this.spinner.show();
    this.pageSetupService.getPageSettings(this.planNumber).subscribe(flags => {
      if (flags.status === APP_CONST.SUCCESS) {
        this.pageList = this.pageSetupService.getPageList(flags.data);
        console.log("pageList", this.pageList)
        this.pageSecurityForm = this.buildFormGroup(this.pageList);
        this.spinner.hide();
      }
    });
  }

  buildFormGroup(pageList: Partial<IPageList>[]) {
    console.log("pageList", pageList)
    let group: any = {};

    pageList.forEach(page => {
      group[page.key] = new FormControl(page.value || false);
      if (page.subItems) {
        page.subItems.forEach(subPage => {
          group[subPage.key] = new FormControl(page.value || false);
        });
      }
    });
    return new FormGroup(group);
  }
  onMockSubmit() {
    AdminDataService.successMsg =
      'Plan Page Security Information successfully updated ';
    this.router.navigate(['/admin']);
  }
  // The below two methods can be writtern in generic with less line of code if the parent
  //  and child properties are having fixed pattern
  DisableChild(thisCtr) {
    let childCtr = '';
    if (thisCtr.controlName === 'addEnrollmentPageActive') {
      childCtr = 'addEnrollmentImportPageActive';
    } else if (thisCtr.controlName === 'batchParticipantUpdatePageActive') {
      childCtr = 'batchParticipantUpdateImportPageActive';
    } else if (thisCtr.controlName === 'contributionPageActive') {
      childCtr = 'contribImportPageActive';
    } else if (thisCtr.controlName === 'loanRepaymentPageActive') {
      childCtr = 'loanImportPageActive';
      this.pageSecurityForm.controls['loanImportPageActive'].disable();
    }
    // .disable() or disableControl is not working since it is rendering as dynamic checkbox.
    if (childCtr !== '') {
      this.element = document.getElementById(childCtr) as HTMLElement;
      if (this.pageSecurityForm.controls[thisCtr.controlName].value) {
        this.pageSecurityForm.controls[childCtr].setValue(false);
        this.element.setAttribute('disabled', 'true');
      } else {
        this.element.removeAttribute('disabled');
      }
    }
  }
  onSubmit() {
    console.log('this.pageSecurityForm.value', this.pageSecurityForm.value);
    if (ENV.TEST) this.onMockSubmit();
    else {
      this.spinner.show();
      this.pageSetupService
        .savePageSettings(this.pageSecurityForm.value, this.planNumber)
        .subscribe(
          pageFlags => {
            if (pageFlags.status === APP_CONST.SUCCESS) {
              AdminDataService.successMsg =
                'Plan Page Security Information successfully updated ';
              this.spinner.hide();
              this.router.navigate(['/admin']);
            }
          },
          err => {
            console.log('Error in save page security', err);
            this.spinner.hide();
          }
        );
    }
  }

  gotoPrevious() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
}
