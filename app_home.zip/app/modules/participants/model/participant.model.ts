export interface ParticipantMorningStar {
  headers: string[];
  rows: string[];
}

// Admin Settings
export class ParticipantOptionSetting {
  displayQDIA:                    boolean;
  displayMorningStar:             boolean;
  displayEnrollParticipant:       boolean;
  disableQDIA:                    boolean;
  disableMorningStar:             boolean;
  morningStarError:               boolean;
  enableEnrollParticipant:        boolean;
  displayEmail:                   boolean;
  canLoadOptionalDataElements:    boolean;
  participantMinAge:              number;
  participantMaxAge:              number;
  salaryDataElement?:              string;
  salaryEffectiveDateDataElement?: string;
}
// Participant
export interface ParticipantItem {
  ssn: string;
  name: string;
}

// Participant Required Data
export interface IParticipantRequiredData {
  ssn: string;
  email?: string;
  lastName: string;
  firstName: string;
  mName?: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  zip: string;
  state: string;
  country: string;
  dateOfBirth: string;
  dateOfHire: string;
  terminationDate?: string;
  terminationReason?: string;
  makeParticipantActive?: string;
  absenceStartDate?: string;
  absenceStartDateReason?: string;
  absenceEndDate?: string;
  absenceEndDateReason?: string;
  enrollFlag: boolean;
  mstarFlag: boolean;
  qdiaFlag: boolean;
}

// Particaipant Optional Field Data

export interface Option {
  value: string;
  displayText: string;
}

export interface ParticipantOptionalField {
  label: string;
  componentType: string;
  value: string;
  readOnly: boolean;
  disabled: boolean;
  option: Option[];
  required: boolean;
  type: string;
  key: string;
  length: number;
}

// Participant Contribution Screen
export interface ParticipantContributionItem {
  key: string;
  label: string;
  value: string;
  readonly: boolean;
}
export interface IParticipantContribution {
  invElectChangeAllowed: boolean;
  mstarFlag: boolean;
  contribElection: {
    type: string;
    list: ParticipantContributionItem[];
  };
  catchupContribElection: {
    type: string;
    list: ParticipantContributionItem[];
  };
  investmentElection: {
    acrossAllSourceElectionFlg: string;
    list: ParticipantContributionItem[];
  };
}

// Participant Contribution Investment Screen
export interface ParticipantFundSourceItem {
  sourceID: string;
  value: string;
  readonly: boolean;
}
export interface ParticipantFundSource {
  fundName: string;
  sources: ParticipantFundSourceItem[];
}
export interface ParticipantSourceMapItem {
  sourceID: string;
  sourceName: string;
}
export interface IParticipantFundSources {
  fundSources: ParticipantFundSource[];
  sourceMap: ParticipantSourceMapItem[];
}

export class ParticipantData {
  participantRequiredData: IParticipantRequiredData;
  participantOptionalData: ParticipantOptionalField[];
  participantContributionElectionData: IParticipantContribution;
  participantContributionInvestmentData: IParticipantFundSources;
  constructor() {
    //  Set Participant Required Data
    this.participantRequiredData = {} as IParticipantRequiredData;
    this.participantRequiredData.ssn = '';
    this.participantRequiredData.firstName = '';
    this.participantRequiredData.lastName = '';
    this.participantRequiredData.mName = '';
    this.participantRequiredData.email = '';
    this.participantRequiredData.addressLine1 = '';
    this.participantRequiredData.addressLine2 = '';
    this.participantRequiredData.city = '';
    this.participantRequiredData.state = '';
    this.participantRequiredData.zip = '';
    this.participantRequiredData.country = '';
    this.participantRequiredData.dateOfBirth = '';
    this.participantRequiredData.dateOfHire = '';
    this.participantRequiredData.enrollFlag = false;
    this.participantRequiredData.mstarFlag = false;
    this.participantRequiredData.qdiaFlag = false;
  }
}
