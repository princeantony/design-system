export class DataElement{
  dataElement1: string;
  dataElement2: string;
  dataElement3: string;
  omniName: string;
  overrideName: string;
  userOverride: boolean;
  accuUserOverride: boolean;
  addEnrollment: string;
  participant: string;
  contribution: string;
  batchParticipant: string;
  accumulate: true;
  accuOverrideName: string;
  dataElement: string;
}
