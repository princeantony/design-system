import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateGridTextboxComponent } from './template-grid-textbox.component';

describe('TemplateGridTextboxComponent', () => {
  let component: TemplateGridTextboxComponent;
  let fixture: ComponentFixture<TemplateGridTextboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateGridTextboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateGridTextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
