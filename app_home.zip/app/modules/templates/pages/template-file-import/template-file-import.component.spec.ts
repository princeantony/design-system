import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateFileImportComponent } from './template-file-import.component';

describe('TemplateFileImportComponent', () => {
  let component: TemplateFileImportComponent;
  let fixture: ComponentFixture<TemplateFileImportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateFileImportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateFileImportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
