import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { APP_CONST, ENV, SUB_TITLE } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { TemplateGridLinkComponent } from '../../components/template-grid-link/template-grid-link.component';
import { TemplatesService } from '../../services/templates.service';

@Component({
  selector: 'app-template-existing-fixed-width',
  templateUrl: './template-existing-fixed-width.component.html',
  styleUrls: ['./template-existing-fixed-width.component.scss']
})
export class TemplateExistingFixedWidthComponent implements OnInit {
  fwtemplateForm = this.fb.group({
    templateId: [],
    headerCount: ['0'],
    trailerCount: ['0']
  });
  fwtemplateFieldForm = this.fb.group({
    fieldType: [],
    startPosition: [],
    fieldLength: []
  });
  planNumber: string;
  subTitle: string;
  importType: string;
  fieldDropdown: any;
  fieldGridColumnDefs: any;
  fieldRowData = [];
  columnDefs = [];
  gridApi: any;
  frameworkComponents: any;
  editType: any;
  rowData: any;
  fileData: any;
  fileType: any;
  rowDataTemp = [];
  successMsg: string;
  constructor(private templateservice: TemplatesService,
              private fb: FormBuilder) { }

  ngOnInit() {
    this.subTitle = SUB_TITLE.TEMPLATE_EXISTING;
    this.planNumber = PayAdminGlobalState.planNumber;
    this.planNumber = PayAdminGlobalState.planNumber;
    this.importType = PayAdminGlobalState.importType;
    this.fileType = PayAdminGlobalState.importFileType;
   // this.fieldGridColumnDefs = GRID_CONFIG.COLUMN_DEFS_FIXED_WIDTH;
    this.fileData = PayAdminGlobalState.importFileData;
    this.frameworkComponents = { linkRenderer: TemplateGridLinkComponent };
    this.editType = 'fullRow';
    if (ENV.TEST) {
      this.getMockFieldList();
    } else {
      this.getFieldList();
    }
  }

  getMockFieldList() {
    this.templateservice
      .getAvailableColsMock(this.planNumber, this.importType)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.fieldDropdown = response.data.availableColumnList;
            this.getMockTemplateDetails();
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }
  getFieldList() {
    this.templateservice
      .getAvailableCols(this.planNumber, this.fileType, this.importType)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.fieldDropdown = response.data.availableColumnList;
          }
        },
        err => {
          console.log('Error', err);
        }
      );

  }
  getMockTemplateDetails() {
    this.templateservice.getMockTemplateDetails().subscribe(response => {

    },
    err => {
      console.log('Error', err);
    });
  }

}
