import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ApiService } from './api.service';
import { MockService } from './mock.service';
import { ENV } from '../../shared/constants/app.constants';
import { SERVICE_URL } from '../../shared/constants/service.constants';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService
  ) {}

  countryChanged = new Subject<string>();

  getCountryList(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getCountryListMock()
      : this.apiService.get(SERVICE_URL.GET_COUNTRY);
  }
  getStateList(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getStateListMock()
      : this.apiService.get(SERVICE_URL.GET_STATE);
  }
}
