import { Component, OnInit, Input } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-de-modal',
  templateUrl: './de-modal.component.html'

})
export class DEModalComponent implements OnInit {
  @Input() deId;
  @Input() type;
  constructor(private modalService: ModalService,
              private router: Router) { }

  ngOnInit() {
  }

  closeModal(id: string) {
    this.modalService.close(id);
}
continueTo() {
  this.router.navigate(['/admin/dataElements/delete']);
}

}


