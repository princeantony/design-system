import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';

@Component({
  selector: "app-admin-grid-radio",
  templateUrl: "./admin-grid-radio.component.html",
  // styleUrls: ["./admin-grid-radio-button.component.scss"]
})

export class AdminGridRadioComponent implements ICellRendererAngularComp {

  private params: any;

  agInit(params: any): void {
    this.params = params;
  }

  refresh(params): boolean {
    return true;
  }

  handleChange() {
    this.params.node.setSelected(!this.params.node.selected)
    console.log(this.params.node.id);
  }
}
