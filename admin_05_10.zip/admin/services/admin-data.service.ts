import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminDataService {
  private dataElementId = new BehaviorSubject('0');
  currentMessage = this.dataElementId.asObservable();
  constructor() { }

  setCurrentElementID(id: string) {
    this.dataElementId.next(id);
  }
  getCurrentElementID() {
    //this.dataElementId.next();
  }
}
//https://angularfirebase.com/lessons/sharing-data-between-angular-components-four-methods/
