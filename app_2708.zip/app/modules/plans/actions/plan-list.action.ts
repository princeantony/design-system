import{ACTION_TYPE} from '../../../shared/constants/app.constants';

import { Action } from '@ngrx/store'

export class PlanListAction implements Action {
    readonly type = ACTION_TYPE.LIST_PLAN;
    
    constructor(public planList: any) {
    }
    
}
export class UserListAction implements Action {
    readonly type = ACTION_TYPE.LIST_USER;
    constructor(public userList: any) {
    }
    
}
//export type Actions = PlanListAction | UserListAction







