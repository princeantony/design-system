import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {ListPlan} from '../../../../shared/mocks/listPlan';
import { Observable } from 'rxjs';
import _ from 'lodash';
@Component({
  selector: 'app-pay-admin-home',
  templateUrl: './pay-admin-home.component.html',
  styleUrls: ['./pay-admin-home.component.scss']
})
export class PayAdminHomeComponent implements OnDestroy {
hidePageTitle = false;
changePlan = true;
 planNumber: string;
 private sub: any;
 planList = ListPlan.data;
 selectedPlan : any;
 planTitle : string;

  constructor(private route: ActivatedRoute) {}

ngOnInit(params) {
  this.sub = this.route.params.subscribe(params => {
       this.planNumber = params['planId']; 
     // this.selectedPlan = _.find(this.planList, ['planNumber', this.planNumber]);
     // this.planTitle = this.selectedPlan.planNumber + "-" + this.selectedPlan.planName;
     
    });
  }
   ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
