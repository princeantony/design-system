import { Injectable } from '@angular/core';
import { HOME_FLAGS } from '../../../shared/mocks/menuItems-mock';
import { MenuItem } from '../../../shared/interfaces/menu-item.interface';
import { HomeMenuItems } from '../../../shared/config/home.config';
import { ApiService } from '../../../shared/services/api.service';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import {Utils} from "../../../shared/utils/pay-admin.utils";
import { IApiResponse } from '../../../shared/interfaces/api-response.interface';
import { Observable } from 'rxjs';
import { MockService } from '../../../shared/services/mock.service';
@Injectable({
  providedIn: 'root'
})
export class HomeService {
  menuItemsFlag : IApiResponse
  menuItemRows: any;
  constructor(
    private apiService: ApiService,
    private utils : Utils,
    private mockService: MockService) {
  }

  getMenuList(planNumber: string) : Observable<any>{
    return this.apiService.get(SERVICE_URL.GET_HOME_URL+planNumber)
  }
  getMockMenuList(planNumber: string) : Observable<any>{
     return this.mockService.getHomeFlags();
  }
  getMenuItemRows(menuItemsFlag : any)
  {
    let menuItemsToBind: MenuItem[] = [];
    HomeMenuItems.forEach(menuItem => {
      if (menuItemsFlag[menuItem.key]) {
        menuItemsToBind.push(menuItem);
      }
    });
    return this.utils.chunkArray(menuItemsToBind, 3)
  }
}
