import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-submit',
  templateUrl: './bank-submit.component.html',
  styleUrls: ['./bank-submit.component.scss']
})
export class BankSubmitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
