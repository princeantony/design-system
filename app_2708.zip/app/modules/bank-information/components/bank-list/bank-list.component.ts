import { Component, OnInit } from '@angular/core';
import {GRID_CONFIG,APP_CONST} from '../../../../shared/constants/app.constants';

import { GridLinkComponent } from '../grid-link/grid-link.component';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
import { BankInfoService } from '../../services/bank-info.service';
import { BankInfo } from '../../../../shared/models/bank-info.model';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-bank-list',
  templateUrl: './bank-list.component.html',
  styleUrls: ['./bank-list.component.scss']
})
export class BankListComponent implements OnInit {
	
	
columnDefs: any;

//rowData:BankInfo;
bankInfo:any;
subDiv: any;
bankInfoData: any;
frameworkComponents: any;
context:any;

sub:any;



  constructor(
    private modalService: ModalService,
    private router : Router,
    private route: ActivatedRoute,
    private bankInfoService: BankInfoService,
    private spinner: NgxSpinnerService) {

   }
   routeTo(link) {
     if(link == "addBank"){
      //this.modalService.open('bankMod');
      this.sub = this.route.params.subscribe(params => {
         
        let planId = params['planId'];
        this.router.navigate(["/bankInfo/editorcreate"]);
       
        });

     }
     else if(link == "edit"){
      this.sub = this.route.params.subscribe(params => {
         
      let planId = params['planId'];
      this.router.navigate(["/bankInfo/editorcreate"]);
     
      });
     }
   
  }
  ngOnInit() {
    this.spinner.show();
    this.getMockDivSub();
    
    
  
   

    

    
    
    this.columnDefs = this.columnDefs = GRID_CONFIG.BANK_INFO.COLUMN_DEFS;
    this.frameworkComponents = {
      linkRenderer: GridLinkComponent
    }
    this.context = { componentParent: this };

  }
  getMockBankInfo() : void{
    this.bankInfoService.getBankInfoMock().subscribe(bankInfo => {
      this.spinner.hide();

      //if(bankInfo.status === APP_CONST.LOGIN_SUCCESS) 
      //{
      this.bankInfoData = bankInfo;
      this.bindBankInfo();
     // this.store.dispatch(new PlanListAction({planList: plans.data }) )
     // }
    })};
    getMockDivSub() : void{
      this.bankInfoService.getSubDivMock().subscribe(subDiv => {

        //if(bankInfo.status === APP_CONST.LOGIN_SUCCESS) 
        //{
        this.subDiv = subDiv;
        this.getMockBankInfo();
       // this.store.dispatch(new PlanListAction({planList: plans.data }) )
       // }
    })};
    bindBankInfo()
      {
        this.bankInfoData.forEach(element => {
      
          _.merge(element, _.find(this.subDiv, ['id', element.divsub]));
          
         });
      }
      
}
