import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { BankInfoService } from '../../services/bank-info.service';

@Component({
  selector: 'app-bank-edit-or-create',
  templateUrl: './bank-edit-or-create.component.html'

})
export class BankEditOrCreateComponent implements OnInit {
sub: any;
formData:any;
  constructor(private route: ActivatedRoute, 
              private router: Router, 
              private fb: FormBuilder, 
              private bankInfoSer: BankInfoService ) { }

  ngOnInit() {
  }

  bankInfoForm = this.fb.group({
    name:[''],
    divLoc: [''],
    bankName: [''],
    bankCity: [''],
    bankState: [''],
    bankZip: [''],
    bankAdd:[''],
    routingNo:[''],
    conRountingNo:[''],
    accNo:[''],
    conAccNo:[''],
    accType:['']
    

  
    /* lastName: [''],
    address: this.fb.group({
      street: [''],
      city: [''],
      state: [''],
      zip: ['']
    }), */
  });

  

  onSubmit(){
    console.log(this.bankInfoForm.value);
    this.formData = this.bankInfoForm.value;
    this.bankInfoSer.setBankInfo(this.formData);
    this.sub = this.route.params.subscribe(params => {
         
      let planId = params['planId'];
      this.router.navigate(["/confirm/"+ planId]);
      
     
      });
      
  }

}
