import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-none',
  templateUrl: './bank-none.component.html',
  styleUrls: ['./bank-none.component.scss']
})
export class BankNoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
