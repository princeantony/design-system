import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankNoneComponent } from './bank-none.component';

describe('BankNoneComponent', () => {
  let component: BankNoneComponent;
  let fixture: ComponentFixture<BankNoneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankNoneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankNoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
