import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankAvailableComponent } from './bank-available.component';

describe('BankAvailableComponent', () => {
  let component: BankAvailableComponent;
  let fixture: ComponentFixture<BankAvailableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankAvailableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankAvailableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
