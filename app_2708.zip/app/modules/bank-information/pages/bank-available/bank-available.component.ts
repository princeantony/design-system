import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-bank-available',
  templateUrl: './bank-available.component.html',
  styleUrls: ['./bank-available.component.scss']
})
export class BankAvailableComponent implements OnDestroy {
	hidePageTitle = false;
  changePlan = false;
 planNumber: string;
 private sub: any;

 selectedPlan : any;
 planTitle : string;
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit(params) {
  //this.pageTitle = "Bank Information";
  this.hidePageTitle = false;

  this.sub = this.route.params.subscribe(params => {
       this.planNumber = params['planId']; 
     
      this.planTitle = this.planNumber + "-" + "Bank Information";
     
    });
    console.log("---------this.planTitle", this.planTitle);
  }
  navToBack(){
    this.router.navigate(["/home/" + this.planNumber ]);

  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }


}
