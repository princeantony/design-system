import { Component, OnInit } from '@angular/core';
import { BankInfoService } from '../../services/bank-info.service';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub : any;
  
  constructor(private bankInfoService: BankInfoService, 
              private route: ActivatedRoute, 
              private router : Router,
              private modalService: ModalService) { }

  ngOnInit() {
   this.bankInfo =  this.bankInfoService.getBankInfo();
   console.log("-----------this.bankInfo", this.bankInfoService.getBankInfo());
  }

  onSubmit(){

    this.modalService.open('bankSubmit');
    //this.navigateTo("");
    
    
    

  }

  onEdit(){
    this.navigateTo("bankInfo/edit")

  }
  navigateTo(link){
   

    this.sub = this.route.params.subscribe(params => {
         
      let planId = params['planId'];
      this.router.navigate(["/home/" + planId + "/"+link]);
      
     
      });

  }


  

}
