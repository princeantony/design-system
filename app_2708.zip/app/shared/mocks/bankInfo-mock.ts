
import {BankInfo} from '../models/bank-info.model';

export const bankInfo = [
    {
        "addressId": "0000000000001",
        "planNumber": "559958",
        "divsub": "0001",
        "bankName": "",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "",
        "address1": "Flying BANK Aha",
        "address2": "",
        "city": "Vatican",
        "state": "FL",
        "zipcode": "",
        "valid": true
    },
    {
        "addressId": "0000000001001",
        "divsub": "1001",
        "valid": false
    },
    {
        "addressId": "0000000001002",
        "divsub": "1002",
        "valid": false
    },
    {
        "addressId": "0000000001003",
        "divsub": "1003",
        "valid": false
    },
    {
        "addressId": "0000000001004",
        "divsub": "1004",
        "valid": false
    },
    {
        "addressId": "0000000001005",
        "divsub": "1005",
        "valid": false
    },
    {
        "addressId": "0000000001006",
        "divsub": "1006",
        "valid": false
    },
    {
        "addressId": "0000000001007",
        "divsub": "1007",
        "valid": false
    },
    {
        "addressId": "0000000001008",
        "divsub": "1008",
        "valid": false
    },
    {
        "addressId": "0000000001009",
        "divsub": "1009",
        "valid": false
    },
    {
        "addressId": "0000000001010",
        "divsub": "1010",
        "valid": false
    },
    {
        "addressId": "0000000001011",
        "planNumber": "559958",
        "divsub": "1011",
        "bankName": "Clearcase Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001012",
        "planNumber": "559958",
        "divsub": "1012",
        "bankName": "Non3 Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001013",
        "planNumber": "559958",
        "divsub": "1013",
        "bankName": "Non3 Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001014",
        "divsub": "1014",
        "valid": false
    },
    {
        "addressId": "0000000001015",
        "planNumber": "559958",
        "divsub": "1015",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001016",
        "planNumber": "559958",
        "divsub": "1016",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001017",
        "planNumber": "559958",
        "divsub": "1017",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001018",
        "planNumber": "559958",
        "divsub": "1018",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001019",
        "planNumber": "559958",
        "divsub": "1019",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001020",
        "planNumber": "559958",
        "divsub": "1020",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001021",
        "divsub": "1021",
        "valid": false
    },
    {
        "addressId": "0000000001022",
        "divsub": "1022",
        "valid": false
    },
    {
        "addressId": "0000000001023",
        "divsub": "1023",
        "valid": false
    },
    {
        "addressId": "0000000001024",
        "divsub": "1024",
        "valid": false
    },
    {
        "addressId": "0000000009999",
        "divsub": "9999",
        "valid": false
    },
    {
        "addressId": "000000000EASE",
        "divsub": "EASE",
        "valid": false
    }

]

export const divSub = [{"id":"0001","text":"MERUELO ENTERPRISES","name":"","phone":""},
{"id":"1001","text":"LA PIZZA LOCA, INC.","name":"","phone":""},
{"id":"1002","text":"LPL DISTRIBUTION, INC.","name":"","phone":""},
{"id":"1003","text":"MERUELO ENTERPRISES","name":"","phone":""},
{"id":"1004","text":"MERONA ENTERPRISES, INC.","name":"","phone":""},
{"id":"1005","text":"FUJISAN FRANCHISING CORP","name":"","phone":""},
{"id":"1006","text":"CANTAMAR PROPERTY MNGMT","name":"","phone":""},
{"id":"1007","text":"ALISE AVIATION, LLC","name":"","phone":""},
{"id":"1008","text":"MERUELO MEDIA HLDG DBA KWHY-22","name":"","phone":""},
{"id":"1009","text":"PACIFIC WHEY HOLDING, LLC","name":"","phone":""},{"id":"1010","text":"HERMAN WEISSKER, INC.","name":"","phone":""},{"id":"1011","text":"TIDWELL EXCAVATING ACQUISITION","name":"","phone":""},{"id":"1012","text":"DOTY BROS EQUIPMENT CO","name":"","phone":""},{"id":"1013","text":"NEAL ELECTRIC","name":"","phone":""},{"id":"1014","text":"SELECT ELECTRIC INC.","name":"","phone":""},{"id":"1015","text":"FUJI FOODS PRODUCTS, INC.","name":"","phone":""},{"id":"1016","text":"HG STAFFING, LLC","name":"","phone":""},{"id":"1017","text":"MEI-GSR HOLDINGS","name":"","phone":""},{"id":"1018","text":"MERUELO GROUP LLC","name":"","phone":""},{"id":"1019","text":"MERUELO RADIO HOLDINGS","name":"","phone":""},{"id":"1020","text":"MERUELLO MEDIA LLC","name":"","phone":""},{"id":"1021","text":"MERUELO REAL PROPERTY CORP","name":"","phone":""},{"id":"1022","text":"ONE CALL CONSTRUCTION","name":"","phone":""},{"id":"1023","text":"SOCAL RESTAURANT MANAGEMENT LLC","name":"","phone":""},{"id":"1024","text":"KPWR RADIO","name":"","phone":""},{"id":"9999","text":"Forfeiture Account","name":"","phone":""},{"id":"EASE","text":"EASE Account","name":"","phone":""}]