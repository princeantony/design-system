export const MESSAGES=
{
    VOYA_WORKING_TIME: 'The voya office timing message',
    VOYA_APP_NAME : 'Payroll/Administration',
    SERVICE_ERROR: 'There is an error occurred while calling the service!',
    SERVICE_SUCCESS: 'Service call succeeded!',
    SERVICE_START: 'Please wait... Service call in progress!'
};

export const GRID_CONFIG = {
    LIST_PLAN: {
      GRID_SIZE : {width: 555, height: 800},
      COLUMN_DEFS : [
      { headerName: "Plan Number", field: "planNumber", width: 200 },
      { headerName: "Plan Name", field: "planName", width: 350 }
    ]},
    LIST_USRS: {
        GRID_SIZE : {width: 555, height: 800},
        COLUMN_DEFS : [
        { headerName: "ID", field: "id", width: 200 },
        { headerName: "Name", field: "name", width: 350 },
        {headerName: "User Name", field: "username", width: 350 }
      ]},

      BANK_INFO: {
      GRID_SIZE : {width: 880, height: 800},
      COLUMN_DEFS : [
      { headerName: "Division/Location Number", field: "divsub", width: 200 },
      { headerName: "Division/Location Name", field: "text", width: 300 },
      { headerName: "Bank Name", field: "bankName", width: 150, suppressFilter: true },
      { headerName: "Account Type", field: "accountType", width: 125, suppressFilter: true },
      { headerName: "Actions", field: "actions", cellRenderer: "linkRenderer", width: 100, suppressFilter: true }
      

    ]}


  };
export const ACTION_TYPE =
{
    LIST_PLAN : 'LIST_PLAN',
    LIST_USER : 'LIST_USER',
    HOME_FLAG: 'HOME_FLAG'
}
export const APP_CONST = 
{
    APP_CONTEXT: '../',
    LOGIN_SUCCESS: 'SUCCESS'

}


