export interface IBankInfo{
    
}