import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import {ICellRendererAngularComp} from 'ag-grid-angular';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import _ from 'lodash';
@Component({
  selector: 'app-admin-grid-checkbox',
  templateUrl: './admin-grid-checkbox.component.html'

})
export class AdminGridCheckboxComponent  implements ICellRendererAngularComp {
  @Output() Click = new EventEmitter<boolean>();
  constructor() { }
  value: boolean;
  controlClass: string;
  controlName: string;
  isCatchUp = false;
  parent: string;
    agInit(params: any): void {
        this.value = params.value;
        this.controlClass = 'small';
        this.parent = (_.has(params.data, 'deferralCatchUp') ? 'money' : 'investment');
        this.controlName = this.parent + '_' + params.colDef.field + '_' + params.rowIndex;
        if(params.colDef.field === "contributionCatchUp" || params.colDef.field === "deferralCatchUp")
        {
        this.isCatchUp = !PayAdminGlobalState.isCatchUp;
        }

    }
    onValueChange(event: any) {
      const id = _.split(event.target.id, '_');
      const gridName = id[0];
      const name = id[1];
      const index = id[2];
      const item = {};
      item[name] = event.target.checked;
      if (gridName === 'money') {
      Object.assign(PayAdminGlobalState.moneySource[index], item);
      } else {
        Object.assign(PayAdminGlobalState.investments[index], item);
      }
    }
    refresh(): boolean {
        return false;
    }

}
