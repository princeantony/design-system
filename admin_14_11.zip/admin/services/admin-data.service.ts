import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class AdminDataService {
  static dataElementId: string;
  static dataElementNewOrder: string;
  static optionCode: string;
  static dataElements: any[];
  static dataElement: any;
  static dataElementOptions: any[];
  static dataElementOption: any;
  isValidNewOrder(newOrder): boolean {
    return true;
  }
}
