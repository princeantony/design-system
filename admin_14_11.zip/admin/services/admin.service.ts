import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';
import { SERVICE_URL } from 'src/app/shared/constants/service.constants';

import { AdminMenuItems } from '../../../shared/config/admin.config';
import { IMenuItem } from '../../../shared/interfaces/menu-item.interface';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { Utils } from '../../../shared/utils/pay-admin.utils';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  constructor(private mockService: MockService, private utils: Utils, private apiService: ApiService) {}

  getMockMenuList(planNumber: string): Observable<any> {
    return this.mockService.getAdminFlags();
  }
  getMenuItemRows(menuItemsFlag: any) {
    const menuItemsToBind: IMenuItem[] = [];
    AdminMenuItems.forEach(menuItem => {
      if (menuItemsFlag[menuItem.key]) {
        menuItemsToBind.push(menuItem);
      }
    });
    return this.utils.chunkArray(menuItemsToBind, 3);
  }

  getMockTerminationList(): Observable<any> {
    return this.mockService.getTerminationReason();
  }

  getDEList(planNumber: string): Observable<any> {
    return (ENV.TEST)
    ? this.mockService.getDataElements()
    : this.apiService.get(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber);

  }
  getDEOptions(planNumber: string, dataelementID: string )
  {
    return (ENV.TEST)
    ? this.mockService.getDEOptions()
    : this.apiService.get(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID + '/values');
  }
  updateOrderNumber(planNumber: string, dataelementID: string, newOrder: number )
  {
    const order = {dataElement: dataelementID, ovrdDisplayOrder: newOrder};
    return (ENV.TEST)
    ? this.mockService.successMock()
    : this.apiService.put(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/overrideDisplayOrder/', order);
  }
  deleteDE(planNumber: string, dataelementID: string )
  {
    console.log("dataelementID", dataelementID)
    return (ENV.TEST)
    ? this.mockService.successMock()
    : this.apiService.delete(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID  );
  }
  updateDE(planNumber: string, updatedDE: any)
  {
    return (ENV.TEST)
    ? this.mockService.successMock()
    : this.apiService.post(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/',updatedDE  );
  }
  saveDE(planNumber: string, newdDE: any, selectedDEId: string,  isCreate: boolean)
  {
    if (ENV.TEST) {
     return this.mockService.successMock()
    } else {
      return (isCreate)
      ? this.apiService.post(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + selectedDEId, newdDE  )
      : this.apiService.put(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + selectedDEId, newdDE    );
    }

  }
  saveDEOption(planNumber: string, newdDEOption: any, dataelementID: string,  isCreate: boolean)
  {
    const obj = {'code': newdDEOption.valueCode, 'text': newdDEOption.value}
    if (ENV.TEST) {
     return this.mockService.successMock()
    } else {
      return (isCreate)
      ? this.apiService.post(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID + '/value' ,obj  )
      : this.apiService.put(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID + '/value' ,obj  );
    }

  }
}
