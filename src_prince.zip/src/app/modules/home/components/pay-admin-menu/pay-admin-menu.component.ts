import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-admin-menu',
  templateUrl: './pay-admin-menu.component.html',
  styleUrls: ['./pay-admin-menu.component.css']
})
export class PayAdminMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
