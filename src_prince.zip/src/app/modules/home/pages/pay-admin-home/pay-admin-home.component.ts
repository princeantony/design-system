import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-admin-home',
  templateUrl: './pay-admin-home.component.html',
  styleUrls: ['./pay-admin-home.component.css']
})
export class PayAdminHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
