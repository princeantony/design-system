import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AgGridModule} from 'ag-grid-angular';
import { AppComponent } from './app.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { ListPlansComponent } from './modules/plans/components/list-plans/list-plans.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';
//import { HeaderComponent } from './shared/components/layout/header/header.component';
import { VoyaTextboxComponent } from './shared/components/form/voya-textbox/voya-textbox.component';
import { VoyaLabelComponent } from './shared/components/form/voya-label/voya-label.component';
import { VoyaButtonComponent } from './shared/components/form/voya-button/voya-button.component';
import { GridComponent } from './shared/components/form/grid/grid.component';
import { PayAdminHomeComponent } from './modules/home/components/payadmin-home/payadmin-home.component';
import { PayAdminRoutingModule, PayAdminRoutingComponents } from '../app/shared/modules/pay-admin-routing.module';

import { HeaderComponent } from '../app/shared/components/layout/header/header.component';
import { HeadingComponent } from '../app/shared/components/heading/heading.component';
import { MenuComponent } from '../app/shared/components/menu/menu.component';
import { TimeInfoComponent } from './shared/components/form/time-info/time-info.component';
import { PageTitleComponent } from './shared/components/layout/page-title/page-title.component';
import { PayAdminMenuComponent } from './modules/home/components/pay-admin-menu/pay-admin-menu.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    ListPlansComponent,
    PlanSelectionComponent,
    HeaderComponent,
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent,
    GridComponent,
    PayAdminHomeComponent,
    PayAdminRoutingComponents,
    HeadingComponent,
    MenuComponent,
    TimeInfoComponent,
    PageTitleComponent,
    PayAdminMenuComponent
    
  ],
  imports: [
    BrowserModule,
    PayAdminRoutingModule,
    AgGridModule.withComponents(
      [
        AppComponent, GridComponent,PlanSelectionComponent,ListPlansComponent
          
      ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
