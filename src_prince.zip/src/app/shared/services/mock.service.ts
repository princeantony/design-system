import {ListPlan} from '../mocks/listPlan';
export class MockService {
    getListPlan(): any {
      return ListPlan;
    }
  }