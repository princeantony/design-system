import { Component, OnInit } from "@angular/core";
import { MenuItem } from "../../interfaces/menu-item.interface";
import { MenuItems } from "../../mocks/menuItems-mock";
import Utils from "../../utilites/utils";

@Component({
  selector: "app-menu",
  templateUrl: "./menu.component.html",
  styleUrls: ["./menu.component.css"],
  providers: [Utils]
})
export class MenuComponent implements OnInit {
  menuItems: MenuItem[];
  menuItemRows: Array<MenuItem[]>;

  constructor(private utils: Utils) {}

  ngOnInit() {
    this.menuItems = MenuItems;
    this.menuItemRows = this.utils.chunkArray(this.menuItems, 3);
    console.log(this.menuItemRows);
  }
}
