import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heading',
  templateUrl: './heading.component.html',
  styleUrls: ['./heading.component.css']
})
export class HeadingComponent implements OnInit {
  appTitle: string;
  planTitle: string;
  pageTitle: string;
  constructor() { 
    this.appTitle = 'Payroll/Administration';
    this.planTitle = '559985 - ING September 2010 Release';
    this.pageTitle = 'Bank Information';
  }

  ngOnInit() {
  }

}
