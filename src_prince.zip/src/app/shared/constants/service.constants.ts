export const SERVICE_URL=
{
    GET_EXT_EMPLOYEES_URL: 'https://jsonplaceholder.typicode.com/users', // to test
    GET_LISTPLAN_URL: 'listPlan'
};