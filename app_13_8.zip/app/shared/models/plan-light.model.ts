import {IPlanLight} from '../interfaces/plan-light.interface';
export class PlanLight {
    Plans : IPlanLight[];
  }
  