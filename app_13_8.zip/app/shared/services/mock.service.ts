import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
import {ListPlan} from '../mocks/listPlan';

import {PlanLight} from '../models/plan-light.model';
@Injectable({
  providedIn: 'root',
})

export class MockService {
constructor() { }
/*
getListPlans(): Observable<PlanLight[]> {
console.log("in mock svc")
    return of(ListPlan);
  }
*/
  }