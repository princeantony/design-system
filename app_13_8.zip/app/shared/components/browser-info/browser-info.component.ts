import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../services/modal.service';

@Component({
  selector: 'app-browser-info',
  templateUrl: './browser-info.component.html',
  styleUrls: ['./browser-info.component.css']
})
export class BrowserInfoComponent implements OnInit {

  constructor(private modalService: ModalService) { }


  ngOnInit() {
  }
  closeModal(id: string) {
    this.modalService.close(id);
}
}
