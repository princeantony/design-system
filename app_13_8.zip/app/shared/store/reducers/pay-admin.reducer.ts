import { ActionReducer, Action } from '@ngrx/store';
import{ACTION_TYPE} from '../../constants/app.constants';

export function PayAdminReducer(state: null, action) {
	 switch (action.type) {
		case ACTION_TYPE.LIST_PLAN:
		console.log("in reducer",action.planList)
            return Object.assign({}, state, {PlanList: action.planList});

		default:
			return state;
	}
}