import { ActionReducer, Action } from '@ngrx/store';
import{ACTION_TYPE} from '../../constants/app.constants';

export function UserReducer(state: null, action) {
	 switch (action.type) {
		case ACTION_TYPE.USER_LIST:
		console.log("in user reducer",action.planList)
            return Object.assign({}, state, {UserList: action.planList});

		default:
			return state;
	}
}