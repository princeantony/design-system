export const SERVICE_URL=
{
    APP_URL:"https://jsonplaceholder.typicode.com/",
    GET_EXT_EMPLOYEES_URL: 'users', // to test
    GET_LISTPLAN_URL: 'listPlan'
};