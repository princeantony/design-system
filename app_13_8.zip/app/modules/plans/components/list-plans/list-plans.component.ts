import { Store } from '@ngrx/store';
import { Component, OnInit} from '@angular/core';
import { Observable } from 'rxjs';
import {COLUMN_DEFS} from '../../../../shared/constants/app.constants';
import {PlanListAction} from '../../../plans/actions/plan-list.action';
import {MockService} from '../../../../shared/services/mock.service';
import {ListPlan} from '../../../../shared/mocks/listPlan';
import { PlanLight } from '../../../../shared/models/plan-light.model';
import { ApiService } from '../../../../shared/services/api.service';
import{SERVICE_URL} from '../../../../shared/constants/service.constants';
import { AppState } from '../../../../shared/store/state/app.state';
import { IUser } from '../../../../shared/interfaces/user.interface';

@Component({
  selector: 'app-list-plans',
  templateUrl: './list-plans.component.html',
  styleUrls: ['./list-plans.component.css']
})

export class ListPlansComponent implements OnInit {
//planLight : any = null
//users;
rowData;
users: Observable<IUser[]>;  //
constructor(private store: Store<AppState>, private apiService: ApiService) {
this.getUsers();
  //constructor(private store: Store<any>, private mockService: MockService){
  this.users = store.select('UserList');

console.log("users", this.users)

  if(this.users)
    {
      //this.rowData = this.users
      //this.getUsers();
    // this.planLight = ListPlan;
    }
   // this.rowData=this.planLight;
	}
  getPlans() {
    //this.users = this.planListAction.getPlans()

  }
  getUsers(): void {
    console.log("in getuser")
    this.apiService.get(SERVICE_URL.GET_EXT_EMPLOYEES_URL)
      .subscribe(users => {

        this.rowData = users;
        this.store.dispatch(new PlanListAction({planList: users }) )
     
      });
  }
  columnDefs = COLUMN_DEFS.LIST_USERS;
  ngOnInit() {
  }

}
