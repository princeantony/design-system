import{ACTION_TYPE} from '../../../shared/constants/app.constants';
import {ListPlan} from '../../../shared/mocks/listPlan';

import {MockService} from '../../../shared/services/mock.service';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { ApiService } from 'src/app/shared/services/api.service';
import { Injectable } from '@angular/core'
import { Action } from '@ngrx/store'

export class PlanListAction implements Action {
    readonly type = ACTION_TYPE.LIST_PLAN;
    //public planList: any;
    constructor(public planList: any) {
        console.log("in action", planList)
        //this.getPlans();
    }
    getPlans(){
        //this.planList = ApiService.get(SERVICE_URL.GET_EXT_EMPLOYEES_URL)
    }

}
export type Actions = PlanListAction







