import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppComponent } from './app.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { SpinnerComponent } from './shared/components/layout/spinner/spinner.component';
import { PlanListComponent } from './modules/plans/components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';


import {StoreDevtoolsModule} from '@ngrx/store-devtools';

import { PayAdminRoutingModule, PayAdminRoutingComponents } from './shared/modules/pay-admin-routing.module';
import {PayAdminHomeComponent} from './modules/home/pages/pay-admin-home/pay-admin-home.component'; 
import { HeaderComponent } from './shared/components/layout/header/header.component';

import { TimeInfoComponent } from './shared/components/time-info/time-info.component';
import { PageTitleComponent } from './shared/components/layout/page-title/page-title.component';
import { TitleMessageComponent } from './shared/components/layout/title-message/title-message.component';
import { PayAdminMenuComponent } from './modules/home/components/pay-admin-menu/pay-admin-menu.component';
import { ModalService } from './shared/services/modal.service';
import { BrowserInfoComponent } from './shared/components/browser-info/browser-info.component';


import { BankAvailableComponent } from './modules/bank-information/pages/bank-available/bank-available.component';
import { BankListComponent } from './modules/bank-information/components/bank-list/bank-list.component';

import {ApiService} from './shared/services/api.service';


import { GridLinkComponent } from './modules/bank-information/components/grid-link/grid-link.component';
import { BankModalComponent } from './modules/bank-information/components/bank-modal/bank-modal.component';
import { ConfirmationComponent } from './modules/bank-information/pages/confirmation/confirmation.component';
import {DisclosureComponent } from './modules/bank-information/components/disclosure/disclosure.component';
import { BankSubmitComponent } from './modules/bank-information/components/bank-submit/bank-submit.component';
import { HelpComponent } from './modules/bank-information/components/help/help.component';
import { CreateComponent } from './modules/bank-information/pages/create/create.component';


//Participant Module
import { ParticipantAddComponent } from './modules/participants/pages/participant-add/participant-add.component';
import { ParticipantAddOptionalComponent } from './modules/participants/pages/participant-add-optional/participant-add-optional.component';
import { ParticipantContributionElectionComponent } from "./modules/participants/components/participant-contribution-election/participant-contribution-election.component";
import { ParticipantAddInvestmentElectionComponent } from './modules/participants/pages/participant-add-investment-election/participant-add-investment-election.component';
import { ParticipantAddContributionElectionComponent } from './modules/participants/pages/participant-add-contribution-election/participant-add-contribution-election.component';
import { ParticipantUpdateContributionElectionComponent } from './modules/participants/pages/participant-update-contribution-election/participant-update-contribution-election.component';
import { ParticipantUpdateInvestmentElectionComponent } from './modules/participants/pages/participant-update-investment-election/participant-update-investment-election.component';
import { ParticipantUpdateOptionalComponent } from './modules/participants/pages/participant-update-optional/participant-update-optional.component';
import { ParticipantUpdateComponent } from './modules/participants/pages/participant-update/participant-update.component';
import { ParticipantRequiredDataComponent } from './modules/participants/components/participant-required-data/participant-required-data.component';
import { ParticipantOptionalDataComponent } from './modules/participants/components/participant-optional-data/participant-optional-data.component';
import { ParticipantInvestmentElectionComponent } from './modules/participants/components/participant-investment-election/participant-investment-election.component';
import { MyCustomInputComponent } from './shared/components/form/my-custom-input/my-custom-input.component';


//Form Components
import { VoyaTextboxComponent } from './shared/components/form/voya-textbox/voya-textbox.component';
import { VoyaSelectComponent } from './shared/components/form/voya-select/voya-select.component';
import { VoyaEmailComponent } from './shared/components/form/voya-email/voya-email.component';
import { VoyaZipComponent } from './shared/components/form/voya-zip/voya-zip.component';
import { VoyaSsnComponent } from './shared/components/form/voya-ssn/voya-ssn.component';
import { VoyaRoutingNumberComponent } from './shared/components/form/voya-routing-number/voya-routing-number.component';

import { VoyaLabelComponent } from './shared/components/form/voya-label/voya-label.component';
import { VoyaButtonComponent } from './shared/components/form/voya-button/voya-button.component';
import { GridComponent } from './shared/components/form/voya-grid/grid.component';
import { VoyaLinkComponent } from './shared/components/form/voya-link/voya-link.component';
import { VoyaCounterComponent } from './shared/components/form/voya-input/voya-counter/voya-counter.component';
import { VoyaNumberComponent } from './shared/components/form/voya-input/voya-number/voya-number.component';

import { VoyaPagingComponent } from './shared/components/form/voya-paging/voya-paging.component';

//Directives
import { ModalComponent } from './shared/directives/modal.component';
import { VoyaCurrencyDirective } from './shared/directives/voya-currency.directive';
import { SSNDirective } from './shared/directives/voya-ssn.directive';
import { NumberDirective } from './shared/directives/voya-number.directive';

// Pipes
import { VoyaCurrencyPipe } from './shared/pipes/voya-currency.pipe';
import { VoyaSSNPipe } from './shared/pipes/voya-SSN.pipe';

//Utils
import { Utils } from './shared/utils/pay-admin.utils';

// vendor components
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxSpinnerModule } from 'ngx-spinner';
import {AgGridModule} from 'ag-grid-angular';
import { environment } from '../environments/environment';
import { ContributionInputGroupComponent } from './modules/participants/components/participant-contribution-election/contribution-input-group/contribution-input-group.component';

// Admin
import { AdminMenuComponent } from './modules/admin/components/admin-menu/admin-menu.component';
import { AdminHomeComponent } from './modules/admin/pages/admin-home/admin-home.component';
import { AdminPageSetupComponent } from './modules/admin/components/admin-page-setup/admin-page-setup.component';
import { AdminPageSecurityComponent } from './modules/admin/pages/admin-page-security/admin-page-security.component';
import { VoyaCheckboxComponent } from './shared/components/form/voya-checkbox/voya-checkbox.component';
import { VoyaRadioComponent } from './shared/components/form/voya-radio/voya-radio.component';
import { VoyaRadioNewComponent } from './shared/components/form/voya-radio-new/voya-radio-new.component';
import { AdminPlanSetupComponent } from './modules/admin/pages/admin-plan-setup/admin-plan-setup.component';
import { AdminGridCheckboxComponent } from './modules/admin/components/admin-grid-checkbox/admin-grid-checkbox.component';
import { AdminPlanSetupGridComponent } from './modules/admin/components/admin-plan-setup-grid/admin-plan-setup-grid.component';
import { AdminGridTextboxComponent } from './modules/admin/components/admin-grid-textbox/admin-grid-textbox.component';
import { VoyaDateComponent } from './shared/components/form/voya-date/voya-date.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    PlanListComponent,
    PlanSelectionComponent,
    HeaderComponent,
    GridComponent,
    PayAdminHomeComponent,
    PayAdminRoutingComponents,
    TimeInfoComponent,
    PageTitleComponent,
    PayAdminMenuComponent,
    VoyaLinkComponent,
    BrowserInfoComponent,
    BankAvailableComponent,
    BankListComponent,
    BankSubmitComponent,
    ConfirmationComponent,
    CreateComponent,
    VoyaPagingComponent,
    GridLinkComponent,
    BankModalComponent,
    DisclosureComponent,
    TitleMessageComponent,
    HelpComponent,
    SpinnerComponent,        
    
    ParticipantAddComponent,
    ParticipantAddOptionalComponent,
    ParticipantContributionElectionComponent,
    ParticipantAddInvestmentElectionComponent,
    ParticipantAddContributionElectionComponent,
    ParticipantUpdateContributionElectionComponent,
    ParticipantUpdateInvestmentElectionComponent,
    ParticipantUpdateOptionalComponent,
    ParticipantUpdateComponent,
    ParticipantRequiredDataComponent,
    ParticipantOptionalDataComponent,
    ParticipantInvestmentElectionComponent,
    MyCustomInputComponent,

    ModalComponent,
    VoyaCurrencyDirective,
    SSNDirective,
    NumberDirective,

    VoyaCurrencyPipe,
    VoyaSSNPipe,
    
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent,
    GridComponent,
    VoyaLinkComponent,
    //InputTextComponent,
    VoyaEmailComponent,
    VoyaZipComponent,
    VoyaCounterComponent,
    VoyaNumberComponent,
    VoyaSelectComponent,
    VoyaPagingComponent,
    VoyaSsnComponent ,
    VoyaRoutingNumberComponent,
    ContributionInputGroupComponent,
    AdminMenuComponent,
    AdminHomeComponent,
    AdminPageSetupComponent,
    AdminPageSecurityComponent,
    VoyaCheckboxComponent,
    VoyaRadioComponent,
    AdminPlanSetupComponent,
AdminGridCheckboxComponent,
AdminPlanSetupGridComponent, 
AdminGridTextboxComponent, 
VoyaDateComponent ,
VoyaRadioNewComponent

  ],
  imports: [
    BrowserModule,
    PayAdminRoutingModule,
    NgxSpinnerModule,
    HttpClientModule,
    NgSelectModule,
    FormsModule,
     ReactiveFormsModule,
     NgbModule,
    AgGridModule.withComponents([GridLinkComponent,AdminGridCheckboxComponent,AdminGridTextboxComponent]),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: environment.production })
  ],
  providers: [ModalService, ApiService, Utils],
  bootstrap: [AppComponent ]
})
export class AppModule { }
