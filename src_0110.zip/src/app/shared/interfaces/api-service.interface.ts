import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
export interface IApiService
{
    get(apiMethod: string): Observable<any>;
    getByKey(apiMethod: string, key: string, value: string):  Observable<any>;
    getByObject(apiMethod: string, paramsObj: any): Observable<any>;
    post (apiMethod: string, inputData: any): Observable<any> ;
     put (apiMethod: string, inputData: any): Observable<any> ;
}