export const StateListMock = {
  status: "SUCCESS",
  data: [
    {
      value: "AB",
      label: "ALBERTA"
    },
    {
      value: "AK",
      label: "ALASKA"
    },
    {
      value: "AL",
      label: "ALABAMA"
    },
    {
      value: "AR",
      label: "ARKANSAS"
    },
    {
      value: "AS",
      label: "AMERICAN SAMOA"
    },
    {
      value: "AZ",
      label: "ARIZONA"
    }
  ]
};

export const CountryListMock = {
  status: "SUCCESS",
  data: [
    {
      value: "AFG",
      label: "AFGHANISTAN"
    },
    {
      value: "ALB",
      label: "ALBANIA"
    },
    {
      value: "DZA",
      label: "ALGERIA"
    }
  ]
};
