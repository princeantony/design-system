export class BankInfo{
        addressId: string;
        planNumber: string;
        divsub: string;
        bankName: string;
        acctNumber: string;
        abaNumber: string;
        accountType: string;
        address1:string;
        address2:string;
        city: string;
        state: string;
        zipcode: string;
        valid: boolean;
        divsubName: string;
}