import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaNumberComponent } from './voya-number.component';

describe('VoyaNumberComponent', () => {
  let component: VoyaNumberComponent;
  let fixture: ComponentFixture<VoyaNumberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaNumberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
