import { Component, OnInit, Input, ElementRef, forwardRef, Renderer } from '@angular/core';
import { Validator, Validators, NG_VALUE_ACCESSOR, ControlValueAccessor} from '@angular/forms';



export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = /*@ts2dart_const*/ {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => MyCustomInputComponent),
  multi: true
};

const noop = () => {};

@Component({
  selector: 'my-custom-input',
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR],
  templateUrl: "./my-custom-input.component.html"
})


export class MyCustomInputComponent implements ControlValueAccessor {
  @Input() control;


  // The internal data model
  private _value: any = '';

  //Placeholders for the callbacks
  private _onTouchedCallback: (_:any) => void = noop;
  
  private _onChangeCallback: (_:any) => void = noop;

  //get accessor
  get value(): any { return this._value; };

  //set accessor including call the onchange callback
  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }
  
  //Set touched on blur
  onTouched(){
    this._onTouchedCallback(null);
  }

  //From ControlValueAccessor interface
  writeValue(value: any) {
    this._value = value;
  }

  //From ControlValueAccessor interface
  registerOnChange(fn: any) {
    this._onChangeCallback = fn;
  }

  //From ControlValueAccessor interface
  registerOnTouched(fn: any) {
    this._onTouchedCallback = fn;
  }

}