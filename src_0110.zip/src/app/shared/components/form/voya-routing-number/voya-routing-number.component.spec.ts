import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaRoutingNumberComponent } from './voya-routing-number.component';

describe('VoyaRoutingNumberComponent', () => {
  let component: VoyaRoutingNumberComponent;
  let fixture: ComponentFixture<VoyaRoutingNumberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaRoutingNumberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaRoutingNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
