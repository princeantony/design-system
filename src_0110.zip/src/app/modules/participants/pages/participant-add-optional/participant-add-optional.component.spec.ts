import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantAddOptionalComponent } from './participant-add-optional.component';

describe('ParticipantAddOptionalComponent', () => {
  let component: ParticipantAddOptionalComponent;
  let fixture: ComponentFixture<ParticipantAddOptionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantAddOptionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantAddOptionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
