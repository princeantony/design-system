import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-update-optional',
  templateUrl: './participant-update-optional.component.html',
  styleUrls: ['./participant-update-optional.component.scss']
})
export class ParticipantUpdateOptionalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
