import { Component, OnInit } from "@angular/core";
import { ParticipantOptionalFields } from "./participant-optional-fields";
import { ParticipantOptionalFieldModelsService } from "./participant-optional-data-fields.service";
import { FormGroup } from "@angular/forms";

import { ParticipantsService } from "../../service/participants.service";
import { ParticipantOptionalFieldModel } from "../../model/participant.model";
import { ParticipantOptionalFieldTextBox } from "./participant-optional-field-textbox";
import { ParticipantOptionalFieldDropDown } from "./participant-optional-field-dropdown";

@Component({
  selector: "participant-optional-data",
  templateUrl: "./participant-optional-data.component.html",
  styleUrls: ["./participant-optional-data.component.scss"]
})
export class ParticipantOptionalDataComponent implements OnInit {
  optionalFields: ParticipantOptionalFields<any>[] = [];
  participantOptionalDataField: ParticipantOptionalFieldModel[];
  participantOptionalDataForm: FormGroup;

  constructor(private participantsService: ParticipantsService) {}

  ngOnInit() {
    this.getOptionalDataFields();
    this.participantOptionalDataForm = this.participantsService.toFormGroup(
      this.optionalFields
    );
  }

  getOptionalDataFields() {
    this.participantsService.getOptionalDataFieldsMock().subscribe(result => {
      if (result.status === "SUCCESS") {
        this.participantOptionalDataField = result.data;
      }
    });
    this.participantOptionalDataField.forEach(
      (field: ParticipantOptionalFieldModel) => {
        if (field.controlType === "text") {
          this.optionalFields.push(
            new ParticipantOptionalFieldTextBox({
              key: field.label.split(" ").join("-"),
              label: field.label,
              required: field.required,
              value: field.value,
              type: "text"
            })
          );
        }
        if (field.controlType === "dropdown") {
          this.optionalFields.push(
            new ParticipantOptionalFieldDropDown({
              key: field.label.split(" ").join("-"),
              label: field.label,
              required: field.required,
              value: field.value,
              options: field.option
            })
          );
        }
      }
    );
  }

  onSubmit() {
    console.log(this.participantOptionalDataForm.value);
  }

  onDropDownChange() {
  }
}
