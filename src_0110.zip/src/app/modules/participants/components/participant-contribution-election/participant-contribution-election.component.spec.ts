import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantContributionElectionComponent } from './participant-contribution-election.component';

describe('ParticipantContributionElectionComponent', () => {
  let component: ParticipantContributionElectionComponent;
  let fixture: ComponentFixture<ParticipantContributionElectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantContributionElectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantContributionElectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
