import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-investment-election',
  templateUrl: './participant-investment-election.component.html',
  styleUrls: ['./participant-investment-election.component.scss']
})
export class ParticipantInvestmentElectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
