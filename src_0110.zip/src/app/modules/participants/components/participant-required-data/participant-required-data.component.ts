import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  NgForm
} from "@angular/forms";

import { ParticipantsService } from "../../service/participants.service";
import { CommonService } from "../../../../shared/services/common.service";

import { IParticipantRequiredData } from "../../model/participantRequiredData.model";
import { ParticipantAdminSetting } from "../../model/participant.model";

@Component({
  selector: "participant-required-data",
  templateUrl: "./participant-required-data.component.html",
  styleUrls: ["./participant-required-data.component.scss"]
})
export class ParticipantRequiredDataComponent implements OnInit {
  participantRequiredDataForm: FormGroup;
  participantRequiredData: IParticipantRequiredData;
  participantAdminSetting: ParticipantAdminSetting;
  model;
  ssn: string;
  fname: string;
  countryList: {value:string, label:string}[];
  stateList: {value:string, label:string}[];

  constructor(
    private formBuilder: FormBuilder,
    private participantsService: ParticipantsService,
    private common: CommonService,
    private router: Router,
  ) {}

  ngOnInit() {
    //Get Admin Settings
    this.participantsService.getParticipantAdminSettingMock().subscribe(result => {
      if(result.status === "SUCCESS"){
        this.participantAdminSetting = result.data;  
      }
    });

    //Get County List
    this.common.getCountryListMock().subscribe(result=> {
      if(result.status === "SUCCESS"){
        this.countryList = result.data;
      }
    })

    //Get State List
    this.common.getStateListMock().subscribe(result=> {
      if(result.status === "SUCCESS"){
        this.stateList = result.data;
      }
    })



    this.participantRequiredDataForm = this.formBuilder.group({
      ssn: [""],
      email: [""],
      lastName: ["Sandhya"],
      firstName: [""],
      mName: [""],
      addressLine1: [""],
      addressLine2: [""],
      city: [""],
      zip: [""],
      state: [""],
      country: [null],
      dateOfBirth: [null],
      dateOfHire: [""],
      enrollFlag: [false],
      mstarFlag: [false],
      qdiaFlag: [""]
    });
  }

  onSubmit() {
    this.setParticipantRequiredData();
    if(this.participantRequiredDataForm.value.enrollFlag){
      this.router.navigate(["addParticipant/Optional"]);
    }
  }

  onStateChange(value: string) {
    console.log("Value changed: " + value);
  }

  setParticipantRequiredData() {
    let data: IParticipantRequiredData = this.participantRequiredDataForm.value;
    console.log(data);
    this.participantRequiredData = data;
  }
}
