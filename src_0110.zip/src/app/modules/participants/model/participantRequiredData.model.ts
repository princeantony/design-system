export interface IParticipantRequiredData {
  ssn: string;
  email: string;
  lastName: string;
  firstName: string;
  mName: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  zip: string;
  state: string;
  country: string;
  dateOfBirth: string;
  dateOfHire: string;
  enrollFlag: boolean;
  mstarFlag: boolean;
  qdiaFlag: boolean;
}
