import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { MockService } from "../../../shared/services/mock.service";
import { ApiService } from "../../../shared/services/api.service";
import { SERVICE_URL } from "../../../shared/constants/service.constants";
import _ from "lodash";
@Injectable({
  providedIn: "root"
})
export class AdminPlanSetupService {
  constructor(private mockService: MockService,  private apiService: ApiService) {}
  getMockPlanSetup(planNumber: string): Observable<any>{
  return this.mockService.getPlanSetup();

  }
getMockMoneySource(planNumber: string):Observable<any>{
  return this.mockService.getMoneySource(); 
  
 }
  getMockInvestments(planNumber: string):Observable<any>{
  return this.mockService.getInvestments(); 
  
 }
 getMockEnrollmentStatusCode(planNumber: string):Observable<any>{
  return this.mockService.getInvestments(); 
  
 }

getPlanSetup(planNumber: string):Observable<any>{
  return this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL+planNumber); 
  
 }
 getMoneySource(planNumber: string):Observable<any>{
  return this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL+planNumber); 
  
 }
  getInvestments(planNumber: string):Observable<any>{
  return this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL+planNumber); 
  
 }

 savePlanSetup(planNumber: string):Observable<any>{
  return this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL+planNumber); 
  
 }

 generateMoneySourceTableData(moneysouceValues: any, moneySouceFields: any) 
 {
 console.log("moneysouceValues",moneysouceValues , "moneySouceFields", moneySouceFields)
 console.log("assign", _.assign({ 'code': 0 }, moneysouceValues,moneySouceFields));
 
 }
 genereateInvestmentTableData(investmentValues: any, investmentFields: any)  
 {
  console.log("investmentValues",investmentValues , "investmentFields", investmentFields)
  console.log("assign", _.assign({ 'code': 0 }, investmentValues,investmentFields));

 }
 meargeObjects(payadminFields: any, ominiFields: any)
 {
  var mergedObj = _.toArray(_.merge(_.keyBy(payadminFields, 'code'), _.keyBy(ominiFields, 'code')));
 
   //var merged1 = _.take(mergedObj, _.size(mergedObj));
 return  _.take(mergedObj, _.size(mergedObj));
   //console.log("merged1", merged1 );


 }
}