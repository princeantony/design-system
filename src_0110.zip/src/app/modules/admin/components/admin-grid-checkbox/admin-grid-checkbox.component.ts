import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
  selector: 'app-admin-grid-checkbox',
  templateUrl: './admin-grid-checkbox.component.html'

})
export class AdminGridCheckboxComponent  implements ICellRendererAngularComp {
  constructor() { }
  value : boolean;
  controlClass: string;
  controlName: string;
    agInit(params: any): void {   
        //console.log("params",params)  
        this.value = params.value; 
        this.controlClass = "small";
        this.controlName = "chk_"+params.colDef.field+ "_"+params.rowIndex;
    }
   
    refresh(): boolean {
        return false;
    }

}
