import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from "ag-grid-angular";

@Component({
  selector: 'app-admin-grid-textbox',
  templateUrl: './admin-grid-textbox.component.html'
})
export class AdminGridTextboxComponent implements ICellRendererAngularComp {
  constructor() { }
  public params: any;
  controlName: string;
  value: string;
    agInit(params: any): void {  
        this.params = params;  
         this.controlName = "txt_"+params.colDef.field+ "_"+params.rowIndex; 
         this.value= params.value;
    }
   
    refresh(): boolean {
        return false;
    }
}
