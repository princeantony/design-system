import { Component, OnInit, ElementRef } from '@angular/core';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { IBankInfo } from '../../../../shared/interfaces/bank.interface';
import { BankInfoService } from '../../services/bank-info.service';
import {APP_CONST, ENV} from '../../../../shared/constants/app.constants';
import { NgxSpinnerService } from 'ngx-spinner';
import _ from 'lodash';
import { Environment } from '../../../../../../node_modules/ag-grid';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html'


})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub : any;
  updateTime: any;
  updateDate: any;
  bankDetails:any;
  accType: string;
  divSubs : any;
  divSub: string;
  hidePageTitle:boolean;
  print:boolean = false;
  printBtn:boolean = false;
  subTitle:string;
  planNumber:string;
  payAdminGlobalState: PayAdminGlobalState;
  constructor( 
              private route: ActivatedRoute, 
              private router : Router,
              private printForm: ElementRef,
              private spinner: NgxSpinnerService, 
              private modalService: ModalService,

              private bankInfoService: BankInfoService) { }

  ngOnInit() {

    PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
    PayAdminGlobalState.currentPage = "/bankInfo/confirm";

    this.hidePageTitle = false;
   this.subTitle = "Bank Information";
  this.planNumber =  PayAdminGlobalState.planNumber; 
  
   this.bankDetails = PayAdminGlobalState.bankDetails;
  
   this.divSubs = PayAdminGlobalState.subDiv;
  
   this.divSub =_.filter(this.divSubs, ['id', PayAdminGlobalState.divsubId])[0].text;
   //this.divSub = PayAdminGlobalState.divsubId;
   
   if(this.bankDetails.bankInfo.accountType == "C"){
     this.accType = "Checking";
   }
   else{
     this.accType = "Savings";
   }

   this.route.url.subscribe(params => {
    if(params[1].path == "print"){
      this.printBtn = true;
      this.print = true;
  
    }
  });
  }
onPrint(){
    
    window.print();

PayAdminGlobalState.successMsg = "";

}
onMockSubmit(){

  if(_.split(PayAdminGlobalState.previousPage, '/')[2] === "edit"){
  PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
  this.router.navigate(["/home/success"]);
  }
  else{
          PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
          this.router.navigate(["/home/success"]);
    }
  }

  onSubmit(){
 console.log("bankDetails to insert", this.bankDetails);
    let planId = PayAdminGlobalState.planNumber;
   this.spinner.show();
    this.updateDate = new Date().toLocaleDateString();
    this.updateTime = new Date().toLocaleTimeString();
    if(ENV.TEST)
    {
      this.onMockSubmit();
    }
    else{
    if(_.split(PayAdminGlobalState.previousPage, '/')[2] === "edit"){

      this.bankInfoService.updateBankInfo(this.bankDetails,planId,PayAdminGlobalState.divsubId).subscribe(bankInfo => { 
      this.spinner.hide();

   if(bankInfo.status === APP_CONST.SUCCESS){
    PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
    
    this.router.navigate(["/home/success"]);
   }
  
   
},  (err => {console.log("Error", err),this.spinner.hide();}));

    }
    else{
        this.bankInfoService.postBankInfo(this.bankDetails,planId,PayAdminGlobalState.divsubId).subscribe(bankInfo => { 
        this.spinner.hide();
 
        if(bankInfo.status === APP_CONST.SUCCESS){
            PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
            
            this.router.navigate(["/home/success"]);
      }
   
 }, (err => {console.log("Error", err),this.spinner.hide();}));

    }
  }
  }
  onEdit(){
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
  gotoHome(){
    this.router.navigate(["/home"]);

  }
}
