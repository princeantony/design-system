import { Component, OnInit} from '@angular/core';
import { Injectable } from '@angular/core';
import {GRID_CONFIG,APP_CONST, ENV} from '../../../../shared/constants/app.constants';
import {LoginUser} from '../../../../shared/mocks/login-user.mock';
import { PlanService } from '../../services/plan.service';
import { AuthService } from '../../services/auth.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import _ from 'lodash';
@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss']
  
})
@Injectable()
export class PlanListComponent implements OnInit {
columnDefs: any;
planData: any;
width;
planListItem : any;
constructor(
  private planService: PlanService,
  private authService: AuthService,
  private spinner: NgxSpinnerService) 
  {
  }
  ngOnInit() {
    this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
    this.width= GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
    this.planListItem = PayAdminGlobalState.planListState;
    
    if(ENV.TEST)
    {
    this.getMockPlans();
    }
    else{
      if(PayAdminGlobalState.planListState)
      this.planData = PayAdminGlobalState.planListState
      else
      {
      this.spinner.show();
      this.login();
      }
    }
}
  getPlans(): void {
    this.planService.getPlans().subscribe(plans => {
      this.spinner.hide();
      if(plans.status === APP_CONST.SUCCESS) 
      {
        this.planData = plans.data;
       PayAdminGlobalState.planListState = this.planData; // will enable if we use local state
      }
      
    },
    (
      err => 
      {
       this.spinner.hide();
       console.log("Error in plan load err.error.text=>", err.error.text);
        //var errorJSON = JSON.parse( err.error.text);
        //console.log("Error in plan load", errorJSON);
       // if(err.error.text != undefined)
       // this.planData = err.error.text.data ;       
      }
    ));
  }
  login() : void{
   this.authService.doAuthenticte(LoginUser).subscribe(loginInfo => { 
   if(loginInfo.status === APP_CONST.SUCCESS) 
   this.getPlans();
  },
   (err => {console.log("Error in login call", err),this.spinner.hide();})
  );
  }
 
  getMockPlans() : void{
    this.planService.getMockPlans().subscribe(plans => {
      this.spinner.hide();
      if(plans.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.planData = plans.data;
      PayAdminGlobalState.planListState = this.planData;
      }
    });
    
  }
}
