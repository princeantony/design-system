import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { Router } from '../../../../../../node_modules/@angular/router';

@Component({
  selector: 'app-plan-selection',
  templateUrl: './plan-selection.component.html'
})
export class PlanSelectionComponent implements OnInit {
  hidePageTitle:boolean = false;
  pageTitleClass: boolean  = true;
  planNumberStatus = false;
  pageTitle = "Plan Selection";
  subTitle = "Plan Selection";
  constructor(private router : Router) {
    
   }
  ngOnInit() {
    PayAdminGlobalState.currentPage = "/plans";
    if(PayAdminGlobalState.planNumber){
      this.planNumberStatus = true;

    }
  }
  gotoBack(){
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
}
