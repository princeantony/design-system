import { Component, OnInit } from '@angular/core';
const pageSlot = 10;
@Component({
  selector: 'app-voya-paging',
  templateUrl: './voya-paging.component.html',
  styleUrls: ['./voya-paging.component.scss']
})
export class VoyaPagingComponent implements OnInit {
  private gridApi;

  nextStatus = false;
  prevStatus = true;
  selectedPage = 1;
  // maxRange = false;
  btnNum = [];
  totalPages;
  constructor() { }

  ngOnInit() {
  }
  createPageSlot(minNum: number, maxNum: number) {
    this.btnNum = [];

    for (let i = minNum; i < maxNum; i++) {
      if (i + 1 <= this.totalPages) {
        this.btnNum.push(i + 1);
      } else {
        this.nextStatus = true;
      }
    }
  }
  gotoPage(pageNum) {
    this.gridApi.paginationGoToPage(pageNum - 1);
    this.selectedPage = pageNum;
  }
  gotoPrev() {
    this.nextStatus = false;
    let firstNum = this.btnNum[0] - (pageSlot + 1);
    let lastNum = firstNum + pageSlot;
    this.createPageSlot(firstNum, lastNum);

    if (firstNum + 1 <= 1) {
      this.prevStatus = true;
    }
  }

  gotoNext() {
    this.prevStatus = false;
    let minNum = this.btnNum[pageSlot - 1];

    let maxNum = minNum + pageSlot;
    console.log(minNum + " : " + maxNum);
    this.createPageSlot(minNum, maxNum);
  }
}
