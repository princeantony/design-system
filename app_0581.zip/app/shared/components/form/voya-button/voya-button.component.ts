import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voya-button',
  templateUrl: './voya-button.component.html',
  styleUrls: ['./voya-button.component.scss']
})
export class VoyaButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
