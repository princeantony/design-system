export interface IBankInfo{
    addressId: string,
    planNumber: string,
    //locationNumber: string,
    //locationName: string,
    divsub:string,
    bankName: string,
    acctNumber:string,
    abaNumber: string,
    accountType: string,
    address1:string,
    address2: string,
    city: string,
    zipcode: string,
    valid: boolean

}
export interface IBankSubDiv{
    id: string,
    text: string,
    name: string,
    phone: string
}