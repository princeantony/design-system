import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from "ag-grid-angular";
import { ActivatedRoute } from '../../../../../../node_modules/@angular/router';
import { ROUTER_CONST } from "../../../../shared/constants/app.constants";



@Component({
  selector: 'app-grid-link',
  templateUrl: './grid-link.component.html'
})
export class GridLinkComponent implements ICellRendererAngularComp {

  constructor() { }

  public params: any;
  public link : string;
  public navParam : string;
  planNumber;
private sub: any;
    agInit(params: any): void {     
        this.params = params;
        if(this.params.data){
          if(!this.params.data.bankName){
            this.link = ROUTER_CONST.ADD_BANK;
            this.navParam = "create/"+this.params.data.addressId;
          

          }
          else{
            this.link = ROUTER_CONST.EDIT_BANK;
            this.navParam = "edit/"+this.params.data.addressId;
            
          }
        }
    }

    public invokeRouteTo(param) {
      
      this.params.context.componentParent.routeTo(param);
  }
  
    refresh(): boolean {
        return false;
    }

}
