import { Component, OnInit, ElementRef } from '@angular/core';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { IBankInfo } from '../../../../shared/interfaces/bank.interface';
import { BankInfoService } from '../../services/bank-info.service';
import _ from 'lodash';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html'

})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub : any;
  updateTime: any;
  updateDate: any;
  bankDetails:any;
  accType: string;
  divSubs : any;
  divSub: string;
  hidePageTitle:boolean;
  print:boolean = false;
  printBtn:boolean = false;
  subTitle:string;
  planNumber:string;
  payAdminGlobalState: PayAdminGlobalState;
  
  
  constructor( 
              private route: ActivatedRoute, 
              private router : Router,
              private printForm: ElementRef, 
              private modalService: ModalService,
              private bankInfoService: BankInfoService) { }

  ngOnInit() {

    PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
    PayAdminGlobalState.currentPage = "/bankInfo/confirm";

    this.hidePageTitle = false;
   this.subTitle = "Bank Information";
  this.planNumber =  PayAdminGlobalState.planNumber; 
  
   this.bankDetails = PayAdminGlobalState.bankDetails;
   console.log("-------------this.bankDetails", this.bankDetails);
   this.divSubs = PayAdminGlobalState.subDiv;
   this.divSub =_.filter(this.divSubs, ['id', this.bankDetails.bankInfo.divsub])[0].text;
   
   if(this.bankDetails.bankInfo.accountType == "C"){
     this.accType = "Checking";

   }
   else{
     this.accType = "Savings";
   }

   this.route.url.subscribe(params => {
    if(params[1].path == "print"){
      this.printBtn = true;
      this.print = true;
  
    }
    
  
  });
   
  }
onPrint(){
  this.printBtn = false;
  setTimeout(()=>{    
    window.print();
}, 50);
PayAdminGlobalState.successMsg = "";

  
 

}
  onSubmit(){
    let planId = PayAdminGlobalState.planNumber;

    this.updateDate = new Date().toLocaleDateString();
    this.updateTime = new Date().toLocaleTimeString();
    
    this.bankInfoService.postBankInfo(this.bankDetails, PayAdminGlobalState.planNumber).subscribe(bankInfo => { 
   
   console.log("--------bankInfo",bankInfo);
  /*  if(bankInfo.status === APP_CONST.LOGIN_SUCCESS){
     PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
    
    this.router.navigate(["/home/" + planId +"/success"]);
   } */
   
  });
    //this.bankInfoService.postBankInfo(payload, PayAdminGlobalState.planNumber);
    
    
    

  }

  onEdit(){
    this.router.navigate([PayAdminGlobalState.previousPage]);
    

  }
 

  

}
