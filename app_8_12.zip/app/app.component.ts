import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CommonService } from '../app/shared/services/common.service';
import { PreviousRouteService } from './shared/services/previous-route.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  title = 'PayAdmin';
  date = new Date().toLocaleDateString();
  constructor(
    private commonService: CommonService,
    private router: Router,
   private previousRouteService: PreviousRouteService
  ) {}
  /* we should call all the common services as synchronize call. Below code is now writtern as asynchronize */
  ngOnInit(): void {
    this.router.navigate(['/plans']);
  }
}

// Need to revisit this logic once we get the complete information on the websponsor - payadmin integration
