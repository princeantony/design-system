import { Component, Input, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

import { APP_CONST, ENV } from '../../../../shared/constants/app.constants';
import { IMenuItem } from '../../../../shared/interfaces/menu-item.interface';
import { ToastrService } from '../../../../shared/services/toastr.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { HomeService } from '../../services/home.service';

@Component({
  selector: 'app-pay-admin-menu',
  templateUrl: './pay-admin-menu.component.html'
})
export class PayAdminMenuComponent implements OnInit {
  @Input()
  planNumber: string;
  menuItemRows: Array<IMenuItem[]>;
  appContext = APP_CONST.APP_CONTEXT;
  homeFlags: any;
  message: string;
  payAdminGlobalState: PayAdminGlobalState;
  private sub: any;
  constructor(
    private homeService: HomeService,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    private toastrService: ToastrService,
    private vcr: ViewContainerRef,
    private router: Router
  ) {
    this.toastrService.toastr.setRootViewContainerRef(vcr);
  }
  ngOnInit() {
    this.spinner.show();
    if (ENV.TEST) {
      this.getMockMenuList();
    } else{
      this.getMenuList();
      }
  }
  getMenuList() {
    this.homeService.getMenuList(this.planNumber).subscribe(
      flags => {
        this.spinner.hide();
        if (flags.status === APP_CONST.SUCCESS) {
          this.menuItemRows = this.homeService.getMenuItemRows(flags.data);
          this.homeFlags = flags.data;
          PayAdminGlobalState.homeFlagState = this.menuItemRows;
        } else {
          this.toastrService.showError(flags.error.msg, flags.status + ' !');
        }

      },
      err => {
        this.toastrService.showError('Not able to get home tiles. Try again ', 'Error' + '!');
        console.log('Error in home', err)
        this.spinner.hide();
      }
    );
  }
  getMockMenuList() {
    this.homeService.getMockMenuList(this.planNumber).subscribe(flags => {
      this.spinner.hide();
      if (flags.status === APP_CONST.SUCCESS) {
        this.menuItemRows = this.homeService.getMenuItemRows(flags.data);
        this.homeFlags = flags.data;
      }
    });
  }
  navigateTo(menuItemRow) {

  }
}
