import { Component, Input, OnInit, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { DifferencePipe, MomentModule } from 'ngx-moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { forkJoin, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { AlertMessage } from 'src/app/shared/interfaces/alert.interface';
import { CommonService } from 'src/app/shared/services/common.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { MESSAGE } from '../../constants/participants.constants';
import {
  IParticipantRequiredData,
  Option,
  ParticipantData,
  ParticipantOptionalField,
  ParticipantOptionSetting,
} from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';

//import { LoggerService } from 'src/app/shared/services/logger.service';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'participant-required-data',
  templateUrl: './participant-required-data.component.html',
  styleUrls: ['./participant-required-data.component.scss'],
  providers: [DifferencePipe]
})
export class ParticipantRequiredDataComponent implements OnInit {
  private messageList: string[] = [];
  alertMessage: AlertMessage = new AlertMessage();
  private _editMode = false;
  private statusText: string;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }
  countryChanged = new Subject<string>();
  participantData = new ParticipantData();
  participantOptionSetting: ParticipantOptionSetting;
  participantRequiredDataForm: FormGroup;
  requiredData: IParticipantRequiredData;
  participantOptionalDataField: ParticipantOptionalField[];
  participantAge = -1;

  countryList: { value: string; displayText: string }[];
  stateList: { value: string; displayText: string }[];
  terminationReason: { value: string; displayText: string }[];

  loaStartDate: string;
  loaStartReason: Option[];
  loaEndDate: string;
  loaEndReason: Option[];

  // parameter to set dataofBirth start Date
  dobStartData: {};
  dohStartDate: {};

  accountTypeItems: { value: string; label: string }[];
  constructor(
    private previousRouteService: PreviousRouteService,
    private formBuilder: FormBuilder,
    private participantsService: ParticipantsService,
    private router: Router,
    private commonService: CommonService,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    private modalservice: ModalService,
    private moment: MomentModule,
    private dateDiff: DifferencePipe,
    //private logger: LoggerService,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }

  participantOptionSetting$ = this.participantsService.getParticipantOptionSetting();
  participantStatusList$ = this.participantsService.getParticipantStatusFromStatusList();
  participantODE$ = this.participantsService.getParticipantOptionalDataFields$();
  participantTerminationReason$ = this.participantsService.getParticipantTerminationReason();
  participantForkJoin$ = forkJoin(
    this.participantOptionSetting$.pipe(
      catchError(err => {
        console.error('Participant Option Setting Errored Out');
        return throwError(err);
      })
    ),
    this.participantStatusList$.pipe(
      catchError(err => {
        console.error('Participant Status List Errored Out');
        return throwError(err);
      })
    ),
    this.participantODE$.pipe(
      catchError(err => {
        console.error('Participant Data Element Errored Out');
        return throwError(err);
      })
    )
  );
  ngOnInit() {
    this.spinner.show();
    ParticipantStore.EditMode = this.EditMode;
    this.terminationReason = [
      {
        value: '1',
        displayText: 'With Cause'
      },
      {
        value: '2',
        displayText: 'Laid Off'
      },
      {
        value: '3',
        displayText: 'Special'
      },
      {
        value: '4',
        displayText: 'Retirement'
      },
      {
        value: '5',
        displayText: 'Permanent Disability'
      },
      {
        value: '6',
        displayText: 'Death'
      },
      {
        value: '7',
        displayText: '100% Withdrawal'
      },
      {
        value: '8',
        displayText: 'Not Transferred Out'
      },
      {
        value: '9',
        displayText: 'Converted'
      },
      {
        value: 'A',
        displayText: 'User Defined 1'
      },
      {
        value: 'B',
        displayText: 'User Defined 2'
      },
      {
        value: 'C',
        displayText: 'User Defined 3'
      },
      {
        value: 'D',
        displayText: 'Converted'
      },
      {
        value: 'E',
        displayText: 'QDRO'
      },
      {
        value: 'F',
        displayText: 'Beneficiary'
      },
      {
        value: 'I',
        displayText: 'Irrevocable Declination'
      },
      {
        value: 'L',
        displayText: 'Leave of Absence'
      },
      {
        value: 'N',
        displayText: 'New Entrant'
      },
      {
        value: 'R',
        displayText: 'Rehire'
      },
      {
        value: 'T',
        displayText: 'Transferred to Other Plan'
      },
      {
        value: 'V',
        displayText: 'Voluntary Termination'
      },
      {
        value: 'X',
        displayText: 'Excluded Class'
      }
    ];

    this.stateList = PayAdminGlobalState.StateList;
    this.countryList = PayAdminGlobalState.CountryList;

    if (ParticipantStore.ParticipantOptionSetting.servicePayLoad) {
      this.participantOptionSetting = ParticipantStore.ParticipantOptionSetting;
      this.participantData = ParticipantStore.ParticipantData;
      this.statusText = ParticipantStore.Status;
      this.terminationReason = ParticipantStore.TerminationReasonList;
      if (this.EditMode) {
        if (this.participantOptionSetting.canLoadOptionalDataElements) {
          this.participantOptionalDataField =
            ParticipantStore.ParticipantData.optionalData;
        }
      }

      // Initialize Form
      this.initFrom();
      this.onChanges();
      this.spinner.hide();
    } else {
      this.participantForkJoin$.subscribe(
        ([options, statuslist, ode]) => {
          if (
            options.status === 'SUCCESS' &&
            statuslist.status === 'SUCCESS' &&
            ode.status === 'SUCCESS'
          ) {
            this.participantOptionSetting = ParticipantStore.ParticipantOptionSetting =
              options.data;
            console.info(
              'Participant Option Setting',
              this.participantOptionSetting
            );
            ParticipantStore.TerminationReasonList = this.terminationReason;

            console.info(
              'Participant Termination Reason',
              this.terminationReason
            );
            this.setStartDates();
            ParticipantStore.ParticipantStatusList = statuslist.data;

            console.info(
              'ParticipantStatusList',
              ParticipantStore.ParticipantStatusList
            );
            if (!this.EditMode) {
              ParticipantStore.StatusCode =
                ParticipantStore.ParticipantOptionSetting.statusCode;
              ParticipantStore.Status = this.statusText = this.participantsService.getParticipantStatus(
                ParticipantStore.ParticipantOptionSetting.statusCode
              );

              this.participantData.requiredData.country = 'USA';
            } else {
              // Participant Update Section

              ParticipantStore.StatusCode = this.participantData.requiredData.statusCode;
              ParticipantStore.Status = this.statusText = this.participantsService.getParticipantStatus(
                ParticipantStore.ParticipantData.requiredData.statusCode
              );
              if (this.participantOptionSetting.displayLOA) {
                ParticipantStore.ParticipantData.optionalData = this.participantOptionalDataField =
                  ode.data;
              }
            }
            ParticipantStore.ParticipantOptionSetting.servicePayLoad = true;
            // Initialize Form
            this.initFrom();
            this.onChanges();
            this.spinner.hide();
          } else {
            this.spinner.hide();
            console.log(options);
            console.log(statuslist);
            console.log(ode);
            console.log('Something Went wrong!!!');
          }
        },
        error => {
          this.spinner.hide();
          this.toasterError(error);
        }
      );
    }
  }

  initFrom() {
    if (this.EditMode) {
      // Note:  get Participant Required data from store which is prefilled in search participant
      this.participantData = ParticipantStore.ParticipantData;
      ParticipantStore.ParticipantSSN = this.participantData.requiredData.ssn;
      if (this.participantOptionSetting.displayLOA) {
        this.initLOAFields();
        console.info('LOA Fields Initialzed');
      }
    }
    console.info('participant data', this.participantData);

    this.participantRequiredDataForm = this.formBuilder.group({
      ssn: [this.participantData.requiredData.ssn],
      email: [this.participantData.requiredData.email],
      lastName: [this.participantData.requiredData.lastName],
      firstName: [this.participantData.requiredData.firstName],
      middleInitial: [this.participantData.requiredData.middleInitial],
      address1: [this.participantData.requiredData.address1],
      address2: [this.participantData.requiredData.address2],
      city: [this.participantData.requiredData.city],
      zipCode: [this.participantData.requiredData.zipCode],
      state: [this.participantData.requiredData.state],
      country: [this.participantData.requiredData.country],
      birthDate: [this.participantData.requiredData.birthDate],
      hireDate: [this.participantData.requiredData.hireDate],
      termDate: [this.participantData.requiredData.termDate],
      termCode: [this.participantData.requiredData.termCode],
      makeParticipantActive: [
        this.participantData.requiredData.makeParticipantActive
      ],
      absenceStartDate: [this.loaStartDate],
      absenceStartDateReason: [
        this.participantData.requiredData.absenceStartDateReason
      ],
      absenceEndDate: [this.loaEndDate],
      absenceEndDateReason: [
        this.participantData.requiredData.absenceEndDateReason
      ],
      enrollFlag: [this.participantData.requiredData.enrollFlag],
      mstarFlag: [this.participantData.requiredData.mstarFlag],
      qdiaFlag: [this.participantData.requiredData.qdiaFlag]
    });
  }

  initLOAFields() {
    // "loaStartDateDataElement": "PTPH771", "loaStartReasonDataElement": "PTPH841",
    // "loaEndDateDataElement": "PTPH772", "loaEndReasonDataElement": "PTPH842",
    // Get data from Optional Data Element and fill it here.
    if (this.participantOptionalDataField) {
      const LOAStartDateElementKey = this.participantOptionSetting
        .loaStartDateDataElement;
      const LOAEndDateElementKey = this.participantOptionSetting
        .loaEndDateDataElement;
      const LOAStartReasonKey = this.participantOptionSetting
        .loaStartReasonDataElement;
      const LOAEndReasonKey = this.participantOptionSetting
        .loaEndReasonDataElement;
      this.participantOptionalDataField.forEach(ode => {
        switch (ode.key) {
          case LOAStartDateElementKey:
            this.loaStartDate = ode.value;
            break;
          case LOAEndDateElementKey:
            this.loaEndDate = ode.value;
            break;
          case LOAStartReasonKey:
            this.loaStartReason = ode.option;
            break;
          case LOAEndReasonKey:
            this.loaEndReason = ode.option;
            break;
        }
      });
    }
  }

  onChanges() {
    this.participantRequiredDataForm.controls[
      'middleInitial'
    ].valueChanges.subscribe(val => {
      this.participantRequiredDataForm.controls['middleInitial'].setValue(
        val.toUpperCase(),
        { emitEvent: false }
      );
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'lastName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'firstName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'birthDate'
    ].valueChanges.subscribe(val => {
      this.validateBirthDate();
      this.validateBirthAndHireDate();
    });
    this.participantRequiredDataForm.controls[
      'hireDate'
    ].valueChanges.subscribe(val => {
      this.validateHireDate();
      this.validateBirthAndHireDate();
    });
  }

  validateNameMaxlengthExceeded() {
    if (
      this.participantRequiredDataForm.controls['middleInitial'].value.length +
        this.participantRequiredDataForm.controls['firstName'].value.length +
        this.participantRequiredDataForm.controls['lastName'].value.length >
      30
    ) {
      this.participantRequiredDataForm.controls['lastName'].setErrors({
        MaxLengthExceeded: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    } else {
      this.participantRequiredDataForm.setErrors({ invalid: false });
    }
  }
  validateHireDate() {
    if (
      this.isFutureDate(
        this.participantRequiredDataForm.controls['hireDate'].value
      )
    ) {
      this.participantRequiredDataForm.controls['hireDate'].setErrors({
        InvalidDateFutureDate: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    } else {
      this.participantRequiredDataForm.setErrors({ invalid: false });
    }
  }
  validateBirthDate() {
    if (
      this.isFutureDate(
        this.participantRequiredDataForm.controls['birthDate'].value
      )
    ) {
      this.participantRequiredDataForm.controls['birthDate'].setErrors({
        InvalidDateFutureDate: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    } else {
      this.participantRequiredDataForm.setErrors({ invalid: false });
    }

    const age = this.getAge(
      this.participantRequiredDataForm.controls['birthDate'].value
    );
    this.participantAge = age;

    if (age) {
      if (
        age <= this.participantOptionSetting.participantMinAge ||
        age > this.participantOptionSetting.participantMaxAge
      ) {
        this.participantRequiredDataForm.controls['birthDate'].setErrors({
          InvalidAge: true
        });
        this.participantRequiredDataForm.setErrors({ invalid: true });
      } else {
        this.participantRequiredDataForm.setErrors({ invalid: false });
      }
    }
  }
  validateBirthAndHireDate() {
    const ageOnHireDate = this.getYearsBetweenHireDateBirthday(
      this.participantRequiredDataForm.controls['birthDate'].value,
      this.participantRequiredDataForm.controls['hireDate'].value
    );

    if (ageOnHireDate) {
      if (
        ageOnHireDate <= this.participantOptionSetting.participantMinAge ||
        ageOnHireDate > this.participantOptionSetting.participantMaxAge
      ) {
        this.participantRequiredDataForm.controls['birthDate'].setErrors({
          InvalidAgeOnHireDate: true
        });
        this.participantRequiredDataForm.setErrors({ invalid: true });
      } else {
        this.participantRequiredDataForm.setErrors({ invalid: false });
      }
    }
  }
  isFutureDate(date: string): boolean {
    const [monthB, dayB, yearB] = date.split('/');
    if (date.split('/').length === 3) {
      const _date = new Date(yearB + '-' + monthB + '-' + dayB);
      const today = new Date();
      return _date > today;
    }
    return false;
  }

  getAge(birhthDay: string): number | null {
    let age = null;
    const [monthB, dayB, yearB] = birhthDay.split('/');
    if (birhthDay.split('/').length === 3) {
      const birthDate = new Date(yearB + '-' + monthB + '-' + dayB);
      const today = new Date();
      // DifferencePipe.transform(value, otherValue, unit, precision)
      age = this.dateDiff.transform(today, birthDate, 'years');
    }
    return age;
  }
  getYearsBetweenHireDateBirthday(birhthDay: string, hireDay: string) {
    if (birhthDay && hireDay) {
      if (
        birhthDay.split('/').length === 3 &&
        hireDay.split('/').length === 3
      ) {
        const [monthB, dayB, yearB] = birhthDay.split('/');
        const birthDate = new Date(yearB + '-' + monthB + '-' + dayB);
        const [monthH, dayH, yearH] = hireDay.split('/');
        const hireDate = new Date(yearH + '-' + monthH + '-' + dayH);

        return this.dateDiff.transform(hireDate, birthDate, 'years');
        // The Participant must be between 15 and 90 years of age for Employment.
      }
    }
    return null;
  }
  setStartDates() {
    this.dobStartData = { year: new Date().getFullYear() - 19 - 9, month: 1 };
    this.dohStartDate = { year: new Date().getFullYear() - 9, month: 1 };
  }

  onSubmit() {
    this.validateSSN().subscribe(
      isValidSSN => {
        if (isValidSSN) {
          // quickfix for ssn
          const ssn = this.participantRequiredDataForm.value.ssn
            .split('-')
            .join('');
          ParticipantStore.ParticipantSSN = ssn;
          this.participantRequiredDataForm.controls['ssn'].setValue(ssn);
          const data: IParticipantRequiredData = this
            .participantRequiredDataForm.value;

          ParticipantStore.ParticipantData.requiredData = data;
          // Update LOA Fields
          this.updateLOADataToStore();
          console.info(
            'Required Page before submit',
            ParticipantStore.ParticipantData
          );

          if (this.participantRequiredDataForm.value.enrollFlag) {
            if (
              ParticipantStore.ParticipantOptionSetting
                .canLoadOptionalDataElements
            ) {
              if (!this.EditMode) {
                this.router.navigate(['addParticipant/Optional']);
              } else {
                this.router.navigate(['UpdateParticipant/Optional']);
              }
            } else {
              if (!this.EditMode) {
                this.router.navigate(['addParticipant/ContributionElection']);
              } else {
                this.router.navigate([
                  'UpdateParticipant/ContributionElection'
                ]);
              }
            }
          } else {
            if (!this.EditMode) {
              this.router.navigate(['addParticipant/Confirmation']);
            } else {
              this.router.navigate(['UpadteParticipant/Confirmation']);
            }
          }
        }
      },
      error => {
        this.toasterError(error);
      }
    );
  }

  updateLOADataToStore() {
    if (this.EditMode && this.participantOptionSetting.displayLOA) {
      ParticipantStore.ParticipantData.optionalData.forEach(
        (ode, index, object) => {
          switch (ode.key) {
            case this.participantOptionSetting.loaStartDateDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceStartDate'
              ].value;
              break;
            case this.participantOptionSetting.loaEndDateDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceEndDate'
              ].value;
              break;
            case this.participantOptionSetting.loaStartReasonDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceStartDateReason'
              ].value;
              break;
            case this.participantOptionSetting.loaEndReasonDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceEndDateReason'
              ].value;
              break;
          }
        }
      );
    }
  }

  validateSSN(): any {
    if (!this.EditMode) {
      this.participantsService
        .validateAddParticipantSSN(
          this.participantRequiredDataForm.controls['ssn'].value
            .split('-')
            .join('')
        )
        .subscribe(
          res => {
            if (res.status === 'SUCCESS') {
              return of(true);
            } else if (res.status === 'ERROR') {
              const errors: string = res.error.msg;
              this.messageList = errors.split(',');
              return of(false);
            }
          },
          err => {
            console.log(err);
            return of(false);
          }
        );
    } else {
      this.participantsService
        .validateUpdateParticipantSSN(
          this.participantRequiredDataForm.controls['ssn'].value
            .split('-')
            .join('')
        )
        .subscribe(
          res => {
            if (res.status === 'SUCCESS') {
              return of(true);
            } else if (res.status === 'ERROR') {
              const errors: string = res.error.msg;
              this.messageList = errors.split(',');
              return of(false);
            }
          },
          err => {
            console.log(err);
            return of(false);
          }
        );
    }
    return of(true);
  }

  onStateChange(value: string) {}

  onCountryChange(value: string) {
    this.commonService.countryChanged.next(value);
  }
  onEnrollFlagChange(value: boolean) {
    if (
      !this.participantOptionSetting.displayMorningStar &&
      !this.participantOptionSetting.displayQDIA
    ) {
      return;
    }
    if (value) {
      this.participantOptionSetting.disableQDIA = false;
      this.participantOptionSetting.disableMorningStar = false;
    } else {
      this.participantRequiredDataForm.controls['mstarFlag'].setValue(false);
      this.participantRequiredDataForm.controls['qdiaFlag'].setValue(false);
      this.participantOptionSetting.disableQDIA = true;
      this.participantOptionSetting.disableMorningStar = true;
    }
  }
  onMstarFlagChange(value: boolean) {
    setTimeout(() => {
      this.participantData.requiredData.mstarFlag = value;
      if (value) {
        if (this.participantOptionSetting.morningStarError) {
          this.participantRequiredDataForm.controls['mstarFlag'].setValue(
            false
          );

          this.participantData.requiredData.mstarFlag = false;

          this.toastr.error(
            'Morningstar Managed Account Program is not available at this time.!',
            'Morning Star Error' + ' !',
            { showCloseButton: true }
          );
          this.participantRequiredDataForm.value.mstarFlag = false;
        }
      }
    }, 500);
  }

  openAlertModal(field) {
    this.alertMessage.title = 'Help QDIA';
    this.alertMessage.content = MESSAGE['QDIA_HELP'];
    this.modalservice.open('alert-modal');
  }
  onBackClicked() {
    // this.router.navigate([PayAdminGlobalState.previousPage]);
    if (!this.EditMode) {
      this.router.navigate(['home']);
    } else {
      this.router.navigate(['participantUpdateSearch']);
    }
  }

  toasterError(error) {
    this.spinner.hide();
    console.error(error);
    this.toastr.error('Something Went Wrong', 'Error!!!', {
      showCloseButton: true
    });
  }
}
