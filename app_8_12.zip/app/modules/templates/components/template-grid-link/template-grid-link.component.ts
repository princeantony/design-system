import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-template-grid-link',
  templateUrl: './template-grid-link.component.html',
  styleUrls: ['./template-grid-link.component.scss']
})
export class TemplateGridLinkComponent implements ICellRendererAngularComp {
  params: any;
  constructor() {}
  agInit(params: any): void {
    this.params = params;
    console.log('----------params', this.params);
    /* if (this.params.data) {
      if (!this.params.data.bankName) {
        this.link = ROUTER_CONST.ADD_BANK;
        this.navParam = 'create/' + this.params.data.divsub;
      } else {
        this.link = ROUTER_CONST.EDIT_BANK;
        this.navParam = 'edit/' + this.params.data.divsub;
      }
    } */
  }
  edit() {
    console.log('---edit', this.params);
    this.params.api.setFocusedCell(this.params.rowIndex, 'fieldType');
    /* this.gridApi.startEditingCell({
      rowIndex: 2,
      colKey: "make"
    }); */
        this.params.api.startEditingCell({
          rowIndex: this.params.rowIndex,
          colKey: 'fieldType'
        });

  }
  delete() {
    this.params.api.updateRowData({ remove: [this.params.data] });

  }
  refresh(): boolean {
    return false;
  }
}
