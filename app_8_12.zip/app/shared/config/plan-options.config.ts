export const DivLocationOptons = [
    {
      'displayText': 'Multiple Division/Location',
      'value': 'M'
    },
     {
      'displayText': 'No Division/Location Restrictions',
      'value': 'N'
    },
    {
      'displayText': 'Single Division/Location',
      'value': 'S'
    }
];
export const EntrollmentOptions = [
   {
      'displayText': 'No Deferral Needed',
      'value': 'N'
    },
     {
      'displayText': 'Deferral Req, Show %',
      'value': 'P'
    },
    {
      'displayText': 'Deferral Req, Show $',
      'value': 'A'
    },
    {
      'displayText': 'Deferral Req, Show B',
      'value': 'B'
    },
    {
      'displayText': 'Demographic Info Only',
      'value': 'I'
    }
];


export const PinLenthOptions =[
  {
    'displayText': '0',
    'value': 0
  },
   {
      'displayText': '4',
      'value': 4
    },
     {
      'displayText': '6',
      'value': 6
    },

];

export const ParticipantUpdateOptions =[
    {
      'displayText': 'No Deferral Needed',
      'value': 'N'
    },
    {
      'displayText': 'Deferral Req, Show %',
      'value': 'P'
    },
    {
      'displayText': 'Deferral Req, Show $',
      'value': 'A'
    },
    {
      'displayText': 'Deferral Req, Show B',
      'value': 'B'
    },
    {
      'displayText': 'Demographic Info Only',
      'value': 'I'
    }
    ];

export const CatchUpOptions =[
    {
      'displayText': 'No Catch-up elections',
      'value': 'N'
    },
    {
      'displayText': 'Catch-up %',
      'value': 'P'
    },
    {
      'displayText': 'Catch-up $',
      'value': 'A'
    },
    {
      'displayText': 'Catch-up % and $',
      'value': 'B'
    }
    ];

export const EmailDEOptions =[
    {
      'displayText': 'PH155,PH156',
      'value': 'PH155'
    },
    {
      'displayText': 'VR151,VR152',
      'value': 'VR151'
    }
    ];
