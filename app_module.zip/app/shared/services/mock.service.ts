import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { bankInfo, divSub } from '../mocks/bankInfo-mock';
import { CountryListMock, MockSuccessResponse, StateListMock } from '../mocks/common-mock';
import { DataElementOptions, DataElementsList } from '../mocks/data-elements.mock';
import { ListPlan } from '../mocks/listPlan';
import { ADMIN_FLAGS, HOME_FLAGS } from '../mocks/menuItems-mock';
import {
  PariticipantContributionData,
  ParticipantAdminSettingMock,
  ParticipantFundData,
  ParticipantList,
  ParticipantMorningStar,
  ParticipantOptionalData,
  ParticipantOtherDivSub,
  ParticipantOtherExpandedDivSub,
  ParticipantStatusListMock,
} from '../mocks/participants-mock';
import { displayOptions, enrollmentStatusCode, investments, moneySources, planSetup } from '../mocks/plan-setup.mock';
import { updateDataResponse } from '../mocks/template-fixed-width';
import {
  columnList,
  existingTemplate,
  saveTemplateResponse,
  templateData,
  templateOptions,
  validationData,
} from '../mocks/template-with-error';
import { TerminationReasonList } from '../mocks/termination-reason.mock';

@Injectable({
  providedIn: 'root'
})
export class MockService {
  constructor() {}

  getCountryListMock(): Observable<any> {
    return of(CountryListMock);
  }

  getStateListMock(): Observable<any> {
    return of(StateListMock);
  }

  getListPlans(): Observable<any> {
    return of(ListPlan);
  }
  getHomeFlags(): Observable<any> {
    return of(HOME_FLAGS);
  }
  getBankInfo(): Observable<any> {
    return of(bankInfo);
  }
  getSubDiv(): Observable<any> {
    return of(divSub);
  }

  getparticipantListMock(): Observable<any> {
    return of(ParticipantList);
  }

  getParticipantMorningStarDataMock(): Observable<any> {
    return of(ParticipantMorningStar);
  }
  getParticipantAdminSettingMock(): Observable<any> {
    return of(ParticipantAdminSettingMock);
  }

  getParticipantStatusListMock(): Observable<any> {
    return of(ParticipantStatusListMock);
  }
  getParticipantOptionalDataFieldsMock(): Observable<any> {
    return of(ParticipantOptionalData);
  }
  getParticipantOtherDivSubMock(): Observable<any> {
    return of(ParticipantOtherDivSub);
  }
  getParticipantOtherExpandedDivSub(): Observable<any> {
    return of(ParticipantOtherExpandedDivSub);
  }
  getParticipantContributionDataMock(): Observable<any> {
    return of(PariticipantContributionData);
  }
  getParticipantParticipantFundData(): Observable<any> {
    return of(ParticipantFundData);
  }

  getAdminFlags(): Observable<any> {
    return of(ADMIN_FLAGS);
  }
  // Admin - Plansetup
  getPlanSetup(): Observable<any> {
    return of(planSetup);
  }
  getMoneySource(): Observable<any> {
    return of(moneySources);
  }
  getInvestments(): Observable<any> {
    return of(investments);
  }
  getPlanOptions(): Observable<any> {
    return of(displayOptions);
  }
  getEnrollmentList(): Observable<any> {
    return of(enrollmentStatusCode);
  }
  savePlanSetup(): Observable<any> {
    return of(MockSuccessResponse);
  }
  successMock(): Observable<any> {
    return of(MockSuccessResponse);
  }
  // Admin Plansetup ends

  // file Import
  postWithFile(): Observable<any> {
    return of(templateData);
  }
  getTemplateOtions(): Observable<any> {
    return of(templateOptions);
  }

  getAvailableCols(): Observable<any> {
    return of(columnList);
  }
  getValidationData(): Observable<any> {
    return of(validationData);
    // return of(validationDataWithErrors);
  }
  getExistingTemplate(): Observable<any> {
    return of(existingTemplate);
  }
  doAuthenticate(): Observable<any> {
    return of(MockSuccessResponse);
  }
  getTerminationReason(): Observable<any> {
    return of(TerminationReasonList);
  }
  getDataElements(): Observable<any> {
    return of(DataElementsList);
  }
  saveTemplate() {
    return of(saveTemplateResponse);
  }
  getUpdateDataResponse() {
    return of(updateDataResponse);
  }
  getDEOptions() {
    return of(DataElementOptions);
  }
}
