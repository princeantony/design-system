import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaRadioComponent } from './voya-radio.component';

describe('VoyaRadioComponent', () => {
  let component: VoyaRadioComponent;
  let fixture: ComponentFixture<VoyaRadioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaRadioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaRadioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
