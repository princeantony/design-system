import { Injectable } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable, Subject, Subscription } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';

import { ENV } from '../../../shared/constants/app.constants';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { ParticipantOptionalFields } from '../components/participant-optional-data/participant-optional-fields';
import * as Participant from '../model/participant.model';
import { ParticipantOptionSetting } from '../model/participant.model';

@Injectable({
  providedIn: 'root'
})
export class ParticipantsService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService,
    private commonService: CommonService
  ) {}

  private participantData: Participant.ParticipantData = new Participant.ParticipantData();
  private participantOtherDivSub: Participant.Option[];
  private participantOtherExpandedDivSub: Participant.Option[];
  private participantOptionSetting: ParticipantOptionSetting;
  private participantStatusList: Participant.Option[];

  private participantOtherDivSubChanged = new Subject<string>();
  private subscription: Subscription;

  setParticipantOptionSetting() {}

  getParticipantOptionSetting(): ParticipantOptionSetting {
    if (this.participantOptionSetting) {
      // TODO: Clear participant option setting when ever you change a plan.
      return this.participantOptionSetting;
    }
    if (ENV.TEST) {
      this.mockService.getParticipantAdminSettingMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.participantOptionSetting = result.data;
        }
      });
    }
    return this.participantOptionSetting;
  }

  getParticipantStatus(): string {
    if (this.participantOptionSetting) {
      this.getParticipantStatusList();
      const statusItem: Participant.Option = this.participantStatusList.find(
        item => item.value === this.participantOptionSetting.statusCode
      );
      if (statusItem) {
        return statusItem.displayText;
      }
    }
    return '';
  }

  getParticipantStatusList(): void {
    if (ENV.TEST) {
      this.mockService.getParticipantStatusListMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.participantStatusList = result.data;
        }
      });
    }
  }

  getParticipantList(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getparticipantListMock()
      : this.mockService.getparticipantListMock();
  }

  getParticipantListBySSN(ssn: string): Participant.ParticipantItem[] {
    let participantList: Participant.ParticipantItem[] = [];
    if (ENV.TEST) {
      let participantListByName: Participant.ParticipantItem[] = [];
      this.mockService.getparticipantListMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          participantList = result.data;
        }
      });

      participantListByName = participantList.filter(
        (value: Participant.ParticipantItem, index, array) => {
          if (value.ssn.indexOf(ssn) !== -1) {
            return true;
          }
          return false;
        }
      );
      return participantListByName;
    } else {
      return participantList;
    }
  }

  getParticipantListByLastName(name: string): Participant.ParticipantItem[] {
    let participantList: Participant.ParticipantItem[] = [];
    if (ENV.TEST) {
      let participantListByName: Participant.ParticipantItem[] = [];
      this.mockService.getparticipantListMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          participantList = result.data;
        }
      });

      participantListByName = participantList.filter(
        (value: Participant.ParticipantItem, index, array) => {
          if (value.name.toLowerCase().indexOf(name.toLowerCase()) !== -1) {
            return true;
          }
          return false;
        }
      );
      return participantListByName;
    } else {
      return participantList;
    }
  }

  getParticipantMorningStarData(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getParticipantMorningStarDataMock()
      : this.mockService.getParticipantMorningStarDataMock();
  }

  getParticipantData(): Participant.ParticipantData {
    return this.participantData;
  }

  toFormGroup(fields: ParticipantOptionalFields<any>[]) {
    const group: any = {};

    fields.forEach(field => {
      group[field.key] = new FormControl(field.value || '');
    });
    return new FormGroup(group);
  }

  getParticipantOptionalDataFields(): Participant.ParticipantOptionalField[] {
    if (ENV.TEST) {
      if (this.participantData.optionalData.length > 0) {
        return this.participantData.optionalData;
      } else {
        this.mockService
          .getParticipantOptionalDataFieldsMock()
          .subscribe(result => {
            if (result.status === 'SUCCESS') {
              this.participantData.optionalData = result.data;
            }
          });
      }
    } else {
      return [] as Participant.ParticipantOptionalField[];
    }

    return [] as Participant.ParticipantOptionalField[];
  }

  getParticipantContributionData(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getParticipantContributionDataMock()
      : this.mockService.getParticipantContributionDataMock();
  }

  getParticipantParticipantFundData(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getParticipantParticipantFundData()
      : this.mockService.getParticipantParticipantFundData();
  }

  getParticipantOtherDivSub(selectedValue: string): Participant.Option[] {
    if (ENV.TEST) {
      const isRangeDivSub: RegExp = RegExp('^([A-Z]|[a-z]){2}\\d{3}$');
      if (selectedValue === 'O!') {
        this.mockService.getParticipantOtherDivSubMock().subscribe(result => {
          if (result.status === 'SUCCESS') {
            this.participantOtherDivSub = result.data;
          }
        });
        return this.participantOtherDivSub;
      } else if (isRangeDivSub.test(selectedValue)) {
        this.mockService
          .getParticipantOtherExpandedDivSub()
          .subscribe(result => {
            if (result.status === 'SUCCESS') {
              this.participantOtherExpandedDivSub = result.data;
            }
          });
        return this.participantOtherExpandedDivSub;
      } else {
        this.participantOtherExpandedDivSub = <Participant.Option[]>[];
        this.participantOtherDivSub = <Participant.Option[]>[];
      }
    }
  }

  addParticpantRequiredData(
    participantRequiredData: Participant.IParticipantRequiredData
  ) {
    this.participantData.requiredData = participantRequiredData;
    console.log(this.participantData);
  }

  addParticipantOptionalData(
    participantOptionalData: Participant.ParticipantOptionalField[]
  ) {
    this.participantData.optionalData = participantOptionalData;
    console.log(this.participantData);
  }

  addParticipantContributionElectionData(
    participantContributionElectionData: Participant.ParticipantContribution
  ) {
    this.participantData.participantContribution = participantContributionElectionData;
    console.log(this.participantData);
  }

  addparticipantContributionInvestmentData(
    participantContributionInvestmentData: Participant.IParticipantFundSources
  ) {
    this.participantData.participantContributionInvestmentData = participantContributionInvestmentData;
    console.log(this.participantData);
  }

  getParticipantDataToSubmit(): Participant.ParticipantSubmitData {
    const _participant: Participant.ParticipantSubmitData = {} as Participant.ParticipantSubmitData;
    _participant.participantInfo = this.getParticipantInfoSubmitData();
    _participant.optionalDataElement = this.getParticipantOptionalDataElementSubmitData();
    _participant.contributionElections = this.getContributionsSubmitData();
    _participant.catchUpContributionElections = this.getCatchupContributionsSubmitData();
    _participant.investmentElectionsList = this.getInvestmentElectionsListSubmitData();
    return _participant;
  }

  getParticipantInfoSubmitData(): Participant.ParticipantInfo {
    debugger;
    const pInfo: Participant.ParticipantInfo = {} as Participant.ParticipantInfo;
    const info = this.participantData.requiredData;
    pInfo.partSSN = info.ssn;
    pInfo.firstName = info.firstName;
    pInfo.lastName = info.lastName;
    pInfo.middleInitial = info.mName;
    pInfo.address1 = info.addressLine1;
    pInfo.address2 = info.addressLine2;
    pInfo.city = info.city;
    pInfo.state = info.state;
    pInfo.zipCode = info.zip;
    pInfo.country = info.country;
    pInfo.email = info.email;
    //pInfo.statusCode = info.
    //pInfo.backupStatusCode = info
    pInfo.birthDate = info.dateOfBirth;
    pInfo.hireDate = info.dateOfHire;
    //pInfo.rehireDate = info.
    pInfo.termDate = info.terminationDate;
    pInfo.termCode = info.terminationReason;
    //pInfo.defType = info
    //pInfo.catchupDefType = info
    //pInfo.planId = info
    pInfo.enrollFlag = info.enrollFlag;
    //pInfo.newDivsubUpdated = info
    //pInfo.sameAsSource = info
    pInfo.mstarFlag = info.mstarFlag;
    pInfo.qdiaFlag = info.qdiaFlag;
    return pInfo;
  }

  getParticipantOptionalDataElementSubmitData(): Participant.ParticipantCodeValue[] {
    const ODEs: Participant.ParticipantCodeValue[] = [];
    this.participantData.optionalData.forEach(
      <ParticipantOptionalField>(item) => {
        const ODEItem: Participant.ParticipantCodeValue = {
          code: '',
          value: ''
        };
        ODEItem.code = item.key;
        ODEItem.value = item.value;
        ODEs.push(ODEItem);
      }
    );
    return ODEs;
  }

  getContributionsSubmitData(): Participant.ParticipantCodeValue[] {
    const contribs: Participant.ParticipantCodeValue[] = [];
    this.participantData.participantContribution.contribElection.forEach(
      <ParticipantContributionElectionItem>(item) => {
        const contrib: Participant.ParticipantCodeValue = {
          code: '',
          value: ''
        };
        contrib.code = item.key;
        contrib.value = item.value;
        contribs.push(contrib);
      }
    );
    return contribs;
  }

  getCatchupContributionsSubmitData(): Participant.ParticipantCodeValue[] {
    const catchupContribs: Participant.ParticipantCodeValue[] = [];
    this.participantData.participantContribution.catchupContribElection.forEach(
      <ParticipantContributionElectionItem>(item) => {
        const catchupContrib: Participant.ParticipantCodeValue = {
          code: '',
          value: ''
        };
        catchupContrib.code = item.key;
        catchupContrib.value = item.value;
        catchupContribs.push(catchupContrib);
      }
    );
    return catchupContribs;
  }

  getInvestmentElectionsListSubmitData(): Participant.PariticantInvestmentElectionItemSubmit[] {
    const investments: Participant.PariticantInvestmentElectionItemSubmit[] = [];
    this.participantData.participantContributionInvestmentData.fundSources.forEach(
      fSource => {
        let fundSoures: Participant.ParticipantFundSource;
        fundSoures = fSource;
        fundSoures.percents.forEach(percent => {
          const investment: Participant.PariticantInvestmentElectionItemSubmit = {} as Participant.PariticantInvestmentElectionItemSubmit;
          investment.investmentId = percent.investmentId;
          investment.newPercent = percent.currentPercent;
          investment.sourceId = percent.sourceId;
          investments.push(investment);
        });
      }
    );

    return investments;
  }

  updateParticipantData() {}
}
