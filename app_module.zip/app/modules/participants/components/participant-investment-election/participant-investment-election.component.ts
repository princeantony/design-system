import { Component, Input, OnInit } from '@angular/core';
import { ColDef, GridOptions } from 'ag-grid-community';

import { NumericEditorComponent } from '../../../../shared/components/ag-grid/editor/numeric-editor/numeric-editor.component';
import {
  IParticipantFundSources,
  ParticipantFundSource,
  ParticipantFundSourceItem
} from '../../model/participant.model';
import { CellValueChangedEvent, CellEditingStartedEvent } from 'ag-grid';
import { ParticipantsService } from '../../service/participants.service';

@Component({
  selector: 'participant-investment-election',
  templateUrl: './participant-investment-election.component.html',
  styleUrls: ['./participant-investment-election.component.scss']
})
export class ParticipantInvestmentElectionComponent implements OnInit {
  private _participantFundSources: IParticipantFundSources = {} as IParticipantFundSources;
  @Input()
  set participantFundSources(value: IParticipantFundSources) {
    this._participantFundSources = value;
    console.log(this._participantFundSources);
  }
  get participantFundSources() {
    return this._participantFundSources;
  }

  public gridOptions: GridOptions;

  constructor(private participantsService: ParticipantsService) {}
  ngOnInit() {
    this.gridOptions = <GridOptions>{
      rowData: this.createRowData(),
      columnDefs: this.createColumnDefs(),
      context: { componentParent: this },
      frameworkComponents: {
        numericEditorComponent: NumericEditorComponent
      },
      rowHeight: 32,
      singleClickEdit: true,
      stopEditingWhenGridLosesFocus: true
    };
  }
  oncellEditingStarted(event: CellEditingStartedEvent) {
    const field = event.colDef.field;
    const newValue = event.value;
    const rowIndex = event.rowIndex;
    if (
      this.participantFundSources.fundSources[rowIndex].percents[
        this.participantFundSources.fundSources[rowIndex].percents.findIndex(
          item => item.sourceId === field
        )
      ].readOnly
    ) {
      this.gridOptions.api.stopEditing();
    }
  }
  onCellValueChanged(event: CellValueChangedEvent) {
    const field = event.colDef.field;
    const newValue = event.value;
    const rowIndex = event.rowIndex;
    this.participantFundSources.fundSources[rowIndex].percents[
      this.participantFundSources.fundSources[rowIndex].percents.findIndex(
        item => item.sourceId === field
      )
    ].currentPercent = newValue;
  }
  createColumnDefs() {
    const columnsList = this.participantFundSources.sourceMap;
    const gridColumns: ColDef[] = [];

    // Create First Default FundNameColumn
    gridColumns.push({
      field: 'fundName',
      headerName: 'Fund Name',
      editable: false
    });
    // Push one column for each Source item
    if (columnsList) {
      columnsList.forEach(column => {
        gridColumns.push({
          field: column.sourceId,
          headerName: column.sourceName,
          editable: true,
          cellEditor: 'numericEditorComponent',
          valueFormatter: function percentFormatter(params) {
            return params.value + ' %';
          },
          cellClass: 'number-cell'
        });
      });
    }

    return gridColumns;
  }
  createRowData() {
    const fundSources: ParticipantFundSource[] = this.participantFundSources
      .fundSources;
    const rows = [];
    if (fundSources) {
      fundSources.forEach(fundSrc => {
        const rowItem = Object.assign({ fundName: fundSrc.fundName });
        const sources: ParticipantFundSourceItem[] = fundSrc.percents;

        sources.forEach((src: ParticipantFundSourceItem) => {
          Object.assign(rowItem, { [src.sourceId]: src.currentPercent });
        });
        rows.push(rowItem);
      });
    }
    return rows;
  }

  refreshEvenRowsCurrencyData() {
    this.gridOptions.api.forEachNode(rowNode => {
      if (rowNode.data.value % 2 === 0) {
        rowNode.setDataValue(
          'currency',
          rowNode.data.value + Number(Math.random().toFixed(2))
        );
      }
    });
    this.gridOptions.api.refreshCells({ columns: ['currency'] });
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit();
  }
  onNextClick() {
    // De-Serealize row data to FundSources Model
    console.log(this.gridOptions.rowData);
    console.log(this.participantsService.getParticipantDataToSubmit());
  }
}
