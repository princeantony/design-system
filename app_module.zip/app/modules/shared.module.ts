
import { NgModule } from '@angular/core';
import { AgGridModule } from 'ag-grid-angular';
import { ToastModule } from 'ng6-toastr';
import { NgxSpinnerModule } from 'ngx-spinner';
import { HttpClientModule } from '@angular/common/http';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { GridComponent } from '../shared/components/form/voya-grid/grid.component';
import { PlanListComponent } from './plans/components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './plans/pages/plan-selection/plan-selection.component';
import { AdminGridRadioComponent } from './admin/components/admin-grid-radio/admin-grid-radio.component';
import { AdminGridEditButtonComponent } from './admin/components/admin-grid-edit-button/admin-grid-edit-button.component';
import { TemplateGridLinkComponent } from './templates/components/template-grid-link/template-grid-link.component';
import { TemplateGridTextboxComponent } from './templates/components/template-grid-textbox/template-grid-textbox.component';
import { TemplateGridHeaderComponent } from './templates/components/template-grid-header/template-grid-header.component';
import { NumericEditorComponent } from '../shared/components/ag-grid/editor/numeric-editor/numeric-editor.component';
import { SquareRenderer } from '../shared/components/ag-grid/renderer/square-renderer.component';
import { DataElementTextboxComponent } from './admin/components/admin-data-elements/admin-data-element-textbox/data-element-textbox.component';
import { AdminGridTextboxComponent } from './admin/components/admin-grid-textbox/admin-grid-textbox.component';
import { AdminGridCheckboxComponent } from './admin/components/admin-grid-checkbox/admin-grid-checkbox.component';
import { GridLinkComponent } from './bank-information/components/grid-link/grid-link.component';
import { TimeInfoComponent } from '../shared/components/time-info/time-info.component';
import { PageTitleComponent } from '../shared/components/layout/page-title/page-title.component';
import { TitleMessageComponent } from '../shared/components/layout/title-message/title-message.component';
import { BrowserModule } from '@angular/platform-browser';
import { SpinnerComponent } from '../shared/components/layout/spinner/spinner.component';

@NgModule({
  declarations: [
    GridComponent,
    TimeInfoComponent,
    PageTitleComponent,
    TitleMessageComponent,
    SpinnerComponent
   ],
  exports: [
    GridComponent,
    TimeInfoComponent,
    PageTitleComponent,
    TitleMessageComponent,
    SpinnerComponent
  ],
  imports: [
    BrowserModule,
    NgxSpinnerModule,
    AgGridModule.withComponents([
      PlanListComponent,
      PlanSelectionComponent
    ])
  ]

})
export class SharedModule {}
