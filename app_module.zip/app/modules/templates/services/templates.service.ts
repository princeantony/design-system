import { Injectable } from '@angular/core';

import { Observable } from '../../../../../node_modules/rxjs';
import { MockService } from '../../../shared/services/mock.service';
import { SERVICE_URL } from './../../../shared/constants/service.constants';
import { ApiService } from './../../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class TemplatesService {
  constructor(
    private apiService: ApiService,
    private mockService: MockService
  ) {}
  mockuploadFile(): Observable<any> {
    return this.mockService.postWithFile();
  }

  uploadFile(formData: FormData, planNumber: string): Observable<any> {
    return this.apiService.postWithFile(
      SERVICE_URL.FILEIMPORT_MAIN + '666006/fileType/xls/importType/E/file',
      formData
    );
    /* return this.apiService.postWithFile(
      SERVICE_URL.FILEIMPORT_MAIN + planNumber + 'file',
      formData
    ); */
  }

  getMockTemplateOptions(): Observable<any> {
    return this.mockService.getTemplateOtions();
  }
  getTemplateOptions(
    planNumber: string,
    fileType: string,
    importType: string
  ): Observable<any> {
    return this.apiService.get(
      // SERVICE_URL.GET_TEMPLATE_OPTIONS + planNumber + '/filetype/' + fileType
      // 'common/import/plan/40311K/fileType/FXW/importType/E/templates'
      SERVICE_URL.FILEIMPORT_MAIN +
        planNumber +
        '/fileType/' +
        fileType +
        '/importType/' +
        importType +
        '/templates'
    );
  }
  deleteTemplate(planNumber: string, templateObj: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_TEMPLATE_DELETE + planNumber,
      templateObj
    );
  }

  getAvailableColsMock(planNumber: string, type: string): Observable<any> {
    return this.mockService.getAvailableCols();
  }
  getAvailableCols(
    planNumber: string,
    fileType: string,
    importType: string
  ): Observable<any> {
    return this.apiService.get(
      SERVICE_URL.FILEIMPORT_MAIN +
        planNumber +
        '/fileType/' +
        fileType +
        '/importType/' +
        importType +
        '/columnlist'
    );
  }

  saveTemplate(planId: string, templateData: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.FILEIMPORT_MAIN + planId + '/template/save',
      templateData
    );
  }
  saveMockTemplate() {
    return this.mockService.saveTemplate();
  }

  validateMockFileData(): Observable<any> {
    return this.mockService.getValidationData();
  }
  validateFileData(planNumber: string, fileData: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_VALIDATE_FILEDATA + planNumber + '/template/validate',
      fileData
    );
  }
  getMockTemplateDetails(): Observable<any> {
    return this.mockService.getExistingTemplate();
  }
  getTemplateDetails(planNumber: string, templateId: string): Observable<any> {
    return this.apiService.get(
      SERVICE_URL.FILEIMPORT_MAIN +
        planNumber +
        '/templateId/' +
        templateId +
        '/template/info'
    );
  }
  confirmData(url: string, planNumber: string, fileData: any): Observable<any> {
    return this.apiService.post(url + '/plan' + planNumber + SERVICE_URL.POST_TEMPLATE_VERIFY, fileData);
  }
  mockUpdateData(): Observable<any> {
    return this.mockService.getUpdateDataResponse();
  }
  updateData(templateMapping: any): Observable<any> {
    return;
  }
}
