import { Component, OnInit, Input } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-template-modal-error',
  templateUrl: './template-modal-error.component.html',
  styleUrls: ['./template-modal-error.component.scss']
})
export class TemplateModalErrorComponent implements OnInit {
  @Input()
  errorObj: any;

  constructor(private modalService: ModalService) {}

  ngOnInit() {}
  closePopup() {
    this.modalService.close('error-modal');
  }
  onPrint() {
    window.print();
    /* const content = document.getElementById('error-modal');
    // const container = content.getElementsByClassName('container')[0];
    console.log('---------------content', content);
    const winPrint = window.open(
      '',
      '',
      'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0'
    );
    winPrint.document.write(content.innerHTML);
    winPrint.document.close();
    winPrint.focus();
    winPrint.print();
    winPrint.close(); */
  }
}
