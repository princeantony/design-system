import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-data-element-textbox',
  templateUrl: './data-element-textbox.component.html'
})
export class DataElementTextboxComponent implements ICellRendererAngularComp {
  constructor() {}
  public params: any;
  controlName: string;
  value: string;
  shouldShow = false;
  agInit(params: any): void {
    this.params = params;
    this.controlName = params.colDef.field + '_' + params.rowIndex;
    this.value = params.value;
    if(params.data.defaultSortOrder < 999 &&  params.data.defaultSortOrder !== ''){
      this.shouldShow = true;
    }
  }

    onBlur(event: any) {
      const order = event.target.value;
      this.params.context.componentParent.getNewOrder(order);
    }
  refresh(): boolean {
    return false;
  }
}
