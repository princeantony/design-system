import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { PlanService } from 'src/app/modules/plans/services/plan.service';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';

@Component({
    selector: 'app-admin-plan-copy',
    templateUrl: './admin-plan-copy.component.html',
    styleUrls: ['./admin-plan-copy.component.scss']
  })

export class AdminPlanCopyComponent implements OnInit{
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    planCopyColumnDefs:any;
    planCopyData:any;
    private gridApi;
    selected = true;
    errorCount = 0;

    planCopyForm = this.fb.group({
      'allSegments': new FormControl('', Validators.required),
      'generalPlanInfo': new FormControl('', Validators.required),
      'planSources': new FormControl('', Validators.required),
      'planPages': new FormControl('', Validators.required),
      'planErrors': new FormControl('', Validators.required),
      'planDataElements': new FormControl('', Validators.required),
    });
    constructor( private fb: FormBuilder,
       private planService: PlanService,
       private spinner: NgxSpinnerService,
       private router: Router,
       public toastr: ToastsManager,
       vcr: ViewContainerRef
      ) {
       this.planCopyColumnDefs = GRID_CONFIG.PLAN_COPY.COLUMN_DEFS_PLANS;
       this.toastr.setRootViewContainerRef(vcr);
      }

    ngOnInit() {
      this.hidePageTitle = false;
      this.subTitle = 'Plan Copy';
      this.planNumber = PayAdminGlobalState.planNumber ;
      this.getPlans();
    }

    onSubmit(){
      console.log (this.gridApi.getSelectedRows());
    }

    gridReady(params) {
      console.log(params.api);
      this.gridApi = params.api;
    }
    getPlans(): void {
      this.planService.getPlans().subscribe(plans => {
        this.spinner.hide();
        if (plans.status === APP_CONST.SUCCESS) {
          this.planCopyData = plans.data;
          // PayAdminGlobalState.planListState = this.planData; // will enable if we use local state
        } else {
          this.toastr.error(plans.error.msg, plans.status + ' !', { showCloseButton: true });
        }
      },
        (
          err => {
            this.spinner.hide();
            this.errorCount ++;
            if (err.error && err.error.text)
            {
              if(this.errorCount < 4 )
              {
                this.getPlans();
              }
            } else{
              this.spinner.hide();
             this.toastr.error('Error while fetching Plans. Try again!', err.error.status + ' !', { showCloseButton: true });
            }
          }
        ));
    }
    selectAll(value: any) {
      if (value){
        this.planCopyForm.controls['generalPlanInfo'].setValue(true);
        this.planCopyForm.controls['planSources'].setValue(true);
        this.planCopyForm.controls['planPages'].setValue(true);
        this.planCopyForm.controls['planErrors'].setValue(true);
        this.planCopyForm.controls['planDataElements'].setValue(true);
      }

      if (value){
        this.planCopyForm.controls['generalPlanInfo'].setValue(false);
        this.planCopyForm.controls['planSources'].setValue(false);
        this.planCopyForm.controls['planPages'].setValue(false);
        this.planCopyForm.controls['planErrors'].setValue(false);
        this.planCopyForm.controls['planDataElements'].setValue(false);
      }


    }
}
