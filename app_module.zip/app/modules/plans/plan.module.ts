
import { NgModule } from '@angular/core';
import { PlanListComponent } from './components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './pages/plan-selection/plan-selection.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
const planRoutes: Routes = [
  {
    path: 'plans',
    component: PlanSelectionComponent,
    data: { title: 'Plan List' }
  }];
@NgModule({
  declarations: [
    PlanListComponent,
    PlanSelectionComponent
   ],
  exports: [
    PlanListComponent,
    PlanSelectionComponent
  ],
  imports: [
    SharedModule,
    RouterModule.forRoot(
      planRoutes,
    )
  ],
})
export class PlanModule {}
