import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html'
})
export class LoginPageComponent implements OnInit {
  constructor(private router: Router) {}
  ngOnInit() {
    if (PayAdminGlobalState.loginUser && PayAdminGlobalState.loginStatus)
    {
     this.router.navigate(['/app']);
    }

  }
}

