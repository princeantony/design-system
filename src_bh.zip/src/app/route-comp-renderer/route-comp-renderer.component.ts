import { Component} from '@angular/core';

import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-route-comp-renderer',
  templateUrl: './route-comp-renderer.component.html',
  styleUrls: ['./route-comp-renderer.component.scss']
})
export class RouteCompRendererComponent implements ICellRendererAngularComp {

  constructor() { }

  public params: any;
 test;

    agInit(params: any): void {
      console.log("--------params",params );
        this.params = params;
       //this.test =this.params.value; 
    }
    getData(){
      console.log("-------getData");
      this.test =this.params.value; 
    }

  /*   public invokeParentMethod() {
      console.log("---------invokeParentMethod");
     // this.params.context.componentParent.methodFromParent(this.params.value);
  } */

    

    refresh(): boolean {
        return false;
    }

}
