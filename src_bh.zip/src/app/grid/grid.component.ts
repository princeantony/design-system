import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridNg2 } from 'ag-grid-angular';
import { RouteCompRendererComponent } from '.././route-comp-renderer/route-comp-renderer.component';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss']
})
export class GridComponent  {

  @ViewChild('agGrid') agGrid:AgGridNg2;
  title = 'app';
  private frameworkComponents;
  private columnDefs;
  private rowData;
  private context;
 
test ="Hello!!!";
 
constructor(private http:HttpClient){
 // this.context = {componentParent:this};
  this.columnDefs = [
    {headerName: 'Make', field: 'make' , 
   cellRendererFramework: RouteCompRendererComponent,
    //cellRenderer: "routeCompRendererComponent",
    cellRendererParams: {
      inRouterLink: 'toyota',
  } 
    /*cellRenderer:  function(params) {
      return '<a href ="/toyota">'+ params.value+'</a>' } */
    },
    {headerName: 'Model', field: 'model' ,filter: 'agTextColumnFilter'},
    {headerName: 'Price', field: 'price'}
];



//this.frameworkComponents = {routeCompRenderer: RouteCompRendererComponent};
/* autoGroupColumnDef = {
  headerName: 'Price',
  field: 'price',
  cellRenderer: 'agGroupCellRenderer',
  cellRendererParams: {
      checkbox: true
  }
}; */




  this.rowData = this.http.get('https://api.myjson.com/bins/ly7d1');
  /* this.context = { componentParent: this };
  this.frameworkComponents = {
    routeCompRendererComponent: RouteCompRendererComponent};
  
} */

/* methodFromParent(cell) {
  alert("Parent Component Method from " + cell + "!");
} */


/* getSelectedRows() {
  const selectedNodes = this.agGrid.api.getSelectedNodes();
  console.log("-----selectedNodes",selectedNodes);
  const selectedData = selectedNodes.map( node => node.data );
  console.log("-----selectedData",selectedData);
  const selectedDataStringPresentation = selectedData.map( node => node.make + ' ' + node.model).join(', ');
  alert(`Selected nodes: ${selectedDataStringPresentation}`);
} */

}
}
