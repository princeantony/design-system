import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-toyota',
  templateUrl: './toyota.component.html',
  styleUrls: ['./toyota.component.scss']
})
export class ToyotaComponent implements OnInit {
  @Input() test;


  constructor() { 
    console.log("-----------test",this.test);
  }

  ngOnInit() {
    console.log("-----------test",this.test);
    
  }
  

}
