import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import _ from 'lodash';
import { AppState } from '../../../../shared/store/state/app.state';
import {  State } from '@ngrx/store';
@Component({
  selector: 'app-pay-admin-home',
  templateUrl: './pay-admin-home.component.html',
  styleUrls: ['./pay-admin-home.component.scss']
})
export class PayAdminHomeComponent implements OnDestroy {
hidePageTitle = false;
 planNumber: string;
 private sub: any;
 planListItem: any;
 selectedPlan : any;
 planTitle : string;

  constructor(private route: ActivatedRoute, private state: State<AppState>) {}

ngOnInit(params) {
  this.planListItem = this.state.getValue().planList;
  if(this.planListItem != undefined)
  {
  this.sub = this.route.params.subscribe(params => {
       this.planNumber = params['planId']; 
      this.selectedPlan = _.find(this.planListItem, ['planNumber', this.planNumber]);
      this.planTitle = this.selectedPlan.planNumber + "-" + this.selectedPlan.planName;
     
    });
  }
}

   ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
