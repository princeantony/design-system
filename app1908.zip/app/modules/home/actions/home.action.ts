import{ACTION_TYPE} from '../../../shared/constants/app.constants';

import { Action } from '@ngrx/store'

export class HomeAction implements Action {
    readonly type = ACTION_TYPE.HOME_FLAG;
    
    constructor(public homeFlag: any) {
    }
    
}