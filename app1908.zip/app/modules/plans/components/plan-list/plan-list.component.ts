import { Store, State } from '@ngrx/store';
import { Component, OnInit} from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {GRID_CONFIG,APP_CONST} from '../../../../shared/constants/app.constants';
import {PlanListAction, UserListAction} from '../../../plans/actions/plan-list.action';
import {MockService} from '../../../../shared/services/mock.service';
import {ListPlan} from '../../../../shared/mocks/listPlan';
import {ApiService} from '../../../../shared/services/api.service';
import {SERVICE_URL} from '../../../../shared/constants/service.constants'
import {LoginUser} from '../../../../shared/mocks/login-user.mock';
import {AppState} from '../../../../shared/store/state/app.state';
import {IPlanLight} from '../../../../shared/interfaces/plan-light.interface';
import { PlanService } from '../../services/plan.service';
import { AuthService } from '../../services/auth.service';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss']
})
@Injectable()
export class PlanListComponent implements OnInit {
columnDefs: any;
rowData: any;
width;
planListItem : any;
userListItem : any;
constructor(
  private store: Store<AppState>,
  private state: State<AppState>,
  private planService: PlanService,
  private authService: AuthService,
  private spinner: NgxSpinnerService
) 
  {
 
  this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
  this.width= GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
}

  ngOnInit() {
  this.planListItem = this.state.getValue().planList;
  if(this.planListItem === undefined)
  {
 //this.login(); //for actual service 
 this.spinner.show();
 this.getMockPlans();
  }
  else
  {
  this.rowData = this.planListItem.planList;
  }

  }
  getPlans(): void {
    this.planService.getPlans().subscribe(plans => {
      this.spinner.hide();
      if(plans.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.rowData = plans.data;
      this.store.dispatch(new PlanListAction({planList: plans.data }) )
      }
    });
  }
  login() : void{
   this.authService.doAuthenticte(LoginUser).subscribe(loginInfo => { 
   if(loginInfo.status === APP_CONST.LOGIN_SUCCESS) 
   this.getPlans();
  });
  }
  getUsers() : void{
    this.planService.getUsers().subscribe(users => {
      this.spinner.hide();
      this.rowData = users;
      this.store.dispatch(new UserListAction({userList: users }) )
    });
    
  }
  getMockPlans() : void{
    this.planService.getMockPlans().subscribe(plans => {
      this.spinner.hide();
      if(plans.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.rowData = plans.data;
      this.store.dispatch(new PlanListAction({planList: plans.data }) )
      }
    });
    
  }
}
