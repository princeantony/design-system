export const SERVICE_URL=
{
    APP_URL: "https://jsonplaceholder.typicode.com/",// to test
   // APP_URL: "http://localhost:2608/payadmin/ws/ers/service/",
    GET_EXT_EMPLOYEES_URL: 'users', // to test
    GET_DIRECT_LOGIN_URL: 'login/direct',
    GET_LISTPLAN_URL: 'plans',
    GET_HOME_URL: 'home'
};