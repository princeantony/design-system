import { ActionReducer, Action } from '@ngrx/store';
import{ACTION_TYPE} from '../../constants/app.constants';

export function UserReducer(state: null, action) {
	 switch (action.type) {
        case ACTION_TYPE.LIST_USER:
            return Object.assign({}, state, action.userList);
		default:
			return state;
	}
}