import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GridOptions } from 'ag-grid-community';
import { SSNDirective } from 'src/app/shared/directives/voya-ssn.directive';
import { VoyaSSNPipe } from 'src/app/shared/pipes/voya-SSN.pipe';
import { ValidatorsService } from 'src/app/shared/services/validators.service';

import { ParticipantItem } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';

enum ParticipantSearchType {
  SSN = 'Search By SSN',
  NAME = 'Search By Last Name'
}
@Component({
  selector: 'app-participant-search',
  templateUrl: './participant-search.component.html',
  styleUrls: ['./participant-search.component.scss'],
  providers: [VoyaSSNPipe, SSNDirective]
})
export class ParticipantSearchComponent implements OnInit {
  private SearchType = ParticipantSearchType;
  private participantSearchTypeList = [];
  private participantSearchForm: FormGroup = new FormGroup({});
  constructor(
    private participantService: ParticipantsService,
    private router: Router,
    private validatorService: ValidatorsService
  ) {}
  private participantList: ParticipantItem[] = [] as ParticipantItem[];
  private participantSSN: string;
  private participantLastName: string;
  private participantSearchType: string;
  public gridOptions: GridOptions;
  ngOnInit() {
    this.participantSearchTypeList = [
      { displayText: 'Search By SSN', value: 'SSN' },
      { displayText: 'Search By Last Name', value: 'NAME' }
    ];
    this.participantSSN = this.participantLastName = '';
    this.participantSearchType = 'SSN';

    this.participantSearchForm = new FormGroup({
      searchSSNInput: new FormControl(this.participantSSN, [
        Validators.required
      ]),
      searchLastNameInput: new FormControl(this.participantLastName),
      searchType: new FormControl(this.participantSearchType)
    });

    this.gridOptions = <GridOptions>{
      rowData: this.participantList,
      columnDefs: [
        {
          field: 'ssn',
          headerName: 'Social Security Number',
          valueFormatter: this.ssnFormatter,
          width: 150
        },
        {
          field: 'name',
          headerName: 'Participant Name'
        }
      ],
      context: { componentParent: this },
      rowHeight: 32
    };
  }

  ssnFormatter(params) {
    const separator = '-';
    let value = params.value;
    let pipedSSN: string = value;
    if (value && value.replace(separator, '').length === 9) {
      value = value.replace(/-/g, ''); // value = 123456789
      pipedSSN =
        value.slice(0, 3) +
        separator +
        value.slice(3, 5) +
        separator +
        value.slice(5);
    }
    return pipedSSN;
  }

  onParticipantSearch() {
    // Clear store on selecting a participant
    this.participantService.resetParticipantStore();
    const searchType = this.participantSearchForm.controls['searchType'].value;
    if (searchType === 'SSN') {
      // TODO: get required data and update store Got to required data component and fill the form
      this.participantService
        .getParticipantBySSN$(
          this.participantSearchForm.controls['searchSSNInput'].value.split('-').join('')
        )
        .subscribe(res => {
          if (res.status === 'SUCCESS') {
            // TODO: Handle type checking here
            ParticipantStore.ParticipantData.requiredData = res.data;
            ParticipantStore.ParticipantData.requiredData.ssn = this.participantSearchForm.controls[
              'searchSSNInput'
            ].value;
            this.router.navigate(['UpdateParticipant']);
          }
        });
    } else if (searchType === 'NAME') {
      this.participantService
        .getParticipantListByLastName$(
          this.participantSearchForm.controls['searchLastNameInput'].value
        )
        .subscribe(res => {
          if (res.status === 'SUCCESS') {
            this.participantList = res.data;
          }
          this.participantSearchForm.controls['searchSSNInput'].setValue('');
          this.participantSearchForm.controls['searchLastNameInput'].setValue(
            ''
          );
          this.participantSearchForm.controls['searchType'].setValue('SSN');

          this.gridOptions.rowData = this.participantList;
        });
    }
  }

  debugg() {
    console.log(this.participantSearchForm.controls['searchSSNInput']);
    console.log(this.participantSearchForm.controls['searchLastNameInput']);
  }

  onParticipantSelect(params) {
    // Clear store on selecting a participant
    this.participantService.resetParticipantStore();
    console.log(params.data.ssn);
    // TODO: get required data and update store Got to required data component and fill the form
    this.participantService
      .getParticipantBySSN$(params.data.ssn)
      .subscribe(res => {
        if (res.status === 'SUCCESS') {
          // TODO: Handle type checking here
          ParticipantStore.ParticipantData.requiredData = res.data;
          ParticipantStore.ParticipantData.requiredData.ssn = params.data.ssn;
          this.router.navigate(['UpdateParticipant']);
        }
      });
    this.router.navigate(['UpdateParticipant']);
  }

  onParticipantSearchByChange(value) {
    this.participantSearchType = value;
    this.participantSearchForm.controls['searchSSNInput'].setValue('');
    this.participantSearchForm.controls['searchLastNameInput'].setValue('');
  }

  onBackClicked() {
    if (this.participantList.length > 0) {
      this.participantList = [];
      this.participantSearchForm.reset();
    }
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit();
  }
}
