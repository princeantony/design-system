import { ParticipantOptionSetting } from '../model/participant.model';
import * as Participant from '../model/participant.model';

export class ParticipantStore {
  static Active = false;
  static PlanID: string;
  static Divsub: string;
  static StatusCode: string;
  static Status: string;
  static ParticipantOptionSetting: ParticipantOptionSetting = new ParticipantOptionSetting();
  static ParticipantStatusList: Participant.Option[];
  static ParticipantData: Participant.ParticipantData = new Participant.ParticipantData();
}
