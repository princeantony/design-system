import { Injectable } from '@angular/core';

import { DataElement, IDeDisplayOrder } from '../models/data-element-model';
@Injectable({
  providedIn: 'root'
})
export class AdminDataService {
  static dataElementId: string;
  static dataElementNewOrder: IDeDisplayOrder[];
  static optionCode: string;
  static dataElements: DataElement[];
  static dataElement: DataElement;
  static dataElementOptions: any[];
  static dataElementOption: any;
  static successMsg: string;
  isValidNewOrder(newOrder): boolean {
    return true;
  }

}
