import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { PageListItems } from '../../../shared/config/page-security.config';
import { ENV } from '../../../shared/constants/app.constants';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { IPageList } from '../../../shared/interfaces/page-list.interface';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';

@Injectable({
  providedIn: 'root'
})
export class AdminPageSetupService {
  constructor(private mockService: MockService,  private apiService: ApiService) {}

  // Page security mock methods
  getMockPageSettings(planNumber: string): Observable<any> {
    return this.mockService.getHomeFlags();
  }

   savePageSettings(updatedPageSettings: any, planNumber: string): Observable<any> {
    return this.apiService.put(SERVICE_URL.GET_PAGE_INFO_URL+planNumber,updatedPageSettings);
  }

 getPageSettings(planNumber: string): Observable<any> {
  return (ENV.TEST)
  ?  this.getMockPageSettings(planNumber)
  : this.apiService.get(SERVICE_URL.GET_PAGE_INFO_URL+ planNumber)
}
 getPageList(pageFlag: any) : Partial<IPageList>[] {
    const pagesToBind: Partial<IPageList>[] = [];
    PageListItems.forEach(page => {
      if (pageFlag[page.key]) {
        page.value = true;

      }

       if (page.subItems) {
        page.subItems.forEach(subPage => {
          if (pageFlag[subPage.key]) {
            subPage.value = true;
          }
        });
      }
      pagesToBind.push(page);
    });

    return pagesToBind;
  }
}
