import { Component, Input, OnInit } from '@angular/core';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';

@Component({
  selector: 'app-title-message',
  templateUrl: './title-message.component.html',
  styleUrls: ['./title-message.component.scss']
})
export class TitleMessageComponent implements OnInit {
  @Input() message;
  @Input() showPrint = true;
  constructor(
              private route: ActivatedRoute,
              private router: Router) { }
  ngOnInit() {
  }
  takePrint(){

    if(PayAdminGlobalState.previousPage === '/bankInfo/confirm') {
    this.router.navigate(['home/print']);
    }
  }
}

