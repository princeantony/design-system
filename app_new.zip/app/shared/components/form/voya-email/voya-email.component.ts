import { Component, forwardRef, OnInit } from '@angular/core';
import {
  ControlValueAccessor,
  FormControl,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidationErrors,
  Validator,
  Validators,
} from '@angular/forms';

import { BaseInputComponent } from '../base-input/base-input.component';

export const INPUT_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => VoyaEmailComponent),
  multi: true
};

const noop = () => {};
@Component({
  selector: 'voya-email',
  templateUrl: './voya-email.component.html',
  styleUrls: ['./voya-email.component.scss'],
  providers: [
    INPUT_VALUE_ACCESSOR,
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => VoyaEmailComponent),
      multi: true
    }
  ]
})
export class VoyaEmailComponent extends BaseInputComponent
  implements OnInit, ControlValueAccessor, Validator {
  private _value: any = '';
  isLabelHidden: boolean;
  ngOnInit() {
    this.isLabelHidden = false;
  }

  get value(): any {
    return this._value;
  }
  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  onTouched(event: any) {
    if (event.target.value === '') {
      this.isLabelHidden = true;
    }
    if (event.target.value !== '') {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus() {
    this.isLabelHidden = false;
  }

  propagateChange = (_: any) => {};

  writeValue(value: string): void {
    this._value = value || '';
    if (this._value.length > 0) {
      this.isLabelHidden = false;
    }
    if (this._value.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  validate(ctrl: FormControl): ValidationErrors | null {
    if (this.isRequired) {
      return Validators.compose([Validators.required, Validators.email])(ctrl);
    } else {
      return Validators.compose([Validators.email])(ctrl);
    }
  }
}
