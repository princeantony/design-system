import { Component, forwardRef, Input, OnInit } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

import {
  NgbDateParserFormatter,
  NgbCalendar,
  NgbDateStruct
} from '../../../../../../node_modules/@ng-bootstrap/ng-bootstrap';
import { BaseInputComponent } from '../base-input/base-input.component';
import { NgbDateCustomParserFormatter } from './dateformat';
import { VoyaDatePipe } from 'src/app/shared/pipes/voya-date.pipe';

const noop = () => {};
@Component({
  selector: 'voya-date',
  templateUrl: './voya-date.component.html',
  styleUrls: ['./voya-date.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaDateComponent),
      multi: true
    }
  ]
})
export class VoyaDateComponent extends BaseInputComponent implements OnInit {
  isLabelHidden: boolean;
  model: NgbDateStruct;

  constructor(private calendar: NgbCalendar, voyaDatePipe: VoyaDatePipe) {
    super();
  }
  private _startDate: {
    year: number | null;
    month: number | null;
    day?: number | null;
  } = null;
  private _maxDate: {
    year: number | null;
    month: number | null;
    day?: number | null;
  } = null;
  private _minDate: {
    year: number | null;
    month: number | null;
    day?: number | null;
  } = null;
  private _value: any = '';

  //#region @INPUT() StartDate
  @Input()
  set StartDate(
    value: {
      year: number | null;
      month: number | null;
      day?: number | null;
    } | null
  ) {
    if (value) {
      this._startDate = value;
    } else {
      this._startDate = this.value;
    }
  }
  get StartDate(): {
    year: number | null;
    month: number | null;
    day?: number | null;
  } | null {
    return this._startDate;
  }
  //#endregion

  //#region @INPUT() MaxDate
  @Input()
  set MaxDate(
    value: {
      year: number | null;
      month: number | null;
      day?: number | null;
    } | null
  ) {
    if (value) {
      this._maxDate = value;
    } else {
      const curDate: Date = new Date();
      this._maxDate = {
        year: 2099,
        month: curDate.getMonth()
      };
    }
  }
  get MaxDate(): {
    year: number | null;
    month: number | null;
    day?: number | null;
  } | null {
    return this._maxDate;
  }
  //#endregion

  //#region @INPUT() MinDate
  @Input()
  set MinDate(
    value: {
      year: number | null;
      month: number | null;
      day?: number | null;
    } | null
  ) {
    if (value) {
      this._minDate = value;
    } else {
      const curDate: Date = new Date();
      this._minDate = {
        year: 1900,
        month: curDate.getMonth()
      };
    }
  }
  get MinDate(): {
    year: number | null;
    month: number | null;
    day?: number | null;
  } | null {
    return this._minDate;
  }
  //#endregion

  ngOnInit() {
    this.isLabelHidden = false;
    if (!this.StartDate) {
      this.StartDate = null;
    }
    if (!this.MaxDate) {
      this.MaxDate = null;
    }
    if (!this.MinDate) {
      this.MinDate = null;
    }
  }

  // The internal data model
  // get accessor
  get value(): NgbDateStruct | any {
    return this._value;
  }
  // set accessor including call the onchange callback
  set value(v: NgbDateStruct | any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  // Set touched on blur
  onTouched(event: any) {
    if (event.target.value === '') {
      this.isLabelHidden = true;
    }
    if (event.target.value !== '') {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus() {
    this.isLabelHidden = false;
  }

  writeValue(value: string): void {
    this._value = value || null;
    if (this._value === null) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  showHideLabel(value: any) {
    if (!this.value) {
      this.isLabelHidden = true;
    } else {
      this.isLabelHidden = false;
    }
  }
  onDateSelection(value) {}
}
