export interface InputConfig {
  id: string;
  class?: string;
  name: string;
  type: string;
  label: string;
  placeholder: string;

  required?: boolean;
  disabled?: boolean;
  readOnly?: boolean;

  pattern?: string;
  maxlength?: number;
  min?: number;
  max?: number;

  rows?: number;
  error: string;
}
