export const BatchParticipantDivisionList=
{ "status": "SUCCESS",
"data": [
    {
        "id": "1199",
        "text": "1199 Covenant Health System",
        "name": "",
        "phone": "",
        "textOnly": "Covenant Health System"
    },
    {
        "id": "1144",
        "text": "1144 Athena Health System",
        "name": "",
        "phone": "",
        "textOnly": "Athena Health System"
    },
    {
        "id": "1511",
        "text": "1511 Catholic Services",
        "name": "",
        "phone": "",
        "textOnly": "Catholic Services"
    },
    {
        "id": "1198",
        "text": "0098 Covenant Health System",
        "name": "",
        "phone": "",
        "textOnly": "Covenant Health System"
    }
]
}
