import { IPageList } from "../interfaces/page-list.interface";
    export const PageListItems: Partial<IPageList>[] = [
        {
            key: "addEnrollmentPageActive",
            label:"Add/Enrollment",
            value: false,
            subItems:[{
                key: "addEnrollmentImportPageActive",
                label: "Add/Enrollment Import",
                value: false

            }]
        },
        {
            key: "participantUpdatePageActive",
            label: "Participant Update",
            value: false

        },
        {
            key: "batchParticipantUpdatePageActive",
            label: "Batch Participant Update",
            value: false,
            subItems:
            [{
                key:"batchParticipantUpdateImportPageActive",
                label: "Batch Participant Update Import",
                value: false
            }]

        },
        {
            key: "contributionPageActive",
            label: "Contribution",
            value: false,

            subItems:[{
                key: "contribImportPageActive",
                label:"Contribution Import",
                value: false
            }]
        },
        {
            key: "loanRepaymentPageActive",
            label: "Loan Repayment",
            value: false,

            subItems:[{
                key: "loanImportPageActive",
                label:"Loan Repayment Import",
                value: false
            }]
        },

        {
            key: "bankInfoPageActive",
            label:"Bank Information",
            value: false
        },
        {
            key: "reportsPageActive",
            label:"Reports",
            value: false
        }
    ]
