// import { Component, OnInit, Input, forwardRef } from "@angular/core";
// import { ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";
// import { VoyaCurrencyPipe } from "../../../../pipes/voya-currency.pipe";
// import { INPUT_TYPE } from "../../../../constants/app.constants";
// import { INPUT_CONFIG } from "../../../../constants/app.constants";

// @Component({
//   selector: "voya-input",
//   providers: [
//     VoyaCurrencyPipe,
//     {
//       provide: NG_VALUE_ACCESSOR,
//       useExisting: forwardRef(() => InputTextComponent),
//       multi: true
//     }
//   ],
//   templateUrl: "./input-text.component.html",
//   styleUrls: ["./input-text.component.scss"]
// })
// export class InputTextComponent implements OnInit, ControlValueAccessor {
//   genericType: string;
//   pattern: string;
//   mask: any;
//   private _InputConfig: INPUT_CONFIG;
//   private defaultConfig: INPUT_CONFIG = {
//     id: "inputID",
//     name: "inputName",
//     type: INPUT_TYPE.alphabets,
//     required: true,
//     label: "Input Text",
//     placeholder: "Please enter value",
//     error: "Please enter valid Value"
//   };

//   propagateChange = (_: any) => {};
//   @Input() _inputValue: string;
//   set InputValue(value: string) {
//     this._inputValue = value || "";
//     this.propagateChange(this._inputValue);
//   }
//   get InputValue(): string {
//     return this._inputValue;
//   }

//   @Input()
//   set InputConfig(config: INPUT_CONFIG | null) {
//     this._InputConfig = config || this.defaultConfig;
//     console.log(this._InputConfig);

//     switch (this._InputConfig.type.trim().toLowerCase()) {
//       case INPUT_TYPE.alphabets: {
//         this.genericType = "alphabets";
//         this.pattern = !this._InputConfig.pattern
//           ? this._InputConfig.pattern
//           : "^[a-zA-Z]*";
//         break;
//       }
//       case INPUT_TYPE.alphanumeric: {
//         this.genericType = "alphanumeric";
//         this.pattern = !this._InputConfig.pattern
//           ? this._InputConfig.pattern
//           : "^[a-zA-Z0-9]*";
//         break;
//       }
//       case INPUT_TYPE.number: {
//         this.genericType = "number";
//         this.pattern = !this._InputConfig.pattern
//           ? this._InputConfig.pattern
//           : "^[0-9]*$";
//         break;
//       }
//       case INPUT_TYPE.email: {
//         this.genericType = "email";
//         break;
//       }
//       case INPUT_TYPE.zip: {
//         this.mask = [
//           /\d/,
//           /\d/,
//           /\d/,
//           /\d/,
//           /\d/,
//           "-",
//           /\d?/,
//           /\d?/,
//           /\d?/,
//           /\d?/
//         ];
//         this.genericType = "zip";
//         this.pattern = !this._InputConfig.pattern
//           ? this._InputConfig.pattern
//           : "^d{5}(?:[-s]?d{4})?$";
//         break;
//       }
//       case INPUT_TYPE.ssn: {
//         this.mask = [
//           /\d/,
//           /\d/,
//           /\d/,
//           "-",
//           /\d/,
//           /\d/,
//           "-",
//           /\d/,
//           /\d/,
//           /\d/,
//           /\d/
//         ];
//         this.genericType = "ssn";
//         this.pattern = !this._InputConfig.pattern
//           ? this._InputConfig.pattern
//           : "^d{3}-?d{2}-?d{4}$";
//         break;
//       }
//       case INPUT_TYPE.currency: {
//         this.genericType = "currency";
//         break;
//       }
//     }
//   }

//   writeValue(value: any): void {
//     if (value) {
//       this.InputValue = value;
//     }
//   }

//   registerOnChange(fn: any): void {
//     this.propagateChange = fn;
//   }
//   registerOnTouched(): void {}
//   setDisabledState?(): void {}

//   ngOnInit() {}
// }
