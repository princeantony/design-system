import { Component, OnInit, forwardRef, Input } from "@angular/core";
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";

export const INPUT_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => VoyaEmailComponent),
  multi: true
};

@Component({
  selector: "voya-email",
  templateUrl: "./voya-email.component.html",
  styleUrls: ["./voya-email.component.scss"],
  providers: [INPUT_VALUE_ACCESSOR]
})
export class VoyaEmailComponent implements OnInit, ControlValueAccessor {
  controlID: string;

  constructor() {}
  isLabelHidden: boolean = false;
  onChange = (_: any) => {};
  onTouched = () => {};
  ngOnInit() {}
  inputValue: string;
  @Input() placeHolderText: string;
  @Input() controlLabel: string;

  //value from [(model)]
  writeValue(value: string): void {
    this.inputValue = value || "";
    if (this.inputValue.length > 0) {
      this.isLabelHidden = false;
    }
    if (this.inputValue.length === 0) {
      this.isLabelHidden = true;
    }
  }
  pushChanges(value: any) {
    this.onChange(value);
  }

  registerOnChange(fn: (_: any) => {}): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: () => {}): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {}

  showHideLabel(event: any) {
    if (event.target.getAttribute("placeholder") && event.target.value === "") {
      this.isLabelHidden = true;
    }
    if (event.target.value !== "") {
      this.isLabelHidden = false;
    }
  }
}
