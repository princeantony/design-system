import { Component, OnInit, Input, forwardRef } from "@angular/core";
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  NG_VALIDATORS,
  Validator,
  FormControl,
  ValidationErrors,
  Validators
} from "@angular/forms";
import { SSNDirective } from "../../../directives/voya-ssn.directive";
import { VoyaSSNPipe } from "../../../pipes/voya-SSN.pipe";

const noop = () => {};

@Component({
  selector: "voya-ssn",
  templateUrl: "./voya-ssn.component.html",
  styleUrls: ["./voya-ssn.component.scss"],
  providers: [
    VoyaSSNPipe,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaSsnComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => VoyaSsnComponent),
      multi: true,
    }
  ]
})
export class VoyaSsnComponent
  implements OnInit, ControlValueAccessor, Validator {
  @Input() control;
  @Input() placeHolderText: string;
  @Input() controlLabel: string;
  private _isRequired: boolean;

  @Input()
  set isRequired(value: boolean) {
    this._isRequired = (value) || true;
  }
  get isRequired(): boolean { return this._isRequired; }


  ngOnInit() {
    this.isLabelHidden = false;
    if(this._isRequired === undefined){
      this._isRequired = true;
    }
  }

  // The internal data model
  private _value: any = '';
  //get accessor
  get value(): any { return this._value; };
  //set accessor including call the onchange callback
  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  //Placeholders for the callbacks
  private _onTouchedCallback: (_:any) => void = noop;
  private _onChangeCallback: (_:any) => void = noop;


  isLabelHidden: boolean;
  //Set touched on blur
  onTouched(event: any){
    if (event.target.value === "") {
      this.isLabelHidden = true;
    }
    if (event.target.value !== "") {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus(){
    this.isLabelHidden = false;
  }

  propagateChange = (_: any) => {};


  writeValue(value: string): void {
    this._value = value || "";
    if (this._value.length > 0) {
      this.isLabelHidden = false;
    }
    if (this._value.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  validate(ctrl: FormControl): ValidationErrors | null {
    return Validators.compose([
      Validators.required,
      Validators.pattern('^\\d{3}-?\\d{2}-?\\d{4}$')
    ])(ctrl);
  }
}
