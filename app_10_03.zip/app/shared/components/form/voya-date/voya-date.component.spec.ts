import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaDateComponent } from './voya-date.component';

describe('VoyaDateComponent', () => {
  let component: VoyaDateComponent;
  let fixture: ComponentFixture<VoyaDateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaDateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaDateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
