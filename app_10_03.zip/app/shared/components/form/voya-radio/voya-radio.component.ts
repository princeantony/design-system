import { Component, OnInit, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from 'node_modules/@angular/forms';

const noop = () => {};
@Component({
  selector: 'voya-radio',
  templateUrl: './voya-radio.component.html',
  styleUrls: ['./voya-radio.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaRadioComponent),
      multi: true
    }
  ]
})
export class VoyaRadioComponent implements OnInit {
  @Input() control;
  @Input() groupLabel: string;
  @Input() items: {label,value}[];
  @Input() controlName: string;
 @Output() Click= new EventEmitter<boolean>();

  ngOnInit() {
  }

  // The internal data model
  private _value: boolean = false;
  //get accessor
  get value(): boolean { return this._value; };
  //set accessor including call the onchange callback
  set value(v: boolean) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }
  onRadioClick()
{
  this.Click.emit(this._value);
}
  //Placeholders for the callbacks
  private _onTouchedCallback: (_:any) => void = noop;
  private _onChangeCallback: (_:any) => void = noop;

  //Set touched on blur
  onTouched(){
    this._onTouchedCallback(null);
  }

  isLabelHidden: boolean;

  writeValue(value: boolean): void {
    this._value = value || false;
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

}
