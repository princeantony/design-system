import { Component, OnInit, Input } from "@angular/core";
import { GridOptions } from "ag-grid";
import { Router } from "@angular/router";
import { PayAdminGlobalState } from "../../../store/pay-admin-global.store";

const pageSlot = 10;
@Component({
  selector: "voya-grid",
  templateUrl: "./grid.component.html"
  
})
export class GridComponent implements OnInit {
  @Input()
  rowData: any;
  @Input()
  columnDefs: any;
  @Input()
  context: any;
  @Input()
  frameworkComponents: any;
  @Input()
  rowClick: boolean;
  @Input()
  floatingFilter : boolean;
  @Input()
  rowStyle 
  @Input()
  headerHeight: any;
  @Input()
  hidePagination: boolean;

 
payAdminGlobal : PayAdminGlobalState;
  private gridApi;
  

  nextStatus = false;
  prevStatus = true;
  selectedPage = 1;
  // maxRange = false;
  btnNum = [];
  totalPages;
  constructor(private router: Router) {}
  onRowClicked(params) {
    if(this.rowClick){
    let planId = params.data.planNumber;
    PayAdminGlobalState.planNumber = planId;
    this.router.navigate(["/home"]);
  }
  }
  ngOnInit() {
    
  }

  onGridReady(params) {
    this.gridApi = params.api;
console.log("in grid comp gridApi", this.gridApi)

    if (this.gridApi) {
      this.initPagination();
      
    }
    
  }

  initPagination(){

    this.totalPages = this.gridApi.paginationGetTotalPages();

      if (this.totalPages > pageSlot) {
        this.createPageSlot(0, pageSlot);
      } else {
        this.createPageSlot(0, this.totalPages);
        this.nextStatus = true;
      }


  }

  createPageSlot(minNum: number, maxNum: number) {
    this.btnNum = [];

    for (let i = minNum; i < maxNum; i++) {
      //debugger;
      if (i + 1 <= this.totalPages) {
        this.btnNum.push(i + 1);
      } else {
        this.nextStatus = true;
      }
    }
    
  }
  gotoPage(pageNum) {
    this.gridApi.paginationGoToPage(pageNum - 1);
    this.selectedPage = pageNum;
  }
  gotoPrev() {
    this.nextStatus = false;
    let firstNum = this.btnNum[0] - (pageSlot + 1);
    let lastNum = firstNum + pageSlot;
    this.createPageSlot(firstNum, lastNum);

    if (firstNum + 1 <= 1) {
      this.prevStatus = true;
    }
  }

  gotoNext() {
    this.prevStatus = false;
    let minNum = this.btnNum[pageSlot - 1];

    let maxNum = minNum + pageSlot;
    console.log(minNum + " : " + maxNum);
    this.createPageSlot(minNum, maxNum);
  }

  onPaginationChanged() {
    
    if (this.gridApi) {
       
        
      this.initPagination();
      
    

    }
  }
}
