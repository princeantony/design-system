import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaEmailComponent } from './voya-email.component';

describe('VoyaEmailComponent', () => {
  let component: VoyaEmailComponent;
  let fixture: ComponentFixture<VoyaEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
