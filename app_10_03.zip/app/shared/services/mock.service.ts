import { Injectable } from "@angular/core";

import { Observable, of } from "rxjs";
import { ListPlan } from "../mocks/listPlan";

import { HOME_FLAGS, ADMIN_FLAGS } from "../mocks/menuItems-mock";
import { bankInfo, divSub } from "../mocks/bankInfo-mock";
import { CountryListMock, StateListMock} from "../mocks/common-mock";

import {
  ParticipantAdminSettingMock,
  ParticipantOptionalData,
  PariticipantContributionData
} from "../mocks/participants-mock";
import { planSetup, moneySources, investments } from "../mocks/plan-setup.mock";


@Injectable({
  providedIn: "root"
})
export class MockService {
  constructor() {}

  getCountryListMock(): Observable<any>{
    return of(CountryListMock);
  }

  getStateListMock(): Observable<any>{
    return of(StateListMock);
  }

  getListPlans(): Observable<any> {
    return of(ListPlan);
  }
  getHomeFlags(): Observable<any> {
    return of(HOME_FLAGS);
  }
  getBankInfo(): Observable<any> {
    return of(bankInfo);
  }
  getSubDiv(): Observable<any> {
    return of(divSub);
  }

  getParticipantAdminSettingMock(): Observable<any> {
    return of(ParticipantAdminSettingMock);
  }

  getOptionalDataFieldsMock(): Observable<any> {
    return of(ParticipantOptionalData);
  }
  getAdminFlags(): Observable<any> {
    return of(ADMIN_FLAGS);
  }

  getContributionDataMock(): Observable<any> {
    return of(PariticipantContributionData);
  }
  getPlanSetup(): Observable<any>{
    return of(planSetup)

  }
   getMoneySource(): Observable<any>{
    return of(moneySources)

  }
   getInvestments(): Observable<any>{
    return of(investments)

  }

}
