import { Injectable } from '@angular/core';
import { Observable } from "rxjs";
import { ApiService } from "./api.service";
import { MockService } from "./mock.service";

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(
    private mockService: MockService,
    private apiService: ApiService
  ) {}

  getCountryListMock(): Observable<any> {
    return this.mockService.getCountryListMock();
  }
  getStateListMock(): Observable<any> {
    return this.mockService.getStateListMock();
  }
}
