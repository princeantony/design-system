export const ParticipantAdminSettingMock = {
  status: "SUCCESS",
  data: {
    QDIAVisible: true,
    QDIAEnabled: false,
    statusText: "00-Active and Eligible for contribution",
    morningStarVisible: true,
    morningStarEnabled: true,
    enrollParticipantVisible: true,
    enrollParticipantEnabled: true,
    emailEnabled: true
  }
};

export const ParticipantOptionalData = {
  status: "SUCCESS",
  data: [
    {
      controlType: "text",
      label: "Employee Number (Optional)",
      value: "i717421",
      required: "true",
      readonly: "false",
      disabled: "false",
      key: "empNumber",
      type: "text",
      option: ""
    },
    {
      controlType: "text",
      label: "Rehire Date",
      value: "",
      required: "true",
      readonly: "false",
      disabled: "false",
      key: "rehireDate",
      type: "date",
      option: ""
    },
    {
      controlType: "dropdown",
      label: "Div Sub",
      value: "0001",
      required: "true",
      readonly: "false",
      disabled: "false",
      key: "divSub",
      type: "",
      option: [
        {
          value: "0",
          label: "select"
        },
        {
          value: "0001",
          label: "0001 BI WEEKLY"
        },
        {
          value: "0099",
          label: "0099 PLAN TO PLAN TRF"
        },
        {
          value: "0033",
          label: "0033 PLAN Dummy"
        }
      ]
    },
    {
      controlType: "dropdown",
      label: "Marital Status",
      value: "0",
      required: "true",
      readonly: "false",
      disabled: "false",
      key: "maritalStatus",
      type: "",
      option: [
        {
          value: "0",
          label: "select"
        },
        {
          value: "married",
          label: "married"
        },
        {
          value: "open",
          label: "open"
        },
        {
          value: "divorced",
          label: "Divorced"
        },
        {
          value: "separated",
          label: "Separated"
        }
      ]
    }
  ]
};

export const PariticipantContributionData = {
  status: "SUCCESS",
  data: {
    invElectChangeAllowed: false,
    mstarFlag: true,
    contribElection: {
      type: "Percent",
      list: [
        {
          key: "contriEEPreTax",
          label: "EE Pre Tax",
          value: "15",
          readonly: false
        },
        {
          key: "contrRoth",
          label: "Roth",
          value: "2",
          readonly: false
        }
      ]
    },
    catchupContribElection: {
      type: "Amount",
      list: [
        {
          key: "catchEEPreTax",
          label: "EE Pre Tax Catch Up",
          value: "25",
          readonly: false
        },
        {
          key: "catchRoth",
          label: "Roth Catch Up",
          value: "10",
          readonly: false
        }
      ]
    },
    investmentElection: {
      acrossAllSourceElectionFlg: "true",
      list: [
        {
          key:"investment1",
          label: "Pre Tax Vol Elections",
          value: "true",
          readonly: false
        },
        {
          key:"investment2",
          label: "Profit Share Elections",
          value: "true",
          readonly: false
        },
        {
          key:"investment3",
          label: "Across ALL Sources Elections",
          value: "true",
          readonly: false
        },
        {
          key:"investment4",
          label: "SH NON-ELECT Elections",
          value: "true",
          readonly: false
        }
      ]
    }
  }
};
