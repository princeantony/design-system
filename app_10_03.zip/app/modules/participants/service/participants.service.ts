import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ApiService } from "../../../shared/services/api.service";
import { MockService } from "../../../shared/services/mock.service";

import { FormControl, FormGroup, Validators } from "@angular/forms";

import { ParticipantOptionalFields } from "../components/participant-optional-data/participant-optional-fields";
import { ParticipantOptionalFieldTextBox } from "../components/participant-optional-data/participant-optional-field-textbox";
import { ParticipantOptionalFieldDropDown } from "../components/participant-optional-data/participant-optional-field-dropdown";

import { IParticipantRequiredData } from "../../../modules/participants/model/participantRequiredData.model";

@Injectable({
  providedIn: "root"
})
export class ParticipantsService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService
  ) {}

  getParticipantAdminSettingMock(): Observable<any> {
    return this.mockService.getParticipantAdminSettingMock();
  }

  toFormGroup(fields: ParticipantOptionalFields<any>[]) {
    let group: any = {};

    fields.forEach(field => {
      // group[field.key] = field.required
      //   ? new FormControl(field.value || "", Validators.required)
      //   : new FormControl(field.value || "");

      group[field.key] = new FormControl(field.value || "");
    });
    return new FormGroup(group);
  }

  getOptionalDataFieldsMock(): Observable<any> {
    return this.mockService.getOptionalDataFieldsMock();
  }

  getContributionDataMock(): Observable<any> {
    return this.mockService.getContributionDataMock();
  }
}
