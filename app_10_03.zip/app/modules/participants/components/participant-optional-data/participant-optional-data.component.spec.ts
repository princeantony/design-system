import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantOptionalDataComponent } from './participant-optional-data.component';

describe('ParticipantOptionalDataComponent', () => {
  let component: ParticipantOptionalDataComponent;
  let fixture: ComponentFixture<ParticipantOptionalDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantOptionalDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantOptionalDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
