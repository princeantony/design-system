import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantRequiredDataComponent } from './participant-required-data.component';

describe('ParticipantRequiredDataComponent', () => {
  let component: ParticipantRequiredDataComponent;
  let fixture: ComponentFixture<ParticipantRequiredDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantRequiredDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantRequiredDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
