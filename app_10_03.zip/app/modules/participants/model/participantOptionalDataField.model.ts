interface option {
  value: string;
  label: string;
}

export interface ParticipantOptionalFieldModel {
  controlType: string;
  label: string;
  value: string;
  required: boolean;
  readonly: boolean;
  disabled: boolean;
  option: option[];
}
