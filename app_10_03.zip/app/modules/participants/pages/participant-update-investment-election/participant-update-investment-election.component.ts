import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-update-investment-election',
  templateUrl: './participant-update-investment-election.component.html',
  styleUrls: ['./participant-update-investment-election.component.scss']
})
export class ParticipantUpdateInvestmentElectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
