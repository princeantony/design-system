import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-add-investment-election',
  templateUrl: './participant-add-investment-election.component.html',
  styleUrls: ['./participant-add-investment-election.component.scss']
})
export class ParticipantAddInvestmentElectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
