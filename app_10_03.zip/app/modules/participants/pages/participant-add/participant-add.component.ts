import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-add',
  templateUrl: './participant-add.component.html',
  styleUrls: ['./participant-add.component.scss']
})
export class ParticipantAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
