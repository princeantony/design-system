import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantAddContributionElectionComponent } from './participant-add-contribution-election.component';

describe('ParticipantAddContributionElectionComponent', () => {
  let component: ParticipantAddContributionElectionComponent;
  let fixture: ComponentFixture<ParticipantAddContributionElectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantAddContributionElectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantAddContributionElectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
