import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-add-optional',
  templateUrl: './participant-add-optional.component.html',
  styleUrls: ['./participant-add-optional.component.scss']
})
export class ParticipantAddOptionalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
