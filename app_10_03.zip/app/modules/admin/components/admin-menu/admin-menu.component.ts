import { Component, OnInit,Input } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import {APP_CONST} from '../../../../shared/constants/app.constants';
import { IMenuItem } from "../../../../shared/interfaces/menu-item.interface";

@Component({
  selector: 'app-admin-menu',
  templateUrl: './admin-menu.component.html'

})
export class AdminMenuComponent implements OnInit {
  @Input() planNumber: string;
  menuItemRows: Array<IMenuItem[]>;

  constructor(private adminService: AdminService) { }

  ngOnInit() {
    this.getMockMenuList();
  }

  getMockMenuList()
  {
    this.adminService.getMockMenuList(this.planNumber).subscribe(flags => {
      //this.spinner.hide();
      if(flags.status === APP_CONST.SUCCESS)
      {
      this.menuItemRows = this.adminService.getMenuItemRows(flags.data);
      //PayAdminGlobalState.homeFlagState = this.menuItemRows;
      }
    });
  }

}
