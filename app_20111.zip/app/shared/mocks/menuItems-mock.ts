import { IApiResponse } from '../interfaces/api-response.interface';

export const HOME_FLAGS: IApiResponse = {
  status: 'SUCCESS',
  data: {
    addEnrollmentImportPageActive: true,
    participantUpdatePageActive: true,
    addEnrollmentPageActive: true,
    bankInfoPageActive: true,
    batchParticipantUpdateImportPageActive: true,
    batchParticipantUpdatePageActive: true,
    contribImportPageActive: true,
    contributionPageActive: true,
    loanImportPageActive: true,
    loanRepaymentPageActive: true,
    adminPageActive: true
  }
};
export const ADMIN_FLAGS: IApiResponse = {
  status: 'SUCCESS',
  data: {
    generalAdministrationPageActive: true,
    terminationInformationPageActive: true,
    matchingPageActive: true,
    errorSuppressionPageActive: true,
    optionalDataElementsPageActive: true,
    pageSecurityPageActive: true,
    copyPlanInfoToOtherPlansPageActive: true,
    updateUserProfilePageActive: true

    // "loanRepaymentPageActive": false
  }
};
