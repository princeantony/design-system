export class DataElement{
  objectID: string;
  subObjectID: string;
  dataElement: string;
  omniName: string;
  overrideName: string;
  overrideFlag: boolean;
  overrideFlagChar: string;
  accOverFlag: boolean;
  enrollmentUsageCode: string;
  participantUsageCode: string;
  contributionUsageCode: string;
  censusUsageCode: string;
  accumulate: true;
  accuOverrideName: string;
  optionalElementID: string;
  defaultSortOrder: number;
  overrideSortOrder: number;
  showLOA: boolean;
  sortOrderOverride: boolean;
}
export interface IDeDisplayOrder{
  objectID: string;
  subObjectID: string;
  dataElement: string;
  omniName: string;
  overrideSortOrder: number;
// constructor(){
//   this.objectID = '';
//   this.subObjectID = '';
//   this.dataElement = '';
//   this.omniName = '';
//   this.overrideSortOrder = 0;
// }
}

