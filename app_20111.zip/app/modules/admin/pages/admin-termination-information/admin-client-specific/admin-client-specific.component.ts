import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';

import { APP_CONST } from '../../../../../shared/constants/app.constants';
import { GRID_CONFIG } from '../../../../../shared/constants/grid.constants';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-client-specific',
  templateUrl: './admin-client-specific.component.html',
  styleUrls: ['./admin-client-specific.component.scss']
})

export class AdminClientSpecificComponent implements OnInit {
  slectDataColumnDefs: any;
  selectData: any;
  hidePageTitle: boolean;
  subTitle: string;
  planNumber: string;
  appContext = APP_CONST.APP_CONTEXT;
  homeFlag: any;
  termCSColumnDefs: any;
  termList: any;
  isCustomMask: boolean;
  style;
  TRItems: any;

  clientSpecificForm = this.fb.group({
    'optionCode': new FormControl('', Validators.required),
    'optionText': new FormControl('', Validators.required),
    'NewTroption': new FormControl(''),
  });

  constructor(private fb: FormBuilder, private adminService: AdminService) {
    this.termCSColumnDefs = GRID_CONFIG.TERMINATION_CLIENT_SPECIFIC.COLUMN_DEFS_REASON
    this.style = { width: '20%' };
  }

  ngOnInit() {
    this.hidePageTitle = false;
    this.subTitle = 'Termination Information';
    this.planNumber = '559985';

    this.getMockTerminationList();
    this.TRItems = [{ label: 'New Termination Reason Option', value: 'NewTroption' }]
  }

  onRadioClick(value: string) {
    // this.isCustomMask =  (value === ADMIN_CONFIG.CUSTOM_MASK_VALUE) ? true : false;
    console.log("clicked");
  }

  getMockTerminationList() {
    this.adminService.getMockTerminationList().subscribe(flags => {
      if (flags.status === APP_CONST.SUCCESS) {
        this.termList = flags.data;
        console.log("---------this.termList", this.termList);
        // PayAdminGlobalState.homeFlagState = this.menuItemRows;
      }
    });

  }

  handleChange() {
    console.log("New Termination reason selected");
  }
}
