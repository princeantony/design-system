import { Component, Input, OnInit, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs/Subject';
import { CommonService } from 'src/app/shared/services/common.service';
import { ModalService } from 'src/app/shared/services/modal.service';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import {
  IParticipantRequiredData,
  Option,
  ParticipantData,
  ParticipantOptionalField,
  ParticipantOptionSetting
} from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';
import { Observable, of } from 'rxjs';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'participant-required-data',
  templateUrl: './participant-required-data.component.html',
  styleUrls: ['./participant-required-data.component.scss']
})
export class ParticipantRequiredDataComponent implements OnInit {
  private messageList: string[] = [];
  private _editMode = false;
  private statusText: string;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }
  countryChanged = new Subject<string>();
  participantData = new ParticipantData();
  participantOptionSetting: ParticipantOptionSetting;
  participantRequiredDataForm: FormGroup;
  requiredData: IParticipantRequiredData;
  participantOptionalDataField: ParticipantOptionalField[];

  countryList: { value: string; displayText: string }[];
  stateList: { value: string; displayText: string }[];

  // "loaStartDateDataElement": "PTPH771",
  // "loaStartReasonDataElement": "PTPH841",
  // "loaEndDateDataElement": "PTPH772",
  // "loaEndReasonDataElement": "PTPH842",

  loaStartDate: string;
  loaStartReason: Option[];
  loaEndDate: string;
  loaEndReason: Option[];

  // parameter to set dataofBirth start Date
  dobStartData: {};
  dohStartDate: {};

  accountTypeItems: { value: string; label: string }[];

  constructor(
    private formBuilder: FormBuilder,
    private participantsService: ParticipantsService,
    private router: Router,
    private commonService: CommonService,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    private modalservice: ModalService,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.spinner.show();
    // Get Country List
    this.countryList = PayAdminGlobalState.countryList;
    this.stateList = PayAdminGlobalState.stateList;

    // Get Option Setting
    this.participantsService.getParticipantOptionSetting().subscribe(result => {
      if (result.status === 'SUCCESS') {
        this.participantOptionSetting = ParticipantStore.ParticipantOptionSetting =
          result.data;

        this.setStartDates();
        console.log(ParticipantStore.ParticipantOptionSetting);
        // Get Status List and find Status
        this.participantsService
          .getParticipantStatusFromStatusList()
          .subscribe(resStatusList => {
            if (resStatusList.status === 'SUCCESS') {
              ParticipantStore.ParticipantStatusList = resStatusList.data;

              if (!this.EditMode) {
                this.statusText = this.participantsService.getParticipantStatus(
                  ParticipantStore.ParticipantOptionSetting.statusCode
                );
              } else {
                // Participant Update Section
                this.statusText = this.participantsService.getParticipantStatus(
                  ParticipantStore.ParticipantData.requiredData.statusCode
                );
                ParticipantStore.Status = this.statusText;
              }

              if (this.EditMode) {
                // Note:  get Participant Required data from store which is prefilled in search participant
                this.participantData = ParticipantStore.ParticipantData;
                if (this.participantOptionSetting.displayLOA) {
                  // "loaStartDateDataElement": "PTPH771", "loaStartReasonDataElement": "PTPH841",
                  // "loaEndDateDataElement": "PTPH772", "loaEndReasonDataElement": "PTPH842",
                  // Get data from Optional Data Element and fill it here.
                  if (
                    this.participantOptionSetting.canLoadOptionalDataElements
                  ) {
                    if (
                      ParticipantStore.ParticipantData.optionalData.length > 0
                    ) {
                      this.participantOptionalDataField =
                        ParticipantStore.ParticipantData.optionalData;
                      this.initLOAFields();
                    } else {
                      this.participantsService
                        .getParticipantOptionalDataFields$()
                        .subscribe(resultODELoaFields => {
                          if (resultODELoaFields.status === 'SUCCESS') {
                            ParticipantStore.ParticipantData.optionalData =
                              resultODELoaFields.data;
                            this.participantOptionalDataField =
                              resultODELoaFields.data;
                            this.initLOAFields();
                          }
                          if (resultODELoaFields.status === 'ERROR') {
                          }
                        });
                    }
                  }
                }
              }
              console.log(this.participantData);
              this.participantData = ParticipantStore.ParticipantData;
              // Initialize Form
              this.initFrom();
              this.onChanges();
              this.spinner.hide();
            }
          });
      }
    });
  }

  initFrom() {
    this.participantRequiredDataForm = this.formBuilder.group({
      ssn: [this.participantData.requiredData.ssn],
      email: [this.participantData.requiredData.email],
      lastName: [this.participantData.requiredData.lastName],
      firstName: [this.participantData.requiredData.firstName],
      middleInitial: [this.participantData.requiredData.middleInitial],
      address1: [this.participantData.requiredData.address1],
      address2: [this.participantData.requiredData.address2],
      city: [this.participantData.requiredData.city],
      zipCode: [this.participantData.requiredData.zipCode],
      state: [this.participantData.requiredData.state],
      country: [this.participantData.requiredData.country],
      birthDate: [this.participantData.requiredData.birthDate],
      hireDate: [this.participantData.requiredData.hireDate],
      terminationDate: [this.participantData.requiredData.terminationDate],
      terminationReason: [this.participantData.requiredData.terminationReason],
      makeParticipantActive: [
        this.participantData.requiredData.makeParticipantActive
      ],
      absenceStartDate: [this.loaStartDate],
      absenceStartDateReason: [
        this.participantData.requiredData.absenceStartDateReason
      ],
      absenceEndDate: [this.loaEndDate],
      absenceEndDateReason: [
        this.participantData.requiredData.absenceEndDateReason
      ],
      enrollFlag: [this.participantData.requiredData.enrollFlag],
      mstarFlag: [this.participantData.requiredData.mstarFlag],
      qdiaFlag: [this.participantData.requiredData.qdiaFlag]
    });
  }

  initLOAFields() {
    // this.participantOptionalDataField
    const LOAStartDateElementKey = this.participantOptionSetting
      .loaStartDateDataElement;
    const LOAEndDateElementKey = this.participantOptionSetting
      .loaEndDateDataElement;
    const LOAStartReasonKey = this.participantOptionSetting
      .loaStartReasonDataElement;
    const LOAEndReasonKey = this.participantOptionSetting
      .loaEndReasonDataElement;
    this.participantOptionalDataField.forEach(ode => {
      switch (ode.key) {
        case LOAStartDateElementKey:
          this.loaStartDate = ode.value;
          break;
        case LOAEndDateElementKey:
          this.loaEndDate = ode.value;
          break;
        case LOAStartReasonKey:
          this.loaStartReason = ode.option;
          break;
        case LOAEndReasonKey:
          this.loaEndReason = ode.option;
          break;
      }
    });
  }

  onChanges() {
    this.participantRequiredDataForm.controls[
      'middleInitial'
    ].valueChanges.subscribe(val => {
      this.participantRequiredDataForm.controls['middleInitial'].setValue(
        val.toUpperCase(),
        { emitEvent: false }
      );
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'lastName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'firstName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'birthDate'
    ].valueChanges.subscribe(val => {
      this.validateAge();
    });
    this.participantRequiredDataForm.controls[
      'hireDate'
    ].valueChanges.subscribe(val => {
      this.validateAge();
    });
  }

  validateNameMaxlengthExceeded() {
    if (
      this.participantRequiredDataForm.controls['middleInitial'].value.length +
        this.participantRequiredDataForm.controls['firstName'].value.length +
        this.participantRequiredDataForm.controls['lastName'].value.length >
      30
    ) {
      this.participantRequiredDataForm.controls['lastName'].setErrors({
        MaxLengthExceeded: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    }
  }
  validateAge() {
    const age = this.calculateAge(
      this.participantRequiredDataForm.controls['birthDate'].value,
      this.participantRequiredDataForm.controls['hireDate'].value
    );
    if (age < 18 || age > 90) {
      this.participantRequiredDataForm.controls['birthDate'].setErrors({
        InvalidAge: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    }
  }
  calculateAge(birhthDay: any, hireDay: any) {
    const birthDate = new Date(
      birhthDay.year + '-' + birhthDay.month + '-' + birhthDay.day
    );
    const hireDate = new Date(
      hireDay.year + '-' + hireDay.month + '-' + hireDay.day
    );

    const ageDifMs = new Date(hireDate).getTime() - birthDate.getTime();

    const ageDate = new Date(ageDifMs); // miliseconds from epoch

    return Math.abs(ageDate.getFullYear() - 1970);
    // https://stackoverflow.com/questions/4060004/calculate-age-given-the-birth-date-in-the-format-yyyymmdd
  }
  setStartDates() {
    this.dobStartData = { year: new Date().getFullYear() - 19 - 9, month: 1 };
    this.dohStartDate = { year: new Date().getFullYear() - 9, month: 1 };
  }

  onSubmit() {
    this.validateSSN().subscribe(isValidSSN => {
      if (isValidSSN) {
        const data: IParticipantRequiredData = this.participantRequiredDataForm
          .value;

        ParticipantStore.ParticipantData.requiredData = data;
        // Update LOA Fields
        this.updateLOADataToStore();

        if (this.participantRequiredDataForm.value.enrollFlag) {
          if (
            ParticipantStore.ParticipantOptionSetting
              .canLoadOptionalDataElements
          ) {
            if (!this.EditMode) {
              this.router.navigate(['addParticipant/Optional']);
            } else {
              this.router.navigate(['UpdateParticipant/Optional']);
            }
          } else {
            if (!this.EditMode) {
              this.router.navigate(['addParticipant/ContributionElection']);
            } else {
              this.router.navigate(['UpdateParticipant/ContributionElection']);
            }
          }
        } else {
          this.router.navigate(['addParticipant/Confirmation']);
        }
      } else {
        return false;
      }
    });
  }

  updateLOADataToStore() {
    if (this.EditMode && this.participantOptionSetting.displayLOA) {
      ParticipantStore.ParticipantData.optionalData.forEach(
        (ode, index, object) => {
          switch (ode.key) {
            case this.participantOptionSetting.loaStartDateDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceStartDate'
              ].value;
              break;
            case this.participantOptionSetting.loaEndDateDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceEndDate'
              ].value;
              break;
            case this.participantOptionSetting.loaStartReasonDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceStartDateReason'
              ].value;
              break;
            case this.participantOptionSetting.loaEndReasonDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceEndDateReason'
              ].value;
              break;
          }
        }
      );
      console.log(ParticipantStore.ParticipantData.optionalData);
    }
  }

  validateSSN(): Observable<boolean> {
    this.participantsService
      .validateAddParticipantSSN(
        this.participantRequiredDataForm.controls['ssn'].value
      )
      .subscribe(res => {
        if (res.status === 'SUCCESS') {
          return of(true);
        } else if (res.status === 'ERROR') {
          const errors: string = res.error.msg;
          this.messageList = errors.split(',');
          return of(false);
        }
      });
    return of(true);
  }

  onStateChange(value: string) {}

  onCountryChange(value: string) {
    this.commonService.countryChanged.next(value);
  }
  openHelpQDIA() {
    this.modalservice.open('partiticipant-help-modal');
  }
  onEnrollFlagChange(value: boolean) {
    if (
      !this.participantOptionSetting.displayMorningStar &&
      !this.participantOptionSetting.displayQDIA
    ) {
      return;
    }
    if (value) {
      this.participantOptionSetting.disableQDIA = false;
      this.participantOptionSetting.disableMorningStar = false;
    } else {
      this.participantRequiredDataForm.controls['mstarFlag'].setValue(false);
      this.participantRequiredDataForm.controls['qdiaFlag'].setValue(false);
      this.participantOptionSetting.disableQDIA = true;
      this.participantOptionSetting.disableMorningStar = true;
    }
  }
  onMstarFlagChange(value: boolean) {
    this.participantData.requiredData.mstarFlag = value;
    if (value) {
      if (this.participantOptionSetting.morningStarError) {
        console.log(
          this.participantRequiredDataForm.controls['mstarFlag'].value
        );
        this.participantRequiredDataForm.controls['mstarFlag'].setValue(false);

        this.participantData.requiredData.mstarFlag = false;

        console.log(this.participantRequiredDataForm.value);
        this.toastr.error(
          'Morningstar Managed Account Program is not available at this time.!',
          'Morning Star Error' + ' !',
          { showCloseButton: true }
        );
        this.participantRequiredDataForm.value.mstarFlag = false;
      }
    }
  }
}
