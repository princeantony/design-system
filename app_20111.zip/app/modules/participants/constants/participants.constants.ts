export const MESSAGE = {
  PTPH740: `<p>By entering a date in this field, {0} will update the employee's
    participation status to active. Plan Sponsor must verify vesting information and update accordingly.
    Please advise the employee to establish their contribution rates and confirm their investment allocation on line.
    </br></br>Refer to the help icon next to Rehire Date field for more information.</p>`
};
