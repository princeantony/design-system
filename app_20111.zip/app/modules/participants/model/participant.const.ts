export const PARTICIPANT_DIVSUB_FILTER = [
  {
    value: 'AE001',
    displayText: 'A - E'
  },
  {
    value: 'FJ002',
    displayText: 'F - J'
  },
  {
    value: 'KO003',
    displayText: 'K - O'
  },
  {
    value: 'PT004',
    displayText: 'P - T'
  },
  {
    value: 'UZ005',
    displayText: 'U - Z'
  }
];

export const ODE_DIVSUB_CODE = 'PTPH244';
