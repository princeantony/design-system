import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {createUser} from '../actions/user-action'
import UserList from './show-users';
import _ from "lodash";
class CreateUser extends Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.saveToReducer = this.saveToReducer.bind(this);
    this.state = {items: [], txtName: ''};
  }

  handleChange(e) {
    this.setState({txtName: e.target.value});
  }

  handleSubmit(e) {
    e.preventDefault();
    var newItem = {
      text: this.state.txtName,
      id: Date.now()
    };
    this.setState((prevState) => ({
      items: prevState.items.concat(newItem),
      text: ''
    }));
  }
  saveToReducer(e)
  {
    const updatedUser= _.merge(this.props.newUser,this.state.items)
    this.props.actions.createUser(updatedUser);
  }
  render() {
    return (
      <div>
        <h3>Add Users</h3>
        <UserList items={this.state.items} />

        <form onSubmit={this.handleSubmit}>
        Name: <input onChange={this.handleChange} value={this.state.txtName} />
          <button>{'Add User #' + (this.state.items.length + 1)}</button>
        </form>
        <br/>
         <button onClick={this.saveToReducer}>Add User to Reducer</button>
        
      </div>
    );
  }


}
function mapStateToProps(state) {
    return {
        newUser: (state.newUser != null ? state.newUser.UserName : [])
    };
}
function matchDispatchToProps(dispatch){
  return {actions: bindActionCreators({ createUser }, dispatch)};
}

export default connect(mapStateToProps, matchDispatchToProps)(CreateUser);