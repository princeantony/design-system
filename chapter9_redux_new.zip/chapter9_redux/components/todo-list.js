import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import { debug } from 'util';
class TodoList extends Component {
  render() {
    return (
      <ul>
        {this.props.items.map(item => (
          <li key={item.id}>{item.task}</li>
        ))}
      </ul>
    );
  }
}
export default TodoList;