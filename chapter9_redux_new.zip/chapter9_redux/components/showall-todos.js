import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {connect} from 'react-redux';
import TodoList from './todo-list';
import UserList from './show-users';
class ShowAllToDos extends Component {
    renderDefaultTodo() {
       return this.props.defaultTodos.map((todo) => {
            return (

                <li key={todo.id}>
                    {todo.task}
                </li>
      );
        });
    }
    renderDefaultNames() {
     return this.props.defaultNames.map((user) => {
            return (
                <li key={user.id}>
                    {user.name}
                </li>
      );
        });
    }
    render() {
        return (
            <div>
                <h1>Default ToDo Details </h1>
                <ul>
                    {this.renderDefaultTodo()}
                </ul>
                <h1>Default names </h1>
                <ul>
                     {this.renderDefaultNames()}
                </ul>
                <h1>Custom todos list from Reducer</h1>
                <TodoList items={this.props.customToDo} />
                <h1>USer list from Reducer </h1>
                <UserList items={this.props.newUser} />
            </div>
        );
    }

}

function mapStateToProps(state) {
    return {
          defaultTodos: state.defaultTodo,
          defaultNames: state.defaultNames,
          customToDo: state.customToDo.ToDos,
          newUser: state.newUser.UserName,
    };
}

export default connect(mapStateToProps)(ShowAllToDos);
