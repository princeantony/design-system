import {combineReducers} from 'redux';
import InitialToDoReducer from './reducer-initial-todos';
import InitialNameReducer from './reducer-initial-names';
import CustomToDoReducer from './reducer-todo';
import NewUserReducer from './reducer-names';
const allReducers = combineReducers({
    defaultTodo: InitialToDoReducer,
    defaultNames: InitialNameReducer,
    customToDo: CustomToDoReducer,
    newUser: NewUserReducer
});

export default allReducers
