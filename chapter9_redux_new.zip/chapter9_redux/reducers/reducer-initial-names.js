
export default function () {
    return [
        {
            id: 1,
            name: 'Ram Kumar'
        },
        {
            id: 2,
            name: 'John Mathew'    
        }  
    ]
}
