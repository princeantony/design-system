export default function (state = null, action) {
    switch (action.type) {
        case 'USER-CREATED':
        return Object.assign({}, state, {UserName: action.name});
        break;
    }
    return state;
}
