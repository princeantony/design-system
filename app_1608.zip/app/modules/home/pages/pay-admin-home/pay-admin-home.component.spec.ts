import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayAdminHomeComponent } from './pay-admin-home.component';

describe('PayAdminHomeComponent', () => {
  let component: PayAdminHomeComponent;
  let fixture: ComponentFixture<PayAdminHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayAdminHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayAdminHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
