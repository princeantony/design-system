import { Component, OnInit, Input } from "@angular/core";
import { GridOptions } from "ag-grid";
import { Router } from "@angular/router";
const pageSlot = 10;
@Component({
  selector: "voya-grid",
  templateUrl: "./grid.component.html",
  styleUrls: ["./grid.component.scss"]
})
export class GridComponent implements OnInit {
  @Input()
  rowData: any;
  @Input()
  columnDefs: any;

  private gridApi;

  nextStatus = false;
  prevStatus = true;
  selectedPage = 1;
  // maxRange = false;
  btnNum = [];
  totalPages;
  constructor(private router: Router) {}
  onRowClicked(params) {
    let planId = params.data.planNumber;
    this.router.navigate(["/home/" + planId + ""]);
  }
  ngOnInit() {}

  onGridReady(params) {
    this.gridApi = params.api;


    if (this.gridApi) {
      this.totalPages = this.gridApi.paginationGetTotalPages();

      if (this.totalPages > pageSlot) {
        this.createPageSlot(0, pageSlot);
      } else {
        this.createPageSlot(0, this.totalPages);
      }
    }
  }

  createPageSlot(minNum: number, maxNum: number) {
    this.btnNum = [];

    for (let i = minNum; i < maxNum; i++) {
      if (i + 1 <= this.totalPages) {
        this.btnNum.push(i + 1);
      } else {
        this.nextStatus = true;
      }
    }
  }
  gotoPage(pageNum) {
    this.gridApi.paginationGoToPage(pageNum - 1);
    this.selectedPage = pageNum;
  }
  gotoPrev() {
    this.nextStatus = false;
    let firstNum = this.btnNum[0] - (pageSlot + 1);
    let lastNum = firstNum + pageSlot;
    this.createPageSlot(firstNum, lastNum);

    if (firstNum + 1 <= 1) {
      this.prevStatus = true;
    }
  }

  gotoNext() {
    this.prevStatus = false;
    let minNum = this.btnNum[pageSlot - 1];

    let maxNum = minNum + pageSlot;
    console.log(minNum + " : " + maxNum);
    this.createPageSlot(minNum, maxNum);
  }

  onPaginationChanged() {
    if (this.gridApi) {
    }
  }
}
