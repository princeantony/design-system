import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voya-textbox',
  templateUrl: './voya-textbox.component.html',
  styleUrls: ['./voya-textbox.component.scss']
})
export class VoyaTextboxComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
