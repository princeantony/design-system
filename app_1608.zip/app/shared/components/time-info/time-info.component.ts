import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-time-info',
  templateUrl: './time-info.component.html',
  styleUrls: ['./time-info.component.scss']
})
export class TimeInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
