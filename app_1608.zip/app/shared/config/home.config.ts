import { MenuItem } from "../interfaces/menu-item.interface";
    export const HomeMenuItems: MenuItem[] = [
      {
        key: "addEnrollmentFlag",
        menuHeading: "Add/Enroll",
        menuSubheading: "Add/Enroll Participants",
        menuIcon: "addenroll.svg"
      },
      {
        key: "paricipantFlag",
        menuHeading: "Participant Update",
        menuSubheading: "View/Update participant information",
        menuIcon: "participantupdate.svg"
      },
      {
        key: "batchParticipantFlag",
        menuHeading: "Batch Participant Update",
        menuSubheading: "Update multiple participant",
        menuIcon: "batchparticipantupdate.svg"
      },
      {
        key: "contributionFlag",
        menuHeading: "Contributions",
        menuSubheading: "Process contributions to accounts",
        menuIcon: "contributions.svg"
      },
      {
        key: "pendingBatchFlag",
        menuHeading: "Pending/Submitted Batches",
        menuSubheading: "Review batch information",
        menuIcon: "pendingsubmittedbatches.svg"
      },
      {
        key: "loanRepaymentFlag",
        menuHeading: "Loan Repayment",
        menuSubheading: "Process loan repayments",
        menuIcon: "loanrepayment.svg"
      },
      {
        key: "bankInfoFlag",
        menuHeading: "Bank Information",
        menuSubheading: "Add or update assigned bank",
        menuIcon: "bankinformation.svg"
      },
      {
        key: "adminFlag",
        menuHeading: "Administration",
        menuSubheading: "Review and update your settings",
        menuIcon: "administration.svg"
      }
    ];