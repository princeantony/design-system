export const LoginUser=
{
  "userName": "SPAYNG01",
  "password": "ING12345",
  "clientId": "INGWIN",
  "divisionId": "WIN"
}
