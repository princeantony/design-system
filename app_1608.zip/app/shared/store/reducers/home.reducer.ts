import { ActionReducer, Action } from '@ngrx/store';
import{ACTION_TYPE} from '../../constants/app.constants';

export function HomeReducer(state: null, action) {
	 switch (action.type) {
		case ACTION_TYPE.HOME_FLAG:
            return Object.assign({}, state, action.homeFlag);

		default:
			return state;
	}
}