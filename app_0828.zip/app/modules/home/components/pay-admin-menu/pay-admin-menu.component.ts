import { Component, OnInit, Injectable, Input } from '@angular/core';
import { MenuItem } from "../../../../shared/interfaces/menu-item.interface";
import { HomeService } from "../../services/home.service";
import {APP_CONST} from '../../../../shared/constants/app.constants';
import { Store, State } from '@ngrx/store';
import { AppState } from '../../../../shared/store/state/app.state';
import { HomeAction } from '../../actions/home.action';
import { Observable } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';
import {  ActivatedRoute } from '@angular/router';
import { PayAdminGlobalState } from '../../../../shared/store/global';
@Component({
  selector: 'app-pay-admin-menu',
  templateUrl: './pay-admin-menu.component.html',
  styleUrls: ['./pay-admin-menu.component.scss']
})
export class PayAdminMenuComponent implements OnInit {
  @Input() planNumber: string;
  menuItemRows: Array<MenuItem[]>;
  appContext =  APP_CONST.APP_CONTEXT;
  homeFlag : any;
  payAdminGlobalState : PayAdminGlobalState
  private sub: any;
  constructor(
    private homeService: HomeService,
    private store: Store<AppState>,
    private state: State<AppState>,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute
  ) {}
  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;


    this.getMockMenuList();
    /*
    this.homeFlag = this.state.getValue().homeFlag;
    if(this.homeFlag === undefined)
    {
      this.getMockMenuList();
      this.spinner.show();
      //this.getMenuList();
      this.getMockMenuList();
    }
 else{
  console.log("from state home");
  console.log("this.homeFlag",this.homeFlag);
  this.menuItemRows = this.homeFlag;
 }
 */
}
  getMenuList()
  {
    this.homeService.getMenuList(this.planNumber).subscribe(flags => {
      this.spinner.hide();
      if(flags.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.menuItemRows = this.homeService.getMenuItemRows(flags);
      //this.store.dispatch(new HomeAction({homeFlag: this.menuItemRows }) )
      }
    });
  }
  getMockMenuList()
  {
    this.homeService.getMockMenuList(this.planNumber).subscribe(flags => {
      this.spinner.hide();
      if(flags.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.menuItemRows = this.homeService.getMenuItemRows(flags.data);
      //this.store.dispatch(new HomeAction({homeFlag: this.menuItemRows }) )
      }
    });
  }
}
