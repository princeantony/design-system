import{ACTION_TYPE} from '../../../shared/constants/app.constants';

import { Action } from '@ngrx/store'

export class BankSubDivAction implements Action {
    readonly type = ACTION_TYPE.BANK_SUBDIV;
        constructor(public bankSubDiv: any) {
        }
}
export class BankInfoAction implements Action {
    readonly type = ACTION_TYPE.BANK_INFO;
        constructor(public bankInfo: any) {
        }
}