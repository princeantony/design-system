export  class  PayAdminGlobalState{
    static planNumber: string;
    static planName: string
}