import {IPlanLight} from '../../interfaces/plan-light.interface';
import { IUser } from '../../interfaces/user.interface';
import { IBankInfo, IBankSubDiv } from '../../interfaces/bank.interface';

export interface AppState {
    readonly planList: IPlanLight[];
    readonly userList: IUser[];
    readonly homeFlag: any;
    readonly bankInfo: IBankInfo;
    readonly bankSubDiv: IBankSubDiv
}