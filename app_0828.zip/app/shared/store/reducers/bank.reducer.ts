import { ActionReducer, Action } from '@ngrx/store';
import{ACTION_TYPE} from '../../constants/app.constants';

export function BankReducer(state: null, action) {
	 switch (action.type) {
	   case ACTION_TYPE.BANK_INFO:
		return Object.assign({}, state, action.bankInfo);
		case ACTION_TYPE.BANK_SUBDIV:
            return Object.assign({}, state, action.bankSubDiv);
		default:
			return state;
	}
}