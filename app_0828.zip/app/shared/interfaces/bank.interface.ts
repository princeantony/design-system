export interface IBankInfo{
    locationNumber: string,
    locationName: string,
    bankName: string,
    accountType: string
}
export interface IBankSubDiv{
    id: string,
    text: string,
    name: string,
    phone: string
}