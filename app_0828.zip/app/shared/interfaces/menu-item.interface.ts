export interface MenuItem{
    key: string;
    menuHeading: string;
    menuSubheading: string;
    menuIcon: string;
}