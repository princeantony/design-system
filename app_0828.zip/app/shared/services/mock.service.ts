import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
import {ListPlan} from '../mocks/listPlan';
import {PlanLight} from '../models/plan-light.model';
import { HOME_FLAGS } from '../mocks/menuItems-mock';
import {bankInfo, divSub} from '../mocks/bankInfo-mock';
@Injectable({
  providedIn: 'root',
})

export class MockService {
constructor() { }

getListPlans(): Observable<any> {
console.log("from mock plan svc")
    return of(ListPlan);
  }
  getHomeFlags(): Observable<any> {

        return of(HOME_FLAGS);
      }
  getBankInfo(): Observable<any> {
    return of(bankInfo);
  }
  getSubDiv(): Observable<any> {
    return of(divSub);
  }
  }

  