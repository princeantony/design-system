import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlanSelectionComponent } from '../../modules/plans/pages/plan-selection/plan-selection.component';
import { PayAdminHomeComponent } from '../../modules/home/pages/pay-admin-home/pay-admin-home.component';
import { BankAvailableComponent } from '../../modules/bank-information/pages/bank-available/bank-available.component';
import { BankEditOrCreateComponent } from '../../modules/bank-information/pages/bank-edit-or-create/bank-edit-or-create.component';
import { BankModalComponent } from '../../modules/bank-information/components/bank-modal/bank-modal.component';
import { ConfirmationComponent } from '../../modules/bank-information/pages/confirmation/confirmation.component';
import { BankNoneComponent } from '../../modules/bank-information/pages/bank-none/bank-none.component';

const payAdmiinRoutes: Routes = [
  {
    path: '',
    component: PlanSelectionComponent,
    data: { title: 'Plan List' }
  },
  {
    path: 'home/:planId',
    component: PayAdminHomeComponent
  },
  {
    path: 'bankInfo/editorcreate',
    component: BankEditOrCreateComponent
  },
  {
    path: 'bankInfo/:planId',
    component: BankAvailableComponent
  },
  

  
  {
    path : 'confirm/:planId',
    component: ConfirmationComponent
  },

  { 
    path: '**',
     component: PlanSelectionComponent 
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(payAdmiinRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    
    
  ]
})
export class PayAdminRoutingModule { }
export const PayAdminRoutingComponents = [PlanSelectionComponent, PayAdminHomeComponent, BankAvailableComponent];