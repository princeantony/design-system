import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AgGridModule} from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { PlanListComponent } from './modules/plans/components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';

import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import { GridComponent } from './shared/components/form/voya-grid/grid.component';

import { PayAdminRoutingModule, PayAdminRoutingComponents } from './shared/modules/pay-admin-routing.module';
import {PayAdminHomeComponent} from './modules/home/pages/pay-admin-home/pay-admin-home.component'; 
import { HeaderComponent } from './shared/components/layout/header/header.component';

import { TimeInfoComponent } from './shared/components/time-info/time-info.component';
import { PageTitleComponent } from './shared/components/layout/page-title/page-title.component';
import { PayAdminMenuComponent } from './modules/home/components/pay-admin-menu/pay-admin-menu.component';
import { VoyaLinkComponent } from './shared/components/form/voya-link/voya-link.component';
import { ModalService } from './shared/services/modal.service';
import { ModalComponent } from './shared/directives/modal.component';
import { BrowserInfoComponent } from './shared/components/browser-info/browser-info.component';
import {PlanReducer} from './shared/store/reducers/plan.reducer';

import { BankAvailableComponent } from './modules/bank-information/pages/bank-available/bank-available.component';
import { BankListComponent } from './modules/bank-information/components/bank-list/bank-list.component';

import { InputTextComponent } from './shared/components/form/voya-input/input-text/input-text.component';
import {ApiService} from './shared/services/api.service';
import { VoyaPagingComponent } from './shared/components/form/voya-paging/voya-paging.component';
import { UserReducer } from './shared/store/reducers/user.reducer';
import { Utils } from './shared/utils/pay-admin.utils';
import { HomeReducer } from './shared/store/reducers/home.reducer';
import { NgxSpinnerModule } from 'ngx-spinner';
import { GridLinkComponent } from './modules/bank-information/components/grid-link/grid-link.component';
import { BankEditOrCreateComponent } from './modules/bank-information/pages/bank-edit-or-create/bank-edit-or-create.component';
import { BankModalComponent } from './modules/bank-information/components/bank-modal/bank-modal.component';
import { ConfirmationComponent } from './modules/bank-information/pages/confirmation/confirmation.component';
import { BankNoneComponent } from './modules/bank-information/pages/bank-none/bank-none.component';
import { EditDisclosureComponent } from './modules/bank-information/components/edit-disclosure/edit-disclosure.component';
import { BankSubmitComponent } from './modules/bank-information/components/bank-submit/bank-submit.component';
import { BankReducer } from './shared/store/reducers/bank.reducer';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    PlanListComponent,
    PlanSelectionComponent,
    HeaderComponent,
    GridComponent,
    PayAdminHomeComponent,
    PayAdminRoutingComponents,
    TimeInfoComponent,
    PageTitleComponent,
    PayAdminMenuComponent,
    VoyaLinkComponent,
    ModalComponent,
    BrowserInfoComponent,
    BankAvailableComponent,
    BankListComponent,
    BankEditOrCreateComponent,
    BankSubmitComponent,
    ConfirmationComponent,
    BankNoneComponent,
    InputTextComponent,
    VoyaPagingComponent,
    GridLinkComponent,
    BankModalComponent,
    EditDisclosureComponent
  ],
  imports: [
    BrowserModule,
    PayAdminRoutingModule,
    NgxSpinnerModule,
    HttpClientModule,
    FormsModule,
     ReactiveFormsModule,
     StoreModule.forRoot({ 
     planList: PlanReducer,
     userList: UserReducer,
     homeFlag: HomeReducer,
     bankSubDiv: BankReducer
     }),
    StoreDevtoolsModule.instrument({maxAge: 10}),
    AgGridModule.withComponents([GridLinkComponent])
  ],
  providers: [ModalService, ApiService, Utils],
  bootstrap: [AppComponent ]
})
export class AppModule { }
