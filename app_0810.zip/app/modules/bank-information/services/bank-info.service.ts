import { Injectable } from '@angular/core';
import * as Rx from "rxjs";
import { MockService } from '../../../shared/services/mock.service';
import { ApiService } from '../../../shared/services/api.service';
import { Observable } from 'rxjs';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
const subject = new Rx.BehaviorSubject("");

@Injectable({
  providedIn: 'root'
})
export class BankInfoService {
form : any;

  constructor(private mockService : MockService,private apiService: ApiService) { }

getBankInfo(planNumber: string) : Observable<any>
{
return this.apiService.get(SERVICE_URL.GET_BANK_INFO_URL +planNumber)
}
getBankInfoMock():Observable<any>
{
return this.mockService.getBankInfo();
}

getSubDiv(planNumber: string):Observable<any>
{
return this.apiService.get(SERVICE_URL.GET_HOME_URL +planNumber+"/divsub")
}
getSubDivMock():Observable<any>
{
return this.mockService.getSubDiv();
}
updateBankInfo(bankInfo: any, planNumber: string,divsubId: string):Observable<any>{
  console.log("bankInfo to save",bankInfo)
  
 if(divsubId === "")
 {
 return this.apiService.put(SERVICE_URL.POST_BANK_INFO_URL+planNumber,bankInfo); 
 }
 else
 {
 return this.apiService.put(SERVICE_URL.POST_BANK_INFO_URL+planNumber+"/divsub/"+divsubId, bankInfo); 
 }
}
postBankInfo(bankInfo: any, planNumber: string,divsubId: string):Observable<any>{
   if(divsubId === "")
 {
return this.apiService.post(SERVICE_URL.POST_BANK_INFO_URL+planNumber, bankInfo); 
 }
 else
 {
 return this.apiService.post(SERVICE_URL.POST_BANK_INFO_URL+planNumber+"/divsub/"+divsubId, bankInfo); 
 }
 
}

}
