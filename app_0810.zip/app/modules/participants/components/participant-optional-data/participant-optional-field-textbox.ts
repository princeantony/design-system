import { ParticipantOptionalFields } from './participant-optional-fields';

export class ParticipantOptionalFieldTextBox extends ParticipantOptionalFields<string> {
    controlType = 'textbox';
    type: string;
  
    constructor(options: {} = {}) {
      super(options);
      this.type = options['type'] || '';
    }  
}
