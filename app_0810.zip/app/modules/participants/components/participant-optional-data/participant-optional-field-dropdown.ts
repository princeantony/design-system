import { ParticipantOptionalFields } from "./participant-optional-fields";

export class ParticipantOptionalFieldDropDown extends ParticipantOptionalFields<string> {
  controlType = "dropdown";
  options: { value: string; label: string }[] = [];

  constructor(options: {} = {}) {
    super(options);
    this.options = options["options"] || [];
  }
}
