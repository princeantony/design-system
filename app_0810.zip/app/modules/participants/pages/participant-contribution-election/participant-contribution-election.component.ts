import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-contribution-election',
  templateUrl: './participant-contribution-election.component.html',
  styleUrls: ['./participant-contribution-election.component.scss']
})
export class ParticipantContributionElectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
