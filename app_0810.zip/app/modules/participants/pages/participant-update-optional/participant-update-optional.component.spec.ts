import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantUpdateOptionalComponent } from './participant-update-optional.component';

describe('ParticipantUpdateOptionalComponent', () => {
  let component: ParticipantUpdateOptionalComponent;
  let fixture: ComponentFixture<ParticipantUpdateOptionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantUpdateOptionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantUpdateOptionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
