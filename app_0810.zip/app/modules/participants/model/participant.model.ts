export class ParticipantAdminSetting {
  QDIAVisible: boolean;
  QDIAEnabled: boolean;
  statusText: string;
  morningStarVisible: boolean;
  morningStarEnabled: boolean;
  enrollParticipantVisible: boolean;
  enrollParticipantEnabled: boolean;
  emailEnabled: boolean;
}
export interface IParticipantRequiredData {
  ssn: string;
  email: string;
  lastName: string;
  firstName: string;
  mName: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  zip: string;
  state: string;
  country: string;
  dateOfBirth: string;
  dateOfHire: string;
  enrollFlag: boolean;
  mstarFlag: boolean;
  qdiaFlag: boolean;
}
interface option {
  value: string;
  label: string;
}

export interface ParticipantOptionalFieldModel {
  controlType: string;
  label: string;
  value: string;
  required: boolean;
  readonly: boolean;
  disabled: boolean;
  option: option[];
}

export interface ParticipantContributionItem {
  key: string;
  label: string;
  value: string;
  readonly: boolean;
}
export interface ParticipantContributionModel {
  invElectChangeAllowed: boolean;
  mstarFlag: boolean;
  contribElection: {
    type: string;
    list: ParticipantContributionItem[];
  };
  catchupContribElection: {
    type: string;
    list: ParticipantContributionItem[];
  };
  investmentElection: {
    acrossAllSourceElectionFlg: string;
    list: ParticipantContributionItem[];
  };
}
