import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaCheckboxComponent } from './voya-checkbox.component';

describe('VoyaCheckboxComponent', () => {
  let component: VoyaCheckboxComponent;
  let fixture: ComponentFixture<VoyaCheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaCheckboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
