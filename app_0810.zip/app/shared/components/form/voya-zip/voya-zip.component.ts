import { Component, OnInit, Input, forwardRef } from "@angular/core";
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  FormControl,
  ValidationErrors,
  Validators,
  Validator,
  NG_VALIDATORS
} from "@angular/forms";

const noop = () => {};
@Component({
  selector: "voya-zip",
  templateUrl: "./voya-zip.component.html",
  styleUrls: ["./voya-zip.component.scss"],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaZipComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => VoyaZipComponent),
      multi: true
    }
  ]
})
export class VoyaZipComponent
  implements OnInit, ControlValueAccessor, Validator {
  @Input() control;
  @Input() placeHolderText: string;
  @Input() controlLabel: string;

  private _isRequired: boolean = true;;

  // @Input()
  // set isRequired(value: boolean) {
  //   this._isRequired = value || true;
  // }
  // get isRequired(): boolean {
  //   return this._isRequired;
  // }
@Input()
  set isRequired(value: boolean) {
    this._isRequired = value;
  }
  get isRequired(): boolean {
    return this._isRequired;
  }

  ngOnInit() {
    this.isLabelHidden = false;
    if (this._isRequired === undefined) {
      this._isRequired = true;
    }
  }

  // The internal data model
  private _value: any = "";
  //get accessor
  get value(): any {
    return this._value;
  }
  //set accessor including call the onchange callback
  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  //Placeholders for the callbacks
  private _onTouchedCallback: (_: any) => void = noop;
  private _onChangeCallback: (_: any) => void = noop;

  isLabelHidden: boolean;
  //Set touched on blur
  onTouched(event: any){
    if (event.target.value === "") {
      this.isLabelHidden = true;
    }
    if (event.target.value !== "") {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus(){
    this.isLabelHidden = false;
  }

  propagateChange = (_: any) => {};

  writeValue(value: string): void {
    this._value = value || "";
    if (this._value.length > 0) {
      this.isLabelHidden = false;
    }
    if (this._value.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}


    validate(ctrl: FormControl): ValidationErrors | null {
    if (this._isRequired) {
      return Validators.compose([
        Validators.required,
        Validators.pattern("^\\d{5}(?:[-\\s]?\\d{4})?")
      ])(ctrl);
    } else{
      return Validators.compose([
        Validators.pattern("^\\d{5}(?:[-\\s]?\\d{4})?")
      ])(ctrl);
    }
    
  }
}
