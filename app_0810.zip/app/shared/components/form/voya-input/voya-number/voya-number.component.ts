import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voya-number',
  templateUrl: './voya-number.component.html',
  styleUrls: ['./voya-number.component.scss']
})
export class VoyaNumberComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
