import { Component, OnInit, Input, forwardRef, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from 'node_modules/@angular/forms';

const noop = () => {};
@Component({
  selector: 'voya-radio-new',
  templateUrl: './voya-radio-new.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaRadioNewComponent),
      multi: true
    }
  ]
})
export class VoyaRadioNewComponent implements OnInit {
  @Input() control;  
  @Input() groupLabel: string;
  //@Input() items: {label,value}[]; 
  @Input() controlName: string;
  @Output() onClick =  new EventEmitter<string>();
  private _items: { value: string; label: string }[];
  @Input()
  set items(list: { value: string; label: string }[]) {
    this._items = list || [{ value: '', label: '' }];
  }
  get items() {
    return this._items;
  }
  
  ngOnInit() {
    
  }

  private _value: any = null;
  get value(): any { 
    return this._value; 
  };
  set value(v: any) {
    console.log("v",v);
      this._value = v;
      this._onChangeCallback(v);
    if(v === ''){
      this._value = null;
    }
  }

onRadioClick(e)
{
  debugger;
  console.log("this._value", e)
  this.onClick.emit(this._value);
}
 
  //Placeholders for the callbacks
  private _onTouchedCallback: (_:any) => void = noop;  
  private _onChangeCallback: (_:any) => void = noop;
  
  //Set touched on blur
  onTouched(){
    this._onTouchedCallback(null);
  }

  isLabelHidden: boolean;
  
  writeValue(value: string): void {
    this._value = value || null;
    if(this._value === null){
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  
 
  
}
