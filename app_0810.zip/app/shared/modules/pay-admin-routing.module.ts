import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { PlanSelectionComponent } from "../../modules/plans/pages/plan-selection/plan-selection.component";
import { PayAdminHomeComponent } from "../../modules/home/pages/pay-admin-home/pay-admin-home.component";
import { BankAvailableComponent } from "../../modules/bank-information/pages/bank-available/bank-available.component";
import { ConfirmationComponent } from "../../modules/bank-information/pages/confirmation/confirmation.component";
import { CreateComponent } from "../../modules/bank-information/pages/create/create.component";

//Participant Module Components
import { ParticipantAddComponent } from "../../modules/participants/pages/participant-add/participant-add.component";
import { ParticipantAddOptionalComponent } from "../../modules/participants/pages/participant-add-optional/participant-add-optional.component";
import { ParticipantAddContributionElectionComponent } from "../../modules/participants/pages/participant-add-contribution-election/participant-add-contribution-election.component";
import { ParticipantAddInvestmentElectionComponent } from "../../modules/participants/pages/participant-add-investment-election/participant-add-investment-election.component";

import { ContributionInputGroupComponent } from "../../modules/participants/components/participant-contribution-election/contribution-input-group/contribution-input-group.component";
import { ParticipantContributionElectionComponent } from "../../modules/participants/components/participant-contribution-election/participant-contribution-election.component";

//Admin Module Components
import { AdminHomeComponent } from "../../modules/admin/pages/admin-home/admin-home.component";
import { AdminPageSecurityComponent } from "../../modules/admin/pages/admin-page-security/admin-page-security.component";
import { AdminPlanSetupComponent } from "../../modules/admin/pages/admin-plan-setup/admin-plan-setup.component";

const payAdmiinRoutes: Routes = [
  {
    path: "plans",
    component: PlanSelectionComponent,
    data: { title: "Plan List" }
  },
  {
    path: "home",
    component: PayAdminHomeComponent
  },
  {
    path: "home/success",
    component: PayAdminHomeComponent
  },
  {
    path: "home/print",
    component: ConfirmationComponent
  },

  {
    path: "bankInfo/edit/:divsubId",
    component: CreateComponent
  },
  {
    path: "bankInfo/edit",
    component: CreateComponent
  },
  {
    path: "bankInfo/create/:divsubId",
    component: CreateComponent
  },
  {
    path: "bankInfo/create",
    component: CreateComponent
  },
  {
    path: "bankInfo",
    component: BankAvailableComponent
  },
  {
    path: "bankInfo/confirm",
    component: ConfirmationComponent
  },
  //Participant Module Routing Rules
  {
    path: "participant",
    component: ParticipantAddComponent
  },
  {
    path: "addParticipant/Optional",
    component: ParticipantAddOptionalComponent
  },
  {
    path: "addParticipant/ContributionElection",
    component: ParticipantAddContributionElectionComponent
  },
  {
    path: "addParticipant/ContributionInvestment",
    component: ParticipantAddInvestmentElectionComponent
  },
  
  //Admin Module Routing Rules
  {
    path: "admin",
    component: AdminHomeComponent
  },
  {
    path: "pageSecurity",
    component: AdminPageSecurityComponent
  },
  {
    path: "planSetup",
    component: AdminPlanSetupComponent
  },
  {
    path: "**",
    component: PlanSelectionComponent //ParticipantAddContributionElectionComponent //PlanSelectionComponent //
  }
];

@NgModule({
  imports: [RouterModule.forRoot(payAdmiinRoutes)],
  exports: [RouterModule],
  providers: []
})
export class PayAdminRoutingModule {}
export const PayAdminRoutingComponents = [
  PlanSelectionComponent,
  PayAdminHomeComponent,
  BankAvailableComponent
];
