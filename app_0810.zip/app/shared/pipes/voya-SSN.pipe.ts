import { Pipe, PipeTransform } from "@angular/core";
@Pipe({
  name: "voyaSSN"
})
export class VoyaSSNPipe implements PipeTransform {
  private format: string;

  constructor() {
    this.format = "NNN-NN-NNNN";
  }
  transform(value: string, separator: string = "-"): string {
    let pipedSSN: string = value;
    if (value && value.replace(separator, "").length === 9) {
      value = value.replace(/-/g,''); //value = 123456789
      pipedSSN =
        value.slice(0, 3) +
        separator +
        value.slice(3, 5) +
        separator +
        value.slice(5);
    }

    return pipedSSN;
  }

  parse(value: string, separator: string = "-"): string {
    // console.log("Value " + value);
    // value = value.replace(/-/g,'');
    return value;
  }
}
