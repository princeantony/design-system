export const SERVICE_URL=
{
    APP_URL: "http://localhost:4200/payadmin/ws/ers/service/",
    //APP_URL: "https://reqres.in/api/users?delay=3",
    GET_DIRECT_LOGIN_URL: 'login/direct',
    GET_LISTPLAN_URL: 'plans',
    GET_HOME_URL: 'plans/plan/',
    GET_SUB_DIV_URL: 'plans/plan/{planNumber}divsub/',
    GET_BANK_INFO_URL: 'bankinfo/plan/',
    POST_BANK_INFO_URL: 'bankinfo/plan/',
    PUT_BANK_INFO_URL: 'bankinfo/plan/',
    GET_ParticipantAdminSetting: '/service/participant/plan/{id}/options',
    GET_PAGE_INFO_URL: 'page/plan/',
    GET_PLAN_SETUP_URL: "admin/plansetup/plan/",
    GET_MONEY_SOURCE_URL: "admin/plan/{id}/moneysources",
    GET_INVESTMENT_URL: "admin/plan/{id}/investments",
    GET_PLAN_ENROLL_STATUS_URL: "admin/plan/plan/{id}/statuslist",
    GET_PLAN_OPTIONS_URL:"service/admin/plan/plan/{id}/options"
    
};

