export const DivLocationOptons = [
    {
      "text": "Divistion1",
      "code": "D1"
    },
     {
      "text": "Divistion2",
      "code": "D2"
    }
]
export const EntrollmentOptions = [
   {
      "text": "Entrollment1",
      "code": "E1"
    },
     {
      "text": "Entrollment2",
      "code": "E2"
    },
]
export const PinLenthOptions =[
   {
      "text": "4",
      "code": "4"
    },
     {
      "text": "6",
      "code": "6"
    }
]

export const ParticipantUpdateOptions =[
    {
      "text": "Participants1",
      "code": "p1"
    },
    {
      "text": "Participants2",
      "code": "p2"
    }
    ]

export const CatchUpOptions =[
    {
      "text": "Catchup1",
      "code": "CP1"
    },
    {
      "text": "Catchup2",
      "code": "CP2"
    }
    ]

export const EmailDEOptions =[
    {
      "text": "EmailDE1",
      "code": "ED1"
    },
    {
      "text": "EmailED2",
      "code": "ED2"
    }
    ]
