import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-optional-data',
  templateUrl: './admin-optional-data.component.html'
})

export class AdminOptionalDataComponent implements OnInit {
  hidePageTitle: boolean;
  subTitle: string;
  planNumber: string;
  updateOtionalDataForm : any;

  populateForm(dataElement) {
    this.updateOtionalDataForm.controls['dataElement1'].setValue(dataElement.dataElement1);
    this.updateOtionalDataForm.controls['dataElement2'].setValue(dataElement.dataElement2);
    this.updateOtionalDataForm.controls['dataElement3'].setValue(dataElement.dataElement3);
    this.updateOtionalDataForm.controls['standardName'].setValue(dataElement.standardName);
    this.updateOtionalDataForm.controls['overrideName'].setValue(dataElement.overrideName);
    this.updateOtionalDataForm.controls['Enrollment'].setValue(dataElement.Enrollment);
    this.updateOtionalDataForm.controls['Participant'].setValue(dataElement.Participant);
    this.updateOtionalDataForm.controls['Contribution'].setValue(dataElement.Contribution);
    this.updateOtionalDataForm.controls['batchParticipant'].setValue(dataElement.batchParticipant);
  }
  onStateChange(value: string) {
    console.log("value changed"  + value);
  }
  constructor(private fb: FormBuilder, ) { }
  ngOnInit() {
    this.updateOtionalDataForm = this.fb.group({
      dataElement1: ['', Validators.required],
      standardName: ['', Validators.required],
      overrideName: ['', Validators.required],
      Enrollment: ['', Validators.required],
      Participant: ['', Validators.required],
      Contribution: ['', Validators.required],
      batchParticipant: ['', Validators.required],
    });
  }

  get dataElement1() {
    return this.updateOtionalDataForm.get('dataElement1');
  }
  get dataElement2() {
    return this.updateOtionalDataForm.get('dataElement2');
  }
  get dataElement3() {
    return this.updateOtionalDataForm.get('dataElement3');
  }
  get standardName() {
    return this.updateOtionalDataForm.get('standardName');
  }
  get overrideName() {
    return this.updateOtionalDataForm.get('overrideName');
  }
  get Enrollment() {
    return this.updateOtionalDataForm.get('Enrollment');
  }
  get Participant() {
    return this.updateOtionalDataForm.get('Participant');
  }
  get Contribution() {
    return this.updateOtionalDataForm.get('Contribution');
  }
  get batchParticipant() {
    return this.updateOtionalDataForm.get('batchParticipant');
  }
}
