import { Component, OnInit, Input } from '@angular/core';
import {AdminGridCheckboxComponent} from '../admin-grid-checkbox/admin-grid-checkbox.component';
import { AdminGridTextboxComponent } from '../admin-grid-textbox/admin-grid-textbox.component';

@Component({
  selector: 'app-admin-plan-setup-grid',
  templateUrl: './admin-plan-setup-grid.component.html',
  styleUrls: ['./admin-plan-setup-grid.component.scss']
})

export class AdminPlanSetupGridComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
  frameworkComponents: any;
  style;

  constructor() { }
  ngOnInit() {
    this.frameworkComponents = {
      checkboxRenderer: AdminGridCheckboxComponent,
      textboxRender : AdminGridTextboxComponent
      };
  }
}
