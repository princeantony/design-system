import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from "@angular/forms";

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { IPageList } from '../../../../shared/interfaces/page-list.interface';


@Component({
  selector: 'app-admin-page-setup',
  templateUrl: './admin-page-setup.component.html',
  styleUrls: ['./admin-page-setup.component.scss']
})
export class AdminPageSetupComponent implements OnInit {
 
  @Input() pageList :IPageList[];
  @Input() form : FormGroup;
  planNumber;

  constructor() { }
  

  ngOnInit() {
   


    
    
  }

}
