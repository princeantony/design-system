import React, {Component} from 'react';
import { Router, Route,  hashHistory, IndexRoute  } from 'react-router'
import MainApp from '../containers/main-app'
import CreateToDo from '../components/create-todo'
import CreateUser from '../components/create-user'
import ShowAllToDos from '../components/showall-todos'

export default class RootApp extends Component
{
   render()
   { 
      return( <Router history = {hashHistory}>
                <Route path = "/" component = {MainApp}>
                <IndexRoute component = {CreateToDo} />
                <Route path = "todo" component = {CreateToDo} />
                <Route path = "user" component = {CreateUser} />
                <Route path = "showall" component = {ShowAllToDos} />
            </Route>
        </Router>)
   }
}