
export default function () {
    return [
        {
            id: 1,
            task: 'Build and Release activity'
        },
        {
            id: 2,
            task: 'Team meeting'    
        }  
    ]
}
