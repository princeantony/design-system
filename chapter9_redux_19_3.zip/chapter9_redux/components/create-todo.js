import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {saveTodos, removeTodos} from '../actions/todo-action'
import TodoList from './todo-list';
import _ from "lodash";
class CreateToDo extends Component {
  constructor(props) {
    super(props);
    this.state = {todoItems: this.props.customToDo };
  }
  handleSubmit(e) {
    e.preventDefault();
    var newTask = {
      task: this.refs.txtTask.value,
      id: Date.now()
    };
    this.setState((prevState) => ({
       todoItems: prevState.todoItems.concat(newTask)
    }));
    this.refs.txtTask.value = '';
  }
  saveToReducer(e)
  {
    this.props.actions.saveTodos(this.state.todoItems);
   
  }
   removeFromReducer(e)
  {
    let updatedTodo = _.slice(this.state.todoItems, 0, this.state.todoItems.length - 1);
    this.setState({todoItems: updatedTodo})
    this.props.actions.removeTodos(updatedTodo);
  }
  render() {
    return (
      <div>
        <h3>TODO</h3>
        <TodoList items={this.state.todoItems} />
        <form onSubmit={this.handleSubmit.bind(this)}>
          Task: <input type="text" ref="txtTask" /> 
           <button>{'Add TODO #' + (this.state.todoItems.length + 1)}</button>
        </form>
        <br/>
         <button onClick={this.saveToReducer.bind(this)}>Save to Reduncer</button>
         <button onClick={this.removeFromReducer.bind(this)}>Remove from Reduncer</button>
      </div>
    );
  }
}
function mapStateToProps(state) {
    return {
      customToDo: (state.customToDos ? state.customToDos.ToDos : [])
    };
}
function matchDispatchToProps(dispatch){
    return {actions: bindActionCreators({ saveTodos, removeTodos }, dispatch)};
}
export default connect(mapStateToProps, matchDispatchToProps)(CreateToDo);