export function createUser (userName) {
    return {
        type: 'USER-CREATED',
        name: userName
    }
};
