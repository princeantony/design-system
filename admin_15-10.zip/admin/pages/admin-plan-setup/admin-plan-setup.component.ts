import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '../../../../../../node_modules/@angular/forms';
import _ from 'lodash';
import { AgGridNg2 } from 'ag-grid-angular';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { SUB_TITLE, APP_CONST, ADMIN_CONFIG } from '../../../../shared/constants/app.constants';
import {  GRID_CONFIG  } from '../../../../shared/constants/grid.constants';
import { AdminPlanSetupService } from '../../services/admin-plan-setup.service';
import { DivLocationOptons,
        EntrollmentOptions,
        PinLenthOptions,
        ParticipantUpdateOptions,
        CatchUpOptions,
        EmailDEOptions} from '../../../../shared/config/plan-options.config';
import { AdminGridCheckboxComponent } from '../../components/admin-grid-checkbox/admin-grid-checkbox.component';
import { AdminGridTextboxComponent } from '../../components/admin-grid-textbox/admin-grid-textbox.component';

@Component({
  selector: 'app-admin-plan-setup',
  templateUrl: './admin-plan-setup.component.html'

})
export class AdminPlanSetupComponent implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  planNumber: string;
  subTitle: string;
  planSetupResponse: any;
  moneySources: any;
  investments: any;
  context: any;
  moneySourcesColumnDefs: any;
  investmentsColumnDefs: any;
  planUpdateForm: FormGroup;
  isCustomMask: boolean;
  nameChangeAllowed: boolean;
  ssnTypeItems: any;
  loanMatching: boolean;
  moneySourceData: any;
  investmentData: any;
  private gridApi;
  shouldDisabled = false;

  participantsItmes: any;
  pinLengthItems: any;
  emailIDItems: any;
  enrollmentItems: any;
  enrollStatusItems: any;
  divLocItems: any;
  catchUpItems: any;
  frameworkComponents: any;
  private gridColumnApi;

  constructor(private planSetupService: AdminPlanSetupService,
              private fb: FormBuilder) {
                this.subTitle = SUB_TITLE.UPDATE_PLAN;
                this.moneySourcesColumnDefs = GRID_CONFIG.PLAN_UPDATE.COLUMN_DEFS_MONEY_SOURCES;
                this.investmentsColumnDefs = GRID_CONFIG.PLAN_UPDATE.COLUMN_DEFS_INVESTMENTS;
                this.ssnTypeItems = ADMIN_CONFIG.SSN_ITEMS;
              }

  ngOnInit() {
  this.participantsItmes = ParticipantUpdateOptions;
  this.pinLengthItems = PinLenthOptions;
  this.emailIDItems = EmailDEOptions;
  this.enrollmentItems = EntrollmentOptions;
  this.divLocItems = DivLocationOptons;
  this.catchUpItems = CatchUpOptions;
  this.planNumber = PayAdminGlobalState.planNumber;
  this.getMockPlanSetup();
  this.getMockEnrollmentStatusCode();
  }
onSubmit() {
  //console.log("planUpdateForm", this.planUpdateForm.value)
//const newSource = _.omit(PayAdminGlobalState.moneySource, 1)
console.log("----------PayAdminGlobalState.moneySource", PayAdminGlobalState.moneySource);
console.log("----------newSource", newSource);
}

onRadioClick(value: string) {
  this.isCustomMask =  (value === ADMIN_CONFIG.CUSTOM_MASK_VALUE) ? true : false;
}
onGridReady(params) {
  this.gridApi = params.api;
  params.api.sizeColumnsToFit();
}
  getMockPlanSetup() {
    this.planSetupService.getMockPlanSetup(this.planNumber).subscribe(planSetup => {
      //this.spinner.hide();
      if (planSetup.status === APP_CONST.SUCCESS) {
    this.planSetupResponse = planSetup.data ;
    this.createFormGroup(planSetup.data);
    this.moneySources = this.getMockMoneySource();
  }
},(err => {console.log("Error in plan load", err); } ));
  }

  createFormGroup(form){
    this.shouldDisabled = !(form.loanMatching);
    this.planUpdateForm = this.fb.group({
    loanMatching: new FormControl(form.loanMatching),
    loanPayoffs:  new FormControl({ value:form.loanPayoffs, disabled:!form.loanMatching}),
    nonACH:       new FormControl(form.nonACH),
    copyPayroll:  new FormControl(form.copyPayroll),
    crossCalendarPayroll: new FormControl(form.crossCalendarPayroll),
    negativeContrib:      new FormControl(form.negativeContrib),
    disActPartWContrib:   new FormControl(form.disActPartWContrib),
    maskSSN:    new FormControl(form.maskSSN),
    customMask: new FormControl(form.customMask),
    nameChangeAllowed: new FormControl(form.nameChangeAllowed),
    submitBatchesInAdvance: new FormControl(form.submitBatchesInAdvance),
    catchUpOption:  new FormControl(form.catchupSrcs),
    participantUpdate:  new FormControl(form.participantUpdate),
    emailDE:  new FormControl(form.emailDE),
    divSubFunc:  new FormControl(form.divSubFunc),
    enrollment:  new FormControl(form.enrollment)
    // enrollment:  new FormControl(form.enrollment)
  });
  if (form.maskSSN === ADMIN_CONFIG.CUSTOM_MASK_VALUE) {
    this.isCustomMask = true;
  }
  }
  toggleCustomMask(value)
{
  if (value) {
    this.isCustomMask = true;
  }
  else{
    this.isCustomMask = false;
  }

}
onStateChange()
{}
enableLoanPayoff(value : any){
  this.shouldDisabled = !value;

}
  getPlanSetup(){
    this.planSetupService.getPlanSetup(this.planNumber).subscribe(planSetup => {
      //this.spinner.hide();
      if(planSetup.status === APP_CONST.SUCCESS)
      {
    this.moneySources =planSetup.data.moneySources;

  }
},(err => {console.log("Error in plan setup load", err);}));

  }
  getMockMoneySource(){
    this.planSetupService.getMockMoneySource(this.planNumber).subscribe(money => {
      if(money.status === APP_CONST.SUCCESS)
      {
        this.moneySources= money.data;
        this.getMockInvestments();
      }
},(err => {console.log("Error in money source load", err);}));

  }
getMockInvestments(){
    this.planSetupService.getMockInvestments(this.planNumber).subscribe(investments => {
      if(investments.status === APP_CONST.SUCCESS)
      {
        this.investments =  investments.data;
        this.moneySourceData = this.generateMoneySourceTableData();
        this.investmentData = this.genereateInvestmentTableData();
        PayAdminGlobalState.moneySource = this.moneySourceData;
        PayAdminGlobalState.investments = this.investmentData;
      }
},(err => {console.log("Error in money source load", err);}));

  }
  getMockEnrollmentStatusCode()
  {

  }
generateMoneySourceTableData()
{
return this.planSetupService.meargeObjects(this.planSetupResponse.moneySources, this.moneySources);
}
genereateInvestmentTableData()
{
return this.planSetupService.meargeObjects(this.planSetupResponse.investments, this.investments );
}

}
