import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { MockService } from "../../../shared/services/mock.service";
import { IMenuItem } from "../../../shared/interfaces/menu-item.interface";
import { AdminMenuItems } from "../../../shared/config/admin.config";
import { Utils } from "../../../shared/utils/pay-admin.utils";
import { PageListItems } from "../../../shared/config/page-security.config";
import { IPageList } from "../../../shared/interfaces/page-list.interface";
import { ApiService } from "../../../shared/services/api.service";
import { SERVICE_URL } from "../../../shared/constants/service.constants";

@Injectable({
  providedIn: "root"
})
export class AdminService {
  constructor(private mockService: MockService, private utils: Utils, private apiService: ApiService) {}

  getMockMenuList(planNumber: string): Observable<any> {
    return this.mockService.getAdminFlags();
  }
  getMenuItemRows(menuItemsFlag: any) {
    let menuItemsToBind: IMenuItem[] = [];
    AdminMenuItems.forEach(menuItem => {
      if (menuItemsFlag[menuItem.key]) {
        menuItemsToBind.push(menuItem);
      }
    });
    return this.utils.chunkArray(menuItemsToBind, 3);
  }
}
