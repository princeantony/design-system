import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent implements OnInit {
  constructor(private modalService: ModalService) {}

  ngOnInit() {}
  closeModal(id) {
    this.modalService.close(id);
  }
}
