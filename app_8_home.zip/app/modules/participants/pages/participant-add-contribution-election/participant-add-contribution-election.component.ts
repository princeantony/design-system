import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-participant-add-contribution-election",
  templateUrl: "./participant-add-contribution-election.component.html",
  styleUrls: ["./participant-add-contribution-election.component.scss"]
})
export class ParticipantAddContributionElectionComponent implements OnInit {
  constructor() {}
  ngOnInit() {}
}
