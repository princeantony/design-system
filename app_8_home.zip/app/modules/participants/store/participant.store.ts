import { ParticipantOptionSetting } from '../model/participant.model';
import * as Participant from '../model/participant.model';

export class ParticipantStore {
  static Active = false;
  static EditMode = false;
  static ParticipantSSN = '';
  static PlanID = '';
  static Divsub = '';
  static StatusCode = '';
  static Status = '';
  static TerminationReasonList: Participant.Option[] = [];
  static ParticipantOptionSetting: ParticipantOptionSetting = new ParticipantOptionSetting();
  static ParticipantStatusList: Participant.Option[];
  static ParticipantData: Participant.ParticipantData = new Participant.ParticipantData();
  static InvestmentElectionSources: string[] = [];
  static reset() {
    debugger;
    this.Active = false;
    this.EditMode = false;
    this.ParticipantSSN = '';
    this.PlanID = '';
    this.Divsub = '';
    this.StatusCode = '';
    this.Status = '';
    this.TerminationReasonList = [];
    this.ParticipantOptionSetting.servicePayLoad = false;
    this.ParticipantStatusList = [];
    this.ParticipantData = new Participant.ParticipantData();
    this.InvestmentElectionSources = [];
  }
}
