import { Component, EventEmitter, forwardRef, Input, OnInit, Output } from '@angular/core';
import { FormControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, ValidationErrors, Validators } from '@angular/forms';

import { BaseInputComponent } from '../base-input/base-input.component';

const noop = () => {};
@Component({
  selector: 'voya-account-number',
  templateUrl: './voya-account-number.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaAccountNumberComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => VoyaAccountNumberComponent),
      multi: true
    }
  ]
})
export class VoyaAccountNumberComponent extends BaseInputComponent
  implements OnInit {
  private _value: any = '';
  isLabelHidden: boolean;
  @Input()
  isMatching = true;
  @Input()
  name: string;
  @Output()
  keyup = new EventEmitter<string>();

  ngOnInit() {
    this.isLabelHidden = false;
    if (this._isRequired === undefined) {
      this._isRequired = true;
    }
  }
  get value(): any {
    return this._value;
  }
  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  onTouched(event: any) {
    if (event.target.value === '') {
      this.isLabelHidden = true;
    }
    if (event.target.value !== '') {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus() {
    this.isLabelHidden = false;
  }
  onKeyup() {
    this.keyup.emit();
  }
  propagateChange = (_: any) => {};

  writeValue(value: string): void {
    this._value = value || '';
    if (this._value.length > 0) {
      this.isLabelHidden = false;
    }
    if (this._value.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  validate(ctrl: FormControl): ValidationErrors | null {
    if (this.isRequired) {
      return Validators.compose([Validators.required])(ctrl);
    } else {
      return null;
    }
  }
}
