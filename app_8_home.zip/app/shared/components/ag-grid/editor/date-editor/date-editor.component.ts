import { AfterViewInit, Component, ViewChild, ViewContainerRef } from '@angular/core';
import { ICellEditorAngularComp } from 'ag-grid-angular';

@Component({
    selector: "app-numeric-editor",
    template: `<input #input 
    appDate 
  [(ngModel)]="value" 
  style="width: 100%">`
})
export class DateEditorComponent
    implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: number;
    private cancelBeforeStart: boolean = false;

    @ViewChild("input", { read: ViewContainerRef })
    public input;

    agInit(params: any): void {
        console.log('------------ params', params);
        this.params = params;
        this.value = this.params.value;
    }

    getValue(): any {
        return this.value;
    }

    isCancelBeforeStart(): boolean {
        return this.cancelBeforeStart;
    }

    ngAfterViewInit() {
        setTimeout(() => {
            this.input.element.nativeElement.focus();
        });
    }
}
