export interface Option {
  value: string;
  displayText: string;
}
