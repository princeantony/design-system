import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-plans',
  templateUrl: './list-plans.component.html',
  styleUrls: ['./list-plans.component.css']
})
export class ListPlansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
