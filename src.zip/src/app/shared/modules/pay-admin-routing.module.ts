import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListPlansComponent } from '../../modules/plans/components/list-plans/list-plans.component';

const payAdmiinRoutes: Routes = [
  {
    path: 'plan',
    component: ListPlansComponent,
    outlet: 'popup'
  }
  
];

@NgModule({
  imports: [
    RouterModule.forChild(payAdmiinRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    
    
  ]
})
export class PayAdminRoutingModule { }