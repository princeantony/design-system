import { Component, OnInit } from '@angular/core';
import {MESSAGES} from '../../../constants/app.constants';
@Component({
  selector: 'app-voya-label',
  templateUrl: './voya-label.component.html',
  styleUrls: ['./voya-label.component.css']
})
export class VoyaLabelComponent implements OnInit {
labelText = MESSAGES.VOYA_WORKING_TIME;
  constructor() {
   }

  ngOnInit() {
  }

}
