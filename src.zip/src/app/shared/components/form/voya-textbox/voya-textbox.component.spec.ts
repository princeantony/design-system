import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaTextboxComponent } from './voya-textbox.component';

describe('VoyaTextboxComponent', () => {
  let component: VoyaTextboxComponent;
  let fixture: ComponentFixture<VoyaTextboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaTextboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaTextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
