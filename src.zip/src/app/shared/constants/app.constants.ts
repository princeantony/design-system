export const EMPLOYEE_CONSTANT=
{
    FIRST_NAME: 'Employee First Name: ',
    LAST_NAME:'Employee Last Name: ',
    PHONE_NUMBER:'Phone Number:',
    EMAIL:'Email Address:'

};

export const MESSAGES=
{
    VOYA_WORKING_TIME: 'timing message',
    SERVICE_ERROR: 'There is an error occurred while calling the service!',
    SERVICE_SUCCESS: 'Service call succeeded!',
    SERVICE_START: 'Please wait... Service call in progress!'
};