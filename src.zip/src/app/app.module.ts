import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { ListPlansComponent } from './modules/plans/components/list-plans/list-plans.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';
import { HeaderComponent } from './shared/components/layout/header/header.component';
import { VoyaTextboxComponent } from './shared/components/form/voya-textbox/voya-textbox.component';
import { VoyaLabelComponent } from './shared/components/form/voya-label/voya-label.component';
import { VoyaButtonComponent } from './shared/components/form/voya-button/voya-button.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    ListPlansComponent,
    PlanSelectionComponent,
    HeaderComponent,
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent
    
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
