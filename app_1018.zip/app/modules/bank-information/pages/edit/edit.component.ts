import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { BankInfoService } from '../../services/bank-info.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { BankStates } from "../../../../shared/config/state.config";
import { IMenuItem } from '../../../../shared/interfaces/menu-item.interface';
import _ from 'lodash';
import { IBankInfo } from '../../../../shared/interfaces/bank.interface';
import { ModalService } from '../../../../shared/services/modal.service';




@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']

})
export class EditComponent implements OnDestroy {
  
/* inputValue: string = 'Hello sandhya';
inputEmail: string = 'sandhyah@voya.com';
inputSSN: string = '';
inputZip: string = '';
inputRoutingNumber: number;
fName: string = 'sandhya'; */
sub: any;
formData:any;

divsubID : string;
bankStates :any; 
bankInfo: any;
divSubs: any;
bankNames:any;
editInfo:any;
updateInfo: IBankInfo;
 copyToAll: boolean = false;

 /* bankName: string;
  city: string;
  state: string;
  zipcode: string;
  address1:string;
  abaNumber:string;
  confirmAbaNumber:string;
  acctNumber:string;
  confirmAcctNumber:string;
  accountType:string; */
  

bankInfoForm = this.fb.group({
   
  //divsub: [''],
  //divsubcopy: [''],
  bankName: [''],
  city: [''],
  state: [''],
  zipcode: [''],
  address1:[''],
  abaNumber:[''],
  confirmAbaNumber:[''],
  acctNumber:[''],
  confirmAcctNumber:[''],
  accountType:[''],
  copyToAll:[false]
  

});
hidePageTitle:boolean;
  subTitle: string;
  planNumber:string;
  emptyBanknames: any;

  constructor(private route: ActivatedRoute, 
              private router: Router, 
              private fb: FormBuilder, 
              private bankInfoService: BankInfoService,
              private modalservice: ModalService ) { }

  ngOnInit(params) {


    

    this.hidePageTitle = false;
    this.subTitle = "Bank Information";
   this.planNumber =  PayAdminGlobalState.planNumber;

    this.bankStates = BankStates;
    this.bankInfo = PayAdminGlobalState.bankinfo;
    //console.log("---------------this.bankInfo", this.bankInfo);
    this.divSubs = PayAdminGlobalState.subDiv;
    this.bankNames = _.filter(this.bankInfo, 'bankName');
    //console.log("------------bankNames", this.bankNames);
    this.emptyBanknames = _.filter(this.bankInfo, ['valid', false]);
   
    
    this.sub = this.route.params.subscribe(params => {
      this.divsubID = params['divsubId'];
      
        
        this.editInfo =  _.filter(this.bankInfo, ['divsub', this.divsubID])[0];
        
       
        
        this.bankInfoForm.controls['bankName'].setValue(this.editInfo.bankName);
        this.bankInfoForm.controls['address1'].setValue(this.editInfo.address1);
        this.bankInfoForm.controls['city'].setValue(this.editInfo.city);
        this.bankInfoForm.controls['state'].setValue(this.editInfo.state);
        this.bankInfoForm.controls['zipcode'].setValue(this.editInfo.zipcode);
        this.bankInfoForm.controls['acctNumber'].setValue(this.editInfo.acctNumber);
        this.bankInfoForm.controls['confirmAcctNumber'].setValue(this.editInfo.acctNumber);
        this.bankInfoForm.controls['accountType'].setValue( _.split(this.editInfo.accountType, " ")[0]);
        this.bankInfoForm.controls['abaNumber'].setValue(this.editInfo.abaNumber);
        this.bankInfoForm.controls['confirmAbaNumber'].setValue(this.editInfo.abaNumber);

       
       

      


    });

    PayAdminGlobalState.previousPage = "/bankInfo";
    PayAdminGlobalState.currentPage = "/bankInfo/edit/"+this.divsubID;
    
   /*  if(!this.bankNames){
      this.showCopyDropdown = false;
    } */


  }

  onSelect(value){
    
    let bankInfoTemp = _.filter(this.bankNames, ['id', value ])[0];
    
    
    
        
        this.bankInfoForm.controls['bankName'].setValue(bankInfoTemp.bankName);
        this.bankInfoForm.controls['address1'].setValue(bankInfoTemp.address1);
        this.bankInfoForm.controls['city'].setValue(bankInfoTemp.city);
        this.bankInfoForm.controls['state'].setValue(bankInfoTemp.state);
        this.bankInfoForm.controls['zipcode'].setValue(bankInfoTemp.zipcode);
        this.bankInfoForm.controls['acctNumber'].setValue(bankInfoTemp.acctNumber);
        this.bankInfoForm.controls['confirmAcctNumber'].setValue(bankInfoTemp.acctNumber);
        this.bankInfoForm.controls['accountType'].setValue( _.split(bankInfoTemp.accountType, " ")[0]);
        this.bankInfoForm.controls['abaNumber'].setValue(bankInfoTemp.abaNumber);
        this.bankInfoForm.controls['confirmAbaNumber'].setValue(bankInfoTemp.abaNumber);
  }

  openHelpModal(){
    this.modalservice.open('helpModal');

  }

 

  

  onSubmit(){
    console.log("---------------------bankInfoForm", this.bankInfoForm);
    
    /* this.updateInfo = this.editInfo;
    _.merge(this.updateInfo, this.bankInfoForm.value); */
    console.log("-----------------")
     this.bankInfoForm.removeControl('confirmAbaNumber');
     this.bankInfoForm.removeControl('confirmAcctNumber');
     this.copyToAll = this.bankInfoForm.controls['copyToAll'].value;
     
    this.bankInfoForm.removeControl('copyToAll');

    this.updateInfo = this.bankInfoForm.value;
    
    //this.updateInfo.addressId = this.editInfo.addressId;
    //this.updateInfo.valid = this.editInfo.valid;
    //this.updateInfo.planNumber = this.editInfo.planNumber;
    //this.updateInfo.divsub = this.editInfo.divsub;
PayAdminGlobalState.divsubId = this.editInfo.divsub;
    
    PayAdminGlobalState.bankDetails ={'bankInfo':this.updateInfo, copyToAll: this.copyToAll } ;
    
    
      this.router.navigate(["bankInfo/confirm/"]);
      
     
      
      
  }
  gotoBack(){
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
