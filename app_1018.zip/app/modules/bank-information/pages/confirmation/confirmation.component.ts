import { Component, OnInit, ElementRef } from '@angular/core';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { IBankInfo } from '../../../../shared/interfaces/bank.interface';
import { BankInfoService } from '../../services/bank-info.service';
import {APP_CONST} from '../../../../shared/constants/app.constants';
import { NgxSpinnerService } from 'ngx-spinner';
import _ from 'lodash';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']

})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub : any;
  updateTime: any;
  updateDate: any;
  bankDetails:any;
  accType: string;
  divSubs : any;
  divSub: string;
  hidePageTitle:boolean;
  print:boolean = false;
  printBtn:boolean = false;
  subTitle:string;
  planNumber:string;
  payAdminGlobalState: PayAdminGlobalState;
  constructor( 
              private route: ActivatedRoute, 
              private router : Router,
              private printForm: ElementRef,
              private spinner: NgxSpinnerService, 
              private modalService: ModalService,

              private bankInfoService: BankInfoService) { }

  ngOnInit() {

    PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
    PayAdminGlobalState.currentPage = "/bankInfo/confirm";

    this.hidePageTitle = false;
   this.subTitle = "Bank Information";
  this.planNumber =  PayAdminGlobalState.planNumber; 
  
   this.bankDetails = PayAdminGlobalState.bankDetails;
   console.log("-------------this.bankDetails", this.bankDetails);
   this.divSubs = PayAdminGlobalState.subDiv;
  
   this.divSub =_.filter(this.divSubs, ['id', PayAdminGlobalState.divsubId])[0].text;
   //this.divSub = PayAdminGlobalState.divsubId;
   
   if(this.bankDetails.bankInfo.accountType == "C"){
     this.accType = "Checking";

   }
   else{
     this.accType = "Savings";
   }

   this.route.url.subscribe(params => {
    if(params[1].path == "print"){
      this.printBtn = true;
      this.print = true;
  
    }
    
  
  });
   
  }
onPrint(){
  this.printBtn = false;
  setTimeout(()=>{    
    window.print();
}, 50);
PayAdminGlobalState.successMsg = "";

  
 

}
  onSubmit(){
    let planId = PayAdminGlobalState.planNumber;
   this.spinner.show();
    this.updateDate = new Date().toLocaleDateString();
    this.updateTime = new Date().toLocaleTimeString();
    console.log("previous page", PayAdminGlobalState.previousPage);
    if(_.split(PayAdminGlobalState.previousPage, '/')[2] === "edit"){

      this.bankInfoService.updateBankInfo(this.bankDetails,planId,PayAdminGlobalState.divsubId).subscribe(bankInfo => { 
      this.spinner.hide();
   //console.log("--------bankInfo",bankInfo);
   if(bankInfo.status === APP_CONST.SUCCESS){
    PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
    
    this.router.navigate(["/home/success"]);
   }
   
},  (err => {console.log("Error", err),this.spinner.hide();}));

    }
    else{
         this.bankInfoService.postBankInfo(this.bankDetails,planId,PayAdminGlobalState.divsubId).subscribe(bankInfo => { 
        this.spinner.hide();
        //console.log("--------bankInfo",bankInfo);
        if(bankInfo.status === APP_CONST.SUCCESS){
            PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
            
            this.router.navigate(["/home/success"]);
       }
   
 }, (err => {console.log("Error", err),this.spinner.hide();}));

      

    }
   
    //this.bankInfoService.postBankInfo(payload, PayAdminGlobalState.planNumber);
    
    
    

  }

  onEdit(){
    this.router.navigate([PayAdminGlobalState.previousPage]);
    

  }
 

  

}
