import { Component, OnInit, Input } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { Router } from '../../../../../../node_modules/@angular/router';

@Component({
  selector: 'app-bank-modal',
  templateUrl: './bank-modal.component.html',
  styleUrls: ['./bank-modal.component.scss']
})
export class BankModalComponent implements OnInit {
  @Input() addressId;

  constructor(private modalService: ModalService,
              private router: Router) { }

  ngOnInit() {
  }

  closeModal(id: string) {
    this.modalService.close(id);
}
continueTo(){
  this.router.navigate(["/bankInfo/create/"+this.addressId]);
}

}


