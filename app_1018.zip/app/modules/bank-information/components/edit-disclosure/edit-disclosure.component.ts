import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-disclosure',
  templateUrl: './edit-disclosure.component.html',
  styleUrls: ['./edit-disclosure.component.scss']
})
export class EditDisclosureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
