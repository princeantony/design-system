import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDisclosureComponent } from './edit-disclosure.component';

describe('EditDisclosureComponent', () => {
  let component: EditDisclosureComponent;
  let fixture: ComponentFixture<EditDisclosureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDisclosureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDisclosureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
