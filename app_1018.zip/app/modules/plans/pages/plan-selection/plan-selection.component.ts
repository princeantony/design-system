import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';

@Component({
  selector: 'app-plan-selection',
  templateUrl: './plan-selection.component.html'
})
export class PlanSelectionComponent implements OnInit {
  hidePageTitle:boolean = true;
  pageTitleClass: boolean  = true;
  
  pageTitle = "Plan Selection"
  constructor() {
   }
  ngOnInit() {
    PayAdminGlobalState.currentPage = "/plans";
  }
}
