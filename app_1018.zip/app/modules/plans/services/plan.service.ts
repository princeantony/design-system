import { Injectable } from '@angular/core';
import { ApiService } from '../../../shared/services/api.service';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { Observable } from 'rxjs';
import { MockService } from '../../../shared/services/mock.service';

@Injectable({
  providedIn: 'root'
})
export class PlanService {
  constructor(private apiService: ApiService, private mockService : MockService) {
   }
   getPlans():Observable<any>
   {
    return this.apiService.get(SERVICE_URL.GET_LISTPLAN_URL)
   }
   getMockPlans():Observable<any>
   {
   return this.mockService.getListPlans();
   }
}
