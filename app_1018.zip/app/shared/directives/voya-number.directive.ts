import { Directive, HostListener, ElementRef, Input } from "@angular/core";

@Directive({
  selector: "[numberDirective]"
})
export class NumberDirective {
  @Input() numberLength: number;
  @Input() _numberType: string;
  set numberType(value: string) {
    debugger;
    this._numberType = value || "";
    console.log("NumberTypeeeee : " +value);
    if(this._numberType === "routing"){
      this.el.setAttribute("pattern","^[0-3]\\d{8}");
    }
    if(this._numberType === "zip"){
      //^\d{5}(?:[-\s]?\d{4})?$
      this.el.setAttribute("pattern","^\\d{5}(?:[-\\s]?\\d{4})?$");
    }
  }
  get numberType(): string {
    return this._numberType;
  }
  private el: any;

  constructor(
    private elementRef: ElementRef
  ) {
    this.el = this.elementRef.nativeElement;
    //^[0-3]\d{8}$
    //this.el.setAttribute("patter","^[0-3]\\d{8}");
    //this.el.setAttribute("pattern","\\d{2}-(?:\\d{4}-){3}\\d{1}");
  }
  ngOnInit() {
    this.numberLength = 99;
  }


  @HostListener("keydown", ["$event.target.value", "$event"])
  onKeyDown(value, event) {
    const e = <KeyboardEvent>event;
    if (
      [46, 8, 9, 27, 13, 110, 190].indexOf(e.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (e.keyCode === 65 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+C
      (e.keyCode === 67 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+V
      (e.keyCode === 86 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+X
      (e.keyCode === 88 && (e.ctrlKey || e.metaKey)) ||
      // Allow: home, end, left, right
      (e.keyCode >= 35 && e.keyCode <= 39)
    ) {
      // let it happen, don't do anything
      return;
    }
    // Ensure that it is a number and stop the keypress
    if (
      (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) &&
      (e.keyCode < 96 || e.keyCode > 105)
    ) {
      e.preventDefault();
    }
    if (value.length >= this.numberLength) {
      e.preventDefault();
    }
  }
}
