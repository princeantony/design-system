import { Directive, HostListener, ElementRef, OnInit } from "@angular/core";
import { VoyaSSNPipe } from "../pipes/voya-SSN.pipe";

@Directive({
  selector: "[appSSN]"
})
export class SSNDirective {
  private el: any;

  constructor(
    private elementRef: ElementRef,
    private formatSSNpipe: VoyaSSNPipe
  ) {
    this.el = this.elementRef.nativeElement;
  }
  ngOnInit() {
    this.el.value = this.formatSSNpipe.transform(this.el.value);
  }
  @HostListener("focus", ["$event.target.value", "$event"])
  onFocus(value, event) {
    console.log("Value On Focus: " + value);
    this.el.value = this.formatSSNpipe.parse(value); // opossite of transform

    console.log("Value On Focus: " + this.el.value);
    console.log("event.which: " + event.which);
    if (event.which === 9) {
      return false;
    }
    //this.el.select();
  }

  @HostListener("blur", ["$event.target.value"])
  onBlur(value) {
    this.el.value = this.formatSSNpipe.transform(value);
  }

  @HostListener("keyup", ["$event.target.value", "$event"])
  onkeyup(value, event) {
    var valueLength = value.replace(/-/g, "").length;
    console.log("Value on KeyUP: " + value.replace(/-/g, ""));
    if (valueLength === 3) {
      this.el.value = this.el.value + "-";
    }
    if (valueLength === 5) {
      this.el.value = this.el.value + "-";
    }
  }

  @HostListener("keydown", ["$event.target.value", "$event"])
  onKeyDown(value, event) {
    const e = <KeyboardEvent>event;
    if (
      [46, 8, 9, 27, 13, 110, 190].indexOf(e.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (e.keyCode === 65 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+C
      (e.keyCode === 67 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+V
      (e.keyCode === 86 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+X
      (e.keyCode === 88 && (e.ctrlKey || e.metaKey)) ||
      // Allow: home, end, left, right
      (e.keyCode >= 35 && e.keyCode <= 39)
    ) {
      // let it happen, don't do anything
      return;
    }
    // Ensure that it is a number and stop the keypress
    if (
      (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) &&
      (e.keyCode < 96 || e.keyCode > 105)
    ) {
      e.preventDefault();
    }
    if (value.replace(/-/g, "").length >= 9) {
      e.preventDefault();
    }
  }
}
