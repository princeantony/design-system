import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import{SERVICE_URL} from '../../shared/constants/service.constants';

import { Observable } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';


import { HttpErrorHandler, HandleError } from './http-error-handler.service';
import { IApiService } from '../interfaces/api-service.interface';



@Injectable()
export class ApiService implements IApiService{
  appUrl = SERVICE_URL.APP_URL;
  private handleError: HandleError;

private httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};
  constructor(private http: HttpClient) {
    //this.handleError = httpErrorHandler.createHandleError('ServiceError');
  }
  

  
  get(apiMethod: string): Observable<any> {  
    return this.http.get<any>(this.appUrl + apiMethod)
      .pipe(
        //catchError(this.handleError<any>('get', []))
      );
  }
  getByKey(apiMethod: string, key: string, value: string): Observable<any> {
    // Add safe, URL encoded search parameter if there is a get term
    const options = value ?{ params: new HttpParams().set(key, value) } : {};

    return this.http.get<any>(this.appUrl+apiMethod,  options)
      .pipe(
        //catchError(this.handleError<any>('getByKey', []))
      );
  }
  getByObject(apiMethod: string, paramsObj: any): Observable<any> {
    // Add safe, URL encoded object as parameter if there is a get term
    const options = paramsObj ? { params: paramsObj } : {};

    return this.http.get<any>(this.appUrl+apiMethod, options)
      .pipe(
        //catchError(this.handleError<any>('getByObject', []))
      );
  }

  post (apiMethod: string,inputData: any): Observable<any> {
    return this.http.post<any>(this.appUrl+apiMethod, inputData, this.httpOptions)
      .pipe(
        //catchError(this.handleError('post', hero))
      );
  }
  put (apiMethod: string,inputData: any): Observable<any> {
    return this.http.put<any>(this.appUrl+apiMethod, inputData, this.httpOptions)
      .pipe(
        //catchError(this.handleError('post', hero))
      );
  }

}