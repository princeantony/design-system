import { Component, OnInit, Input, forwardRef } from "@angular/core";
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";
import { SSNDirective } from "../../../directives/voya-ssn.directive";
import { VoyaSSNPipe } from "../../../pipes/voya-SSN.pipe";

@Component({
  selector: "voya-ssn",
  templateUrl: "./voya-ssn.component.html",
  styleUrls: ["./voya-ssn.component.scss"],
  providers: [
    VoyaSSNPipe,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaSsnComponent),
      multi: true
    }
  ]
})
export class VoyaSsnComponent implements OnInit, ControlValueAccessor {
  isLabelHidden: boolean;
  propagateChange = (_: any) => {};
  inputValue: string;
  @Input() placeHolderText: string;
  @Input() controlLabel: string;
  ngOnInit() {
    this.isLabelHidden = false;
  }
  writeValue(value: string): void {
    this.inputValue = value || "";
    console.log("Input Value From Component" + this.inputValue);
    if (this.inputValue.length > 0) {
      this.isLabelHidden = false;
    }
    if (this.inputValue.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {}
  setDisabledState?(isDisabled: boolean): void {}

  onChange(event) {
    this.propagateChange(event.target.value);
  }

  showHideLabel(event: any) {
    if (event.target.getAttribute("placeholder") && event.target.value === "") {
      this.isLabelHidden = true;
    }
    if (event.target.value !== "") {
      this.isLabelHidden = false;
    }
  }
}
