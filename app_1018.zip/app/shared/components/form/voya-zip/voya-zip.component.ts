import {
  Component,
  OnInit,
  Input,
  forwardRef
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'voya-zip',
  templateUrl: './voya-zip.component.html',
  styleUrls: ['./voya-zip.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaZipComponent),
      multi: true
    }
  ]
})
export class VoyaZipComponent implements OnInit, ControlValueAccessor {
  isLabelHidden: boolean = false;

  propagateChange = (_: any) => {};
  inputValue: string;
  @Input() placeHolderText: string;
  @Input() controlLabel: string;
  // @Input()
  // set inputValue(value: string) {
  //   this.inputValue = (value && value.trim()) || '';
    
  //   if (this.inputValue) this.inputValue = this.inputValue.replace(/-/g,'');
  //   this.propagateChange(this.inputValue);
  // }
  // get inputValue(): string {
  //   if (this.inputValue) this.inputValue = this.inputValue.replace(/-/g,'');
  //   return this.inputValue;
  // }

  ngOnInit() {}

  writeValue(value: string): void {
    this.inputValue = value || "";
    if (this.inputValue.length > 0) {
      this.isLabelHidden = false;
    }
    if (this.inputValue.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {}
  setDisabledState?(isDisabled: boolean): void {}

  onChange(event) {
    this.propagateChange(event.target.value);
  }
  
  showHideLabel(event: any) {
    if (event.target.getAttribute("placeholder") && event.target.value === "") {
      this.isLabelHidden = true;
    }
    if (event.target.value !== "") {
      this.isLabelHidden = false;
    }
  }

}
