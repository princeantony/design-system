import { Component, OnInit, Input, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'voya-counter',
  templateUrl: './voya-counter.component.html',
  styleUrls: ['./voya-counter.component.scss'],
  providers: [
    { 
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaCounterComponent),
      multi: true
    }
  ]
})
export class VoyaCounterComponent implements OnInit, ControlValueAccessor {
  
  propagateChange = (_: any) => {};
  constructor() { }
  @Input() _counterValue = 0;
  get counterValue() {
    return this._counterValue;
  }

  set counterValue(val) {
    this._counterValue = val;
    this.propagateChange(this._counterValue);
  }
  ngOnInit() {
  }

  increment(){
    this.counterValue++;
  }

  decrement(){
    this.counterValue--;
  }

  
  writeValue(value: any): void {
    if(value){
      this.counterValue = value;
    }    
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {
  }
  setDisabledState?(isDisabled: boolean): void {
  }

}
