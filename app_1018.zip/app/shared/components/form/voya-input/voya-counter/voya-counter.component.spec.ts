import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaCounterComponent } from './voya-counter.component';

describe('VoyaCounterComponent', () => {
  let component: VoyaCounterComponent;
  let fixture: ComponentFixture<VoyaCounterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaCounterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaCounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
