import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaSelectComponent } from './voya-select.component';

describe('VoyaSelectComponent', () => {
  let component: VoyaSelectComponent;
  let fixture: ComponentFixture<VoyaSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
