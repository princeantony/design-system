import { Component, OnInit, Input, forwardRef } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgSelectModule, NgOption } from '@ng-select/ng-select';

@Component({
  selector: 'voya-select',
  templateUrl: './voya-select.component.html',
  styleUrls: ['./voya-select.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaSelectComponent),
      multi: true
    }
  ]
})
export class VoyaSelectComponent implements OnInit, ControlValueAccessor {
  propagateChange = (_: any) => {};
  @Input()
  _selectListData: { value: string; label: string }[];
  set SelectListData(list: { value: string; label: string }[]) {
    this._selectListData = list || [{ value: '0', label: 'Select ' }];
    this.propagateChange(this._selectListData);
  }
  get SelectListData() {
    return this._selectListData;
  }

  @Input()
  _SelectedItem: any 
  set SelectedItem(value: any){
    this._SelectedItem = value || 'No Value Selected'
    this.propagateChange(this._selectListData);
  }
  get SelectedItem(){
    return this._SelectedItem;

  }

  writeValue(value: any): void {
    if (value) {
      this.SelectListData = value;
    }
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {}
  setDisabledState?(isDisabled: boolean): void {}

  constructor() {}

  ngOnInit() {}
}
