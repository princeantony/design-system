import { Component, OnInit, Input, forwardRef } from "@angular/core";
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";

@Component({
  selector: "voya-routing-number",
  templateUrl: "./voya-routing-number.component.html",
  styleUrls: ["./voya-routing-number.component.scss"],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaRoutingNumberComponent),
      multi: true
    }
  ]
})
export class VoyaRoutingNumberComponent implements OnInit {
  isLabelHidden: boolean;
  propagateChange = (_: any) => {};
  inputValue: string;
  @Input() placeHolderText: string;
  @Input() controlLabel: string;
  ngOnInit() {
    this.isLabelHidden = false;
  }
  writeValue(value: string): void {
    this.inputValue = value || "";
    console.log("Input Value From Component" + this.inputValue);
    if (this.inputValue.length > 0) {
      this.isLabelHidden = false;
    }
    if (this.inputValue.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {}
  setDisabledState?(isDisabled: boolean): void {}

  onChange(event) {
    this.propagateChange(event.target.value);
  }

  showHideLabel(event: any) {
    if (event.target.getAttribute("placeholder") && event.target.value === "") {
      this.isLabelHidden = true;
    }
    if (event.target.value !== "") {
      this.isLabelHidden = false;
    }
  }
}
