import { Router } from "@angular/router";
import { Component, OnInit, Input } from "@angular/core";
import {ListPlan} from '../../../mocks/listPlan';
import _ from 'lodash';
@Component({
  selector: "app-page-title",
  templateUrl: "./page-title.component.html"
})
export class PageTitleComponent implements OnInit {
  @Input() hidePageTitle: boolean;
  @Input() pageTitleClass: boolean;
  @Input() pageTitle: string;
  @Input() changePlan: boolean;
  @Input() planNumber : string;
  @Input() subTitle: string;
   selectedPlan : any;
   planTitle: string;
   planList = ListPlan.data;
  appTitle = "Payroll/Administration";
  linkText = "Change Plan";
  constructor(private router: Router) {}
 ngOnInit() {

      this.selectedPlan = _.find(this.planList, ['planNumber', this.planNumber]);
      if(this.selectedPlan){
        this.planTitle = "- " +this.selectedPlan.planNumber + "-" + this.selectedPlan.planName;

      }  
}
  navToPlans() {
    if (!this.hidePageTitle) {
      this.router.navigate(['/plans']);
    }
  }
  navToHome(){
    this.router.navigate(['/home']);
  }
}
