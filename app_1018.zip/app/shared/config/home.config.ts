import { IMenuItem } from "../interfaces/menu-item.interface";
    export const HomeMenuItems: IMenuItem[] = [
      {
        key: "addEnrollmentPageActive",
        menuHeading: "Add/Enroll",
        menuSubheading: "Add/Enroll Participants",
        menuIcon: "addenroll.svg",
        linkTo: "bankinfo"
      },
      {
        key: "participantUpdatePageActive",
        menuHeading: "Participant Update",
        menuSubheading: "View/Update participant information",
        menuIcon: "participantupdate.svg",
        linkTo: "bankinfo"
      },
      {
        key: "batchParticipantUpdateImportPageActive",
        menuHeading: "Batch Participant Update",
        menuSubheading: "Update multiple participant",
        menuIcon: "batchparticipantupdate.svg",
        linkTo: "bankinfo"
      },
      {
        key: "contributionPageActive",
        menuHeading: "Contributions",
        menuSubheading: "Process contributions to accounts",
        menuIcon: "contributions.svg",
        linkTo: "bankinfo"
      },
      {
        key: "pendingBatchPageActive",
        menuHeading: "Pending/Submitted Batches",
        menuSubheading: "Review batch information",
        menuIcon: "pendingsubmittedbatches.svg",
       linkTo: "bankinfo"
      },
      {
        key: "loanRepaymentPageActive",
        menuHeading: "Loan Repayment",
        menuSubheading: "Process loan repayments",
        menuIcon: "loanrepayment.svg",
        linkTo: "bankinfo"
      },
      {
        key: "bankInfoPageActive",
        menuHeading: "Bank Information",
        menuSubheading: "Add or update assigned bank",
        menuIcon: "bankinformation.svg",
        linkTo: "bankInfo"

      },
      {
        key: "adminPageActive",
        menuHeading: "Administration",
        menuSubheading: "Review and update your settings",
        menuIcon: "administration.svg",
        linkTo: "bankinfo"
      }
    ];
