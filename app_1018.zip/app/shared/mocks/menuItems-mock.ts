
import { IApiResponse } from "../interfaces/api-response.interface";

export const HOME_FLAGS: IApiResponse =
{
  "status": "SUCCESS",
  "data": {
    "addEnrollmentImportPageActive": true,
    "addEnrollmentPageActive": false,
    "bankInfoPageActive": true,
    "batchParticipantUpdateImportPageActive": false,
    "batchParticipantUpdatePageActive": true,
    "contribImportPageActive": true,
    "contributionPageActive": true,
    "loanImportPageActive": false,
    "loanRepaymentPageActive": false
  }
}
