export const MESSAGES=
{
    VOYA_WORKING_TIME: 'The voya office timing message',
    VOYA_APP_NAME : 'Payroll/Administration',
    SERVICE_ERROR: 'There is an error occurred while calling the service!',
    SERVICE_SUCCESS: 'Service call succeeded!',
    SERVICE_START: 'Please wait... Service call in progress!'
};

export const GRID_CONFIG = {
    LIST_PLAN: {
      GRID_SIZE : {width: 555, height: 800},
      COLUMN_DEFS : [
      { headerName: "Plan Number", field: "planNumber", width: 200 },
      { headerName: "Plan Name", field: "planName", width: 350 }
    ]},
    LIST_USRS: {
        GRID_SIZE : {width: 555, height: 800},
        COLUMN_DEFS : [
        { headerName: "ID", field: "id", width: 200 },
        { headerName: "Name", field: "name", width: 350 },
        {headerName: "User Name", field: "username", width: 350 }
      ]},

      BANK_INFO: {
      GRID_SIZE : {width: 800, height: 800},
      COLUMN_DEFS : [
      { headerName: "Division/Location Number", field: "divsub", width: 200 },
      { headerName: "Division/Location Name", field: "textOnly", width: 300 },
      { headerName: "Bank Name", field: "bankName", width: 150, suppressFilter: true },
      { headerName: "Account Type", field: "accountTypeDescription", width: 125, suppressFilter: true },
      { headerName: "Actions", field: "actions", cellRenderer: "linkRenderer", width: 105, suppressFilter: true }
      

    ]}


  };
export const APP_CONST = 
{
    APP_CONTEXT: '../',
    LOGIN_SUCCESS: 'SUCCESS', // to be removed
    SUCCESS: 'SUCCESS'

};

export const ROUTER_CONST = 
{
  ADD_BANK : "Add Bank",
  EDIT_BANK: "Edit"
}



export enum INPUT_TYPE {
  text = "text",
  alphabets = "alphabets",
  alphanumeric = "alphanumeric",
  number = "number",
  ssn = "ssn",
  email = "email",
  zip = "zip",
  percentage = "percentage",
  currency = "currency"
}

export interface INPUT_CONFIG {
  id: string;
  class?: string;
  name: string;
  type: string;
  label: string;
  placeholder: string;

  required?: boolean;
  disabled?: boolean;
  readOnly?: boolean;

  pattern?: string;
  maxlength?: number;
  min?: number;
  max?: number;

  rows?: number;
  error: string;
}