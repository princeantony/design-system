import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { SpinnerComponent } from './shared/components/layout/spinner/spinner.component';
import { PlanListComponent } from './modules/plans/components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';


import {StoreDevtoolsModule} from '@ngrx/store-devtools';

import { PayAdminRoutingModule, PayAdminRoutingComponents } from './shared/modules/pay-admin-routing.module';
import {PayAdminHomeComponent} from './modules/home/pages/pay-admin-home/pay-admin-home.component'; 
import { HeaderComponent } from './shared/components/layout/header/header.component';

import { TimeInfoComponent } from './shared/components/time-info/time-info.component';
import { PageTitleComponent } from './shared/components/layout/page-title/page-title.component';
import { TitleMessageComponent } from './shared/components/layout/title-message/title-message.component';
import { PayAdminMenuComponent } from './modules/home/components/pay-admin-menu/pay-admin-menu.component';
import { ModalService } from './shared/services/modal.service';
import { BrowserInfoComponent } from './shared/components/browser-info/browser-info.component';


import { BankAvailableComponent } from './modules/bank-information/pages/bank-available/bank-available.component';
import { BankListComponent } from './modules/bank-information/components/bank-list/bank-list.component';

import {ApiService} from './shared/services/api.service';


import { GridLinkComponent } from './modules/bank-information/components/grid-link/grid-link.component';
import { BankModalComponent } from './modules/bank-information/components/bank-modal/bank-modal.component';
import { ConfirmationComponent } from './modules/bank-information/pages/confirmation/confirmation.component';
import { EditDisclosureComponent } from './modules/bank-information/components/edit-disclosure/edit-disclosure.component';
import { BankSubmitComponent } from './modules/bank-information/components/bank-submit/bank-submit.component';
import { HelpComponent } from './modules/bank-information/components/help/help.component';
import { EditComponent } from './modules/bank-information/pages/edit/edit.component';
import { CreateComponent } from './modules/bank-information/pages/create/create.component';

//Form Components
import { VoyaTextboxComponent } from './shared/components/form/voya-textbox/voya-textbox.component';
import { VoyaLabelComponent } from './shared/components/form/voya-label/voya-label.component';
import { VoyaButtonComponent } from './shared/components/form/voya-button/voya-button.component';
import { GridComponent } from './shared/components/form/voya-grid/grid.component';
import { VoyaLinkComponent } from './shared/components/form/voya-link/voya-link.component';
//import { InputTextComponent } from './shared/components/form/voya-input/input-text/input-text.component';
import { VoyaEmailComponent } from './shared/components/form/voya-input/voya-email/voya-email.component';
import { VoyaZipComponent } from './shared/components/form/voya-zip/voya-zip.component';
import { VoyaCounterComponent } from './shared/components/form/voya-input/voya-counter/voya-counter.component';
import { VoyaNumberComponent } from './shared/components/form/voya-input/voya-number/voya-number.component';
import { VoyaSelectComponent } from './shared/components/form/voya-input/voya-select/voya-select.component';
import { VoyaPagingComponent } from './shared/components/form/voya-paging/voya-paging.component';
import { VoyaSsnComponent } from './shared/components/form/voya-ssn/voya-ssn.component';
import { VoyaRoutingNumberComponent } from './shared/components/form/voya-routing-number/voya-routing-number.component';

//Directives
import { ModalComponent } from './shared/directives/modal.component';
import { VoyaCurrencyDirective } from './shared/directives/voya-currency.directive';
import { SSNDirective } from './shared/directives/voya-ssn.directive';
import { NumberDirective } from './shared/directives/voya-number.directive';

// Pipes
import { VoyaCurrencyPipe } from './shared/pipes/voya-currency.pipe';
import { VoyaSSNPipe } from './shared/pipes/voya-SSN.pipe';

//Utils
import { Utils } from './shared/utils/pay-admin.utils';

// vendor components
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxSpinnerModule } from 'ngx-spinner';
import {AgGridModule} from 'ag-grid-angular';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    PlanListComponent,
    PlanSelectionComponent,
    HeaderComponent,
    GridComponent,
    PayAdminHomeComponent,
    PayAdminRoutingComponents,
    TimeInfoComponent,
    PageTitleComponent,
    PayAdminMenuComponent,
    VoyaLinkComponent,
    BrowserInfoComponent,
    BankAvailableComponent,
    BankListComponent,
    EditComponent,
    BankSubmitComponent,
    ConfirmationComponent,
    CreateComponent,
    VoyaPagingComponent,
    GridLinkComponent,
    BankModalComponent,
    EditDisclosureComponent,
    TitleMessageComponent,
    HelpComponent,
    SpinnerComponent,

        
    ModalComponent,
    VoyaCurrencyDirective,
    SSNDirective,
    NumberDirective,

    VoyaCurrencyPipe,
    VoyaSSNPipe,
    
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent,
    GridComponent,
    VoyaLinkComponent,
    //InputTextComponent,
    VoyaEmailComponent,
    VoyaZipComponent,
    VoyaCounterComponent,
    VoyaNumberComponent,
    VoyaSelectComponent,
    VoyaPagingComponent,
    VoyaSsnComponent ,
    VoyaRoutingNumberComponent
  ],
  imports: [
    BrowserModule,
    PayAdminRoutingModule,
    NgxSpinnerModule,
    HttpClientModule,
    NgSelectModule,
    FormsModule,
     ReactiveFormsModule,
    AgGridModule.withComponents([GridLinkComponent])
  ],
  providers: [ModalService, ApiService, Utils],
  bootstrap: [AppComponent ]
})
export class AppModule { }
