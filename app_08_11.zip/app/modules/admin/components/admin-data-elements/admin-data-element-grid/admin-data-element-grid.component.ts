import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { AdminGridRadioComponent } from '../../admin-grid-radio/admin-grid-radio.component';
import { DataElementTextboxComponent } from '../admin-data-element-textbox/data-element-textbox.component';



@Component({
  selector: 'app-admin-data-element-grid',
  templateUrl: './admin-data-element-grid.component.html',
//   styleUrls: ['./admin-data-element-grid.component.scss']
})

export class AdminDataElementGridComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
  @Output()
  getDataId = new EventEmitter<string>();
  @Output()
  newOrder = new EventEmitter<string>();
  context = {
    componentParent: this
};
  frameworkComponents: any;
  style;

  constructor() {  this.style = { width: "102%" }; }
  ngOnInit() {

    this.frameworkComponents = {
      radiobuttonRender : AdminGridRadioComponent,
      textboxRender : DataElementTextboxComponent
      };
  }
  getNewOrder(_newOrder)
  {
    this.newOrder.emit(_newOrder);
  }
  selectedItem(dataElementID) {
    this.getDataId.emit(dataElementID);
   // alert("Parent Component Method from " + dataElementID + "!");
  }

}
