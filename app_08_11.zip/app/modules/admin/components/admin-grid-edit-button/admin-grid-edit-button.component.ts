import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import {ICellRendererAngularComp} from "ag-grid-angular/main";

 @Component({
   selector: "app-admin-grid-edit-button",
   templateUrl: "./admin-grid-edit-button.component.html",
   styleUrls: ["./admin-grid-edit-button.component.scss"]
 })

export class AdminGridEditButtonComponent   {
    public params: any;

    agInit(params: any): void {
        this.params = params;
    }

    public invokeDeleteMethod() {
        this.params.api.setFocusedCell(this.params.node.rowIndex, 'ID');
        //rowNode.setSelected(true);
        var rowNode = this.params.api.getRowNode(this.params.node.rowIndex);
        rowNode.setSelected(true);
        var selectedData = this.params.api.getSelectedRows();        
        this.params.api.updateRowData({remove: selectedData}); 
        console.log("Removed data from grid:", selectedData);   
              
     
 }
     public invokeEditMethod() {
 
           console.log("in edit cell with node clicked:", this.params.node.rowIndex);
          this.params.api.setFocusedCell(this.params.node.rowIndex, 'ID');
          this.params.api.startEditingCell({
          rowIndex: this.params.node.rowIndex,
         colKey: 'ID',
         }
      );
      console.log(this.params.node.rowIndex)
     }
    
}