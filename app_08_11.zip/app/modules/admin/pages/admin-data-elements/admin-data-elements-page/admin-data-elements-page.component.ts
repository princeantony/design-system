import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import _ from 'lodash';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { AdminService } from '../../../services/admin.service';
import { AdminDataService } from '../../../services/admin-data.service';

@Component({
    selector: 'app-admin-data-elements-page',
    templateUrl: './admin-data-elements-page.component.html'
})

export class AdminDataElementsPageComponent implements OnInit {
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    dEColumnDefs: any;
    dEList: any;
    type = 'Data Element';
    modelId = 'deModal';
    selectedDE: any;
    isButtonDisabled = true;
    newOrderNumber: number;
    selectedDEId: string;
    constructor(
      private adminService: AdminService,
      private adminDataService: AdminDataService,
      private router: Router,
      private route: ActivatedRoute,
      private modalService: ModalService) {
        this.dEColumnDefs = GRID_CONFIG.DATA_ELEMENTS.COLUMN_DEFS_ELEMENTS;
    }

    ngOnInit() {
      PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
      PayAdminGlobalState.currentPage = 'admin/dataElements';

      this.hidePageTitle = false;
      this.subTitle = 'Select Data Element Option'; // read from const
      this.planNumber = PayAdminGlobalState.planNumber;

      this.route.url.subscribe(value => {
        const isDelete = _.find(value, ['path', 'delete']);
        if (isDelete) {
        this.onDelete();
        } else {
          this.getDataElementList();
        }
      });

    }

    newElementClick() {
      this.selectedDE = null;
      this.selectedDEId = '';
      this.isButtonDisabled = false;
      PayAdminGlobalState.dataElements = null;
    }

    getDataElementList() {
        this.adminService.getDEList(this.planNumber).subscribe(flags => {
            if (flags.status === APP_CONST.SUCCESS) {
                this.dEList = flags.data;
                PayAdminGlobalState.dataElements = flags.data;
                if(this.selectedDEId) {
                  this.getSelectedDataID(this.selectedDEId);
                }
            }
        });
    }
    getSelectedDataID(_deid: string)
    {
      this.isButtonDisabled = false;
      this.selectedDE = _.filter(this.dEList, ['dataElement', _deid])[0];
      PayAdminGlobalState.dataElement = this.selectedDE;
      this.selectedDEId = _deid;
      console.log('this.selectedDE', this.selectedDE);
    }
    getNewOrder(newOrder) {
      if(this.adminDataService.isValidNewOrder(newOrder))
      {
        this.newOrderNumber = newOrder;
        console.log('new order in parent is', newOrder)
      } else {
    // toater error message
      }


    }
    gotoBack() {
      this.router.navigate([PayAdminGlobalState.previousPage]);
    }
    showDeteleModal() {
      PayAdminGlobalState.currentPage = PayAdminGlobalState.previousPage;
      this.modalService.open(this.modelId);
    }
    onDelete() {
      this.adminService.deleteDE(this.planNumber, this.selectedDEId).subscribe(delRes => {
        if (delRes.status === APP_CONST.SUCCESS) {
          this.getDataElementList(); // will do this logic in client side later
        }
    });
    }
    saveDisplayOrder()
    {
      this.adminService.updateOrderNumber(this.planNumber, this.selectedDEId, this.newOrderNumber).subscribe(saveRes => {
        if (saveRes.status === APP_CONST.SUCCESS) {
          this.getDataElementList(); // will do this logic in client side later
        }
    });
    }
    showOptions() {
      this.router.navigate(['/admin/dataElements/options']);
    }
    onEdit() {
      this.router.navigate(['/admin/dataElements/createOrEdit']);
    }

}

