import { Component, OnInit } from '@angular/core';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
import _ from 'lodash';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalService } from '../../../../../shared/services/modal.service';

@Component({
    selector: 'app-admin-options-data',
    templateUrl: './admin-options-data.component.html'
  })

export class AdminOptionsDataComponent implements OnInit{
    slectDataColumnDefs: any;
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    dataelementID: string;
    isButtonDisabled: false;
    selectedOptionId : string;
    selectedOption: any;
    dataElementOptions: any;
    type = 'Data Element Option';
    modelId = 'deOptionModal';
    navigateTo = 'options/';
    constructor(
      private adminService: AdminService,
      private route: ActivatedRoute,
      private modalService : ModalService,
       private router: Router){}
    ngOnInit(){
        this.slectDataColumnDefs = GRID_CONFIG.DATA_ELEMENTS.OPTIONS;
        this.hidePageTitle = false;
        this.subTitle = 'Select Data Element Option';
        this.planNumber = PayAdminGlobalState.planNumber;
        this.dataelementID =  AdminDataService.dataElementId;
        PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
        PayAdminGlobalState.currentPage = 'admin/dataElements/options';
        this.route.url.subscribe(value => {
          const isDelete = _.find(value, ['path', 'delete']);
          if (isDelete) {
          this.onDelete();
          } else {
            this.getOptions();
          }
        });
    }
    getSelectedOptionId(selectedId: string) {
      this.isButtonDisabled = false;
      this.selectedOption = _.filter(this.dataElementOptions, ['valueCode', selectedId])[0];
      PayAdminGlobalState.dataElementOption = this.selectedOption;
      this.selectedOptionId = selectedId;
    }
    selectNew()
    {
      this.selectedOption = null;
      this.selectedOptionId = '';
      this.isButtonDisabled = false;
      PayAdminGlobalState.dataElementOption = null;
    }
    getOptions()
    {
      this.adminService.getDEOptions(this.planNumber, this.dataelementID).subscribe(options => {
        if (options.status === APP_CONST.SUCCESS) {
            this.dataElementOptions = options.data;
        }
    });
    }
    showDeteleModal() {
      PayAdminGlobalState.currentPage = PayAdminGlobalState.previousPage;
      this.modalService.open('deOptionModal');
    }
    onDelete() {
      this.adminService.deleteDE(this.planNumber, this.selectedOptionId).subscribe(delRes => {
        if (delRes.status === APP_CONST.SUCCESS) {
          this.getOptions(); // can be done through client logic
        }
    });
    }
    onEdit() {
      this.router.navigate(['/admin/dataElements/options/createOrEdit']);
    }
    gotoBack() {
      this.router.navigate([PayAdminGlobalState.previousPage]);
    }

  }
