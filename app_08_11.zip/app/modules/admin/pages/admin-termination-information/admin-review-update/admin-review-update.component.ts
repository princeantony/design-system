import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';
import { AdminService } from '../../../services/admin.service';
import {APP_CONST,ENV} from '../../../../../shared/constants/app.constants';
import {  GRID_CONFIG  } from '../../../../../shared/constants/grid.constants';

@Component({
    selector: 'app-admin-review-update',
    templateUrl: './admin-review-update.component.html',
    styleUrls: ['./admin-review-update.component.scss']
  })

  export class AdminReviewUpdateComponent implements OnInit {
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    private gridApi;
    appContext =  APP_CONST.APP_CONTEXT;
    homeFlag : any;
    termList: any;
    termReasonColumnDefs : any;

    TerminateReasonForm = this.fb.group({
      'optionID': new FormControl('', Validators.required),
      'optionText': new FormControl('', Validators.required),
    })

    constructor( private fb: FormBuilder, private adminService: AdminService){
      this.termReasonColumnDefs = GRID_CONFIG.TERMINATION_REASON.COLUMN_DEFS_REASON;
    }

    ngOnInit(){
      this.hidePageTitle = false;
      this.subTitle = 'Termination Information';
      this.planNumber ='559985'; 

      this.getMockTerminationList();
    }

    gridReady(params) {
      console.log(params.api);
      this.gridApi = params.api;      
    }

    getMockTerminationList(){
      this.adminService.getMockTerminationList().subscribe(flags => {
      if(flags.status === APP_CONST.SUCCESS)
      {
        this.termList = flags.data;   
      console.log("---------this.termList", this.termList);
      //PayAdminGlobalState.homeFlagState = this.menuItemRows;
      }
    });
    }
  }