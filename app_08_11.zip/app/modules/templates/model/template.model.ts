export interface ITemplate{
    
 
        templateId:string;
       headerCount:string;
       trailerCount:string;
       importType: string;
        columnList : any;
       
       
}
export interface IcolumnList { 
    value:string;
    colNumber:string;
}
export interface IcolumnListFW { 
    value:string;
    startPosition : string;
     fieldWidth:string;
}