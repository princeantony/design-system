import { ParticipantOptionalFields } from './participant-optional-fields';

export class ParticipantOptionalFieldTextBox extends ParticipantOptionalFields<
  string
> {
  componentType = 'textbox';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
  }
}
