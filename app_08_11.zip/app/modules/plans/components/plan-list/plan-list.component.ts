import { Component, Injectable, OnInit, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr/ng2-toastr';
import { NgxSpinnerService } from 'ngx-spinner';

import { APP_CONST } from '../../../../shared/constants/app.constants';
import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';
import { LoginUser } from '../../../../shared/mocks/login-user.mock';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { AuthService } from '../../services/auth.service';
import { PlanService } from '../../services/plan.service';

@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss']
})
@Injectable()
export class PlanListComponent implements OnInit {
  columnDefs: any;
  planData: any;
  width;
  errorCount = 0;
  planListItem: any;
  constructor(
    private planService: PlanService,
    private authService: AuthService,
    private spinner: NgxSpinnerService,
    private router : Router,
    public toastr: ToastsManager, vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }
  ngOnInit() {
    this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
    this.width = GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
    this.planListItem = PayAdminGlobalState.planListState;
        this.spinner.show();
        if (PayAdminGlobalState.loginUser && !PayAdminGlobalState.loginStatus) {
        this.login();
        } else  if (PayAdminGlobalState.loginStatus) {
          this.getPlans();
        } else {
          PayAdminGlobalState.loginUser = LoginUser;
          this.login();
          //this.router.navigate(['/']);
        }
  }
  getPlans(): void {
    this.planService.getPlans().subscribe(plans => {
      this.spinner.hide();
      if (plans.status === APP_CONST.SUCCESS) {
        this.planData = plans.data;
        // PayAdminGlobalState.planListState = this.planData; // will enable if we use local state
      } else {
        this.toastr.error(plans.error.msg, plans.status + ' !', { showCloseButton: true });
      }
    },
      (
        err => {
          this.spinner.hide();
          this.errorCount ++;
          if (err.error && err.error.text)
          {
            if(this.errorCount < 4 )
            {
              this.getPlans();
            }
          } else{
            this.spinner.hide();
           this.toastr.error('Error while fetching Plans. Try again!', err.error.status + ' !', { showCloseButton: true });
          }
        }
      ));
  }
  login(): void {
    this.errorCount ++;
    this.authService.doAuthenticte(PayAdminGlobalState.loginUser).subscribe(loginInfo => {
      if (loginInfo.status === APP_CONST.SUCCESS) {
        PayAdminGlobalState.loginStatus = true;
        this.errorCount = 0;
        this.getPlans();
      }
       else
      {
        this.toastr.error(loginInfo.error.msg, loginInfo.status + ' !', { showCloseButton: true });
      }
    },
      (err => {
        if(this.errorCount < 4 )
        {
          this.login();
        } else {
        this.spinner.hide();
        this.toastr.error('Error while authenticating PayAdmin. Click on Logout to try again!', err.error.status + ' !', { showCloseButton: true });
        }
      })
    );
  }
  onRowClicked(params) {
     const planId = params.data.planNumber;
     PayAdminGlobalState.planNumber = planId;
     this.router.navigate(['/home']);
   //}
   }

}
