import { Injectable } from '@angular/core';
import { ApiService } from '../../../shared/services/api.service';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { Observable } from 'rxjs';
import { MockService } from '../../../shared/services/mock.service';
import { ENV } from 'src/app/shared/constants/app.constants';

@Injectable({
  providedIn: 'root'
})
export class PlanService {
  constructor(private apiService: ApiService, private mockService: MockService) {
   }
   getPlans(): Observable<any> {
    return ENV.TEST ? this.mockService.getListPlans() : this.apiService.get(SERVICE_URL.GET_LISTPLAN_URL);
   }
}
