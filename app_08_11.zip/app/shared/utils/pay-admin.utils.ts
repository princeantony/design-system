

export class Utils {
  constructor() {}
  chunkArray<T>(arr: Array<T>, chunkSize: number): Array<Array<T>> {
    return arr.reduce(
      (prevVal: any, currVal: any, currIndx: number, array: Array<T>) =>
        !(currIndx % chunkSize)
          ? prevVal.concat([array.slice(currIndx, currIndx + chunkSize)])
          : prevVal,
      []
    );
  }
}
export function isInteger(value: any): value is number {
  return typeof value === 'number' && isFinite(value) && Math.floor(value) === value;
}
export function isNumber(value: any): value is number {
  return !isNaN(toInteger(value));
}
export function toInteger(value: any): number {
  return parseInt(`${value}`, 10);
}
export function padNumber(value: number) {
  if (isNumber(value)) {
    return `0${value}`.slice(-2);
  } else {
    return '';
  }
}
