import { Component, EventEmitter, forwardRef, OnInit, Output } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from 'node_modules/@angular/forms';

import { BaseInputComponent } from '../base-input/base-input.component';

const noop = () => {};
@Component({
  selector: 'voya-checkbox',
  templateUrl: './voya-checkbox.component.html',
  styleUrls: ['./voya-checkbox.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaCheckboxComponent),
      multi: true
    }
  ]
})
export class VoyaCheckboxComponent extends BaseInputComponent
  implements OnInit, ControlValueAccessor {
  isLabelHidden: boolean;
  private _value = false;
  @Output()
  click = new EventEmitter<boolean>();
  ngOnInit() {
    this.isLabelHidden = false;
  }

  get value(): boolean {
    return this._value;
  }
  set value(v: boolean) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  onTouched() {
    this._onTouchedCallback(null);
  }

  writeValue(value: boolean): void {
    this._value = value || false;
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}
  onValueChange() {
console.log("click")
    this.click.emit(this._value);
  }
}
