import {IPlanLight} from '../../interfaces/plan-light.interface';

export interface AppState {
    readonly planList: IPlanLight[];
   // readonly userList: IUser[];
}