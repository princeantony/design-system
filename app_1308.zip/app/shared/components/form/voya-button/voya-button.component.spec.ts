import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaButtonComponent } from './voya-button.component';

describe('VoyaButtonComponent', () => {
  let component: VoyaButtonComponent;
  let fixture: ComponentFixture<VoyaButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
