import { MenuItem } from "../interfaces/menu-item.interface";

// export const MenuItems: MenuItem[] = [
//   { key: "addEnrollmentFlag", menuHeading: "Add/Enroll", menuSubheading: "Add/Enroll Participants" },
//   { key: "paricipantFlag",menuHeading: "Participant Update", menuSubheading: "View/Update participant information" },
//   { key: "batchParticipantFlag",menuHeading: "Batch Participant Update", menuSubheading: "Update multiple participant" },
//   { key: "contributionFlag",menuHeading: "Contributions", menuSubheading: "Process contributions to accounts" },
//   { key: "pendingBatchFlag",menuHeading: "Pending/Submitted Batches", menuSubheading: "Review batch information" },
//   { key: "loanRepaymentFlag", menuHeading: "Loan Repayment", menuSubheading: "Process loan repayments" },
//   { key: "bankInfoFlag",menuHeading: "Bank Information", menuSubheading: "Add or update assigned bank" },
//   { key: "adminFlag",menuHeading: "Administration", menuSubheading: "Review and update your settings" }
// ];

export const HOME_FLAGS =
{
  "status": "SUCCESS",
  "data": {
    "addEnrollmentFlag": true,
    "addEnrollmentImportFlag": false,
    "paricipantFlag": true,
    "batchParticipantFlag": false,
    "contributionFlag": true,
    "loanRepaymentFlag": true,
    "bankInfoFlag": true,
    "adminFlag": false,
    "pendingBatchFlag": false
  }
}
