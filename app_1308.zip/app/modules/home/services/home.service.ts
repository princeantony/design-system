import { MenuItem } from "../../../shared/interfaces/menu-item.interface";

export default class HomeService {
  private MenuItemMap: MenuItem[] = [
    {
      key: "addEnrollmentFlag",
      menuHeading: "Add/Enroll",
      menuSubheading: "Add/Enroll Participants",
      menuIcon: "addenroll.svg"
    },
    {
      key: "paricipantFlag",
      menuHeading: "Participant Update",
      menuSubheading: "View/Update participant information",
      menuIcon: "participantupdate.svg"
    },
    {
      key: "batchParticipantFlag",
      menuHeading: "Batch Participant Update",
      menuSubheading: "Update multiple participant",
      menuIcon: "batchparticipantupdate.svg"
    },
    {
      key: "contributionFlag",
      menuHeading: "Contributions",
      menuSubheading: "Process contributions to accounts",
      menuIcon: "contributions.svg"
    },
    {
      key: "pendingBatchFlag",
      menuHeading: "Pending/Submitted Batches",
      menuSubheading: "Review batch information",
      menuIcon: "pendingsubmittedbatches.svg"
    },
    {
      key: "loanRepaymentFlag",
      menuHeading: "Loan Repayment",
      menuSubheading: "Process loan repayments",
      menuIcon: "loanrepayment.svg"
    },
    {
      key: "bankInfoFlag",
      menuHeading: "Bank Information",
      menuSubheading: "Add or update assigned bank",
      menuIcon: "bankinformation.svg"
    },
    {
      key: "adminFlag",
      menuHeading: "Administration",
      menuSubheading: "Review and update your settings",
      menuIcon: "administration.svg"
    }
  ];

  private MenuList = {
    status: "SUCCESS",
    data: {
      addEnrollmentFlag: true,
      addEnrollmentImportFlag: false,
      paricipantFlag: true,
      batchParticipantFlag: false,
      contributionFlag: true,
      loanRepaymentFlag: true,
      bankInfoFlag: true,
      adminFlag: false,
      pendingBatchFlag: false
    }
  };

  getMenuList() {
    let menuItemsFlag = this.MenuList.data;
    let menuItemsToBind: MenuItem[] = [];
    this.MenuItemMap.forEach(menuItem => {
      if (menuItemsFlag[menuItem.key]) {
        menuItemsToBind.push(menuItem);
      }
    });
    return menuItemsToBind;
  }
}

export { HomeService };
