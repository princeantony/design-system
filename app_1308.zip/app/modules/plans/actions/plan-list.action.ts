import{ACTION_TYPE} from '../../../shared/constants/app.constants';

import { Action } from '@ngrx/store'

export class PlanListAction implements Action {
    readonly type = ACTION_TYPE.LIST_PLAN;
    constructor(public planList: any) {
        console.log("in action", planList)
    }
    
}
export type Actions = PlanListAction







