import { Store } from '@ngrx/store';
import { Component, OnInit} from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {GRID_CONFIG} from '../../../../shared/constants/app.constants';
import {PlanListAction} from '../../../plans/actions/plan-list.action';
import {MockService} from '../../../../shared/services/mock.service';
import {ListPlan} from '../../../../shared/mocks/listPlan';
import {ApiService} from '../../../../shared/services/api.service';
import {SERVICE_URL} from '../../../../shared/constants/service.constants'
import {LoginUser} from '../../../../shared/mocks/login-user.mock';
import {AppState} from '../../../../shared/store/states/app.state';
import {IPlanLight} from '../../../../shared/interfaces/plan-light.interface';
@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss']
})
@Injectable()
export class PlanListComponent implements OnInit {
rowData: any ;
columnDefs: any;
users : any;
width;
counter : number = 1;
rowData1: Observable<IPlanLight[]>; 
//rowData: Observable<IPlanLight[]>; 
constructor(private store: Store<AppState>, private apiService: ApiService) {
  console.log("in cunst");
  this.rowData=ListPlan.data; // for mock data
  this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
  this.width= GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
  //this.rowData = store.select('planList');
 
}

  ngOnInit() {
    console.log("on init ", this.counter++);
    //this.rowData1 = this.store.select>('planList');
     console.log("this.rowData1 before", this.rowData1)
    this.store.dispatch(new PlanListAction({planList: this.rowData }) );
    this.rowData1 = this.store.select('planList');
    let plans1 =  this.store.select(state => state.PlanList)
     console.log("this.plans1", plans1)
    //this.login(); //for actual service 
  }
  getPlans(): void {
    this.apiService.get(SERVICE_URL.GET_LISTPLAN_URL)
    .subscribe(plans => {
      this.rowData = plans.data;
     // this.store.dispatch(new PlanListAction({planList: plans.data }) )
    });
  }
  login(): any {
    this.apiService.post(SERVICE_URL.GET_DIRECT_LOGIN_URL,LoginUser )
    .subscribe(loginInfo => { if(loginInfo.status === "SUCCESS") this.getPlans();});
  }
}
