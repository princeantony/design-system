import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import {
  AdminDataElementSelectComponent,
} from 'src/app/modules/admin/pages/admin-data-elements/admin-data-element-select/admin-data-element-select.component';
import {
  AdminDataElementsPageComponent,
} from 'src/app/modules/admin/pages/admin-data-elements/admin-data-elements-page/admin-data-elements-page.component';
import {
  AdminOptionsDataComponent,
} from 'src/app/modules/admin/pages/admin-data-elements/admin-options-data/admin-options-data.component';
import {
  AdminClientSpecificComponent,
} from 'src/app/modules/admin/pages/admin-termination-information/admin-client-specific/admin-client-specific.component';
import {
  BatchParticipantActiveComponent,
} from 'src/app/modules/batch-participant/pages/batch-participant-active/batch-participant-active.component';
import {
  BatchParticipantUpdateComponent,
} from 'src/app/modules/batch-participant/pages/batch-participant-update/batch-participant-update.component';
import { CONTRIBUTION_PATH } from 'src/app/modules/contributions/constants/contributions.constant';
import {
  ContributionSetupComponent,
} from 'src/app/modules/contributions/pages/contribution-setup/contribution-setup.component';
import { LoginPageComponent } from 'src/app/modules/login/pages/login-page.component';
import { ParticipantAddComponent } from 'src/app/modules/participants/pages/participant-add/participant-add.component';
import {
  ParticipantImportFileComponent,
} from 'src/app/modules/participants/pages/participant-import/participant-import-file/participant-import-file.component';
import {
  ParticipantSearchComponent,
} from 'src/app/modules/participants/pages/participant-search/participant-search.component';
import {
  ParticipantUpdateContributionElectionComponent,
} from 'src/app/modules/participants/pages/participant-update-contribution-election/participant-update-contribution-election.component';
import {
  ParticipantUpdateInvestmentElectionComponent,
} from 'src/app/modules/participants/pages/participant-update-investment-election/participant-update-investment-election.component';
import {
  ParticipantUpdateOptionalComponent,
} from 'src/app/modules/participants/pages/participant-update-optional/participant-update-optional.component';
import {
  ParticipantUpdateComponent,
} from 'src/app/modules/participants/pages/participant-update/participant-update.component';
import {
  TemplateExistingFixedWidthComponent,
} from 'src/app/modules/templates/pages/template-existing-fixed-width/template-existing-fixed-width.component';
import { TemplateExistingComponent } from 'src/app/modules/templates/pages/template-existing/template-existing.component';
import {
  TemplateVerificationComponent,
} from 'src/app/modules/templates/pages/template-verification/template-verification.component';

import {
  AdminOptionDataComponent,
} from '../../modules/admin/pages/admin-data-elements/admin-option-data/admin-option-data.component';
import { AdminHomeComponent } from '../../modules/admin/pages/admin-home/admin-home.component';
import { AdminPageSecurityComponent } from '../../modules/admin/pages/admin-page-security/admin-page-security.component';
import { AdminPlanCopyComponent } from '../../modules/admin/pages/admin-plan-copy/admin-plan-copy.component';
import { AdminPlanSetupComponent } from '../../modules/admin/pages/admin-plan-setup/admin-plan-setup.component';
import {
  AdminReviewUpdateComponent,
} from '../../modules/admin/pages/admin-termination-information/admin-review-update/admin-review-update.component';
import { BankAvailableComponent } from '../../modules/bank-information/pages/bank-available/bank-available.component';
import { ConfirmationComponent } from '../../modules/bank-information/pages/confirmation/confirmation.component';
import { CreateComponent } from '../../modules/bank-information/pages/create/create.component';
import { PayAdminHomeComponent } from '../../modules/home/pages/pay-admin-home/pay-admin-home.component';
import {
  ParticipantAddContributionElectionComponent,
} from '../../modules/participants/pages/participant-add-contribution-election/participant-add-contribution-election.component';
import {
  ParticipantAddInvestmentElectionComponent,
} from '../../modules/participants/pages/participant-add-investment-election/participant-add-investment-election.component';
import {
  ParticipantAddOptionalComponent,
} from '../../modules/participants/pages/participant-add-optional/participant-add-optional.component';
import {
  ParticipantConfirmationComponent,
} from '../../modules/participants/pages/participant-confirmation/participant-confirmation.component';
import { PlanSelectionComponent } from '../../modules/plans/pages/plan-selection/plan-selection.component';
import { PayAdminReportComponent } from '../../modules/report/report.component';
import {
  TemplateCreateFWComponent,
} from '../../modules/templates/pages/template-create-fixed-width/template-create-fixed-width.component';
import {
  TemplateCreateComponent,
} from '../../modules/templates/pages/template-create-with-errors/template-create-with-errors.component';
import {
  TemplateFileImportComponent,
} from '../../modules/templates/pages/template-file-import/template-file-import.component';
import { TemplateSelectComponent } from '../../modules/templates/pages/template-select/template-select.component';

const payAdmiinRoutes: Routes = [
  {
    path: 'plans',
    component: PlanSelectionComponent, // TestPocComponent, // PlanSelectionComponent, //
    data: { title: 'Plan List' }
  },
  {
    path: 'home',
    component: PayAdminHomeComponent
  },
  {
    path: 'home/success',
    component: PayAdminHomeComponent
  },
  {
    path: 'bankInfo/print',
    component: ConfirmationComponent
  },

  {
    path: 'bankInfo/edit/:divsubId',
    component: CreateComponent
  },
  {
    path: 'bankInfo/edit',
    component: CreateComponent
  },
  {
    path: 'bankInfo/create/:divsubId',
    component: CreateComponent
  },
  {
    path: 'bankInfo/create',
    component: CreateComponent
  },
  {
    path: 'bankInfo',
    component: BankAvailableComponent
  },
  {
    path: 'bankInfo/confirm',
    component: ConfirmationComponent
  },
  // Participant Module Routing Rules
  {
    path: 'participant',
    component: ParticipantAddComponent // ParticipantAddComponent
  },
  {
    path: 'addParticipant/Optional',
    component: ParticipantAddOptionalComponent
  },
  {
    path: 'addParticipant/ContributionElection',
    component: ParticipantAddContributionElectionComponent
  },
  {
    path: 'addParticipant/ContributionInvestment',
    component: ParticipantAddInvestmentElectionComponent
  },
  {
    path: 'addParticipant/Confirmation',
    component: ParticipantConfirmationComponent
  },
  {
    path: 'addParticipant/Confirmation/Print',
    component: ParticipantConfirmationComponent
  },
  {
    path: 'participant/import',
    component: ParticipantImportFileComponent
  },
  // Update participant Module
  {
    path: 'participantUpdateSearch',
    component: ParticipantSearchComponent
  },
  {
    path: 'UpdateParticipant',
    component: ParticipantUpdateComponent
  },
  {
    path: 'UpdateParticipant/Optional',
    component: ParticipantUpdateOptionalComponent
  },
  {
    path: 'UpdateParticipant/ContributionElection',
    component: ParticipantUpdateContributionElectionComponent
  },
  {
    path: 'UpdateParticipant/ContributionInvestment',
    component: ParticipantUpdateInvestmentElectionComponent
  },
  {
    path: 'UpadteParticipant/Confirmation',
    component: ParticipantConfirmationComponent
  },
  {
    path: 'UpadteParticipant/Confirmation/Print',
    component: ParticipantConfirmationComponent
  },
  // Contrib Module Routing Rules
  {
    path: CONTRIBUTION_PATH.CONTRIBUTION_SETUP,
    component: ContributionSetupComponent
  },

  // Admin Module Routing Rules
  {
    path: 'admin',
    component: AdminHomeComponent
  },
  {
    path: 'admin/success',
    component: AdminHomeComponent
  },
  {
    path: 'admin/pageSecurity',
    component: AdminPageSecurityComponent
  },
  {
    path: 'admin/planSetup',
    component: AdminPlanSetupComponent
  },

  {
    path: 'admin/dataElements',
    component: AdminDataElementsPageComponent
  },
  {
    path: 'admin/dataElements/delete',
    component: AdminDataElementsPageComponent
  },
  {
    path: 'admin/dataElements/createOrEdit',
    component: AdminDataElementSelectComponent
  },
  {
    path: 'admin/dataElements/options',
    component: AdminOptionsDataComponent
  },
  {
    path: 'admin/dataElements/options/createOrEdit',
    component: AdminOptionDataComponent
  },

  {
    path: 'admin/dataElements/options/delete',
    component: AdminOptionsDataComponent
  },
  {
    path: 'admin/planCopy',
    component: AdminPlanCopyComponent
  },
  // fileimport module routes

  {
    path: 'fileImport',
    component: TemplateFileImportComponent
  },
  {
    path: 'template/select',
    component: TemplateSelectComponent
  },
  {
    path: 'template/create',
    component: TemplateCreateComponent
  },
  {
    path: 'template/createFW',
    component: TemplateCreateFWComponent
  },
  {
    path: 'template/existing/:id',
    component: TemplateExistingComponent
  },
  {
    path: 'template/verify',
    component: TemplateVerificationComponent
  },
  {
    path: 'template/existing/fixedwidth/:id',
    component: TemplateExistingFixedWidthComponent
  },

  {
    path: 'terminate/reviewUpdate',
    component: AdminReviewUpdateComponent
  },
  {
    path: 'terminate/clientSpecific',
    component: AdminClientSpecificComponent
  },
  {
    path: 'updateBatchParticipant',
    component: BatchParticipantUpdateComponent
  },
  {
    path: 'batchParticipant/active',
    component: BatchParticipantActiveComponent
  },
  // Report
  {
    path: 'report',
    component: PayAdminReportComponent
  },

  {
    path: '**',
    component: PayAdminReportComponent, // AdminPlanSetupComponent AdminDataElementsPageComponent, //LoginPageComponent, //
    data: { title: 'Pay Admin Login' }
  },
  {
    path: 'app',
    component: AppComponent,
    data: { title: 'Pay Admin App' }
  }
];

@NgModule({
  imports: [RouterModule.forRoot(payAdmiinRoutes)],
  exports: [RouterModule],
  providers: []
})
export class PayAdminRoutingModule {}
export const PayAdminRoutingComponents = [
  PlanSelectionComponent,
  PayAdminHomeComponent,
  BankAvailableComponent
];
