import { ToastOptions } from 'ng6-toastr';

export class CustomOption extends ToastOptions {
  animate = 'fade'; // you can override any options available
  newestOnTop = true;
  showCloseButton = true;
  toastLife = 25000;
  positionClass ='toast-bottom-full-width';
}
