export interface Option {
  value: string;
  displayText: string;
}

export class ApplicationResponse {
  status: string;
  data?: any;
  messages?: string[];
  error?: InternalError;
  constructor() {
    this.status = 'ERROR';
    this.data = {};
    this.error = {
      code: 999,
      type: 'APP_ERROR',
      msg: 'DEFAULT ERROR',
      validations: [],
      cause: ''
    };
  }
}
export class InternalError {
  cause?: string;
  code: number;
  type: string;
  msg: string;
  validations?: string[];
}
