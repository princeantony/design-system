import { Injectable } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

import { PayAdminGlobalState } from '../store/pay-admin-global.store';
import { LoggerService } from './logger.service';

@Injectable({
  providedIn: 'root'
})
export class PreviousRouteService {
  private previousUrl: string;
  private currentUrl: string;

  constructor(private router: Router, private logger: LoggerService) {
    this.currentUrl = this.router.url;
    router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.previousUrl = this.currentUrl;
        this.logger.info('Previous URL', this.previousUrl);

        PayAdminGlobalState.previousPage = this.previousUrl;
        this.currentUrl = event.url;
      }
    });
  }

  public getPreviousUrl() {
    return this.previousUrl;
  }
}
