import { Injectable } from '@angular/core';
import _ from 'lodash';
import { Observable } from 'rxjs';

import { ENV } from '../../../shared/constants/app.constants';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';

@Injectable({
  providedIn: 'root'
})
export class AdminPlanSetupService {
  constructor(private mockService: MockService,  private apiService: ApiService) {}

 getOptions(planNumber: string): Observable<any>{
  return  ENV.TEST ? this.mockService.getPlanOptions() : this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL + planNumber + '/options');
  // return   this.mockService.getPlanOptions() ;
 }
getPlanSetup(planNumber: string): Observable<any> {
  return ENV.TEST ? this.mockService.getPlanSetup() : this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL+planNumber);

 }
 getMoneySource(planNumber: string): Observable<any> {
  return ENV.TEST ? this.mockService.getMoneySource() : this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL+planNumber+'/moneysources');
 }
  getInvestments(planNumber: string): Observable<any> {
    return ENV.TEST ? this.mockService.getInvestments() : this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL+planNumber+'/investments');
 }
 getEnrollmentList(planNumber: string): Observable<any> {
  return ENV.TEST ? this.mockService.getEnrollmentList() : this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL + planNumber + '/statuslist');
}
// getPlanSource(planNumber: string): Observable<any> {
//   return ENV.TEST ? this.mockService.getPlanSource() : this.apiService.get(SERVICE_URL.GET_PLAN_SETUP_URL + planNumber + '/plansource');
// }
 savePlanSetup(planNumber: string, PlanSetup: any): Observable<any> {
  return ENV.TEST ? this.mockService.savePlanSetup() : this.apiService.put(SERVICE_URL.GET_PLAN_SETUP_URL + planNumber, PlanSetup);
 }
// Actual services ends here
 mergeObjects(payadminFields: any, ominiFields: any) {
  const mergedObj = _.toArray(_.merge(_.keyBy(payadminFields, 'code'), _.keyBy(ominiFields, 'code')));
   return _.take(mergedObj, _.size(mergedObj));
 }
}
