import { Component, Input, OnInit } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  NgForm
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { ApplicationResponse } from 'src/app/shared/models/common.model';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { CommonService } from '../../../../shared/services/common.service';
import { isEmptyObject } from '../../../../shared/utils/pay-admin.utils';
import {
  ParticipantContribution,
  IParticipantFundSources
} from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';
import { CONTRIBUTION_TYPE } from './contribution-input-group/contribution-input-group.component';

import { PARTICIPANT_PATH } from '../../constants/participants.constants';
import { ErrorHandlerService } from 'src/app/shared/services/error-handler.service';
import { LoggerService } from 'src/app/shared/services/logger.service';
import { IParticipantOptionalFieldsService } from '../participant-optional-data/participant-optional-data-fields.service';
interface Item {
  label: string;
  value: any;
  readOnly: boolean;
  key: string;
  type: string;
  defLimit?: {
    code: string;
    minPercent: number;
    maxPercent: number;
    minAmt: number;
    maxAmt: number;
  };
}

interface FormControlMetadata {
  checkBoxLabel: string;
  checkBoxValue: boolean;
  controlLabel: string;
  controlName: string;
  controlValue: any;
  controlType: string;
  isReadOnly: boolean;
  controlValueType: string;
  formSection: string;
  isDisabled?: boolean;
  minAmt?: number;
  maxAmt?: number;
  minPercent?: number;
  maxPercent?: number;
}

@Component({
  selector: 'participant-contribution-election',
  templateUrl: './participant-contribution-election.component.html',
  styleUrls: ['./participant-contribution-election.component.scss']
})
export class ParticipantContributionElectionComponent implements OnInit {
  constructor(
    private previousRouteService: PreviousRouteService,
    private fb: FormBuilder,
    private participantsService: ParticipantsService,
    private common: CommonService,
    private router: Router,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    private logger: LoggerService,
    private errorHandlerService: ErrorHandlerService
  ) {}
  messageList: string[] = [];
  participantContributionForm: FormGroup;
  contributions: ParticipantContribution = {} as ParticipantContribution;
  contribElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  catchUpContribElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  investmentElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  contribElectionFormArray: FormArray = this.fb.array([]);
  catchUpContribElectionFormArray: FormArray = this.fb.array([]);
  investmentElectionFromArray: FormArray = this.fb.array([]);
  MaxContributionElectionExceeded = false;
  MaxCatchUpContributionElectionExceeded = false;
  MinCatchUpContributionElectionDeceeded = false;
  totalCatchUpContribElection = 0;
  totalContribElections = 0;
  private _editMode = false;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }
  ngOnInit() {
    this.messageList = [];
    this.spinner.show();
    if (
      isEmptyObject(ParticipantStore.ParticipantData.participantContribution)
    ) {
      this.participantsService
        .getParticipantContributionData$(this.EditMode)
        .subscribe(
          result => {
            if (result.status === 'SUCCESS') {
              console.log('contribution data', result.data);

              ParticipantStore.ParticipantData.participantContribution =
                result.data;
              ParticipantStore.ParticipantData.participantContribution.investmentElection.forEach(
                item => {
                  item.value = item.value === 'true' ? true : false;
                }
              );
              this.contributions =
                ParticipantStore.ParticipantData.participantContribution;

              this.initForm();
            } else if (result.status === 'ERROR') {
              this.messageList = this.errorHandlerService.getErrorMessages([
                result
              ]);
              this.spinner.hide();
            }
          },
          err => {
            this.messageList.push(
              'Error while fetching participant contribution '
            );
            this.spinner.hide();
          }
        );
    } else {
      this.contributions =
        ParticipantStore.ParticipantData.participantContribution;
      this.initForm();
    }
  }
  initForm() {
    // FormBuilding :Blue Print
    let hasContribution = false;
    // TODO: if not items move to next screen
    // Add items to each section FromArray
    if (Array.isArray(this.contributions.contribElection)) {
      if (this.contributions.contribElection.length > 0) {
        hasContribution = true;
        this.createContribElectionFormArray();
        this.logger.info(
          'Contribution Election MetadataList',
          this.contribElectionMetaDataList
        );
      }
    }
    if (Array.isArray(this.contributions.catchupContribElection)) {
      if (this.contributions.catchupContribElection.length > 0) {
        hasContribution = true;
        this.createCatchUpContribElectionFormArray();
        this.logger.info(
          'Catch Up Contribution Election MetadataList',
          this.catchUpContribElectionMetaDataList
        );
      }
    }
    if (Array.isArray(this.contributions.investmentElection)) {
      if (this.contributions.investmentElection.length > 0) {
        hasContribution = true;
        this.createInvestmentElectionFromArray();
      }
    }
    if (!hasContribution) {
      ParticipantStore.HasContribution = false;
      this.navigateToNext();
    } else {
      ParticipantStore.HasContribution = true;
      this.participantContributionForm = this.fb.group({
        contributionElection: this.contribElectionFormArray,
        catchUpContributionElection: this.catchUpContribElectionFormArray,
        investmentElection: this.investmentElectionFromArray
      });
      this.onChanges();
    }
    this.spinner.hide();
  }

  onChanges() {
    if (Array.isArray(this.contributions.contribElection)) {
      if (this.contributions.contribElection.length > 0) {
        this.contribElections.forEach((_control, i) => {
          _control.valueChanges.subscribe(val => {
            if (!this.validateContribElection()) {
              _control.setErrors({ MaxContributionElectionExceeded: true });
              this.participantContributionForm.setErrors({ invalid: true });
            } else {
              this.participantContributionForm.setErrors({ invalid: false });
            }
          });
        });
      }
    }

    if (Array.isArray(this.contributions.catchupContribElection)) {
      if (this.contributions.catchupContribElection.length > 0) {
        this.catchUpContribElections.forEach((_control, i) => {
          _control.valueChanges.subscribe(val => {
            this.getTotalCatchUpContribElections();
            if (!this.validateCatchUpContribElection()) {
              _control.setErrors({ CatchUpContribElectionRangeError: true });
              this.participantContributionForm.setErrors({ invalid: true });
            } else {
              this.participantContributionForm.setErrors({ invalid: false });
            }
          });
        });
      }
    }
  }

  validateContribElection() {
    this.MaxContributionElectionExceeded = false;
    this.getTotalContribElections();
    if (this.contributions.customEdit) {
      if (this.contributions.contribDeferralType === 'A') {
        if (
          this.totalContribElections > this.contributions.contribTotalMaxDefAmt
        ) {
          this.MaxContributionElectionExceeded = true;
          return false;
        }
      }
      if (this.contributions.contribDeferralType === 'P') {
        if (
          this.totalContribElections > this.contributions.contribTotalMaxDefPct
        ) {
          this.MaxContributionElectionExceeded = true;
          return false;
        }
      }
      return true;
    }
    return true;
  }
  validateCatchUpContribElection() {
    this.MaxCatchUpContributionElectionExceeded = false;
    this.MinCatchUpContributionElectionDeceeded = false;
    this.getTotalCatchUpContribElections();
    if (this.contributions.catchupDeferralType === 'A') {
      if (
        this.totalCatchUpContribElection >
        this.contributions.catchupContribTotalMaxDefAmt
      ) {
        this.MaxCatchUpContributionElectionExceeded = true;
        return false;
      }
      if (
        this.totalCatchUpContribElection <
        this.contributions.catchupContribTotalMinDefAmt
      ) {
        this.MinCatchUpContributionElectionDeceeded = true;
        return false;
      }
    }
    if (this.contributions.catchupDeferralType === 'P') {
      if (
        this.totalCatchUpContribElection >
        this.contributions.catchupContribTotalMaxDefPct
      ) {
        this.MaxCatchUpContributionElectionExceeded = true;
        return false;
      }
      if (
        this.totalCatchUpContribElection <
        this.contributions.catchupContribTotalMinDefPct
      ) {
        this.MinCatchUpContributionElectionDeceeded = true;
        return false;
      }
    }
    return true;
  }
  validateInvestmentElection() {
    let isAnySourceChecked = false;
    for (let i = 0; i < this.investmentElections.length; i++) {
      const control = this.investmentElections[i] as FormGroup;
      const controlName = this.investmentElectionMetaDataList[i].controlName;
      isAnySourceChecked = control.get(controlName).value;
      if (isAnySourceChecked) {
        return true;
      }
    }
    if (!isAnySourceChecked) {
      return false;
    }
  }

  getTotalContribElections() {
    this.totalContribElections = 0;
    this.contribElections.forEach((_control, i) => {
      let curValue;
      curValue = (<FormGroup>_control).controls[
        this.contribElectionMetaDataList[i].controlName
      ].value;
      if (!curValue) {
        curValue = 0;
      }
      // Update Contribution Model
      this.contributions.contribElection[i].value = curValue;
      this.totalContribElections += parseFloat(curValue);
    });
  }

  getTotalCatchUpContribElections() {
    this.totalCatchUpContribElection = 0;
    this.catchUpContribElections.forEach((_control, i) => {
      let curValue;
      curValue = (<FormGroup>_control).controls[
        this.catchUpContribElectionMetaDataList[i].controlName
      ].value;
      if (!curValue) {
        curValue = 0;
      }
      this.contributions.catchupContribElection[i].value = curValue;
      this.totalCatchUpContribElection += parseFloat(curValue);
    });
  }

  createContribElectionFormArray() {
    if (this.contributions.contribElection) {
      this.contributions.contribElection.forEach(contributionElectionItem => {
        // Fill the metatdata to build the form
        this.contribElectionMetaDataList.push(
          this.addToFormControlMetaDataList(
            contributionElectionItem,
            this.contributions.contribDeferralType,
            'contribElection',
            'text',
            true
          )
        );
        const controlKey: string = contributionElectionItem.key;
        const amountValue: string = parseFloat(
          contributionElectionItem.value
        ).toFixed(2);
        const percentValue: number = parseInt(
          contributionElectionItem.value,
          10
        );
        contributionElectionItem.value =
          this.contributions.contribDeferralType === 'A'
            ? amountValue.toString()
            : percentValue.toString();
        const control: FormControl = new FormControl(
          contributionElectionItem.value
        );
        const controlGroup: FormGroup = this.fb.group({});
        controlGroup.addControl(controlKey, control);
        this.contribElectionFormArray.push(controlGroup);
      });
    }
  }
  createCatchUpContribElectionFormArray() {
    if (this.contributions.catchupContribElection) {
      this.contributions.catchupContribElection.forEach(
        catchUpContributionElectionItem => {
          // Fill the metatdata to build the form
          this.catchUpContribElectionMetaDataList.push(
            this.addToFormControlMetaDataList(
              catchUpContributionElectionItem,
              this.contributions.catchupDeferralType,
              'catchUpContribElection',
              'text'
            )
          );
          const controlKey: string = catchUpContributionElectionItem.key;
          const control: FormControl = new FormControl(
            catchUpContributionElectionItem.value
          );
          const controlGroup: FormGroup = this.fb.group({});
          controlGroup.addControl(controlKey, control);
          this.catchUpContribElectionFormArray.push(controlGroup);
        }
      );
    }
  }
  createInvestmentElectionFromArray() {
    if (this.contributions.investmentElection) {
      this.contributions.investmentElection.forEach(investmentElectionItem => {
        if (ParticipantStore.InvestmentElectionSources.length > 0) {
          ParticipantStore.InvestmentElectionSources.forEach(source => {
            if (source === investmentElectionItem.key) {
              investmentElectionItem.value = true;
            }
          });
        }
        // Fill the metatdata to build the form
        this.investmentElectionMetaDataList.push(
          this.addToFormControlMetaDataList(
            investmentElectionItem,
            '',
            'investmentElection',
            'checkbox'
          )
        );
        const controlKey: string = investmentElectionItem.key;
        const control: FormControl = new FormControl(
          investmentElectionItem.value
        );
        const controlGroup: FormGroup = this.fb.group({});
        controlGroup.addControl(controlKey, control);
        this.investmentElectionFromArray.push(controlGroup);
      });
    }
  }

  investmentElectionValueChagned(sourceItem) {
    setTimeout(() => {
      if (sourceItem.controlName === 'ALL' && sourceItem.value) {
        for (let i = 0; i < this.investmentElections.length; i++) {
          const control = this.investmentElections[i] as FormGroup;
          const controlName = this.investmentElectionMetaDataList[i]
            .controlName;
          if (controlName !== 'ALL') {
            control.get(controlName).setValue(false);
          }
        }
      } else {
        let isOtherSourceChecked = false;
        let allSourceSontrol: FormGroup;
        for (let i = 0; i < this.investmentElections.length; i++) {
          const control = this.investmentElections[i] as FormGroup;
          const controlName = this.investmentElectionMetaDataList[i]
            .controlName;
          if (controlName === 'ALL') {
            allSourceSontrol = control;
          } else if (controlName !== 'ALL') {
            isOtherSourceChecked = control.get(controlName).value;
            if (isOtherSourceChecked) {
              break;
            }
          }
        }
        if (isOtherSourceChecked) {
          allSourceSontrol.get('ALL').setValue(false);
        }
      }
    }, 1);
  }

  get contribElections() {
    if (this.participantContributionForm) {
      return (<FormArray>(
        this.participantContributionForm.controls['contributionElection']
      )).controls;
    } else {
      return [];
    }
  }

  get catchUpContribElections() {
    if (this.participantContributionForm) {
      return (<FormArray>(
        this.participantContributionForm.controls['catchUpContributionElection']
      )).controls;
    } else {
      return [];
    }
  }

  get investmentElections() {
    if (this.participantContributionForm) {
      return (<FormArray>(
        this.participantContributionForm.controls['investmentElection']
      )).controls;
    } else {
      return [];
    }
  }

  addToFormControlMetaDataList(
    item: Item,
    valueType: string,
    section: string,
    type: string,
    isContrib: boolean = false
  ): FormControlMetadata {
    const _formControlMetaData: FormControlMetadata = {} as FormControlMetadata;
    _formControlMetaData.formSection = section;
    _formControlMetaData.controlType = type;
    _formControlMetaData.isReadOnly = item.readOnly;
    _formControlMetaData.controlName = item.key;
    _formControlMetaData.controlValueType = valueType;
    if (type === 'text') {
      _formControlMetaData.controlLabel =
        item.label.trim().length > 0 ? item.label : item.key;
      _formControlMetaData.checkBoxValue = item.value;
      _formControlMetaData.controlValue = item.value;
      if (isContrib) {
        if (this.contributions.customEdit) {
          if (item.defLimit) {
            _formControlMetaData.maxAmt = item.defLimit.maxAmt;
            _formControlMetaData.maxPercent = item.defLimit.maxPercent;
            _formControlMetaData.minAmt = item.defLimit.minAmt;
            _formControlMetaData.minPercent = item.defLimit.minPercent;
          }
        }
      }
    }

    if (type === 'checkbox') {
      _formControlMetaData.checkBoxLabel =
        item.label.trim().length > 0 ? item.label : item.key;
      _formControlMetaData.checkBoxValue = item.value === 'true';
    }
    _formControlMetaData.isDisabled = item.readOnly;
    return _formControlMetaData;
  }

  onContributionElectionTypeChanged(value: string) {
    this.contributions.contribDeferralType =
      value === CONTRIBUTION_TYPE.AMOUNT ? 'A' : 'P';
    this.MaxContributionElectionExceeded = false;
    for (let i = 0; i < this.contribElections.length; i++) {
      const control = this.contribElections[i] as FormGroup;
      const controlName = this.contribElectionMetaDataList[i].controlName;
      control.get(controlName).setValue('0');
    }
  }
  onCatchUpContributionElectionTypeChanged(value: string) {
    this.contributions.catchupDeferralType =
      value === CONTRIBUTION_TYPE.AMOUNT ? 'A' : 'P';
    for (let i = 0; i < this.catchUpContribElections.length; i++) {
      const control = this.catchUpContribElections[i] as FormGroup;
      const controlName = this.catchUpContribElectionMetaDataList[i]
        .controlName;
      control.get(controlName).setValue('0');
    }
  }

  setSelectedInvestmentElectionSources(): boolean {
    let hasInvestmentElectionSources = false;
    let investmentElectionSources = [];
    for (let i = 0; i < this.investmentElections.length; i++) {
      const control = this.investmentElections[i] as FormGroup;
      const controlName = this.investmentElectionMetaDataList[i].controlName;
      if (controlName === 'ALL') {
        if (control.get(controlName).value) {
          investmentElectionSources = [];
          investmentElectionSources.push(controlName);
          break;
        }
      } else if (controlName !== 'ALL') {
        if (control.get(controlName).value) {
          investmentElectionSources.push(controlName);
        }
      }
    }
    if (ParticipantStore.InvestmentElectionSources.length > 0) {
      if (
        investmentElectionSources.join(',') !==
        ParticipantStore.InvestmentElectionSources.join(',')
      ) {
        this.logger.info('Investment Election Changed');
        ParticipantStore.InvestmentElectionSources = [];
        ParticipantStore.InvestmentElectionSources = investmentElectionSources;
        ParticipantStore.ParticipantData.participantContributionInvestmentData = {} as IParticipantFundSources;
      }
    } else {
      ParticipantStore.InvestmentElectionSources = investmentElectionSources;
      this.logger.info(
        'Investment Election Selected',
        ParticipantStore.InvestmentElectionSources
      );
    }
    console.log(
      'Investement Selected Sources',
      ParticipantStore.InvestmentElectionSources
    );
    hasInvestmentElectionSources =
      ParticipantStore.InvestmentElectionSources.length === 0 ? false : true;
    if (!this.contributions.sameAsSourceId) {
      ParticipantStore.ParticipantData.participantContribution.sameAsSourceId =
        '';
    }
    return hasInvestmentElectionSources;
  }
  onSubmit(form: NgForm) {
    if (this.contributions.investmentElection.length > 0) {
      if (this.setSelectedInvestmentElectionSources()) {
        console.log('contribution Submit data', this.contributions);
        // Update store
        ParticipantStore.ParticipantData.participantContribution = this.contributions;
        ParticipantStore.HasContribution = true;
        this.navigateToNext();
      } else {
        this.messageList.push(
          'Please select at least one source for Investment Elections'
        );
      }
    } else {
      console.log('contribution Submit data', this.contributions);
      ParticipantStore.ParticipantData.participantContribution = this.contributions;
      ParticipantStore.HasContribution = true;
      this.navigateToNext();
    }
  }
  navigateToNext() {
    if (this.EditMode) {
      this.router.navigate([PARTICIPANT_PATH.UPDATE.INVESTMENT]);
    } else {
      this.router.navigate([PARTICIPANT_PATH.ADD.INVESTMENT]);
    }
  }
  onBackClicked() {
    if (
      ParticipantStore.ParticipantOptionSetting.canLoadOptionalDataElements &&
      ParticipantStore.HasOptionalData
    ) {
      if (!this.EditMode) {
        this.router.navigate([PARTICIPANT_PATH.ADD.OPTIONAL]);
      } else {
        this.router.navigate([PARTICIPANT_PATH.UPDATE.OPTIONAL]);
      }
    } else {
      if (!this.EditMode) {
        this.router.navigate([PARTICIPANT_PATH.ADD.REQUIRED]);
      } else {
        this.router.navigate([PARTICIPANT_PATH.UPDATE.REQUIRED]);
      }
    }
  }
}
