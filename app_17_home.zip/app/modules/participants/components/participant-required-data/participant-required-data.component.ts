import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { DifferencePipe, MomentModule } from 'ngx-moment';
import { NgxSpinnerService } from 'ngx-spinner';
import { forkJoin, of, throwError } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import { AlertMessage } from 'src/app/shared/interfaces/alert.interface';
import { ApplicationResponse } from 'src/app/shared/models/common.model';
import { CommonService } from 'src/app/shared/services/common.service';
import { ErrorHandlerService } from 'src/app/shared/services/error-handler.service';
import { LoggerService } from 'src/app/shared/services/logger.service';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import {
  MESSAGE,
  PARTICIPANT_PATH
} from '../../constants/participants.constants';
import {
  IParticipantRequiredData,
  Option,
  ParticipantData,
  ParticipantOptionalField,
  ParticipantOptionSetting,
  IParticipantFundSources,
  ParticipantContribution
} from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'participant-required-data',
  templateUrl: './participant-required-data.component.html',
  styleUrls: ['./participant-required-data.component.scss'],
  providers: [DifferencePipe]
})
export class ParticipantRequiredDataComponent implements OnInit {
  private messageList: string[] = [];
  alertMessage: AlertMessage = new AlertMessage();
  private _editMode = false;
  private statusText: string;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }
  isEnrollEnabled = true;
  countryChanged = new Subject<string>();
  participantData = new ParticipantData();
  participantOptionSetting: ParticipantOptionSetting;
  participantRequiredDataForm: FormGroup;
  requiredData: IParticipantRequiredData;
  participantOptionalDataField: ParticipantOptionalField[];
  participantAge = -1;

  countryList: { value: string; displayText: string }[];
  stateList: { value: string; displayText: string }[];
  terminationReason: { value: string; displayText: string }[];

  loaStartDate: string;
  loaStartReason: Option[];
  loaEndDate: string;
  loaEndReason: Option[];

  // parameter to set dataofBirth start Date
  dobStartData: {};
  dohStartDate: {};

  accountTypeItems: { value: string; label: string }[];
  constructor(
    private previousRouteService: PreviousRouteService,
    private formBuilder: FormBuilder,
    private participantsService: ParticipantsService,
    private router: Router,
    private commonService: CommonService,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    private modalservice: ModalService,
    private moment: MomentModule,
    private dateDiff: DifferencePipe,
    private logger: LoggerService,
    private errorHandlerService: ErrorHandlerService,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
    this.logger.info('In Constructor');
  }
  appResponse: ApplicationResponse = new ApplicationResponse();
  participantOptionSetting$ = this.participantsService.getParticipantOptionSetting();
  participantStatusList$ = this.participantsService.getParticipantStatusFromStatusList();
  participantODE$ = this.participantsService.getParticipantOptionalDataFields$();
  participantTerminationReason$ = this.participantsService.getParticipantTerminationReason();
  participantForkJoin$ = forkJoin(
    this.participantOptionSetting$,
    this.participantStatusList$,
    this.participantODE$
  );
  ngOnInit() {
    this.messageList = [];
    this.spinner.show();
    ParticipantStore.EditMode = this.EditMode;
    this.terminationReason = [
      {
        value: '1',
        displayText: 'With Cause'
      },
      {
        value: '2',
        displayText: 'Laid Off'
      },
      {
        value: '3',
        displayText: 'Special'
      },
      {
        value: '4',
        displayText: 'Retirement'
      },
      {
        value: '5',
        displayText: 'Permanent Disability'
      },
      {
        value: '6',
        displayText: 'Death'
      },
      {
        value: '7',
        displayText: '100% Withdrawal'
      },
      {
        value: '8',
        displayText: 'Not Transferred Out'
      },
      {
        value: '9',
        displayText: 'Converted'
      },
      {
        value: 'A',
        displayText: 'User Defined 1'
      },
      {
        value: 'B',
        displayText: 'User Defined 2'
      },
      {
        value: 'C',
        displayText: 'User Defined 3'
      },
      {
        value: 'D',
        displayText: 'Converted'
      },
      {
        value: 'E',
        displayText: 'QDRO'
      },
      {
        value: 'F',
        displayText: 'Beneficiary'
      },
      {
        value: 'I',
        displayText: 'Irrevocable Declination'
      },
      {
        value: 'L',
        displayText: 'Leave of Absence'
      },
      {
        value: 'N',
        displayText: 'New Entrant'
      },
      {
        value: 'R',
        displayText: 'Rehire'
      },
      {
        value: 'T',
        displayText: 'Transferred to Other Plan'
      },
      {
        value: 'V',
        displayText: 'Voluntary Termination'
      },
      {
        value: 'X',
        displayText: 'Excluded Class'
      }
    ];

    this.stateList = PayAdminGlobalState.StateList;
    this.countryList = PayAdminGlobalState.CountryList;

    if (ParticipantStore.ParticipantOptionSetting.servicePayLoad) {
      this.participantOptionSetting = ParticipantStore.ParticipantOptionSetting;
      this.participantData = ParticipantStore.ParticipantData;
      this.statusText = ParticipantStore.Status;
      this.terminationReason = ParticipantStore.TerminationReasonList;
      if (this.EditMode) {
        if (this.participantOptionSetting.canLoadOptionalDataElements) {
          this.participantOptionalDataField =
            ParticipantStore.ParticipantData.optionalData;
        }
        this.isEnrollEnabled = this.participantData.requiredData.enrollFlag;
      } else {
        this.isEnrollEnabled = this.participantOptionSetting.enableEnrollParticipant;
      }

      // Initialize Form
      this.initForm();
      this.onChanges();
      this.spinner.hide();
    } else {
      this.participantForkJoin$.subscribe(
        ([options, statuslist, ode]) => {
          if (
            options.status === 'SUCCESS' &&
            statuslist.status === 'SUCCESS' &&
            ode.status === 'SUCCESS'
          ) {
            this.participantOptionSetting = ParticipantStore.ParticipantOptionSetting =
              options.data;
            this.logger.info('Participant Option Setting', options.data);
            ParticipantStore.TerminationReasonList = this.terminationReason;

            this.logger.info(
              'Participant Termination Reason',
              this.terminationReason
            );
            this.setStartDates();
            ParticipantStore.ParticipantStatusList = statuslist.data;

            this.logger.info(
              'ParticipantStatusList',
              ParticipantStore.ParticipantStatusList
            );
            if (!this.EditMode) {
              // Add/Enroll
              ParticipantStore.StatusCode =
                ParticipantStore.ParticipantOptionSetting.statusCode;
              this.participantData.requiredData.country = 'USA';
              this.isEnrollEnabled = this.participantOptionSetting.enableEnrollParticipant;
            } else {
              // Participant Update Section
              this.participantData.requiredData =
                ParticipantStore.ParticipantData.requiredData;
              this.isEnrollEnabled = this.participantData.requiredData.enrollFlag;
              ParticipantStore.StatusCode = this.participantData.requiredData.statusCode;
              if (this.participantOptionSetting.displayLOA) {
                ParticipantStore.ParticipantData.optionalData = this.participantOptionalDataField =
                  ode.data;
                this.logger.info('Optional Data Element', ode.data);
              }
            }
            ParticipantStore.Status = this.statusText = this.participantsService.getParticipantStatus(
              ParticipantStore.StatusCode
            );
            ParticipantStore.ParticipantData.requiredData.statusCode =
              ParticipantStore.StatusCode;
            ParticipantStore.ParticipantOptionSetting.servicePayLoad = true;
            // Initialize Form
            this.initForm();
            this.onChanges();
            this.spinner.hide();
          } else {
            this.spinner.hide();
            this.messageList = this.errorHandlerService.getErrorMessages([
              options,
              statuslist,
              ode
            ]);
          }
        },
        error => {
          this.spinner.hide();
          this.toasterError(error);
        }
      );
    }
  }

  initForm() {
    if (this.EditMode) {
      // Note:  get Participant Required data from store which is prefilled in search participant
      this.participantData = ParticipantStore.ParticipantData;
      this.logger.info('participant data', this.participantData);
      if (this.participantOptionSetting.displayLOA) {
        this.initLOAFields();
        this.logger.info('LOA Fields Initialzed');
      }
    }

    this.participantRequiredDataForm = this.formBuilder.group({
      ssn: [this.participantData.requiredData.ssn],
      email: [this.participantData.requiredData.email],
      lastName: [this.participantData.requiredData.lastName],
      firstName: [this.participantData.requiredData.firstName],
      middleInitial: [this.participantData.requiredData.middleInitial],
      address1: [this.participantData.requiredData.address1],
      address2: [this.participantData.requiredData.address2],
      city: [this.participantData.requiredData.city],
      zipCode: [this.participantData.requiredData.zipCode],
      state: [this.participantData.requiredData.state],
      country: [this.participantData.requiredData.country],
      birthDate: [this.participantData.requiredData.birthDate],
      hireDate: [this.participantData.requiredData.hireDate],
      termDate: [this.participantData.requiredData.termDate],
      termCode: [this.participantData.requiredData.termCode],
      makeParticipantActive: [
        this.participantData.requiredData.makeParticipantActive
      ],
      absenceStartDate: [this.loaStartDate],
      absenceStartDateReason: [
        this.participantData.requiredData.absenceStartDateReason
      ],
      absenceEndDate: [this.loaEndDate],
      absenceEndDateReason: [
        this.participantData.requiredData.absenceEndDateReason
      ],
      enrollFlag: [this.participantData.requiredData.enrollFlag],
      mstarFlag: [this.participantData.requiredData.mstarFlag],
      qdiaFlag: [this.participantData.requiredData.qdiaFlag]
    });
  }

  initLOAFields() {
    // "loaStartDateDataElement": "PTPH771", "loaStartReasonDataElement": "PTPH841",
    // "loaEndDateDataElement": "PTPH772", "loaEndReasonDataElement": "PTPH842",
    // Get data from Optional Data Element and fill it here.
    if (this.participantOptionalDataField) {
      const LOAStartDateElementKey = this.participantOptionSetting
        .loaStartDateDataElement;
      const LOAEndDateElementKey = this.participantOptionSetting
        .loaEndDateDataElement;
      const LOAStartReasonKey = this.participantOptionSetting
        .loaStartReasonDataElement;
      const LOAEndReasonKey = this.participantOptionSetting
        .loaEndReasonDataElement;
      this.participantOptionalDataField.forEach(ode => {
        switch (ode.key) {
          case LOAStartDateElementKey:
            this.loaStartDate = ode.value;
            break;
          case LOAEndDateElementKey:
            this.loaEndDate = ode.value;
            break;
          case LOAStartReasonKey:
            this.loaStartReason = ode.option;
            break;
          case LOAEndReasonKey:
            this.loaEndReason = ode.option;
            break;
        }
      });
    }
  }

  onChanges() {
    this.participantRequiredDataForm.controls[
      'middleInitial'
    ].valueChanges.subscribe(val => {
      this.participantRequiredDataForm.controls['middleInitial'].setValue(
        val.toUpperCase(),
        { emitEvent: false }
      );
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'lastName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'firstName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'birthDate'
    ].valueChanges.subscribe(val => {
      this.validateBirthDate();
      this.validateBirthAndHireDate();
    });
    this.participantRequiredDataForm.controls[
      'hireDate'
    ].valueChanges.subscribe(val => {
      this.validateHireDate();
      this.validateBirthAndHireDate();
    });
  }

  validateNameMaxlengthExceeded() {
    if (
      this.participantRequiredDataForm.controls['middleInitial'].value.length +
        this.participantRequiredDataForm.controls['firstName'].value.length +
        this.participantRequiredDataForm.controls['lastName'].value.length >
      30
    ) {
      this.participantRequiredDataForm.controls['lastName'].setErrors({
        MaxLengthExceeded: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    } else {
      this.participantRequiredDataForm.setErrors({ invalid: false });
    }
  }
  validateHireDate() {
    if (
      this.isFutureDate(
        this.participantRequiredDataForm.controls['hireDate'].value
      )
    ) {
      this.participantRequiredDataForm.controls['hireDate'].setErrors({
        InvalidDateFutureDate: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    } else {
      this.participantRequiredDataForm.setErrors({ invalid: false });
    }
  }
  validateBirthDate() {
    if (
      this.isFutureDate(
        this.participantRequiredDataForm.controls['birthDate'].value
      )
    ) {
      this.participantRequiredDataForm.controls['birthDate'].setErrors({
        InvalidDateFutureDate: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    } else {
      this.participantRequiredDataForm.setErrors({ invalid: false });
    }

    const age = this.getAge(
      this.participantRequiredDataForm.controls['birthDate'].value
    );
    this.participantAge = age;

    if (age) {
      if (
        age <= this.participantOptionSetting.participantMinAge ||
        age > this.participantOptionSetting.participantMaxAge
      ) {
        this.participantRequiredDataForm.controls['birthDate'].setErrors({
          InvalidAge: true
        });
        this.participantRequiredDataForm.setErrors({ invalid: true });
      } else {
        this.participantRequiredDataForm.setErrors({ invalid: false });
      }
    }
  }
  validateBirthAndHireDate() {
    const ageOnHireDate = this.getYearsBetweenHireDateBirthday(
      this.participantRequiredDataForm.controls['birthDate'].value,
      this.participantRequiredDataForm.controls['hireDate'].value
    );

    if (ageOnHireDate) {
      if (
        ageOnHireDate <= this.participantOptionSetting.participantMinAge ||
        ageOnHireDate > this.participantOptionSetting.participantMaxAge
      ) {
        this.participantRequiredDataForm.controls['birthDate'].setErrors({
          InvalidAgeOnHireDate: true
        });
        this.participantRequiredDataForm.setErrors({ invalid: true });
      } else {
        this.participantRequiredDataForm.setErrors({ invalid: false });
      }
    }
  }
  isFutureDate(date: string): boolean {
    const [monthB, dayB, yearB] = date.split('/');
    if (date.split('/').length === 3) {
      const _date = new Date(yearB + '-' + monthB + '-' + dayB);
      const today = new Date();
      return _date > today;
    }
    return false;
  }
  getAge(birhthDay: string): number | null {
    let age = null;
    const [monthB, dayB, yearB] = birhthDay.split('/');
    if (birhthDay.split('/').length === 3) {
      const birthDate = new Date(yearB + '-' + monthB + '-' + dayB);
      const today = new Date();
      // DifferencePipe.transform(value, otherValue, unit, precision)
      age = this.dateDiff.transform(today, birthDate, 'years');
    }
    return age;
  }
  getYearsBetweenHireDateBirthday(birhthDay: string, hireDay: string) {
    if (birhthDay && hireDay) {
      if (
        birhthDay.split('/').length === 3 &&
        hireDay.split('/').length === 3
      ) {
        const [monthB, dayB, yearB] = birhthDay.split('/');
        const birthDate = new Date(yearB + '-' + monthB + '-' + dayB);
        const [monthH, dayH, yearH] = hireDay.split('/');
        const hireDate = new Date(yearH + '-' + monthH + '-' + dayH);

        return this.dateDiff.transform(hireDate, birthDate, 'years');
        // The Participant must be between 15 and 90 years of age for Employment.
      }
    }
    return null;
  }
  setStartDates() {
    this.dobStartData = { year: new Date().getFullYear() - 19 - 9, month: 1 };
    this.dohStartDate = { year: new Date().getFullYear() - 9, month: 1 };
  }

  onSubmit() {
    ParticipantStore.PrevPath = !this.EditMode
      ? PARTICIPANT_PATH.ADD.REQUIRED
      : PARTICIPANT_PATH.UPDATE.REQUIRED;
    if (ParticipantStore.ParticipantSSN.length > 0) {
      if (
        this.participantRequiredDataForm.controls['ssn'].value
          .split('-')
          .join('') !== ParticipantStore.ParticipantSSN
      ) {
        this.logger.info('SSN Changed: Reload further pages');
        ParticipantStore.ParticipantData.optionalData = [];
        ParticipantStore.ParticipantData.participantContribution = {} as ParticipantContribution;
        ParticipantStore.ParticipantData.participantContributionInvestmentData = {} as IParticipantFundSources;
      }
    }
    if (
      this.participantRequiredDataForm.controls['birthDate'].value !==
      ParticipantStore.ParticipantData.requiredData.birthDate
    ) {
      ParticipantStore.ParticipantData.participantContributionInvestmentData = {} as IParticipantFundSources;
    }
    this.validateSSN().subscribe(
      isValidSSN => {
        if (isValidSSN) {
          // quickfix for ssn
          const ssn = this.participantRequiredDataForm.value.ssn
            .split('-')
            .join('');
          ParticipantStore.ParticipantSSN = ssn;
          this.participantRequiredDataForm.controls['ssn'].setValue(ssn);
          const data: IParticipantRequiredData = this
            .participantRequiredDataForm.value;

          ParticipantStore.ParticipantData.requiredData = data;
          // Update LOA Fields
          this.updateLOADataToStore();
          this.logger.info(
            'Required Page before submit',
            ParticipantStore.ParticipantData
          );

          if (
            ParticipantStore.ParticipantOptionSetting
              .canLoadOptionalDataElements
          ) {
            if (!this.EditMode) {
              this.router.navigate([PARTICIPANT_PATH.ADD.OPTIONAL]);
            } else {
              this.router.navigate([PARTICIPANT_PATH.UPDATE.OPTIONAL]);
            }
          } else {
            if (ParticipantStore.ParticipantData.requiredData.enrollFlag) {
              if (!this.EditMode) {
                this.router.navigate([PARTICIPANT_PATH.ADD.CONTRIBUTION]);
              } else {
                this.router.navigate([PARTICIPANT_PATH.UPDATE.CONTRIBUTION]);
              }
            } else {
              if (!this.EditMode) {
                this.router.navigate([PARTICIPANT_PATH.ADD.CONFIRMATION]);
              } else {
                this.router.navigate([PARTICIPANT_PATH.UPDATE.CONFIRMATION]);
              }
            }
          }
        }
      },
      error => {
        this.toasterError(error);
      }
    );
  }

  updateLOADataToStore() {
    if (this.EditMode && this.participantOptionSetting.displayLOA) {
      ParticipantStore.ParticipantData.optionalData.forEach(
        (ode, index, object) => {
          switch (ode.key) {
            case this.participantOptionSetting.loaStartDateDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceStartDate'
              ].value;
              break;
            case this.participantOptionSetting.loaEndDateDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceEndDate'
              ].value;
              break;
            case this.participantOptionSetting.loaStartReasonDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceStartDateReason'
              ].value;
              break;
            case this.participantOptionSetting.loaEndReasonDataElement:
              ode.value = this.participantRequiredDataForm.controls[
                'absenceEndDateReason'
              ].value;
              break;
          }
        }
      );
    }
  }

  validateSSN(): any {
    if (!this.EditMode) {
      this.participantsService
        .validateAddParticipantSSN(
          this.participantRequiredDataForm.controls['ssn'].value
            .split('-')
            .join('')
        )
        .subscribe(
          res => {
            if (res.status === 'SUCCESS') {
              return of(true);
            } else if (res.status === 'ERROR') {
              this.messageList = this.errorHandlerService.getErrorMessages([
                res
              ]);
              return of(false);
            }
          },
          err => {
            console.log(err);
            return of(false);
          }
        );
    } else {
      this.participantsService
        .validateUpdateParticipantSSN(
          this.participantRequiredDataForm.controls['ssn'].value
            .split('-')
            .join('')
        )
        .subscribe(
          res => {
            if (res.status === 'SUCCESS') {
              return of(true);
            } else if (res.status === 'ERROR') {
              this.messageList = this.errorHandlerService.getErrorMessages([
                res
              ]);
              return of(false);
            }
          },
          err => {
            console.log(err);
            return of(false);
          }
        );
    }
    return of(true);
  }

  onStateChange(value: string) {}

  onCountryChange(value: string) {
    this.commonService.countryChanged.next(value);
  }
  onEnrollFlagChange(value: boolean) {
    setTimeout(() => {
      if (
        !this.participantOptionSetting.displayMorningStar &&
        !this.participantOptionSetting.displayQDIA
      ) {
        return;
      }
      if (value) {
        this.participantOptionSetting.disableQDIA = false;
        this.participantOptionSetting.disableMorningStar = false;
      } else {
        this.participantRequiredDataForm.controls['mstarFlag'].setValue(false);
        this.participantRequiredDataForm.controls['qdiaFlag'].setValue(false);
        this.participantOptionSetting.disableQDIA = true;
        this.participantOptionSetting.disableMorningStar = true;
      }
    }, 1);
  }
  onMstarFlagChange(value: boolean) {
    setTimeout(() => {
      this.participantData.requiredData.mstarFlag = value;
      if (value) {
        if (this.participantOptionSetting.morningStarError) {
          this.participantRequiredDataForm.controls['mstarFlag'].setValue(
            false
          );

          this.participantData.requiredData.mstarFlag = false;
          this.alertMessage.title = 'Morning Star Error!';
          this.alertMessage.content =
            'Morningstar Managed Account Program is not available at this time.!';
          this.modalservice.open('alert-modal');
          this.participantRequiredDataForm.value.mstarFlag = false;
        }
      }
    }, 500);
  }

  openAlertModal(field) {
    this.alertMessage.title = 'Help QDIA';
    this.alertMessage.content = MESSAGE['QDIA_HELP'];
    this.modalservice.open('alert-modal');
  }
  onBackClicked() {
    if (!this.EditMode) {
      this.router.navigate(['home']);
    } else {
      this.router.navigate([PARTICIPANT_PATH.UPDATE.SEARCH]);
    }
  }

  toasterError(error) {
    this.spinner.hide();
    console.error(error);
    this.toastr.error('Something Went Wrong', 'Error!!!', {
      showCloseButton: true
    });
  }
}
