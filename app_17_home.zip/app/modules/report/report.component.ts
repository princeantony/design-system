import { Component, OnInit } from '@angular/core';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';

import { ActivatedRoute, Router } from '@angular/router';
import { PayAdminGlobalState } from '../../shared/store/pay-admin-global.store';
import { APP_CONST } from '../../shared/constants/app.constants';
import { ReportService } from './report.service';
import { FormControl, FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html'
})
export class PayAdminReportComponent implements OnInit {
  reportColumns: any;
  reportData: any;
  reportNames: any;
  reportForm: any;
  reportHeadings: any;
  reportDetails: any;
  reportView = true;
  gridApi: any;
  columnApi: any;
  tempReportData: any;
  style;
  rowStyle;
  gridStyle;
  constructor(
private reportService: ReportService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder
  ) {
    this.gridStyle = { width: 400, height: 200 };
    this.style = { width: '90%' };
    this.rowStyle = { color: '#333333' };
  }
  ngOnInit() {
    this.reportForm = this.fb.group({
      reportList: new FormControl()}
    )
    this.getReportNames();
  }
  getReportNames(): void {
    this.spinner.show();
    this.reportService.getReportNames(PayAdminGlobalState.planNumber).subscribe(
      names => {
        if (names.status === APP_CONST.SUCCESS) {
          this.reportNames = names.data;
          console.log(this.reportNames,names.data)
          this.spinner.hide();
        } else {
          console.log('Error in report name', names);
          this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }
  getReport(reportName: string): void {
    this.spinner.show();
    this.reportService.getReport(reportName).subscribe(
      report => {
        this.spinner.hide();
        if (report.status === APP_CONST.SUCCESS) {
          this.reportData = report.data.content;
          this.tempReportData =  report.data.content;
          this.reportHeadings = report.data.headers ;
          this.reportDetails = {
                          'planName': report.data.planName,
                          'runDate': report.data.runDate,
                          'runTime': report.data.runTime,
                          'attention': report.data.attention,
                          'reportName': report.data.reportName};
          this.createGridHeadings();
        } else {
          console.log('Error in report reportData', report);
                  this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }
  onReportChange(value)
  {
    this.getReport(value.fileName);
  }
  createGridHeadings()
  {
  const newHeadings = [];
    this.reportHeadings.forEach((heading, index) => {
      newHeadings.push(  { headerName: heading.name, field: heading.id, width: (heading.name === 'Name')? 200: 150 });
    });
    this.reportColumns = newHeadings;
    }
    gotoBack() {
      this.router.navigate([PayAdminGlobalState.previousPage]);
    }
    print()
    {
      window.print();
    }
    gridReady(params) {
      this.gridApi = params.api;
      this.columnApi = params.columnApi;
  }

}
