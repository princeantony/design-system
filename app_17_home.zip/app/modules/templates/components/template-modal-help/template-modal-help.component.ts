import { Component, Input, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-template-modal-help',
  templateUrl: './template-modal-help.component.html',
  styleUrls: ['./template-modal-help.component.scss']
})
export class TemplateModalHelpComponent implements OnInit {
  @Input()
  helpText: any;
  constructor(private modalService: ModalService) { }

  ngOnInit() {
  }
  closePopup() {
    this.modalService.close('template-help-modal');
  }

}
