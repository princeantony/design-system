export class ContributionOption {
  enablePayrollCopy: boolean;
  hasDivSub: boolean;
  multiDivSub: boolean;
  participantsWithContributions: boolean;
  moneySources: MoneySource[];

  constructor() {
    this.enablePayrollCopy = false;
    this.hasDivSub = false;
    this.multiDivSub = false;
    this.participantsWithContributions = false;
    this.moneySources = [];
  }
}

export interface MoneySource {
  code: string;
  label: string;
}

export interface ContributionPreviousBatch {
  value: string;
  displayText: string;
  moneySources: string[];
}

export class ContributionParameters {
  batchKey: string;
  batchName: string;
  payrollDate: string;
  copyPayrollKey: string;
  divsubs: string;
  allDivSubs: boolean;
  activeParticipantsOnly: boolean;
  participantsWithContributions: boolean;
  moneySources: string;

  constructor() {
    this.batchKey = '';
    this.batchName = '';
    this.payrollDate = '';
    this.copyPayrollKey = '';
    this.divsubs = ''; // ',' separted list of selected DivSubs
    this.allDivSubs = false;
    this.activeParticipantsOnly = false;
    this.participantsWithContributions = false;
    this.moneySources = ''; // ',' separted list of checked MoneySources
  }
}

export interface ContributionGridData {
  batchKey: string;
  headers: ContributionHeader[];
  response: Array<ContributionRow[]>;
}

export interface ContributionHeader {
  id: string;
  readOnly: boolean;
  label: string;
  mandatory: boolean;
  type?: string;
  summationColumn?: boolean;
}

export interface ContributionRow {
  key: string;
  id: string;
  value: string;
  maskedValue?: string;
  options?: Option[];
}

export interface Option {
  value: string;
  displayText: string;
}

export interface ContributionBatchInfo {
  batchKey: string;
  batchName: string;
  payrollDate: string;
}

export interface ContributionSubmitData {
  batchKey: string;
  updates: ContributionUpdateItem[];
}

export interface ContributionUpdateItem {
  ssn: string;
  data: ContributionDataItem[];
}

export interface ContributionDataItem {
  id: string;
  value: string;
}

export interface ContributionDivSubItem {
  id: string;
  text: string;
  name: string;
  phone: string;
  textOnly: string;
}
