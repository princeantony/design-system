export const ContributionOptionsMock = {
  status: 'SUCCESS',
  data: {
    enablePayrollCopy: true,
    hasDivSub: true,
    multiDivSub: true,
    participantsWithContributions: true,
    moneySources: [
      {
        code: 'A',
        label: 'EE-PRE-TAX'
      },
      {
        code: 'C',
        label: 'Catchup'
      }
    ]
  }
};

export const ContributionPreviousBatchListMock = {
  status: 'SUCCESS',
  data: {
    prevBatches: [
      {
        value: '0|test|20180101|1',
        displayText: 'test 20180101-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180101|1',
        displayText: 'test 20180101-1',
        moneySources: ['E', 'C']
      },
      {
        value: '0|test|20180201|1',
        displayText: 'test 20180201-1',
        moneySources: ['C', 'A']
      },
      {
        value: '0|test|20180301|1',
        displayText: 'test 20180301-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180401|1',
        displayText: 'test 20180401-1',
        moneySources: ['E', 'C']
      },
      {
        value: '0|test|20180102|1',
        displayText: 'test 20180102-1',
        moneySources: ['E']
      },
      {
        value: '0|test|20180103|1',
        displayText: 'test 20180103-1',
        moneySources: ['C']
      },
      {
        value: '0|test|20180104|1',
        displayText: 'test 20180104-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180105|1',
        displayText: 'test 20180101-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180106|1',
        displayText: 'test 20180106-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180107|1',
        displayText: 'test 20180107-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180108|1',
        displayText: 'test 20180108-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180109|1',
        displayText: 'test 20180109-1',
        moneySources: ['E', 'A']
      },
      {
        value: '0|test|20180201|1',
        displayText: 'test 20180201-1',
        moneySources: ['A']
      }
    ]
  }
};

export const ContributionGridDataMock = {
  status: 'SUCCESS',
  data: {
    batchKey: '0|test|20181011|1',
    headers: [
      {
        id: 'name',
        readOnly: true,
        label: 'Name',
        mandatory: true
      },
      {
        id: 'ssn',
        readOnly: true,
        label: 'SSN',
        mandatory: true
      },
      {
        id: 'division',
        readOnly: false,
        label: 'Division/Location',
        type: 'dropdown',
        mandatory: true
      },
      {
        id: 'ODE-PTPH**',
        readOnly: false,
        label: 'Elligible Hours',
        type: 'dropdown',
        mandatory: false
      },
      {
        id: 'SRC- E',
        readOnly: false,
        label: 'EE PRE TAX',
        type: 'text',
        mandatory: false,
        summationColumn: true
      },
      {
        id: 'SRC- A',
        readOnly: false,
        label: 'EE PRE TAX',
        type: 'text',
        mandatory: false,
        summationColumn: true
      }
    ],
    response: [
      [
        {
          key: 'name',
          id: 'name',
          value: 'RINEY-DP,      NOLAN'
        },
        {
          key: 'ssn',
          id: 'ssn',
          value: '028612964',
          maskedValue: '*****2964'
        },
        {
          key: 'division|028612964',
          id: 'division',
          value: '9001'
        },
        {
          key: 'ODE-PTPH**|028612964',
          id: 'ODE-PTPH**',
          value: 'test',
          options: [
            {
              value: 'test',
              displayText: 'test'
            }
          ]
        },
        {
          key: 'SRC- E|028612964',
          id: 'SRC- E',
          value: '100'
        },
        {
          key: 'SRC- A|028612964',
          id: 'SRC- A',
          value: '100'
        }
      ],
      [
        {
          key: 'name',
          id: 'name',
          value: 'RINEY-DP,      NOLAN'
        },
        {
          key: 'ssn',
          id: 'ssn',
          value: '123456789',
          maskedValue: '*****6789'
        },
        {
          key: 'division|123456789',
          id: 'division',
          value: '9001'
        },
        {
          key: 'ODE-PTPH**|123456789',
          id: 'PTPH**',
          value: 'test',
          options: [
            {
              value: 'test',
              displayText: 'test'
            }
          ]
        },
        {
          key: 'SRC- E|123456789',
          id: 'SRC- E',
          value: '100'
        },
        {
          key: 'SRC- A|123456789',
          id: 'SRC- A',
          value: '100'
        }
      ]
    ]
  }
};

export const ContributionBatchInfoMock = {
  batchKey: '0|test|20180101|1',
  batchName: 'test1',
  payrollDate: '10/12/2018'
};

export const ContributionSubmitDataMock = {
  batchKey: '0|test|20181011|1',
  updates: [
    {
      ssn: '123456789',
      data: [
        {
          id: 'division',
          value: '9001'
        },
        {
          id: 'SRC-E',
          value: '100.0'
        },
        {
          id: 'SRC-A',
          value: '130.0'
        }
      ]
    },
    {
      ssn: '777656789',
      data: [
        {
          id: 'division',
          value: '9001'
        },
        {
          id: 'SRC-E',
          value: '200.0'
        },
        {
          id: 'SRC-A',
          value: '130.0'
        }
      ]
    }
  ]
};

export const ContributionAuthDivSubMock = {
  status: 'SUCCESS',
  data: [
    {
      id: '0040',
      text: '0040 ST. CATHERINES',
      name: '',
      phone: '',
      textOnly: 'ST. CATHERINES'
    },
    {
      id: '0055',
      text: '0055 WHEATON FRANCISCAN SERVICES',
      name: '',
      phone: '',
      textOnly: 'WHEATON FRANCISCAN SERVICES'
    },
    {
      id: '0060',
      text: '0060 SET MINISTRIES',
      name: '',
      phone: '',
      textOnly: 'SET MINISTRIES'
    },
    {
      id: '0075',
      text: '0075 ROSALIE MANOR',
      name: '',
      phone: '',
      textOnly: 'ROSALIE MANOR'
    },
    {
      id: '0080',
      text: '0080 FRANCISCAN MINISTRIES',
      name: '',
      phone: '',
      textOnly: 'FRANCISCAN MINISTRIES'
    },
    {
      id: '0099',
      text: '0099 COVENANT HEALTH SYSTEM',
      name: '',
      phone: '',
      textOnly: 'COVENANT HEALTH SYSTEM'
    },
    {
      id: '0101',
      text: "0101 ST. MARY'S",
      name: '',
      phone: '',
      textOnly: "ST. MARY'S"
    },
    {
      id: '0102',
      text: "0102 ST. MARY'S",
      name: '',
      phone: '',
      textOnly: "ST. MARY'S"
    },
    {
      id: '0201',
      text: "0201 ST. LUKE'S",
      name: '',
      phone: '',
      textOnly: "ST. LUKE'S"
    },
    {
      id: '0202',
      text: "0202 ST. LUKE'S",
      name: '',
      phone: '',
      textOnly: "ST. LUKE'S"
    },
    {
      id: '1001',
      text: '1001 WFH - ST. JOSEPH',
      name: '',
      phone: '',
      textOnly: 'WFH - ST. JOSEPH'
    },
    {
      id: '1002',
      text: '1002 ST. MICHAEL HOSPITAL',
      name: '',
      phone: '',
      textOnly: 'ST. MICHAEL HOSPITAL'
    },
    {
      id: '1003',
      text: '1003 ELMBROOK MEMORIAL',
      name: '',
      phone: '',
      textOnly: 'ELMBROOK MEMORIAL'
    },
    {
      id: '1004',
      text: '1004 ST. FRANCIS HOSPITAL',
      name: '',
      phone: '',
      textOnly: 'ST. FRANCIS HOSPITAL'
    },
    {
      id: '2001',
      text: '2001 MARIAN CATHOLIC CENTER',
      name: '',
      phone: '',
      textOnly: 'MARIAN CATHOLIC CENTER'
    },
    {
      id: '2002',
      text: '2002 MARIAN FRANCISCAN CENTER',
      name: '',
      phone: '',
      textOnly: 'MARIAN FRANCISCAN CENTER'
    },
    {
      id: '2003',
      text: '2003 FRANCISCAN WOODS',
      name: '',
      phone: '',
      textOnly: 'FRANCISCAN WOODS'
    },
    {
      id: '2004',
      text: '2004 TERRACE AT ST. FRANCIS',
      name: '',
      phone: '',
      textOnly: 'TERRACE AT ST. FRANCIS'
    },
    {
      id: '3001',
      text: '3001 FRANCISCAN SHARED LAB',
      name: '',
      phone: '',
      textOnly: 'FRANCISCAN SHARED LAB'
    },
    {
      id: '4002',
      text: '4002 COVENANT HOME HEALTH SERVICES',
      name: '',
      phone: '',
      textOnly: 'COVENANT HOME HEALTH SERVICES'
    },
    {
      id: '5001',
      text: '5001 STD SPECIALTIES CLINIC',
      name: '',
      phone: '',
      textOnly: 'STD SPECIALTIES CLINIC'
    },
    {
      id: '5003',
      text: '5003 SFH - CORPORATION',
      name: '',
      phone: '',
      textOnly: 'SFH - CORPORATION'
    },
    {
      id: '5004',
      text: '5004 VILLA OF ST. FRANCIS',
      name: '',
      phone: '',
      textOnly: 'VILLA OF ST. FRANCIS'
    },
    {
      id: '6001',
      text: '6001 COVENANT MEDICAL GROUP',
      name: '',
      phone: '',
      textOnly: 'COVENANT MEDICAL GROUP'
    },
    {
      id: '6003',
      text: '6003 COVENANT MEDICAL GROUP',
      name: '',
      phone: '',
      textOnly: 'COVENANT MEDICAL GROUP'
    },
    {
      id: '7001',
      text: '7001 WHEATON FRANCISCAN SISTERS',
      name: '',
      phone: '',
      textOnly: 'WHEATON FRANCISCAN SISTERS'
    },
    {
      id: '8001',
      text: '8001 MARIANJOY',
      name: '',
      phone: '',
      textOnly: 'MARIANJOY'
    },
    {
      id: '8002',
      text: '8002 REHABILITATION MEDICINE CLINIC',
      name: '',
      phone: '',
      textOnly: 'REHABILITATION MEDICINE CLINIC'
    },
    {
      id: '8003',
      text: '8003 REHABILITATION FOUNDATION, INC.',
      name: '',
      phone: '',
      textOnly: 'REHABILITATION FOUNDATION, INC.'
    },
    {
      id: '9001',
      text: '9001 COVENANT HEALTHCARE, INC',
      name: '',
      phone: '',
      textOnly: 'COVENANT HEALTHCARE, INC'
    }
  ]
};
