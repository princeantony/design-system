import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { BankInfoService } from 'src/app/modules/bank-information/services/bank-info.service';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { BatchParticipantService } from '../../services/batchParticipant.service';

@Component({
    selector: 'app-batch-participant-active',
    templateUrl: './batch-participant-active.component.html',
    styleUrls: ['./batch-participant-active.component.scss']
})

export class BatchParticipantActiveComponent implements OnInit {
    slectDataColumnDefs: any;
    selectData: any;
    hidePageTitle: boolean;
    pageTitle: string;
    planNumber: string;
    participantUpdateForm: FormGroup;
    fieldList: any;
    updateTime: any;
    updateDate: any;
    participantDivisionForm: FormGroup;
    participantColumnDefs: any;
    participantList: any;
    participantHeader: any;
    participantData: any;
    participantGridRows: any;
    private gridApi;
    private gridColumnApi;
    activeOnly: boolean = true;
    urlValues: string;
    selectedDivList: any;
    selectedFieldsList: any;
    divsub: string
    divsubEnabled: boolean;
    validationError: boolean = false;
    displayValidationError: boolean = false;
    dateError: boolean = false;
    salaryError: boolean = false;
    floatError: boolean = false;
    mandateFieldError: boolean = false;
    errorMessage: string[] = [];
    btnDisabled: boolean = true;
    width;


    constructor(private fb: FormBuilder, private batchService: BatchParticipantService, private router: Router,
        private bankInfoService: BankInfoService, private spinner: NgxSpinnerService) {

    }

    ngOnInit() {
        this.hidePageTitle = false;
        this.pageTitle = 'Batch Participant Update ';
        this.planNumber = PayAdminGlobalState.planNumber;
        this.divsub = PayAdminGlobalState.participantDiv;
        this.divsubEnabled = PayAdminGlobalState.BatchdivsubEnabled
        this.selectedDivList = '';
        this.getDivisionList();


    }


    ActiveparticipantForm = this.fb.group({
        activeParticipants: [true],
    });

    buildFormGroup(fieldList: any) {
        let group: any = {};
        group['allSegments'] = new FormControl("")

        fieldList.forEach(field => {
            group[field.id] = new FormControl(field.value || false);

        }
        );

        return new FormGroup(group);
    }
    getDivisionList(): void {
        this.spinner.show();
        if (this.divsubEnabled) {

            this.bankInfoService.getSubDiv(PayAdminGlobalState.planNumber).subscribe(
                subDiv => {
                    this.spinner.hide();
                    if (subDiv.status === APP_CONST.SUCCESS) {

                        this.fieldList = subDiv.data;
                        this.participantDivisionForm = this.buildFormGroup(this.fieldList);
                        this.getParticipantList();
                    }
                },
                err => {
                    console.log('Error in getDivSub', err);
                    this.spinner.hide();
                }
            );
        }
        else {
            this.spinner.hide();
            this.getParticipantList();
        }
    }

    getSelectedDiv() {

        let selectedFields = [];
        let selectedDiv = [];
        console.log('selected Div' , this.participantDivisionForm.value);
        selectedFields = this.participantDivisionForm.value;
        _.forEach(selectedFields, function (value, key) {
            if (value) {
                selectedDiv.push(key);
            }
        });
       // PayAdminGlobalState.selectedFields = selectedFields;
        this.divsub = selectedDiv.join(',');

        this.getParticipantList();

  }

   
  changeActive() {
    var active = this.ActiveparticipantForm.value.activeParticipants;

    if (active) {
        this.activeOnly = true;
    }
    else if (!active) {
        this.activeOnly = false;
    }
    this.getParticipantList();
}


    getParticipantList() {
        this.selectedFieldsList = PayAdminGlobalState.selectedFields.join(',')
        this.urlValues = this.activeOnly + '&divsub=' + this.divsub + '&selflds=' + this.selectedFieldsList
        this.spinner.show();
        this.batchService.getParticipantList(this.urlValues).subscribe(flags => {
            this.spinner.hide();
            if (flags.status === APP_CONST.SUCCESS) {
                this.participantList = flags.data;
                this.participantHeader = this.participantList.headers;
                this.participantData = this.participantList.response;

                var header = [];


                // creating dynamic header constant for grid
                this.participantHeader.forEach(field => {
                    var editable: boolean;
                    if (field.type == "dropdown") {
                        var options = [];
                        field.options.forEach(data => {
                            options.push(data.displayText)
                        });
                        let newHeader = {
                            headerName: field.label, field: field.id, minWidth: 150, cellEditor: "agSelectCellEditor",
                            cellEditorParams: {
                                cellHeight: 100,
                                values: options,
                            }
                        };
                        header.push(newHeader);
                    }

                    else if (!field.readOnly) {
                        editable = true;
                        var id = field.id.slice(0, 4);

                        if (field.id === "PTPH295") {
                            let newHeader = {
                                headerName: field.label, field: field.id, minWidth: 150, editable: editable,
                                cellEditor: 'numericEditor',
                            };
                            header.push(newHeader);
                        }
                        else if (field.id === "PTPH773" || field.id === "PTPH772" ||
                            field.id === "PTPH771" || field.id === "PTPH56" || field.id === "PTPH52") {
                            let newHeader = {
                                headerName: field.label, field: field.id, minWidth: 150, editable: editable,
                                cellEditor: 'dateEditor',
                            };
                            header.push(newHeader);
                        }

                        else if (id === "XXYY") {
                            let newHeader = {
                                headerName: field.label, field: field.id, minWidth: 150, editable: editable,
                                cellEditor: 'floatEditor',
                            };
                            header.push(newHeader);
                        }

                        else {
                            let newHeader = {
                                headerName: field.label, field: field.id, minWidth: 150, editable: editable,
                                cellEditor: 'textEditor',
                            };
                            header.push(newHeader);

                        }
                    }

                    else if (field.readOnly) {
                        editable = false;
                        if (field.id === "name") {
                            let newHeader = {
                                headerName: field.label, field: field.id, minWidth: 200, cellRenderer: 'linkRender', editable: editable
                            };
                            header.push(newHeader);

                        }

                        else {

                            let newHeader = {
                                headerName: field.label, field: field.id, minWidth: 150, editable: editable
                            };
                            header.push(newHeader);
                        }

                    }

                });

                // creating dynamic rows for grid
                let rowData = []
                for (let i = 0; i < this.participantData.length - 1; i++) {
                    let _temp = {};

                    for (let j = 0; j < (this.participantData[i].elements).length - 1; j++) {
                        var id = this.participantData[i].elements[j].id;
                        var name = this.participantData[i].elements[j].value;
                        var key = this.participantData[i].elements[j].key;
                        _temp[id] = name;
                        // _temp["key"] = key;
                    }

                    rowData.push(_temp);
                }
                this.participantColumnDefs = header;
                this.participantGridRows = rowData;
                this.spinner.hide();
                this.setTableWidth();
            }
            else {
                console.log("inside error ", flags);
            }
        },
            (
                err => {
                    this.spinner.hide();
                    console.log("inside error ", err);
                }
            ));


    }


    // Select all Divsub/Location
    selectAll(event) {

        if (event.target.checked) {
            this.fieldList.forEach(field => {
                this.participantDivisionForm.controls[field.id].setValue(true)
            });
        }

        if (!event.target.checked) {
            this.fieldList.forEach(field => {
                this.participantDivisionForm.controls[(field.id)].setValue(false)
            });
        }

        this.enableBtn();

    }

    setTableWidth() {
        var headerCount = this.participantColumnDefs.length;
        if (headerCount === 3) {
            this.width = { width: "62.1%" };
        }
        else if (headerCount === 4) {
            this.width = { width: "81.1%" };
        }
        else {
            this.width = { width: "100%" };
        }
    }

    gotoPrevious() {
        this.router.navigate(['updateBatchParticipant']);
    }

    printAllDisplayedRows() {
        this.validationError = false;
        this.selectedFieldsList = PayAdminGlobalState.selectedFields.join(',')
        var selflds = "?selflds=" + this.selectedFieldsList
        var count = this.gridApi.getDisplayedRowCount();
        let _data = [];
        let _dataElement = {};
        this.errorMessage = [];





        for (var i = 0; i < count; i++) {
            let _elements = {};
            let _row = [];
            var rowNode = this.gridApi.getDisplayedRowAtIndex(i);

            var rowID = [];
            var rowValue = [];

            _.forEach(rowNode.data, function (value, key) {
                rowID.push(key);
            });

            _.forEach(rowNode.data, function (value, key) {
                rowValue.push(value);
            });
            var ssn = rowValue[1];

            console.log('row ID', rowID, 'rowValue', rowValue);

            for (var j = 0; j < (rowID).length; j++) {
                let _temp = {};
                var id = rowID[j].slice(0, 4);

                _temp["key"] = rowID[j] + "-" + ssn;
                _temp["value"] = rowValue[j];
                _row.push(_temp);

                // finding mandatory fields
                var mandatory = _.find(this.participantHeader, { 'id': rowID[j], 'mandatory': true })



                // ------salary field validation--------
                if (rowID[j] === "PTPH811" || rowID[j] == "PTP11733") {
                    if (rowValue[j] == "") {
                        console.log("salary Field is empty");
                        this.validationError = true;
                        this.salaryError = true;
                        this.frameErrorMsg(rowID[j], ssn);
                    }
                }

                // ------date validation--------
                else if (rowID[j] === "PTPH773" || rowID[j] === "PTPH772" ||
                    rowID[j] === "PTPH771" || rowID[j] === "PTPH56" || rowID[j] === "PTPH52") {

                    if (rowValue[j] != "") {
                        var date = (String(rowValue[j]));
                        var reg1 = /^((0|1)\d{1})-((0|1|2)\d{1})-((19|20)\d{2})/g;
                        var reg2 = /^(0\d{1}|1[0-2])\/([0-2]\d{1}|3[0-1])\/(19|20)\d{2}/g;
                        var reg3 = /^(0\d{1}|1[0-2])([0-2]\d{1}|3[0-1])(19|20)\d{2}/g;
                        // console.log(date.match(reg1), " ", date.match(reg3), "", date.match(reg2))
                        if (date.match(reg1) === null && date.match(reg3) === null && date.match(reg2) === null) {
                            console.log("Not matching");
                            this.validationError = true;
                            this.dateError = true;
                            this.frameErrorMsg(rowID[j], ssn);
                        }
                        else if (date.match(reg3) != null && date.length > 8) {
                            console.log("Not matching");
                            this.validationError = true;
                            this.dateError = true;
                            this.frameErrorMsg(rowID[j], ssn);
                        }
                    }

                }

                // ------float max validation--------
                else if (id == "XXYY") {
                    if (rowValue[j] > 999) {
                        console.log("Float Error");
                        this.validationError = true;
                        this.floatError = true;
                        this.frameErrorMsg(rowID[j], ssn);
                    }

                }

                // ------mandatory field validation--------
                else if (mandatory) {
                    console.log(rowValue[j])
                    if (!rowValue[j]) {
                        console.log("mandatory field Error");
                        this.validationError = true;
                        this.mandateFieldError = true;
                        this.frameErrorMsg(rowID[j], ssn);
                    }
                }


            }
            _row = _row.slice(1);
            _row = _row.slice(1);

            _elements["elements"] = _row;
            _data.push(_elements);
        }

        _dataElement["dataElement"] = _data;


        if (this.validationError == true) {
            this.displayValidationError = true;
        }
        else {
            this.displayValidationError = false;
            this.spinner.show();
            this.updateDate = new Date().toLocaleDateString();
            this.updateTime = new Date().toLocaleTimeString();
            this.batchService
                .postBulkParticipants(_dataElement, selflds)
                .subscribe(
                    participants => {
                        this.spinner.hide();
                        if (participants.status === APP_CONST.SUCCESS) {
                            console.log("Post successful")
                            PayAdminGlobalState.successMsg = 'Your batch file has been successfully submitted on ' +
                                this.updateDate +
                                ' at ' +
                                this.updateTime +
                                '. Information for ## new participants has been added to the record keeping system,';
                            this.router.navigate(['/home/success']);
                        } else {
                            console.log("BulkParticipant", participants)
                            participants.forEach(data => {
                                this.errorMessage.push(data.messagge);
                            })
                        }
                    },
                    err => {
                        this.spinner.hide();
                        console.log("err.error", err.error)
                        const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
                    }
                );
        };
    }

    gridReady(params) {
        this.gridApi = params.api;
    }

    enableBtn() {
        var select = _.findKey(this.participantDivisionForm.value);
        if (select === undefined || select === "activeParticipants") {
            this.btnDisabled = true;
        }

        else {
            this.btnDisabled = false;
        }

    }

    frameErrorMsg(rowID, ssn) {
        var errMsg: string;
        if (this.dateError == true) {
            errMsg = rowID + " for participant " + ssn + "is in an invalid format, Expected format is a Date (MMDDCCYY)."
            this.errorMessage.push(errMsg);
        }
        else if (this.salaryError == true) {
            errMsg = rowID + " for participant " + ssn + "must be entered."
            this.errorMessage.push(errMsg);
        }
        else if (this.floatError == true) {
            errMsg = rowID + " for participant " + ssn + "Per Period Hours must not exceed 3 digits before decimal."
            this.errorMessage.push(errMsg);
        }
        else if (this.mandateFieldError == true) {
            errMsg = rowID + " for participant " + ssn + " field is required "
            this.errorMessage.push(errMsg);
        }

    }



}
