import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaLabelComponent } from './voya-label.component';

describe('VoyaLabelComponent', () => {
  let component: VoyaLabelComponent;
  let fixture: ComponentFixture<VoyaLabelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaLabelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
