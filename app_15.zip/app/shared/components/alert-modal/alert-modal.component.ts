import { Component, Input, OnInit } from '@angular/core';

import { ModalService } from '../../services/modal.service';

@Component({
  selector: 'app-alert-modal',
  templateUrl: './alert-modal.component.html'

})
export class AlertModalComponent implements OnInit {
  @Input() alertMessage;

  constructor(private modalService: ModalService) { }

  ngOnInit() {
  }
  closeModal(id) {
    this.modalService.close(id);
  }

}
