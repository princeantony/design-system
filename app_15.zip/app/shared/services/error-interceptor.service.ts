import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ErrorInterceptorService implements HttpInterceptor {
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((error: HttpErrorResponse) => {
        let errMsg = '';
        // Client Side Error
        if (error.error instanceof ErrorEvent) {
          if (!navigator.onLine) {
            errMsg = `Error: No Internet Connection`;
          } else {
            errMsg = `Error: ${error.error.message}`;
          }
        } else {
          // Server Side Error
          errMsg = `Error Code: ${error.status},  Message: ${error.message}`;
        }
        // return an observable
        // return throwError(errMsg);
        console.error(errMsg);
        return throwError(error);
      })
    );
  }
}
