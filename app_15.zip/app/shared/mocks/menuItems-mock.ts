import { IApiResponse } from '../interfaces/api-response.interface';

export const HOME_FLAGS: IApiResponse = {
  status: 'SUCCESS',
  data: {
    addEnrollmentImportPageActive: false,
    participantUpdatePageActive: true,
    addEnrollmentPageActive: true,
    bankInfoPageActive: true,
    batchParticipantUpdateImportPageActive: true,
    batchParticipantUpdatePageActive: true,
    contribImportPageActive: true,
    contributionPageActive: true,
    loanImportPageActive: false,
    loanRepaymentPageActive: false,
    reportsPageActive: true,
    adminPageActive: true,
    disableLoan: false
  }
};
export const ADMIN_FLAGS: IApiResponse = {
  status: 'SUCCESS',
  data: {
    generalAdministrationPageActive: true,
    terminationInformationPageActive: true,
    matchingPageActive: true,
    errorSuppressionPageActive: true,
    optionalDataElementsPageActive: true,
    pageSecurityPageActive: true,
    copyPlanInfoToOtherPlansPageActive: true,
    updateUserProfilePageActive: true

    // "loanRepaymentPageActive": false
  }
};
