const mainUrl =
  window.location.protocol +
  '//' +
  window.location.hostname +
  ':' +
  window.location.port;
export const SERVICE_URL = {
  APP_URL: mainUrl + '/payadmin/ws/ers/service/', // common for all environments

  //#region Common URL
  GET_COUNTRY: 'common/country',
  GET_STATE: 'common/state',
  GET_TERMINATION_REASON_LIST: 'plan/{planId}/termination/reasons',
  GET_ZIP_CODE_STATUS: 'common/validation/zip?state={stateCode}&zip={zipCode}',
  //#endregion

  //#region Login URL
  GET_DIRECT_LOGIN_URL: 'login/direct',
  //#endregion

  //#region Plan & Home
  GET_LISTPLAN_URL: 'plans',
  GET_HOME_URL: 'plans/plan/',
  //#endregion

  //#region Bank Module
  GET_SUB_DIV_URL: 'plans/plan/{planNumber}divsub/',
  POST_BANK_INFO_URL: 'bankinfo/plan/',

  //#endregion

  //#region Add Participant
  GET_PARTICIPANT_ADMIN_OPTIONS: 'participant/plan/{planId}/options',
  GET_PARTICIPANT_MORINGINSTART: 'participant/plan/{planId}/morningstar',

  GET_PARTICIPANT_VALIDATE_SSN:
    'participant/plan/{planId}/validation/ssnnotexists',
  GET_UPDATE_PARTICIPANT_VALIDATE_SSN:
    'participant/plan/{planId}/validation/ssnexists',
  GET_PARTICIAPNT_STATUS_LIST: 'participant/plan/{planId}/status',
  GET_PARTICIPANT_ODE_DIVSUB:
    'participant/plan/{planId}/optionaldataelements/divsub/{optionValue}',
  GET_PARTICIPANT_OPTIONALDATAELEMENTS:
    'participant/plan/{planId}/optionaldataelements',
  GET_PARTICIAPNT_CONTRIBUTION_ELECTIONS:
    'participant/plan/{planId}/contributionelections',
  GET_PARTICIPANT_INVESTMENT_ELECTIONS:
    'participant/plan/{planId}/investmentelections?sources={sources}&sameAsSource={sameAsSource}',
  POST_PARTICIPANT_ENROLL: 'participant/plan/{planId}/enrollparticipant',
  // /service/participant/plan/{planId}/enrollparticipant
  POST_ENROLL_PARTICIPANT: 'participant/plan/{planId}/enrollparticipant',
  //#endregion

  //#region Update Participant
  // NOTE:  Add all your update participant url here
  GET_UPDATE_PARTICIPANT_REQUIRED_DATA: 'participant/plan/{planId}/search/ssn',
  GET_PARTICIPANT_LIST_BY_NAME:
    'participant/plan/{planId}/search/name?name={participantName}',
  POST_UPDATE_PARTICIPANT: 'participant/plan/{planId}/updateparticipant',
  //#endregion

  //#region Contribution - Manual
  GET_CONTRIBUTION_OPTIONS: 'contributions/plan/{planId}/options',
  GET_CONTRIBUTION_AUTH_DIVSUB: 'plans/plan/{planId}/authdivsub',
  GET_CONTRIBUTION_GRID_DATA: 'contributions/plan/{planId}/data',
  PUT_CONTRIBUTION_BATCH_INFO: 'contributions/plan/{planId}/batchinfo',
  GET_CONTRIBUTION_PREVIOUS_BATCH_LIST:
    'contributions/plan/{planId}/priorbatches',
  //#endregion

  //#region Batch Participant Update
  // NOTE:  Add all your Batch Participant Update url here
  //#endregion

  //#region File Import
  // NOTE:  Add all your File Import url here
  FILE_IMPORT:
    'common/import/plan/{planId}/fileType/{fileType}/importType/{importType}/file',
  GET_TEMPLATE_OPTIONS:
    'common/import/plan/{planId}/fileType/{fileType}/importType/{importType}/templates',
  GET_AVAILABLE_COLUMNS:
    'common/import/plan/{planId}/importType/{importType}/columnlist',
  GET_TEMPLATE_DETAILS:
    'common/import/plan/{planId}/templateId/{templateId}/importType/{importType}/fileType/{fileType}/template/info',
  PUT_SAVE_TEMPLATE: 'common/import/plan/{planId}/template/save',
  POST_VALIDATE_FILEDATA: '{module}/import/plan/{planId}/template/validate',
  POST_CONFIRM_DATA: '{module}/plan/{planId}/import/template/verify',
  POST_UPDATE_DATA:
    '/service/participant/import/plan/{planId}/fixed/template/validatedata',
  DELETE_TEMPLATE_DELETE: '/service/common/plan/{planId}/template/delete',
  //#endregion

  //#region Admin
  // NOTE:  Add all your Admin url here
  GET_PAGE_INFO_URL: 'admin/page/plan/',
  GET_PLAN_SETUP_URL: 'admin/plansetup/plan/',
  GET_OPTIONAL_DE_URL: 'admin/optionalde/plan/',
  GET_COPY_PLANS_URL: 'admin/plancopy/plan/{planNumber}/plans',
  PUT_COPY_PLAN_URL: 'admin/plancopy/plan/{planNumber}/copy',
  //#endregion

  // Batch Participnat
  GET_PARTICIPANT_DATA_FIELDS:
    'participant/bulkupdate/plan/{planNumber}/options',
  GET_PARTICIPANTS_DATA:
    'participant/bulkupdate/plan/{planNumber}/participants?activeonly=',
  POST_BULK_PARTICIPANTS:
    'participant/bulkupdate/plan/{planNumber}/participants',

  //#region Report Module
  GET_REPORT_NAMES_URL: 'report/',
  GET_REPORT_URL: 'reportNames'

  //#endregion
};
