export const GRID_CONFIG = {
  LIST_PLAN: {
    GRID_SIZE: { width: 555, height: 800 },
    COLUMN_DEFS: [
      {
        headerName: 'Plan Number',
        field: 'planNumber',
        width: 200,
        unSortIcon: true,
        cellStyle: { 'text-align': 'center' }
      },
      { headerName: 'Plan Name', field: 'planName', width: 350, unSortIcon: true }
    ]
  },
  LIST_USRS: {
    GRID_SIZE: { width: 555, height: 800 },
    COLUMN_DEFS: [
      { headerName: 'ID', field: 'id', width: 200 },
      { headerName: 'Name', field: 'name', width: 350 },
      { headerName: 'User Name', field: 'username', width: 350 }
    ]
  },

  BANK_INFO: {
    GRID_SIZE: { width: 800, height: 800 },
    COLUMN_DEFS: [
      { headerName: 'Division/Location Number', field: 'divsub', width: 200,  unSortIcon: true },
      { headerName: 'Division/Location Name', field: 'textOnly', width: 300,  unSortIcon: true },
      { headerName: 'Bank Name', field: 'bankName', width: 150,  unSortIcon: true },
      {
        headerName: 'Account Type',
        field: 'accountTypeDescription',
        width: 125,
        unSortIcon: true
      },
      {
        headerName: 'Actions',
        field: 'actions',
        cellRenderer: 'linkRenderer',
        width: 105,
        suppressFilter: true,
        unSortIcon: true
      }
    ]
  },
  PLAN_UPDATE: {
    GRID_SIZE: { width: 800, height: 800 },
    COLUMN_DEFS_MONEY_SOURCES: [
      { headerName: 'Source Code', field: 'code', width: 78,  unSortIcon: true },
      { headerName: 'Long Name', field: 'longName', width: 103,  unSortIcon: true },
      { headerName: 'Short Name', field: 'shortName', width: 69,  unSortIcon: true },
      {
        headerName: 'Short Name Override',
        field: 'shortNameOverride',
        cellRenderer: 'textboxRender',
        width: 105,
        unSortIcon: true
      },
      {
        headerName: 'Exclude',
        field: 'exclude',
        cellRenderer: 'checkboxRenderer',
        width: 79,
        unSortIcon: true
      },
      {
        headerName: 'Contribution Catch-Up',
        field: 'contributionCatchUp',
        cellRenderer: 'checkboxRenderer',
        width: 105,
        unSortIcon: true
      },
      {
        headerName: 'Deferral Catch-Up',
        field: 'deferralCatchUp',
        cellRenderer: 'checkboxRenderer',
        width: 70
      },
      {
        headerName: 'Limit',
        field: 'limit',
        cellRenderer: 'checkboxRenderer',
        width: 63,
        unSortIcon: true
      },
      {
        headerName: 'Fort Account From',
        field: 'forfeitureAccountFrom',
        cellRenderer: 'checkboxRenderer',
        width: 84,
        unSortIcon: true
      },
      {
        headerName: 'Fort Account To',
        field: 'forfeitureAccountTo',
        cellRenderer: 'checkboxRenderer',
        width: 85,
        unSortIcon: true
      },
      {
        headerName: 'Prefunded Account From',
        field: 'prefundedAccountFrom',
        cellRenderer: 'checkboxRenderer',
        width: 94,
        unSortIcon: true
      },
      {
        headerName: 'Prefunded Account To',
        field: 'prefundedAccountTo',
        cellRenderer: 'checkboxRenderer',
        width: 98,
        unSortIcon: true
      }
    ],

    COLUMN_DEFS_INVESTMENTS: [
      { headerName: 'Investment Code', field: 'code', width: 135 },
      { headerName: 'Long Name', field: 'longName', width: 300 },
      {
        headerName: 'Long Name Override',
        field: 'longNameOverride',
        cellRenderer: 'textboxRender',
        width: 250,
        unSortIcon: true
      },
      {
        headerName: 'Exclude',
        field: 'exclude',
        cellRenderer: 'checkboxRenderer',
        width: 353,
        unSortIcon: true
      }
    ]
  },

  SUB_DIV_INFO: {
    GRID_SIZE: { width: 600, height: 450 },
    COLUMN_DEFS: [
      { headerName: 'Division/Location Number', field: 'divsub', width: 200,  unSortIcon: true },
      { headerName: 'Division/Location Name', field: 'textOnly', width: 560,  unSortIcon: true }
    ]
  },

  PLAN_COPY: {
    GRID_SIZE: { width: 800, height: 800 },
    COLUMN_DEFS_PLANS: [
      {
        headerName: 'All plans',
        field: 'plan',
        suppressFilter: true,
        headerCheckboxSelection: true,
        headerCheckboxSelectionFilteredOnly: false,
        checkboxSelection: true,
        width: 120
      },
      { headerName: 'Plan number', field: 'planNumber',  unSortIcon: true },
      { headerName: 'Plan name', field: 'planName',  unSortIcon: true }
    ]
  },

  TERMINATION_REASON: {
    GRID_SIZE: { width: 800, height: 800 },
    COLUMN_DEFS_REASON: [
      { headerName: 'Option ID', field: 'ID', width: 95, editable: true },
      {
        headerName: 'DE Option Text',
        field: 'DEText',
        width: 130,
        editable: true,
        unSortIcon: true
      },
      {
        headerName: ' ',
        field: 'link',
        cellRenderer: 'checkboxRenderer',
        width: 150,
        editable: false,
        unSortIcon: true
      }
    ]
  },

  TERMINATION_CLIENT_SPECIFIC: {
    GRID_SIZE: { width: 800, height: 800 },
    COLUMN_DEFS_REASON: [
      { headerName: '', field: '', width: 95, cellRenderer: 'radiobuttonRender' },
      { headerName: 'Option ID', field: 'ID', width: 95, editable: true },
      {
        headerName: 'DE Option Text',
        field: 'DEText',
        width: 130,
        editable: true,
        unSortIcon: true
      }
    ]
  },

  DATA_ELEMENTS: {
    GRID_SIZE: { width: 800, height: 800 },
    COLUMN_DEFS_ELEMENTS: [
      {
        headerName: '',
        field: '',
        width: 30,
        cellRenderer: 'radiobuttonRender'
      },
      { headerName: 'Data Element', field: 'optionalElementID', width: 115,  unSortIcon: true },
      { headerName: 'Omni Name', field: 'omniName', width: 130 },
      { headerName: 'Override Flag', field: 'overrideFlagChar', width: 80,  unSortIcon: true },
      { headerName: 'Override Name', field: 'overrideName', width: 130,  unSortIcon: true },
      { headerName: 'Std. Display Order', field: 'defaultSortOrder', width: 141,  unSortIcon: true },
      { headerName: 'Override Display Order', field: 'overrideSortOrder', width: 153, cellRenderer: 'textboxRender' }
    ],
    OPTIONS: [
      { headerName: '', field: '', width: 30, cellRenderer: 'radiobuttonRender',  unSortIcon: true },
      { headerName: 'Option ID', field: 'valueCode', width: 200,  unSortIcon: true  },
      { headerName: 'DE Option Text', field: 'value', width: 250,  unSortIcon: true }
    ]
  },
  COLUMN_DEFS_FIXED_WIDTH: [
    {
      headerName: 'Field Name',
      field: 'fieldType',
      width: 300,
      editable: false
    },
    {
      headerName: 'Starting Position',
      field: 'startPosition',
      width: 135,
      editable: true
    },
    {
      headerName: 'Field Length',
      field: 'fieldLength',
      width: 135,
      editable: true
    },
    {
      headerName: '',
      field: 'actions',
      cellRenderer: 'linkRenderer',
      width: 200
    }
  ],

  BATCH_PARTICIPANT: {
    GRID_SIZE: { width: 800, height: 800 },
    COLUMN_DEFS_PARTICIPANTS: [
      { headerName: 'Name', field: 'name', width: 150, cellRenderer: 'linkRender',  unSortIcon: true },
      { headerName: 'SSN', field: 'SSN', width: 130,  unSortIcon: true },
      { headerName: 'Date Of Hire', field: 'DOH', width: 200, editable: true,  unSortIcon: true },
      { headerName: 'Email ', field: 'email', width: 130, editable: true,  unSortIcon: true },
      { headerName: 'Address1', field: 'address1', width: 130, editable: true,  unSortIcon: true },
      {
        headerName: 'Address2', field: 'address2', width: 130,
        cellEditor: "agSelectCellEditor",
        cellEditorParams: {
          cellHeight: 100,
          values: ["Address2", "Address1"]
        }
      },
    ]

  }

};
