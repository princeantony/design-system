import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { CommonService } from 'src/app/shared/services/common.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { ToastrService } from '../../../shared/services/toastr.service';
import { AuthService } from '../../login/services/auth.service';

const noop = () => {};

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isLabelHidden: boolean;
  errorCount = 0;
  private _onTouchedCallback: (_: any) => void = noop;
  private _onChangeCallback: (_: any) => void = noop;
  public loginFail;
  constructor(
    private commonService: CommonService,
    private router: Router,
    private authService: AuthService,
    private toastrService: ToastrService,
    private spinner: NgxSpinnerService,
    vcr: ViewContainerRef
  ) {
    this.toastrService.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.loginForm = new FormGroup({
      username: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      clientId: new FormControl('INGWIN', Validators.required),
      divisionId: new FormControl('WIN', Validators.required)
    });
  }

  onSubmit() {
    if (
      this.loginForm.value.username &&
      this.loginForm.value.password &&
      this.loginForm.value.clientId &&
      this.loginForm.value.divisionId
    ) {
      PayAdminGlobalState.loginUser = {
        userName: this.loginForm.value.username,
        password: this.loginForm.value.password,
        clientId: this.loginForm.value.clientId,
        divisionId: this.loginForm.value.divisionId
      };
      PayAdminGlobalState.loginStatus = false;
      this.login();
    } else {
      this.loginFail = true;
    }
  }

  login(): void {
    this.errorCount++;
    this.authService.doAuthenticte(PayAdminGlobalState.loginUser).subscribe(
      loginInfo => {
        if (loginInfo.status === APP_CONST.SUCCESS) {
          PayAdminGlobalState.loginStatus = true;
          if (
            PayAdminGlobalState.loginUser &&
            PayAdminGlobalState.loginStatus
          ) {
            if (
              PayAdminGlobalState.StateList.length < 2 ||
              PayAdminGlobalState.CountryList.length < 2
            ) {
              this.commonService.getCountryStateList().subscribe(
                ([resCountryList, resStateList]) => {
                  try {
                    if (resCountryList.status === 'SUCCESS') {
                      PayAdminGlobalState.CountryList = PayAdminGlobalState.CountryList.concat(
                        resCountryList.data
                      );
                    }
                    if (resStateList.status === 'SUCCESS') {
                      PayAdminGlobalState.StateList = PayAdminGlobalState.StateList.concat(
                        resStateList.data
                      );
                    }
                  } catch (Error) {
                    console.log(
                      'Erorr Occured while parsing State and Country'
                    );
                  }

                  if (PayAdminGlobalState.loginStatus) {
                    this.router.navigate(['/plans']);
                  } else {
                    this.router.navigate(['/']);
                  }
                },
                err => {
                  this.toasterError(err);
                }
              );
            }
          }
        } else {
          this.toastrService.showError(
            loginInfo.error.msg,
            loginInfo.status + ' !'
          );
        }
      },
      err => {
        if (this.errorCount < 4) {
          this.login();
        } else {
          this.spinner.hide();
          this.toastrService.showError(
            'Error while authenticating PayAdmin. Click on Logout to try again!',
            'Login failed'
          );
        }
      }
    );
  }

  onTouched(event: any) {
    if (event.target.value === '') {
      this.isLabelHidden = true;
    }
    if (event.target.value !== '') {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus() {
    this.isLabelHidden = false;
  }

  toasterError(error) {
    this.spinner.hide();
    console.log('err.error', error.error);
    const errMessage =
      error.error.error.code === 400
        ? error.error.error.msg
        : error.error.error.cause;
    this.toastrService.showError(errMessage, error.error.status + '!');
  }
}
