import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';
import { SERVICE_URL } from 'src/app/shared/constants/service.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { AdminMenuItems } from '../../../shared/config/admin.config';
import { IMenuItem } from '../../../shared/interfaces/menu-item.interface';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { Utils } from '../../../shared/utils/pay-admin.utils';
import { DataElement } from '../models/data-element-model';
import { AdminDataService } from './admin-data.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  constructor(private mockService: MockService, private utils: Utils, private apiService: ApiService) {}

  getMockMenuList(planNumber: string): Observable<any> {
    return this.mockService.getAdminFlags();
  }
  getMenuItemRows(menuItemsFlag: any) {
    const menuItemsToBind: IMenuItem[] = [];
    AdminMenuItems.forEach(menuItem => {
      if (menuItemsFlag[menuItem.key]) {
        menuItemsToBind.push(menuItem);
      }
    });
    return this.utils.chunkArray(menuItemsToBind, 3);
  }

  getMockTerminationList(): Observable<any> {
    return this.mockService.getTerminationReason();
  }

  getDEList(planNumber: string): Observable<any> {
    return (ENV.TEST)
    ? this.mockService.getDataElements()
    : this.apiService.get(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber);

  }
  getDEOptions(planNumber: string, dataelementID: string )
  {
    return (ENV.TEST)
    ? this.mockService.getDEOptions()
    : this.apiService.get(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID + '/values');
  }
  updateOrderNumber(planNumber: string, updatedDataelement: any )
  {
    return (ENV.TEST)
    ? this.mockService.successMock()
    : this.apiService.put(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/overrideDisplayOrder/', updatedDataelement);
  }
  deleteDE(planNumber: string, dataelementID: string )
  {
    return (ENV.TEST)
    ? this.mockService.successMock()
    : this.apiService.delete(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID  );
  }
  deleteDEOption(planNumber: string, updatedDE: any, optionValue: string)
  {
    return (ENV.TEST)
    ? this.mockService.successMock()
    : this.apiService.delete(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + updatedDE + '/options/' + optionValue  );
  }
  saveDE(planNumber: string, newdDE: DataElement, selectedDEId: string,  isCreate: boolean)
  {
    if (ENV.TEST) {
     return this.mockService.successMock()
    } else {
      return (isCreate)
      ? this.apiService.post(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + selectedDEId, newdDE  )
      : this.apiService.put(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + selectedDEId, newdDE    );
    }

  }
  saveDEOption(planNumber: string, newdDEOption: any, dataelementID: string,  isCreate: boolean)
  {
    if (ENV.TEST) {
     return this.mockService.successMock()
    } else {
      return (isCreate)
      ? this.apiService.post(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID + '/option', newdDEOption  )
      : this.apiService.put(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID + '/option/initialCode/'+ AdminDataService.dataElementOptionId , newdDEOption  );
    }

  }
  putPlanCopy(planNumber: string, copyPlanObj: any) {
    if (ENV.TEST) {
      return this.mockService.successMock();
    } else {
      return this.apiService.put(SERVICE_URL.PUT_COPY_PLAN_URL.replace('{planNumber}', planNumber), copyPlanObj);
    }

  }

  getPlanCopyPlans()
  {
    return (ENV.TEST)? this.mockService.getListPlans() : this.apiService.get(SERVICE_URL.GET_COPY_PLANS_URL
      .replace('{planNumber}', PayAdminGlobalState.planNumber)
      );
  }
}
