import { Component, Input, OnInit } from '@angular/core';

import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-plan-setup-modal',
  templateUrl: './plan-setup-modal.component.html',
  styleUrls: ['./plan-setup-modal.component.scss']

})
export class PlanSetupModalComponent implements OnInit {
  @Input() modelId = 'participant';
  @Input() title = 'Enrollment Option';

  constructor(private modalService: ModalService) {console.log(this.modelId, 'model id') }

  ngOnInit() {

  }

  closeModal(id: string) {
    this.modalService.close(id);
}
}


