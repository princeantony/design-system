import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import {
  AddEnrollmentOptions,
  BatchParticipantOptions,
  ContributionOptions,
  ParticipantOptions,
} from 'src/app/shared/config/data-element.config';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { APP_CONST } from '../../../../../shared/constants/app.constants';
import { ModalService } from '../../../../../shared/services/modal.service';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-data-element-item',
  templateUrl: './admin-data-element-item.component.html',
  styleUrls: ['./admin-data-element-item.component.scss']
})
export class AdminDataElementItemComponent implements OnInit {
  hidePageTitle: boolean;
  pageTitle: string;
  planNumber: string;
  selectedDataElement: any;
  participantOptions: any;
  addEnrollmentOptions: any;
  contributionOptions: any;
  isButtonDisabled = true;
  batchParticipantOptions: any;
  selectedDEId: string;
  modelId = 'deModal';
  type = 'Data Element';
  isCreate = true;
  disableAccumulate = true;
  overrideRequired = false;
  accOverrideRequired = false;
  showAccumulateDetails = false;
   isValidForm = true;

   errorMeassge = ''
  updateOtionalDataForm = this.fb.group({
    objectID: ['', Validators.required],
    subObjectID: ['', Validators.required],
    dataElement: ['', Validators.required],
    omniName: [''],
    overrideName: [''],
    overrideFlag: [false],
    enrollmentUsageCode: ['N', Validators.required],
    participantUsageCode: ['N', Validators.required],
    contributionUsageCode: ['N', Validators.required],
    censusUsageCode: ['N', Validators.required],
    accumulate: [false, Validators.required],
    accOverFlag: [false],
    accOverName: ['']
  });
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    private modalService: ModalService,
    private adminService: AdminService
  ) {

  }
  populateForm(dataElement) {
    this.updateOtionalDataForm.controls['objectID'].setValue(
      dataElement.objectID
    );
    this.updateOtionalDataForm.controls['subObjectID'].setValue(
      dataElement.subObjectID
    );
    this.updateOtionalDataForm.controls['dataElement'].setValue(
      dataElement.dataElement
    );
    this.updateOtionalDataForm.controls['omniName'].setValue(
      dataElement.omniName
    );
    this.updateOtionalDataForm.controls['overrideName'].setValue(
    dataElement.overrideName
    );
    this.updateOtionalDataForm.controls['overrideFlag'].setValue(
      dataElement.overrideFlag ? true : false
    );
    this.updateOtionalDataForm.controls['accumulate'].setValue(
      dataElement.accumulate
    );
    this.updateOtionalDataForm.controls['enrollmentUsageCode'].setValue(
      dataElement.enrollmentUsageCode
    );
    this.updateOtionalDataForm.controls['participantUsageCode'].setValue(
      dataElement.participantUsageCode
    );
    this.updateOtionalDataForm.controls['contributionUsageCode'].setValue(
      dataElement.contributionUsageCode
    );
    this.updateOtionalDataForm.controls['censusUsageCode'].setValue(
      dataElement.censusUsageCode
    );
    this.updateOtionalDataForm.controls['accOverFlag'].setValue(
      dataElement.accOverFlag
    );
    this.updateOtionalDataForm.controls['accOverName'].setValue(
      dataElement.accOverName
    );
  }

  ngOnInit() {
    PayAdminGlobalState.previousPage = 'admin/dataElements';
    PayAdminGlobalState.currentPage = 'admin/dataElements/createOrEdit';
    this.planNumber = PayAdminGlobalState.planNumber;
    this.participantOptions = ParticipantOptions;

    if (AdminDataService.dataElement && AdminDataService.dataElement.showLOA) {
      const newObj = [{ displayText: 'LOA Functionality', value: 'L' }];
      this.participantOptions = _.unionWith(
        this.participantOptions,
        newObj,
        _.isEqual
      );
    }
    this.addEnrollmentOptions = AddEnrollmentOptions;
    this.contributionOptions = ContributionOptions;
    this.batchParticipantOptions = BatchParticipantOptions;
    this.initialLoad();
  }
  enableDisableFields(dataElement) {
    this.overrideRequired = dataElement.overrideFlag;
    this.accOverrideRequired = dataElement.accOverFlag;
  }
  selectAccumulate(_optionalElementID, _isAccumulte) {
    if (
      _.endsWith(_optionalElementID.toUpperCase(), 'PH085') ||
      _.endsWith(_optionalElementID.toUpperCase(), 'PH340')
    ) {
      this.disableAccumulate = false;
      if(_isAccumulte) {
        this.showAccumulateDetails = true;
      }
    } else {
      this.updateOtionalDataForm.controls['accumulate'].setValue(false);
      this.updateOtionalDataForm.controls['accOverFlag'].setValue(false);
      this.disableAccumulate = true;
      this.showAccumulateDetails = false;
    }
  }
  onClear() {
    this.initialLoad();
  }
  get objectID() {
    return this.updateOtionalDataForm.get('objectID').value;
  }
  get subObjectID() {
    return this.updateOtionalDataForm.get('subObjectID').value;
  }
  get dataElement() {
    return this.updateOtionalDataForm.get('dataElement').value;
  }
  setAccOverRequired() {
   this.accOverrideRequired = !this.accOverrideRequired;
   this.addRemoveOverValidation('accOverFlag', 'accOverName');
  }
  setOverRequired() {
    this.overrideRequired = !this.overrideRequired;
    this.addRemoveOverValidation('overrideFlag', 'overrideName');

  }
  addRemoveOverValidation(checkCtr, txtCtr)
  {
    if(this.updateOtionalDataForm.controls[checkCtr].value) {
      if( _.trim(this.updateOtionalDataForm.controls[txtCtr].value) === '') {
        this.updateOtionalDataForm.setErrors({invalid: true});
        this.isValidForm = false;
        this.errorMeassge = 'Override Name is required if Use Override is selected';
      } else {
        this.errorMeassge = '';
        this.isValidForm = true;
      }
    } else {
      this.isValidForm = true;
      this.errorMeassge = '';
  }
  }
  showAccDetails(value) {
      this.showAccumulateDetails = value;
        this.updateOtionalDataForm.controls['accOverFlag'].setValue(false);
        this.updateOtionalDataForm.controls['accOverName'].clearValidators();
        this.updateOtionalDataForm.controls['accOverName'].setErrors(null);
        this.updateOtionalDataForm.controls['accOverName'].reset();
        this.updateOtionalDataForm.controls['accOverName'].setValue('');
        this.accOverrideRequired = false;
  }
  onKeyUp(event: any) {
    const tempOptionalElementID =
      this.objectID + this.subObjectID + this.dataElement;
    this.selectAccumulate(tempOptionalElementID, false);
   if(this.isCreate){
    this.selectedDEId = tempOptionalElementID;
   }
  }
  doUserCheck(event: any)
  {
    this.addRemoveOverValidation('overrideFlag','overrideName');
  }
  doAccCheck(event: any)
  {
    this.addRemoveOverValidation('accOverFlag', 'accOverName');
  }
  onDelete() {
    this.spinner.show();
    this.adminService.deleteDE(this.planNumber, this.selectedDEId).subscribe(
      delRes => {
        this.spinner.hide();
        if (delRes.status === APP_CONST.SUCCESS) {
          this.router.navigate(['/admin/dataElements']);
        } else {
          console.log('Error in onDelete data element item', delRes); // for testing
          this.errorMeassge = delRes.error.msg;

        }
      },
      err => {
        this.spinner.hide();
        console.log('Error in onDelete data element item outside', err);
        this.toastr.error(
          'Error while deleting Data Element ' + this.selectedDEId,
          err.error.error.status + ' !',
          { showCloseButton: true }
        );
      }
    );
  }
  saveDE() {
  if(this.isValidForm){
    const newDataElement = this.updateOtionalDataForm.value;
    this.adminService
      .saveDE(this.planNumber, newDataElement, this.selectedDEId, this.isCreate)
      .subscribe(
        saveRes => {
          this.spinner.hide();
          if (saveRes.status === APP_CONST.SUCCESS) {
            this.router.navigate(['/admin/dataElements']);
          } else {
            console.log('Error in saveDE data element item', saveRes); // for testing
            this.errorMeassge = saveRes.error.msg;

          }
        },
        err => {
          this.spinner.hide();
          console.log('Error in saveDE data element item outside', err); // for testing
          this.toastr.error(
            'Error while saving Data Element ' + this.selectedDEId,
            err.error.status + ' !',
            { showCloseButton: true }
          );
        }
      );
      } else {
        this.errorMeassge = 'Override Name is required if Use Override is selected';
      }

  }
  showOptions() {
    this.router.navigate(['/admin/dataElements/options']);
  }
  showDeteleModal() {
    this.modalService.open(this.modelId);
  }
  gotoBack() {
    this.router.navigate(['/admin/dataElements']);
  }
  initialLoad() {
    if (
      AdminDataService.dataElement &&
      AdminDataService.dataElement.optionalElementID
    ) {
      this.isButtonDisabled = false;
      this.isCreate = false;
      this.selectedDataElement = AdminDataService.dataElement;

      this.selectedDEId = AdminDataService.dataElement.optionalElementID;
      this.populateForm(this.selectedDataElement);
      this.selectAccumulate(this.selectedDataElement.optionalElementID, AdminDataService.dataElement.accumulate);
      this.enableDisableFields(this.selectedDataElement);
    } else {
      this.updateOtionalDataForm.reset();
      this.disableAccumulate = false;
      this.updateOtionalDataForm.controls['accumulate'].setValue(
        false
      );
      this.updateOtionalDataForm.controls['omniName'].setValue('');
      this.updateOtionalDataForm.controls['overrideFlag'].setValue(false);
      this.updateOtionalDataForm.controls['overrideName'].setValue('');
      this.updateOtionalDataForm.controls['accOverName'].setValue('');
    }


  }
}
