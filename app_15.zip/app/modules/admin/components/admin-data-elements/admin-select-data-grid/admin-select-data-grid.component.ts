import { Component, OnInit, Input } from "@angular/core";

@Component({
  selector: "app-admin-select-data-grid",
  templateUrl: "./admin-select-data-grid.component.html"
})
export class AdminSelectDataGridComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;

  ngOnInit() {
  }
}
