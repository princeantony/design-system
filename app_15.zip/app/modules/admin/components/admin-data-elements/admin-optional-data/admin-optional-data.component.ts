import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-optional-data',
  templateUrl: './admin-optional-data.component.html'
})

export class AdminOptionalDataComponent implements OnInit {
  hidePageTitle: boolean;
  pageTitle: string;
  planNumber: string;
  updateOtionalDataForm = this.fb.group({
    dataElement1: ['', Validators.required],
    standardName: ['', Validators.required],
    overrideName: ['', Validators.required],
    Enrollment: ['', Validators.required],
    Participant: ['', Validators.required],
    Contribution: ['', Validators.required],
    batchParticipant: ['', Validators.required],
  });

  onStateChange(value: string) {
    console.log("value changed"  + value);
  }
  constructor(private fb: FormBuilder, ) { }
  ngOnInit() {

  }
}
