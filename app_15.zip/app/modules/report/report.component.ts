import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

import { APP_CONST } from '../../shared/constants/app.constants';
import { PayAdminGlobalState } from '../../shared/store/pay-admin-global.store';
import { ReportService } from './report.service';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html'
})
export class PayAdminReportComponent implements OnInit {
  reportColumns: any;
  reportData: any;
  reportNames: any;
  reportForm: any;
  reportHeadings: any;
  reportDetails: any;
  style;
  rowStyle;
  gridStyle;
  constructor(
private reportService: ReportService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder
  ) {
    this.gridStyle = { width: 400, height: 200 };
    this.style = { width: '100%' };
    this.rowStyle = { color: '#333333' };
  }
  ngOnInit() {
    this.reportForm = this.fb.group({
      reportList: new FormControl()}
    )
    this.getReportNames();
    //this.getReport();
  }

  getReportNames(): void {
    this.spinner.show();
    this.reportService.getReportNames(PayAdminGlobalState.planNumber).subscribe(
      names => {
        if (names.status === APP_CONST.SUCCESS) {
          this.reportNames = names.data;
          console.log(this.reportNames,names.data )
          this.spinner.hide();
        } else {
          console.log('Error in report name', names);
          this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }

  getReport(reportName: string): void {
    this.reportService.getReport(PayAdminGlobalState.planNumber).subscribe(
      report => {
        this.spinner.hide();
        if (report.status === APP_CONST.SUCCESS) {
          this.reportData = report.data.content;
          this.reportHeadings = report.data.headers ;
          this.reportDetails = {
                          'planName': report.data.planName,
                          'runDa  te': report.data.runDate,
                          'runTime': report.data.runTime,
                          'attention': report.data.attention,
                          'reportName': report.data.reportName};
          this.createGridHeadings();
        } else {
          console.log('Error in report reportData', report);
                  this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }
  createGridHeadings()
  {
const newHeadings = [];
    this.reportHeadings.forEach((heading, index) => {
      newHeadings.push(  { headerName: heading.name, field: heading.id, width: 170 });
    });
    this.reportColumns = newHeadings;
    }


}
