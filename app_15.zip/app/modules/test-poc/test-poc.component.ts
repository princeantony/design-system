import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-test-poc',
  templateUrl: './test-poc.component.html',
  styleUrls: ['./test-poc.component.scss']
})
export class TestPocComponent implements OnInit {
  form: FormGroup;
  constructor(private formBuilder: FormBuilder) {}
  formDate = {
    dob: '',
    displayDOB: true,
    flag: true
  };
  ngOnInit() {
    this.form = this.formBuilder.group({
      dob: this.formDate.dob,
      displayDOB: this.formDate.displayDOB,
      flag: this.formDate.flag
    });
    this.form.controls['displayDOB'].setValue(this.formDate.displayDOB);
  }
  onSetDate() {
    this.form.get('dob').setValue('7/23/1988');
  }
  onCheckBoxChange(value) {
    setTimeout(() => {
      this.form.controls['displayDOB'].setValue(false);
    }, 1);

  }

  onSubmit() {
    // const a = this.formDate.displayDOB;
    const a = this.form.get('displayDOB').value;
    this.form.controls['displayDOB'].setValue(false);
    debugger;
    console.log(this.form);
  }
}
