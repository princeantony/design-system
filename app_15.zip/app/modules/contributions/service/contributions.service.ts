import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';

import { ContributionsMockService } from './contributions-mock.service';
import { catchError } from 'rxjs/operators';
import { ErrorHandlerService } from 'src/app/shared/services/error-handler.service';
import { ApplicationResponse } from 'src/app/shared/models/common.model';
import { ApiService } from 'src/app/shared/services/api.service';
import { SERVICE_URL } from 'src/app/shared/constants/service.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
import { LoggerService } from 'src/app/shared/services/logger.service';

@Injectable({
  providedIn: 'root'
})
export class ContributionsService {
  constructor(
    private apiService: ApiService,
    private contributionsMockService: ContributionsMockService,
    private errorHandlerService: ErrorHandlerService,
    private logger: LoggerService
  ) {}

  private appResponse: ApplicationResponse = new ApplicationResponse();
  getContributionOptions(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService
        .getContributionOptions()
        .pipe(
          catchError(
            this.errorHandlerService.erroHandler(
              'POST_ENROLL_PARTICIPANT',
              'Options',
              this.appResponse
            )
          )
        );
    } else {
      const url = SERVICE_URL.GET_CONTRIBUTION_OPTIONS.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiService
        .get(url)
        .pipe(
          catchError(
            this.errorHandlerService.erroHandler(
              'Contributions',
              'GET_CONTRIBUTION_OPTIONS',
              this.appResponse
            )
          )
        );
    }
  }

  getContributionAuthDivSub(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.getContributionAuthDivSub();
    } else {
      const url = SERVICE_URL.GET_CONTRIBUTION_AUTH_DIVSUB.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiService
        .get(url)
        .pipe(
          catchError(
            this.errorHandlerService.erroHandler(
              'Contribution',
              'GET_CONTRIBUTION_AUTH_DIVSUB',
              this.appResponse
            )
          )
        );
    }
  }
  getContributionPreviousBatchList(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.getContributionPreviousBatchList();
    } else {
      const url = SERVICE_URL.GET_CONTRIBUTION_PREVIOUS_BATCH_LIST.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiService
        .get(url)
        .pipe(
          catchError(
            this.errorHandlerService.erroHandler(
              'Contribution',
              'GET_CONTRIBUTION_PREVIOUS_BATCH_LIST',
              this.appResponse
            )
          )
        );
    }
  }
  getContributionGridData(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.getContributionGridData();
    } else {
      // TODO: get contribution post request object
      const contributionParams = '';
      const url = SERVICE_URL.GET_CONTRIBUTION_GRID_DATA.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiService
        .post(url, contributionParams)
        .pipe(
          catchError(
            this.errorHandlerService.erroHandler(
              'Contribution',
              'GET_CONTRIBUTION_GRID_DATA',
              this.appResponse
            )
          )
        );
    }
  }
  UpdateContributionBatchInfo(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.UpdateContributionBatchInfo();
    } else {
      // TODO: get contribution post request object
      const batchInfo = '';
      const url = SERVICE_URL.PUT_CONTRIBUTION_BATCH_INFO.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiService
        .post(url, batchInfo)
        .pipe(
          catchError(
            this.errorHandlerService.erroHandler(
              'Contribution',
              'PUT_CONTRIBUTION_BATCH_INFO',
              this.appResponse
            )
          )
        );
    }
  }
}
