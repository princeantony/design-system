import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DateEditorComponent } from 'src/app/shared/components/ag-grid/editor/date-editor/date-editor.component';
import { FloatEditorComponent } from 'src/app/shared/components/ag-grid/editor/float-editor/float-editor.component';
import { NumericEditorComponent } from 'src/app/shared/components/ag-grid/editor/numeric-editor/numeric-editor.component';
import {
  TextEditorComponent,
} from 'src/app/shared/components/ag-grid/editor/text-editor-max-forty/text-editor-max-forty.component';

import { BatchGridDatePickerComponent } from '../batch-grid-date-picker/batch-grid-date-picker.component';
import { BatchGridLinkComponent } from '../batch-grid-link/batch-grid-link.component';


@Component({
  selector: 'app-batch-update-grid',
  templateUrl: './batch-update-grid.component.html',
  styleUrls: ['./batch-update-grid.component.scss']
})

export class BatchUpdateGridComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
  @Output() onGridReady = new EventEmitter<any>();
  frameworkComponents: any;
  style;
  components: any;
  private defaultColDef;
  private gridColumnApi;

  constructor() { this.style = { width: "90%" }; }
  ngOnInit() {

    this.frameworkComponents = {
      linkRender: BatchGridLinkComponent,
      dateRender: BatchGridDatePickerComponent,
      numericEditor: NumericEditorComponent,
      dateEditor: DateEditorComponent,
      floatEditor: FloatEditorComponent,
      textEditor : TextEditorComponent,
    };

    this.defaultColDef = { editable: true };


  };

  gridReady(params) {
    this.onGridReady.emit(params);
  }


}

