import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { ErrorHandlerService } from 'src/app/shared/services/error-handler.service';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
import { Utils } from 'src/app/shared/utils/pay-admin.utils';

import * as Participant from '../../../participants/model/participant.model';
import { ParticipantsService } from '../../../participants/service/participants.service';
import { PARTICIPANT_PATH } from '../../constants/participants.constants';
import {
  ParticipantFundSource,
  ParticipantFundSourceItem
} from '../../model/participant.model';
import { ParticipantStore } from '../../store/participant.store';

@Component({
  selector: 'app-participant-confirmation',
  templateUrl: './participant-confirmation.component.html',
  styleUrls: ['./participant-confirmation.component.scss']
})
export class ParticipantConfirmationComponent implements OnInit {
  private participantSubmitData: Participant.ParticipantSubmitData = {} as Participant.ParticipantSubmitData;
  private navigatedFromHomeToPrint = false;
  private pData: Participant.ParticipantData;
  private pName = '';
  private participantData;
  private optionalData = [];
  private optionalDatavalues = [];
  private EditMode = false;
  private participantFundSources;
  private fundRows;
  private tableColumns;
  private enrollFlag;
  private status: string;
  private messageList: string[] = [];
  constructor(
    private previousRouteService: PreviousRouteService,
    private participantsService: ParticipantsService,
    private utils: Utils,
    private spinner: NgxSpinnerService,
    private router: Router,
    private route: ActivatedRoute,
    public toastr: ToastsManager,
    vcr: ViewContainerRef,
    private errorHandlerService: ErrorHandlerService
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }
  private confirmationPageTitle = '';

  ngOnInit() {
    // Get Data from Participant store, format and print the confiramtaion screen
    this.pData = ParticipantStore.ParticipantData;

    this.enrollFlag = ParticipantStore.ParticipantData.requiredData.enrollFlag;
    this.status = ParticipantStore.Status;
    this.pName =
      this.pData.requiredData.firstName +
      ' ' +
      (this.pData.requiredData.middleInitial
        ? this.pData.requiredData.middleInitial + '. '
        : '') +
      this.pData.requiredData.lastName;

    this.route.url.subscribe(value => {
      this.EditMode = _.find(value, ['path', 'UpadteParticipant'])
        ? true
        : false;
      this.navigatedFromHomeToPrint = _.find(value, ['path', 'Print'])
        ? true
        : false;
    });
    if (!this.EditMode) {
      this.confirmationPageTitle = 'Add/Enroll Confirmation';
    } else {
      this.confirmationPageTitle = 'Update Participant Confirmation';
    }
    // this.participantSubmitData = this.participantsService.getParticipantDataToSubmit();
    this.pData.optionalData.forEach(field => {
      if (field.value !== '') {
        if (field.componentType === 'dropdown') {
          const displayText = _.find(field.option, ['value', field.value])
            .displayText;
          this.optionalDatavalues.push({
            label: field.label,
            value: displayText
          });
        } else {
          this.optionalDatavalues.push({
            label: field.label,
            value: field.value
          });
        }
      }
    });
    this.optionalData = this.utils.chunkArray(this.optionalDatavalues, 3);

    this.participantFundSources =
      ParticipantStore.ParticipantData.participantContributionInvestmentData;
    // column data
    const columnsList = this.participantFundSources.sourceMap;
    this.tableColumns = [];

    // Create First Default FundNameColumn
    this.tableColumns.push({
      field: 'fundName',
      headerName: 'Fund Name'
    });
    // Push one column for each Source item
    if (columnsList) {
      columnsList.forEach(column => {
        this.tableColumns.push({
          field: column.sourceId,
          headerName: column.sourceName
        });
      });
    }
    // row data
    const fundSources: ParticipantFundSource[] = this.participantFundSources
      .fundSources;
    this.fundRows = [];
    if (fundSources) {
      fundSources.forEach(fundSrc => {
        const rowItem = Object.assign({ fundName: fundSrc.fundName });
        const sources: ParticipantFundSourceItem[] = fundSrc.percents;

        sources.forEach((src: ParticipantFundSourceItem) => {
          if (src.currentPercent !== '0') {
            Object.assign(rowItem, { [src.sourceId]: src.currentPercent });
          }
        });
        if (_.keys(rowItem).length > 1) {
          this.fundRows.push(rowItem);
        }
      });
    }
  }
  onBackClick() {
    let prevRoute = '';
    if (ParticipantStore.HasInvestment) {
      prevRoute = !this.EditMode
        ? PARTICIPANT_PATH.ADD.INVESTMENT
        : PARTICIPANT_PATH.UPDATE.INVESTMENT;
    } else if (ParticipantStore.HasContribution) {
      prevRoute = !this.EditMode
        ? PARTICIPANT_PATH.ADD.CONTRIBUTION
        : PARTICIPANT_PATH.UPDATE.CONTRIBUTION;
    } else if (ParticipantStore.HasOptionalData) {
      prevRoute = !this.EditMode
        ? PARTICIPANT_PATH.ADD.OPTIONAL
        : PARTICIPANT_PATH.UPDATE.OPTIONAL;
    } else {
      prevRoute = !this.EditMode
        ? PARTICIPANT_PATH.ADD.REQUIRED
        : PARTICIPANT_PATH.UPDATE.REQUIRED;
    }
    this.router.navigate([prevRoute]);
  }
  onSumitClick() {
    this.spinner.show();
    if (this.EditMode) {
      this.participantsService.updateParticipant().subscribe(
        result => {
          if (result.status === 'SUCCESS') {
            this.spinner.hide();
            PayAdminGlobalState.successMsg =
              'Participant updated successfully on ' +
              new Date().toLocaleDateString() +
              ' at ' +
              new Date().toLocaleTimeString() +
              '. For more information,';
            this.router.navigate(['/home/success']);
          } else {
            this.messageList = this.errorHandlerService.getErrorMessages([
              result
            ]);
            this.spinner.hide();
          }
        },
        err => {
          try {
            if (err.error.data.validationErrors.length > 0) {
              const validationErrors = err.error.data.validationErrors;
              validationErrors.forEach(vError => {
                this.messageList.push(vError);
              });
              this.spinner.hide();
            }
          } catch (Error) {
            console.log(Error);
          }
        }
      );
    } else {
      this.participantsService.enrollParticipant().subscribe(
        result => {
          if (result.status === 'SUCCESS') {
            this.spinner.hide();
            PayAdminGlobalState.successMsg =
              'Participant ' +
              (this.enrollFlag ? 'enrolled' : 'added') +
              ' successfully on ' +
              new Date().toLocaleDateString() +
              ' at ' +
              new Date().toLocaleTimeString() +
              ': ' +
              this.pName +
              '. To print a confirmation page,';
            this.router.navigate(['/home/success']);
          }

          if (result.status === 'ERROR') {
            this.messageList = this.errorHandlerService.getErrorMessages([
              result
            ]);
            this.spinner.hide();
          }
        },
        err => {
          try {
            if (err.error.data.validationErrors.length > 0) {
              const validationErrors = err.error.data.validationErrors;
              validationErrors.forEach(vError => {
                this.messageList.push(vError);
              });
            }
            this.spinner.hide();
          } catch (Error) {
            console.log(Error);
          }
        }
      );
    }
  }
}
