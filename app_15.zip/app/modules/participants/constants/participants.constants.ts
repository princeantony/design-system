export const MESSAGE = {
  PTPH740: `Rehire Date should be populated with the employee's most recent hire date.
            By populating this field (Rehire Date), employees in a terminated status code will be updated to an active status and all applicable termination information will be removed.
            </br></br>Please advise the employee that they must establish their contribution rates and confirm their investment allocations in the plan on line in order to resume contributions to the savings plan.
            </br></br>{0} does not use this field to calculate vesting. Depending on your plan's vesting method and service options you may be required to update additional information to correctly calculate the vested balances for the employee.</br></br>Contact {1} for further information.</p>`,
  PTPH062: `Your employee's Alternate Vesting Date is a date you use to take into account service for vesting. If applicable, your employee's Alternate Vesting Date is the date that takes into account service prior to the rehire date.</br></br>For example, if your Employee's rehire date is January 1, 2007 and you need to take into account an additional one year of service prior to the rehire date, your employee's Alternate Vesting Date would be January 1, 2006.</p>`,
  PTPH770: `Your employee's Adjusted Date of Hire is a date you use to take into account service for vesting and eligibility. If applicable, your employee's Adjusted Date of Hire is the date that takes into account service prior to the rehire date.</br></br>For example, if your Employee's rehire date is January 1, 2007 and you need to take into account an additional one year of service prior to the rehire date, your employee's Adjusted Date of Hire would be January 1, 2006</p>`,
  PTPH340: `Test Message 340`,
  PTPH085: `Test message 085`,
  PTPH740_ALERT: `<p>By entering a date in this field, {0} will update the employee's participation status to active. Plan Sponsor must verify vesting information and update accordingly. Please advise the employee to establish their contribution rates and confirm their investment allocation on line.</br></br>Refer to the help icon next to Rehire Date field for more information.</p>`,
  QDIA_HELP: `<p>A Qualified Default Investment Alternative("QDIA") is an investment alternative or option, as defined under rules issued by the Department of Labor, that has been chosen by the Plan's ficuciary in those instances when participants fail to provide direction or instruction how to invest monies in their retirement plan accounet.</p>
              </br>
              <p>Check the QDIA default enrollment box to indictae that you are enrolling the employee into the plan's QDIA option. You will need to set up the investment election to the appropriate QDIA option as part of this enrollment transaction.</p>
              </br>
              <p>Do not select the QDIA default enrollment box if the employee has submitted a signed enrollment form with any portion of the investment election that uses the QDIA fund. For example if the employee actively elects 100% to the plan's QDIA option, this is not considered a defaulted investment election.</p>
              </br>
              <p>Contact Voya for further information</p>`
};

export const PARTICIPANT_PATH = {
  ADD: {
    REQUIRED: 'participant',
    OPTIONAL: 'addParticipant/Optional',
    CONTRIBUTION: 'addParticipant/ContributionElection',
    INVESTMENT: 'addParticipant/ContributionInvestment',
    CONFIRMATION: 'addParticipant/Confirmation',
    CONFIRMATION_PRINT: 'addParticipant/Confirmation/Print'
  },
  UPDATE: {
    SEARCH: 'participantUpdateSearch',
    REQUIRED: 'UpdateParticipant',
    OPTIONAL: 'UpdateParticipant/Optional',
    CONTRIBUTION: 'UpdateParticipant/ContributionElection',
    INVESTMENT: 'UpdateParticipant/ContributionInvestment',
    CONFIRMATION: 'UpadteParticipant/Confirmation',
    CONFIRMATION_PRINT: 'UpadteParticipant/Confirmation/Print'
  }
};
