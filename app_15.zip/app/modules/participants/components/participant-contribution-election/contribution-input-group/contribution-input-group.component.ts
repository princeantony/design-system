import {
  Component,
  EventEmitter,
  forwardRef,
  Input,
  OnInit,
  Output
} from '@angular/core';
import {
  AbstractControl,
  ControlValueAccessor,
  FormControl,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidationErrors,
  Validator,
  Validators
} from '@angular/forms';

import { VoyaCurrencyDirective } from '../../../../../shared/directives/voya-currency.directive';
import { VoyaCurrencyPipe } from '../../../../../shared/pipes/voya-currency.pipe';

export const CONTRIBUTION_TYPE = {
  AMOUNT: 'Amount',
  PERCENT: 'Percent'
};

const noop = () => {};

@Component({
  selector: 'contribution-input-group',
  templateUrl: './contribution-input-group.component.html',
  styleUrls: ['./contribution-input-group.component.scss'],
  providers: [
    VoyaCurrencyDirective,
    VoyaCurrencyPipe,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => ContributionInputGroupComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => ContributionInputGroupComponent),
      multi: true
    }
  ]
})
export class ContributionInputGroupComponent
  implements OnInit, ControlValueAccessor, Validator {
  private _onTouchedCallback: (_: any) => void = noop;
  private _onChangeCallback: (_: any) => void = noop;
  private hasPercentOption = false;
  private hasAmountOption = false;
  private _value: any = '';
  @Input()
  control;
  @Input()
  placeHolderText: string;
  @Input()
  controlLabel: string;
  @Input()
  controlName: string;
  @Input()
  maxLength: number;
  @Input()
  typeOption: { value: string; displayText: string }[];
  private _controlValueType = '';
  @Input()
  set controlValueType(value: string) {
    if (value) {
      if (
        value.toLowerCase().trim() === 'amount' ||
        value.toLowerCase().trim() === 'a'
      ) {
        this._controlValueType = CONTRIBUTION_TYPE.AMOUNT;
      } else {
        this._controlValueType = CONTRIBUTION_TYPE.PERCENT;
      }
    }
  }
  get controlValueType() {
    return this._controlValueType;
  }
  @Output()
  changed = new EventEmitter<string>();

  private isLabelHidden: boolean;
  private _isRequired = true;
  @Input()
  set isRequired(value: boolean) {
    this._isRequired = value;
  }
  get isRequired(): boolean {
    return this._isRequired;
  }

  private _maxAmount = 10000000;
  @Input()
  set maxAmount(value: number) {
    this._maxAmount = value;
  }
  get maxAmount(): number {
    return this._maxAmount;
  }
  private _maxPercent = 100;
  @Input()
  set maxPercent(value: number) {
    this._maxPercent = value;
  }
  get maxPercent(): number {
    return this._maxPercent;
  }
  private _minAmount = 1;
  @Input()
  set minAmount(value: number) {
    this._minAmount = value;
  }
  get minAmount(): number {
    return this._minAmount;
  }
  private _minPercent = 1;
  @Input()
  set minPercent(value: number) {
    this._minPercent = value;
  }
  get minPercent(): number {
    return this._minPercent;
  }
  contributionType = CONTRIBUTION_TYPE;
  type: string =
    this.controlValueType.toLowerCase().trim() === 'amount' ||
    this.controlValueType.toLowerCase().trim() === 'a'
      ? this.contributionType.AMOUNT
      : this.contributionType.PERCENT;
  contributionValue = 0;
  isDropDownOpen = false;
  typeDropDownPrevValue: string;

  constructor() {}

  ngOnInit() {
    this.isLabelHidden = false;
    if (this.typeOption.length > 0) {
      this.typeOption.forEach(opt => {
        if (opt.value.toLowerCase() === 'a') {
          this.hasAmountOption = true;
        }
        if (opt.value.toLowerCase() === 'p') {
          this.hasPercentOption = true;
        }
      });
    }
    this.typeDropDownPrevValue = this.type;
  }
  // get accessor
  get value(): any {
    return this._value;
  }

  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  onTouched(event: any) {
    if (event.target.value === '') {
      this.isLabelHidden = true;
    }
    if (event.target.value !== '') {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus() {
    this.isLabelHidden = false;
  }

  writeValue(value: string): void {
    this._value = value || '';
    if (this._value.length > 0) {
      this.isLabelHidden = false;
    }
    if (this._value.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  validate(ctrl: FormControl): ValidationErrors | null {
    const validatorArray = [];

    if (this.controlValueType === CONTRIBUTION_TYPE.AMOUNT) {
      validatorArray.push(
        this.callValidateMaxAmountLimit(ctrl, this.maxAmount, this.minAmount)
      );
    }
    if (this.controlValueType === CONTRIBUTION_TYPE.PERCENT) {
      validatorArray.push(
        this.callValidateMaxPercentLimit(ctrl, this.maxPercent, this.minPercent)
      );
    }
    if (this.isRequired) {
      validatorArray.push(Validators.required);
    }
    return Validators.compose(validatorArray)(ctrl);
  }

  callValidateMaxAmountLimit(control: AbstractControl, maxAmount: number, minAmount: number) {
    return function() {
      const curValue: number = parseFloat(control.value);
      if (curValue > maxAmount) {
        return { MaxAmountExceeded: true };
      }
      if (curValue < minAmount) {
        return { MinAmountNotMet: true };
      }
      if (curValue === 0) {
        return { AmountZero: true };
      }
      return null;
    };
  }
  callValidateMaxPercentLimit(control: AbstractControl, maxPercent: number, minPercent: number) {
    return function() {
      const curValue: number = parseFloat(control.value);

      if (curValue > maxPercent) {
        return { MaxPercentExceeded: true };
      }
      if (curValue < minPercent) {
        return { MinPercentNotMet: true };
      }
      if (curValue === 0) {
        return { PercentZero: true };
      }
      return null;
    };
  }

  // validateMaxAmountLimit(control: AbstractControl, maxAmount: number) {
  //   const curValue: number = parseFloat(control.value);
  //   if (curValue > maxAmount) {
  //     return { MaxAmountExceeded: true };
  //   }
  //   return null;
  // }
  // validateMaxPercentLimit(control: AbstractControl, maxPercent: number) {
  //   const curValue: number = parseFloat(control.value);
  //   if (curValue > maxPercent) {
  //     return { MaxPercentExceeded: true };
  //   }
  //   return null;
  // }

  toggleDropDown() {
    this.isDropDownOpen = !this.isDropDownOpen;
  }

  onTypeChange(value) {
    this.isDropDownOpen = !this.isDropDownOpen;
    if (value !== this.typeDropDownPrevValue) {
      this.typeDropDownPrevValue = value;
      this.type = value;
      this.changed.emit(this.type);
    }
  }
}
