import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantInvestmentElectionComponent } from './participant-investment-election.component';

describe('ParticipantInvestmentElectionComponent', () => {
  let component: ParticipantInvestmentElectionComponent;
  let fixture: ComponentFixture<ParticipantInvestmentElectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantInvestmentElectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantInvestmentElectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
