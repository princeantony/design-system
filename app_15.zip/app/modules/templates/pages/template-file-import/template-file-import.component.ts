import { Component, OnInit } from '@angular/core';
import { importMapping } from 'src/app/shared/config/template.config';

import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { Router } from '../../../../../../node_modules/@angular/router';
import { APP_CONST, ENV, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { TemplatesService } from '../../services/templates.service';

@Component({
  selector: 'app-template-file-import',
  templateUrl: './template-file-import.component.html',
  styleUrls: ['./template-file-import.component.scss']
})
export class TemplateFileImportComponent implements OnInit {
  importFileItems: any;
  hidePageTitle = false;
  pageTitle: string;
  planNumber: string;
  showUpload = false;
  sampleFileUrl: string;
  file: any;
  fileName: string;
  importType: string;
  fileType: string;
  fileImportForm = this.fb.group({
    importFile: ['no']
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private templateService: TemplatesService
  ) {}

  ngOnInit() {
    this.importFileItems = [
      { label: 'Yes', value: 'yes' },
      { label: 'No', value: 'no' }
    ];

    this.planNumber = PayAdminGlobalState.planNumber;
    this.importType = PayAdminGlobalState.importType;
    console.log('---------import mapping', importMapping);
    this.sampleFileUrl = importMapping[this.importType]['fileUrl'];
    this.pageTitle = SUB_TITLE.FILE_IMPORT;
  }

  gotoBack() {}

  checkUpload(e: any) {
    console.log('----event', e);
    this.file = e.target.files;
    if (this.file.length > 0) {
      this.fileName = this.file[0].name;
    }
  }
  showUploadFile(e: any) {
    if (this.fileImportForm.value.importFile === 'yes') {
      this.showUpload = true;
    } else {
      this.showUpload = false;
    }
  }

  onSubmit() {
    console.log('-----form', this.file);
    const importFileValue = this.fileImportForm.value.importFile;
    if (importFileValue === 'yes') {
      const fileList: FileList = this.file;
      if (fileList.length > 0) {
        const file: File = fileList[0];
        const fileNameSplit = file.name.split('.');

        const formData: FormData = new FormData();
        PayAdminGlobalState.importFileType =
          fileNameSplit[fileNameSplit.length - 1];
        console.log(
          '---PayAdminGlobalState.importFileData.fileType',
          PayAdminGlobalState.importFileType
        );
        formData.append('fileName', file, file.name);
         formData.append('fileType', PayAdminGlobalState.importFileType);
         formData.append('importType', this.importType);
        if (ENV.TEST) {
          this.templateService.mockuploadFile().subscribe(
            response => {
              if (response.status === APP_CONST.SUCCESS) {
                PayAdminGlobalState.importFileData = response.data.fileData;
                this.router.navigate(['/template/select']);
              }

              console.log('------response', response);
            },
            err => {
              console.log('Error', err);
            }
          );
        } else {
          this.templateService
            .uploadFile(formData, this.planNumber, PayAdminGlobalState.importFileType, this.importType)
            .subscribe(
              response => {
                console.log('------response', response);
                if (response.status === APP_CONST.SUCCESS) {
                  PayAdminGlobalState.importFileData = response.data.fileData;
                  this.router.navigate(['/template/select']);
                }
              },
              err => {
                console.log('Error', err);
              }
            );
        }
      }
    } else {
      this.router.navigate(['/participant']);
    }
  }
}
