import { Component, OnInit } from '@angular/core';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';

import { ActivatedRoute, Router } from '@angular/router';
import { PayAdminGlobalState } from '../../shared/store/pay-admin-global.store';
import { APP_CONST } from '../../shared/constants/app.constants';
import { ReportService } from './report.service';
import { FormControl, FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html'
})
export class PayAdminReportComponent implements OnInit {
  reportColumns: any;
  reportData: any;
  reportNames: any;
  reportForm: any;
  reportHeadings: any;
  reportDetails: any;
  style;
  rowStyle;
  constructor(
private reportService: ReportService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private fb: FormBuilder
  ) {
    this.reportColumns = '';
    this.style = { width: '93%' };
    this.rowStyle = { color: '#333333' }; // to be moved to css
  }
  ngOnInit() {
    this.reportForm = this.fb.group({
      reportList: new FormControl()}
    )
    this.getReportNames();
    this.getReport();
  }

  getReportNames(): void {
    this.spinner.show();
    this.reportService.getReportNames(PayAdminGlobalState.planNumber).subscribe(
      names => {
        if (names.status === APP_CONST.SUCCESS) {
          this.reportNames = names.data;
          console.log(this.reportNames,names.data )
          this.spinner.hide();
        } else {
          console.log('Error in report name', names);
          this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }

  getReport(): void {
    this.reportService.getReport(PayAdminGlobalState.planNumber).subscribe(
      report => {
        this.spinner.hide();
        if (report.status === APP_CONST.SUCCESS) {
          this.reportData = report.data.content;
          this.reportHeadings = report.data.headers;
          this.reportDetails = {
                          'planName': report.data.planName,
                          'runDa  te': report.data.runDate,
                          'runTime': report.data.runTime,
                          'attention': report.data.attention,
                          'reportName': report.data.reportName};
          console.log('reportData', this.reportData);
          console.log('reportHeadings', this.reportHeadings);
          console.log(' reportDetails', this.reportDetails);
          this.createGridHeadings();
        } else {
          console.log('Error in report reportData', report);
                  this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }
  createGridHeadings()
  {
    //const newobj = _.merge(this.reportHeadings, this.reportData);
   // console.log(newobj,'newobj')
    this.reportHeadings.forEach(heading => {
      console.log('headings', _.map(this.reportData, heading.id));
    });

      const gridSize =  { width: 555, height: 800 };
      // const abc  =
      //   newobj.forEach(item=> {
      //     console.log(item.name)
      //   //  return { headerName: item.name}
      //   });

      // console.log(abc, 'COLUMN_DEFS');
    }


}
