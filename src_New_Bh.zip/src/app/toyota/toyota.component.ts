import { Component, OnInit, Input , ChangeDetectorRef} from '@angular/core';
import { ActivatedRoute, RouterModule, Routes } from '@angular/router';
import { GridServiceService } from '../grid-service.service';
@Component({
  selector: 'app-toyota',
  templateUrl: './toyota.component.html',
  styleUrls: ['./toyota.component.scss']
})
export class ToyotaComponent implements OnInit {
 data;



  constructor(private route: ActivatedRoute,private ref: ChangeDetectorRef, private gridsrvice: GridServiceService) { 
    //console.log("-----------test",this.test);
  }

  ngOnInit() {
    
    this.gridsrvice.currentData.subscribe(data => this.data = data)
    console.log("--------this.data toyota",this.data);
  }


  

}
