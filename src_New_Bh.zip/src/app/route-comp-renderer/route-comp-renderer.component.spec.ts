import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouteCompRendererComponent } from './route-comp-renderer.component';

describe('RouteCompRendererComponent', () => {
  let component: RouteCompRendererComponent;
  let fixture: ComponentFixture<RouteCompRendererComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RouteCompRendererComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RouteCompRendererComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
