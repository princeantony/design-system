import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { ToyotaComponent } from './toyota/toyota.component';
import { AppRoutingModule } from './/app-routing.module';
import { RouteCompRendererComponent } from './route-comp-renderer/route-comp-renderer.component';
import { GridComponent } from './grid/grid.component';

@NgModule({
  declarations: [
    AppComponent,
    ToyotaComponent,
    RouteCompRendererComponent,
    GridComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AgGridModule.withComponents([RouteCompRendererComponent]),
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
