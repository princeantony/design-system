import { Component, OnInit, ViewChild,ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridNg2 } from 'ag-grid-angular';
import { RouteCompRendererComponent } from '.././route-comp-renderer/route-comp-renderer.component';
import { GridServiceService } from '../grid-service.service';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss']
})
export class GridComponent  {

  @ViewChild('agGrid') agGrid:AgGridNg2;
  title = 'app';
  private frameworkComponents;
  private columnDefs;
  private rowData;
  private context;
  private gridApi;
  private gridColumnApi;
 
data;
 
constructor(private http:HttpClient, private ref: ChangeDetectorRef, private gridService: GridServiceService){
 // this.context = {componentParent:this};
  this.columnDefs = [
    {headerName: 'Make', field: 'make' , 
   //cellRendererFramework: RouteCompRendererComponent,
    cellRenderer: "routeCompRendererComponent",
    cellRendererParams: {
      inRouterLink: 'toyota',
  } 
    
    },
    {headerName: 'Model', field: 'model' ,filter: 'agTextColumnFilter'},
    {headerName: 'Price', field: 'price'}
];



//this.frameworkComponents = {routeCompRenderer: RouteCompRendererComponent};
/* autoGroupColumnDef = {
  headerName: 'Price',
  field: 'price',
  cellRenderer: 'agGroupCellRenderer',
  cellRendererParams: {
      checkbox: true
  }
}; */




  this.rowData = this.http.get('https://api.myjson.com/bins/ly7d1');
  this.context = { componentParent: this };
  this.frameworkComponents = {
    routeCompRendererComponent: RouteCompRendererComponent};

   
  
}

onGridReady(params) {
  this.gridApi = params.api;
  this.gridColumnApi = params.columnApi;

  params.api.sizeColumnsToFit();
}

methodFromParent(cell) {
  console.log("-------data", cell);
  this.data = cell;
  this.gridService.add(this.data);
  //this.change.emit(cell);
  alert("Parent Component Method from " + cell + "!");
  this.ref.markForCheck();
  
}


/* getSelectedRows() {
  const selectedNodes = this.agGrid.api.getSelectedNodes();
  console.log("-----selectedNodes",selectedNodes);
  const selectedData = selectedNodes.map( node => node.data );
  console.log("-----selectedData",selectedData);
  const selectedDataStringPresentation = selectedData.map( node => node.make + ' ' + node.model).join(', ');
  alert(`Selected nodes: ${selectedDataStringPresentation}`);
} */

}

