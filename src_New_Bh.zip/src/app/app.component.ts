import { Component, OnInit, ViewChild, Input } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
test: string = "this is the text";
  constructor() { }

  ngOnInit() {
  }

}