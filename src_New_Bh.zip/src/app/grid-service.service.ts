import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { GridComponent } from './grid/grid.component';

@Injectable({
  providedIn: 'root'
})
export class GridServiceService {
  constructor() { }

  private dataSource = new BehaviorSubject({});
  currentData = this.dataSource.asObservable();
 
  add(dataFr:Object) {
    
    this.dataSource.next(dataFr);
  }
  clear() {
    this.dataSource = null;
  }

  

  
}
