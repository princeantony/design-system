import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import _ from 'lodash';
import { CommonService } from 'src/app/shared/services/common.service';

import { PayAdminGlobalState } from '../../../store/pay-admin-global.store';

// Usage : <app-page-title pageTitle="Add/Enroll Participant"> </app-page-title>
@Component({
  selector: 'app-page-title',
  templateUrl: './page-title.component.html'
})
export class PageTitleComponent implements OnInit {
  // Start Remove these input variables these are handled in this component not required to send as input parmeter
  @Input() hidePageTitle: boolean;
  @Input() pageTitleClass: boolean;
  @Input() changePlan: boolean;
  @Input() planNumber: string;
  @Input() colorChange: boolean;
  // End Remove

  @Input() pageTitle: string;
  selectedPlan: any;
  planTitle: string;
  titleAsLink = true;
  canChangePlan = false;
  isPlanListingPage = false;
  hasPlanSelected = false;

  constructor(private router: Router, private commonService: CommonService) {}
  ngOnInit() {
    if (PayAdminGlobalState.planNumber) {
      this.planNumber = PayAdminGlobalState.planNumber;
    }

    if (this.router.url.toLowerCase().indexOf('/home') >= 0) {
      this.titleAsLink = false;
      if(PayAdminGlobalState.planListState.length > 1){
        this.canChangePlan = true;
      }
    }  else if (this.router.url.toLowerCase().indexOf('/plans') === 0) {
      this.isPlanListingPage = true;
      this.titleAsLink = (this.planNumber) ? true : false;
      this.pageTitle = 'Plan Selection';
    }

    if (this.pageTitle) {
      this.pageTitle = '- ' + this.pageTitle;
    }
    this.selectedPlan = _.find(PayAdminGlobalState.planListState, ['planNumber', this.planNumber]);
    if (this.selectedPlan) {
      this.planTitle =
        '- ' + this.selectedPlan.planNumber + '-' + this.selectedPlan.planName;
    }
  }
  navToPlans() {
    this.router.navigate(['/plans']);
  }

  navToHome() {
    this.router.navigate(['/home']);
  }
}
