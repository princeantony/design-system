import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaSelectMultiComponent } from './voya-select-multi.component';

describe('VoyaSelectComponent', () => {
  let component: VoyaSelectMultiComponent;
  let fixture: ComponentFixture<VoyaSelectMultiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [VoyaSelectMultiComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaSelectMultiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
