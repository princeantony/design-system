import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaZipComponent } from './voya-zip.component';

describe('VoyaZipComponent', () => {
  let component: VoyaZipComponent;
  let fixture: ComponentFixture<VoyaZipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaZipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaZipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
