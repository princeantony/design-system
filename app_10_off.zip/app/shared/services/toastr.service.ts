import { Injectable, NgModule } from '@angular/core';

import { catchError, retry } from 'rxjs/operators';
import { ToastsManager, ToastOptions } from 'ng6-toastr';

@Injectable({
  providedIn: "root"
})
export class ToastrService   {
  constructor(public toastr: ToastsManager) {

   }
   showSuccess(message: string, title: string) {
    this.toastr.success(message, title);
  }

  showError(message: string, title: string) {
    this.toastr.error(message, title);
  }

  showWarning(message: string, title: string) {
    this.toastr.warning(message, title);
  }

  showInfo(message: string, title: string) {
    this.toastr.info(message, title);
  }
  showCustom(message: string, title: string) {
    this.toastr.custom(message, title, {enableHTML: true});
  }
}

