import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

import { bankInfo, divSub } from '../mocks/bankInfo-mock';
import { BatchParticipantDivisionList } from '../mocks/batch-participant-division.mock';
import { BatchParticipantList } from '../mocks/batch-participant-grid.mock';
import { BatchParticipantCheckList } from '../mocks/batch-participant-update.mock';
import {
  CountryListMock,
  MockSuccessResponse,
  StateListMock
} from '../mocks/common-mock';
import {
  DataElementOptions,
  DataElementsList
} from '../mocks/data-elements.mock';
import { ListPlan } from '../mocks/listPlan';
import { ADMIN_FLAGS, HOME_FLAGS } from '../mocks/menuItems-mock';
import {
  PariticipantContributionData,
  ParticipantAdminSettingMock,
  ParticipantDivSubFilter,
  ParticipantFundData,
  ParticipantList,
  ParticipantMorningStar,
  ParticipantOptionalData,
  ParticipantOtherExpandedDivSub,
  ParticipantStatusListMock,
  UpdateParticipantRequiredData,
  ParticipantTerminationReason
} from '../mocks/participants-mock';
import {
  displayOptions,
  enrollmentStatusCode,
  investments,
  moneySources,
  planSetup,
  planSource
} from '../mocks/plan-setup.mock';
import {
  templateDetails,
  updateDataResponse
} from '../mocks/template-fixed-width';
import {
  columnList,
  saveTemplateResponse,
  templateData,
  templateOptions,
  validationDataWithErrors
} from '../mocks/template-with-error';
import { TerminationReasonList } from '../mocks/termination-reason.mock';

@Injectable({
  providedIn: 'root'
})
export class MockService {
  constructor() {}

  getCountryListMock(): Observable<any> {
    return of(CountryListMock).pipe(delay(500));
  }

  getStateListMock(): Observable<any> {
    return of(StateListMock).pipe(delay(500));
  }

  getListPlans(): Observable<any> {
    return of(ListPlan);
  }
  getHomeFlags(): Observable<any> {
    return of(HOME_FLAGS);
  }
  getBankInfo(): Observable<any> {
    return of(bankInfo);
  }
  getSubDiv(): Observable<any> {
    return of(divSub);
  }

  getparticipantListMock(): Observable<any> {
    return of(ParticipantList).pipe(delay(2000));
  }

  getUpdateParticipantRequiredData(): Observable<any> {
    return of(UpdateParticipantRequiredData).pipe(delay(2000));
  }

  getParticipantMorningStarDataMock(): Observable<any> {
    return of(ParticipantMorningStar).pipe(delay(1000));
  }

  getParticipantTerminationReason(): Observable<any> {
    return of(ParticipantTerminationReason).pipe(delay(300));
  }
  getParticipantAdminSettingMock(): Observable<any> {
    return of(ParticipantAdminSettingMock).pipe(delay(4000));
  }

  getParticipantStatusListMock(): Observable<any> {
    return of(ParticipantStatusListMock).pipe(delay(4000));
  }
  getParticipantOptionalDataFieldsMock(): Observable<any> {
    return of(ParticipantOptionalData).pipe(delay(1000));
  }
  getParticipantOtherDivSubMock(): Observable<any> {
    return of(ParticipantDivSubFilter);
  }
  getParticipantOtherExpandedDivSub(): Observable<any> {
    return of(ParticipantOtherExpandedDivSub);
  }
  getParticipantContributionDataMock(): Observable<any> {
    return of(PariticipantContributionData);
  }
  getParticipantParticipantFundData(): Observable<any> {
    return of(ParticipantFundData).pipe(delay(2000));
  }

  getAdminFlags(): Observable<any> {
    return of(ADMIN_FLAGS);
  }
  // Admin - Plansetup
  getPlanSetup(): Observable<any> {
    return of(planSetup);
  }
  getMoneySource(): Observable<any> {
    return of(moneySources);
  }
  getInvestments(): Observable<any> {
    return of(investments);
  }
  getPlanOptions(): Observable<any> {
    return of(displayOptions);
  }
  getEnrollmentList(): Observable<any> {
    return of(enrollmentStatusCode);
  }
  savePlanSetup(): Observable<any> {
    return of(MockSuccessResponse);
  }
  successMock(): Observable<any> {
    return of(MockSuccessResponse);
  }
  getPlanSource(): Observable<any> {
    return of(planSource);
  }
  // Admin Plansetup ends

  // file Import
  postWithFile(): Observable<any> {
    return of(templateData);
  }
  getTemplateOtions(): Observable<any> {
    return of(templateOptions);
  }

  getAvailableCols(): Observable<any> {
    return of(columnList);
  }
  getValidationData(): Observable<any> {
    // return of(validationData);
    return of(validationDataWithErrors);
  }
  getExistingTemplate(): Observable<any> {
    // return of(existingTemplate);
    return of(templateDetails);
  }
  doAuthenticate(): Observable<any> {
    return of(MockSuccessResponse);
  }
  getTerminationReason(): Observable<any> {
    return of(TerminationReasonList);
  }
  getDataElements(): Observable<any> {
    return of(DataElementsList);
  }
  saveTemplate() {
    return of(saveTemplateResponse);
  }
  getUpdateDataResponse() {
    return of(updateDataResponse);
  }
  getDEOptions() {
    return of(DataElementOptions);
  }
  getBatchParticipantFields(): Observable<any> {
    return of(BatchParticipantCheckList);
  }
  getBatchParticipantDivision(): Observable<any> {
    return of(BatchParticipantDivisionList);
  }
  getBatchParticipantList(): Observable<any> {
    return of(BatchParticipantList);
  }
  // report module
  getReportNames(): Observable<any> {
    return of(BatchParticipantList);
  }
  getReport(): Observable<any> {
    return of(BatchParticipantList);
  }
}
