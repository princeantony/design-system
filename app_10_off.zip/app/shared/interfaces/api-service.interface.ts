import { Observable } from 'rxjs';

export interface IApiService {
  get(apiMethod: string): Observable<any>;
  getByKey(apiMethod: string, key: string, value: string): Observable<any>;
  post(apiMethod: string, inputData: any): Observable<any>;
  put(apiMethod: string, inputData: any): Observable<any>;
  delete(apiMethod: string): Observable<any>;
}
