import { Component, OnInit } from '@angular/core';

import { Router } from '../../../../../../node_modules/@angular/router';
import { SERVICE_URL } from '../../../../shared/constants/service.constants';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';

@Component({
  selector: 'app-plan-selection',
  templateUrl: './plan-selection.component.html'
})
export class PlanSelectionComponent implements OnInit {
  planNumberStatus = false;
  constructor(private router: Router) {}
  ngOnInit() {
    PayAdminGlobalState.currentPage = SERVICE_URL.GET_LISTPLAN_URL;
    if (PayAdminGlobalState.planNumber) {
      this.planNumberStatus = true;
    }
  }
  gotoBack() {
    this.router.navigate([PayAdminGlobalState.previousPage]);

  }
}
