import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { forkJoin } from 'rxjs';
import { Option } from 'src/app/shared/models/common.model';

import { ContributionDivSubItem, ContributionOption, ContributionParameters, ContributionPreviousBatch, MoneySource } from '../../model/contributions.model';
import { ContributionsService } from '../../service/contributions.service';

@Component({
  selector: 'app-contribution-setup',
  templateUrl: './contribution-setup.component.html',
  styleUrls: ['./contribution-setup.component.scss']
})
export class ContributionSetupComponent implements OnInit {
  constructor(
    private spinner: NgxSpinnerService,
    private contributionsService: ContributionsService,
    private fb: FormBuilder
  ) {}
  private messageList: string[] = [];
  private contributionSetupForm: FormGroup;
  private contribParameter: ContributionParameters = new ContributionParameters();
  private contribOptions: ContributionOption;
  private divSubList: ContributionDivSubItem[] = [];
  private divSubOption: Option[] = [];
  private previousBatchList: ContributionPreviousBatch[] = [];
  private copyBatchOption: Option[] = [];
  private moneySourcesList: MoneySource[] = [];

  MoneySourcesFormArray: FormArray = this.fb.array([]);

  // service definitions
  displayOptions$ = this.contributionsService.getContributionOptions();
  divSubs$ = this.contributionsService.getContributionAuthDivSub();
  copyContribBatchList$ = this.contributionsService.getContributionPreviousBatchList();

  ngOnInit() {
    this.messageList = [];
    this.spinner.show();
    this.displayOptions$.subscribe(
      resOptions => {
        if (resOptions.status === 'SUCCESS') {
          this.contribOptions = resOptions.data;
          if (
            this.contribOptions.enablePayrollCopy &&
            this.contribOptions.hasDivSub
          ) {
            const fork$ = forkJoin(this.copyContribBatchList$, this.divSubs$);
            fork$.subscribe(([copyBatch, divSub]) => {
              if (copyBatch.status === 'SUCCESS') {
                this.previousBatchList = copyBatch.data;
              }
              if (divSub.status === 'SUCCESS') {
                this.divSubList = divSub.data;
              }
            });
          }
          if (
            this.contribOptions.enablePayrollCopy &&
            !this.contribOptions.hasDivSub
          ) {
            this.copyContribBatchList$.subscribe(
              copyBatch => {
                if (copyBatch.status === 'SUCCESS') {
                  this.previousBatchList = copyBatch.data;
                }
              },
              err => {}
            );
          } else if (
            !this.contribOptions.enablePayrollCopy &&
            this.contribOptions.hasDivSub
          ) {
            this.divSubs$.subscribe(
              divSub => {
                if (divSub.status === 'SUCCESS') {
                  this.divSubList = divSub.data;
                }
              },
              err => {}
            );
          }
          console.log('Options', this.contribOptions);
          console.log('divSub', this.divSubList);
          console.log('Previous Batch List', this.previousBatchList);
        } else if (resOptions.status === 'ERROR') {
          this.messageList.push(
            'Error occurred while fetching Contribution Option'
          );
        }
      },
      err => {
        console.log('Service Error - Contribution Option: ' + err);
      }
    );
    // this.initForm();
  }

  initForm() {
    this.createMoneySourcesFromArray();
    this.contributionSetupForm = this.fb.group({
      batchName: [this.contribParameter.batchName],
      payrollDate: [this.contribParameter.payrollDate],
      divsubs: [],
      allDivSubs: [this.contribParameter.allDivSubs],
      activeParticipantsOnly: [this.contribParameter.activeParticipantsOnly],
      copyPayrollKey: [this.contribParameter.copyPayrollKey],
      participantsWithContributions: [
        this.contribParameter.participantsWithContributions
      ],
      moneySources: this.MoneySourcesFormArray
    });
  }

  get MoneySourceList(): MoneySource[] {
    if (this.contribOptions) {
      this.moneySourcesList = this.contribOptions.moneySources;
    }
    return this.moneySourcesList;
  }
  createMoneySourcesFromArray() {
    // code: string; // label: string;
    this.MoneySourceList.forEach(source => {
      const controlKey: string = source.code;
      const control: FormControl = new FormControl(source.code);
      const controlGroup: FormGroup = this.fb.group({});
      controlGroup.addControl(controlKey, control);
      this.MoneySourcesFormArray.push(controlGroup);
    });
  }
  getCopyBatchList(): Option[] {
    this.previousBatchList.forEach(batch => {
      this.copyBatchOption.push({
        value: batch.value,
        displayText: batch.displayText
      });
    });
    return this.copyBatchOption;
  }
}
