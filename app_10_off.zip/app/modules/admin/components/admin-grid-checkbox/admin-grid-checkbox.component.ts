import { Component, EventEmitter, Output } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import _ from 'lodash';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';

@Component({
  selector: 'app-admin-grid-checkbox',
  templateUrl: './admin-grid-checkbox.component.html'

})
export class AdminGridCheckboxComponent  implements ICellRendererAngularComp {
  @Output() Click = new EventEmitter<boolean>();
  constructor() { }
  value: boolean;
  controlClass: string;
  controlName: string;
  isCatchUp = false;
  public params: any;
  parent: string;
    agInit(params: any): void {
      this.params = params;
        this.value = params.value;
        this.controlClass = 'small';
        this.parent = (_.has(params.data, 'deferralCatchUp') ? 'money' : 'investment');
        this.controlName = this.parent + '_' + params.colDef.field + '_' + params.rowIndex + '_' + params.data.code;
        if(params.colDef.field === 'contributionCatchUp' || params.colDef.field === 'deferralCatchUp')
        {
        this.isCatchUp = !PayAdminGlobalState.isCatchUp;
        }

    }
    onValueChange(event: any) {
      const id = _.split(event.target.id, '_');
      const gridName = id[0];
      const name = id[1];
      const index = id[2];
      const itmeCode = id[3];
      const item = {};
      item[name] = event.target.checked;
      this.params.context.componentParent.getCheckedField({rowIndex:index, fieldCode: itmeCode, fieldName: name, gridName: gridName, fieldValue: event.target.checked });
    }
    refresh(): boolean {
        return false;
    }

}
