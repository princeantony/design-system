import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-data-element-textbox',
  templateUrl: './data-element-textbox.component.html' ,
  styleUrls: ['./data-element-textbox.component.scss']
})
export class DataElementTextboxComponent implements ICellRendererAngularComp {
  constructor() { }
  public params: any;
  controlName: string;
  value: string;
  shouldShow = false;
  agInit(params: any): void {
    this.params = params;
    this.controlName = params.data.optionalElementID;
    this.value = params.value;
    if (params.data.defaultSortOrder < 999 && params.data.defaultSortOrder !== '') {
      this.shouldShow = true;
    }
  }
  isValid(event: any) {
    const order = event.target.value;
    this.params.context.componentParent.isValid(event.target.value);
  }
  onBlur(event: any) {
    const order = event.target.value;
    this.params.context.componentParent.getNewOrder(event.target.value, event.target.id);
  }
  refresh(): boolean {
    return false;
  }
}
