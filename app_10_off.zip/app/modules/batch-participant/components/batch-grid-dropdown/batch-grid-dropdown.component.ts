import { Component } from '@angular/core';
import { INoRowsOverlayAngularComp } from 'ag-grid-angular';

@Component ({
    selector: 'app-batch-grid-dropdown',
    templateUrl: './batch-grid-dropdown.component.html',
})

export class BatchGridDropdownComponent implements INoRowsOverlayAngularComp{
    constructor() { }
    private value: any;

      agInit(params: any): void {
            console.log(params.value);
            this.value = params.value;
      }

      refresh(): boolean {
        return false;
    }


}
