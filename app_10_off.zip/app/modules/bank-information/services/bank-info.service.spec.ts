import { TestBed, inject } from '@angular/core/testing';

import { BankInfoService } from './bank-info.service';

describe('BankInfoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BankInfoService]
    });
  });

  it('should be created', inject([BankInfoService], (service: BankInfoService) => {
    expect(service).toBeTruthy();
  }));
});
