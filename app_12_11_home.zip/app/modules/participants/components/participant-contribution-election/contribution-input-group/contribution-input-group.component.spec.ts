import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContributionInputGroupComponent } from './contribution-input-group.component';

describe('ContributionInputGroupComponent', () => {
  let component: ContributionInputGroupComponent;
  let fixture: ComponentFixture<ContributionInputGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContributionInputGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContributionInputGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
