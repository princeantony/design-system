// import 'ag-grid-enterprise';
import { Component, Input, OnInit, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { CellEditingStartedEvent, CellValueChangedEvent } from 'ag-grid';
import { ColDef, GridOptions } from 'ag-grid-community';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
import { isEmptyObject } from 'src/app/shared/utils/pay-admin.utils';

import { NumericEditorComponent } from '../../../../shared/components/ag-grid/editor/numeric-editor/numeric-editor.component';
import { IParticipantFundSources, ParticipantFundSource, ParticipantFundSourceItem } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';

@Component({
  selector: 'participant-investment-election',
  templateUrl: './participant-investment-election.component.html',
  styleUrls: ['./participant-investment-election.component.scss']
})
export class ParticipantInvestmentElectionComponent implements OnInit {
  private participantFundSources: IParticipantFundSources = {} as IParticipantFundSources;
  private aggFuncs;
  private gridApi;
  private messageList: string[] = [];

  private _editMode = false;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }

  prevValue: string;

  public gridOptions: GridOptions;
  private isFormValid = false;

  constructor(
    private previousRouteService: PreviousRouteService,
    private participantsService: ParticipantsService,
    private router: Router,
    public toastr: ToastsManager,
    private spinner: NgxSpinnerService,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }
  ngOnInit() {
    this.messageList = [];
    this.spinner.show();
    if (
      isEmptyObject(
        ParticipantStore.ParticipantData.participantContributionInvestmentData
      )
    ) {
      this.participantsService
        .getParticipantParticipantFundData$(
          ParticipantStore.ParticipantData.requiredData.ssn,
          ParticipantStore.ParticipantData.requiredData.birthDate,
          ParticipantStore.InvestmentElectionSources.join(','),
          ParticipantStore.ParticipantData.participantContribution.sameAsSource
        )
        .subscribe(
          result => {
            if (result.status === 'SUCCESS') {
              console.log('Fund Source', this.participantFundSources);

              this.participantFundSources = ParticipantStore.ParticipantData.participantContributionInvestmentData =
                result.data;
              this.initForm();
            }
          },
          err => {
            this.messageList.push(
              'Error occurred while fetching Investment Elections.'
            );
            console.log(err);
          }
        );
    } else {
      this.participantFundSources =
        ParticipantStore.ParticipantData.participantContributionInvestmentData;
      this.initForm();
    }
  }

  initForm() {
    if (
      this.participantFundSources.sourceMap.length > 0 &&
      this.participantFundSources.fundSources.length > 0
    ) {
      this.gridOptions = <GridOptions>{
        rowData: this.createRowData(),
        columnDefs: this.createColumnDefs(),
        groupIncludeFooter: true,
        floatingFilter: true,
        // aggFuncs: this.aggFuncs,
        context: { componentParent: this },

        frameworkComponents: {
          numericEditorComponent: NumericEditorComponent
        },
        rowHeight: 32,
        singleClickEdit: true,
        stopEditingWhenGridLosesFocus: true
      };
      this.aggFuncs = {
        sum: this.sumFunction
      };
      this.spinner.hide();
    } else {
      this.messageList.push(
        'No investment elections found for the Participant'
      );
    }
  }

  oncellEditingStarted(event: CellEditingStartedEvent) {
    const field = event.colDef.field;
    const newValue = event.value;
    const rowIndex = event.rowIndex;
    this.prevValue = event.value;
    if (rowIndex === this.gridApi.getDisplayedRowCount()) {
      this.gridApi.stopEditing();
    }
    if (
      this.participantFundSources.fundSources[rowIndex].percents[
        this.participantFundSources.fundSources[rowIndex].percents.findIndex(
          item => item.sourceId === field
        )
      ].readOnly
    ) {
      this.gridOptions.api.stopEditing();
    }
  }

  onCellEditingStopped(event) {
    const result = this.sumFunction(event.colDef.field);
    if (Number(result) <= 100) {
      console.log('--------gridapi', this.gridApi);
      const rowNode = this.gridApi.getRowNode(
        this.gridApi.getDisplayedRowCount() - 1
      );
      rowNode.setDataValue(event.colDef.field, result);
    } else {
      this.toastr.error(
        'Election Percentages total cannot be more than 100%',
        'Validation!',
        { showCloseButton: true }
      );
      event.node.setDataValue(event.colDef.field, this.prevValue);
    }
  }

  onCellValueChanged(event: CellValueChangedEvent) {
    const field = event.colDef.field;
    const newValue = event.value;
    const rowIndex = event.rowIndex;

    if (rowIndex + 1 !== this.gridApi.getDisplayedRowCount()) {
      this.participantFundSources.fundSources[rowIndex].percents[
        this.participantFundSources.fundSources[rowIndex].percents.findIndex(
          item => item.sourceId === field
        )
      ].currentPercent = newValue;
    }
  }
  createColumnDefs() {
    const columnsList = this.participantFundSources.sourceMap;
    const gridColumns: ColDef[] = [];

    // Create First Default FundNameColumn
    gridColumns.push({
      field: 'fundName',
      headerName: 'Fund Name',
      editable: false
    });
    // Push one column for each Source item
    if (columnsList) {
      columnsList.forEach(column => {
        gridColumns.push({
          field: column.sourceId,
          headerName: column.sourceName,
          suppressFilter: true,
          editable: true,
          cellEditor: 'numericEditorComponent',
          valueFormatter: function percentFormatter(params) {
            return params.value + ' %';
          },
          cellClass: 'number-cell'
        });
      });
    }

    return gridColumns;
  }
  createRowData() {
    const fundSources: ParticipantFundSource[] = this.participantFundSources
      .fundSources;
    const rows = [];
    if (fundSources) {
      fundSources.forEach(fundSrc => {
        const rowItem = Object.assign({ fundName: fundSrc.fundName });
        const sources: ParticipantFundSourceItem[] = fundSrc.percents;

        sources.forEach((src: ParticipantFundSourceItem) => {
          Object.assign(rowItem, { [src.sourceId]: src.currentPercent });
        });
        rows.push(rowItem);
      });
    }
    return rows;
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit();
    this.gridApi = params.api;
    const colDefs = this.gridApi.gridOptionsWrapper.gridOptions.columnDefs;
    const totalRow = {};
    colDefs.forEach(colDef => {
      if (colDef.field === 'fundName') {
        totalRow['fundName'] = 'Total';
      } else {
        totalRow[colDef.field] = this.sumFunction(colDef.field);
        if (this.sumFunction(colDef.field) === 100) {
          this.isFormValid = true;
        } else {
          this.isFormValid = false;
        }
      }
    });
    params.api.updateRowData({
      add: [totalRow]
    });
  }
  sumFunction(column) {
    let result = 0;
    console.log('--rowdata', this.gridOptions.rowData);
    this.gridOptions.rowData.forEach(function(element) {
      result += Number(element[column]);
    });
    return result;
  }
  onNextClick() {
    if (this.participantFundSources.fundSources) {
      this.participantFundSources.fundSources.forEach(fundSrc => {
        this.participantFundSources.sourceMap.forEach(source => {
          const sourceID = source.sourceId;
          _.find(
            fundSrc.percents,
            ['sourceId', source.sourceId]
          ).currentPercent = _.find(this.gridOptions.rowData, [
            'fundName',
            fundSrc.fundName
          ])[sourceID];
        });
      });
    }
    ParticipantStore.ParticipantData.participantContributionInvestmentData = this.participantFundSources;

    console.log('Fund Source Submitted', this.participantFundSources);

    if (this.EditMode) {
      this.router.navigate(['UpadteParticipant/Confirmation']);
    } else {
      this.router.navigate(['addParticipant/Confirmation']);
    }
  }

  onBackClick() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
}
