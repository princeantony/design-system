import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-admin-plan-copy-modal',
  templateUrl: './admin-plan-copy-modal.component.html',
  styleUrls: ['./admin-plan-copy-modal.component.scss']
})
export class AdminPlanCopyModalComponent implements OnInit {
  @Output()
  continue = new EventEmitter<any>();

  constructor(private modalservice: ModalService) {}

  ngOnInit() {}
  continueTo(id) {
    this.modalservice.close(id);
    this.continue.emit();

  }
  closeModal(id) {
    this.modalservice.close(id);
  }
}
