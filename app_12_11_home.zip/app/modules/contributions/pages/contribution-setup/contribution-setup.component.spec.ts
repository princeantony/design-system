import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContributionSetupComponent } from './contribution-setup.component';

describe('ContributionSetupComponent', () => {
  let component: ContributionSetupComponent;
  let fixture: ComponentFixture<ContributionSetupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContributionSetupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContributionSetupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
