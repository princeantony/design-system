import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';

import { ContributionsMockService } from './contributions-mock.service';

@Injectable({
  providedIn: 'root'
})
export class ContributionsService {
  constructor(private contributionsMockService: ContributionsMockService) {}

  getContributionOptions(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.getContributionOptions();
    } else {
      return this.contributionsMockService.getContributionOptions();
    }
  }

  getContributionAuthDivSub(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.getContributionAuthDivSub();
    } else {
      return this.contributionsMockService.getContributionAuthDivSub();
    }
  }
  getContributionGridData(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.getContributionGridData();
    } else {
      return this.contributionsMockService.getContributionGridData();
    }
  }
  UpdateContributionBatchInfo(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.UpdateContributionBatchInfo();
    } else {
    }
  }
  getContributionPreviousBatchList(): Observable<any> {
    if (ENV.TEST) {
      return this.contributionsMockService.getContributionPreviousBatchList();
    } else {
      return this.contributionsMockService.getContributionPreviousBatchList();
    }
  }
}
