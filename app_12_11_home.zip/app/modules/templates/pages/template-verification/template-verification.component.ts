import { Component, OnInit } from '@angular/core';
import { importMapping } from 'src/app/shared/config/template.config';
import { ENV, SUB_TITLE } from 'src/app/shared/constants/app.constants';
import { validationData } from 'src/app/shared/mocks/template-with-error';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { TemplatesService } from '../../services/templates.service';

@Component({
  selector: 'app-template-verification',
  templateUrl: './template-verification.component.html',
  styleUrls: ['./template-verification.component.scss']
})
export class TemplateVerificationComponent implements OnInit {
  hidePageTitle = false;
  planNumber: string;
  pageTitle: string;
  rowData: any;
  defaultColDef: any;
  columnDefs = [];
  gridApi: any;
  importType: string;

  constructor(private templateService: TemplatesService) {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.pageTitle = SUB_TITLE.ENROLLMENT_AUDIT;
    this.importType = PayAdminGlobalState.importType;
    if (ENV.TEST) {
      this.rowData = validationData.data.fileData;
      this.columnDefs = this.columnDefs = PayAdminGlobalState.importColumns; /* [
        { field: 'ssn', headerName: 'SSN' },
        { field: 'firstName', headerName: 'First Name' },
        { field: 'lastName', headerName: 'Last Name' }
      ]; */
      this.defaultColDef = { editable: true };
    } else {
      this.rowData = PayAdminGlobalState.importFileData;
      this.columnDefs = PayAdminGlobalState.importColumns;
      console.log('--------filedata', PayAdminGlobalState.importFileData);
      console.log('----------------columnDefs', this.columnDefs);
      this.defaultColDef = { editable: true };
    }

    // const colHeaders = _.keys(this.rowData[0]);
  }

  onGridReady(params) {
    this.gridApi = params.api;
  }

  finish() {
    console.log('-----this api', this.gridApi);
    this.gridApi.stopEditing();
    const fileData = {
      fileData: this.rowData
    };
    const url = importMapping[this.importType]['serviceUrl'];
    this.templateService.confirmData(url, this.planNumber, fileData).subscribe(response => {
      console.log(response);
    },
    err => {
      console.log('Error', err);
    });
  }
}
