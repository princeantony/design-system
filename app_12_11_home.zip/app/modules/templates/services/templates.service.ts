import { Injectable } from '@angular/core';

import { Observable } from '../../../../../node_modules/rxjs';
import { MockService } from '../../../shared/services/mock.service';
import { SERVICE_URL } from './../../../shared/constants/service.constants';
import { ApiService } from './../../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class TemplatesService {
  constructor(
    private apiService: ApiService,
    private mockService: MockService
  ) {}
  mockuploadFile(): Observable<any> {
    return this.mockService.postWithFile();
  }

  uploadFile(
    formData: FormData,
    planNumber: string,
    fileType: string,
    importType: string
  ): Observable<any> {
    return this.apiService.postWithFile(
      SERVICE_URL.FILE_IMPORT.replace('{planId}', planNumber)
        .replace('{fileType}', fileType)
        .replace('{importType}', importType),
      formData
    );
    /* return this.apiService.postWithFile(
      SERVICE_URL.FILEIMPORT_MAIN + planNumber + 'file',
      formData
    ); */
  }

  getMockTemplateOptions(): Observable<any> {
    return this.mockService.getTemplateOtions();
  }
  getTemplateOptions(
    planNumber: string,
    fileType: string,
    importType: string
  ): Observable<any> {
    return this.apiService.get(
      // SERVICE_URL.GET_TEMPLATE_OPTIONS + planNumber + '/filetype/' + fileType
      // 'common/import/plan/40311K/fileType/FXW/importType/E/templates'

      SERVICE_URL.GET_TEMPLATE_OPTIONS.replace('{planId}', planNumber)
        .replace('{fileType}', fileType)
        .replace('{importType}', importType)
    );
  }
  deleteTemplate(planNumber: string, templateObj: any): Observable<any> {
    return this.apiService.deleteByObject(
      SERVICE_URL.DELETE_TEMPLATE_DELETE.replace('{planId}', planNumber),
      templateObj
    );
  }

  getAvailableColsMock(planNumber: string, type: string): Observable<any> {
    return this.mockService.getAvailableCols();
  }
  getAvailableCols(planNumber: string, importType: string): Observable<any> {
    return this.apiService.get(
      SERVICE_URL.GET_AVAILABLE_COLUMNS.replace('{planId}', planNumber).replace(
        '{importType}',
        importType
      )
    );
  }

  saveTemplate(planId: string, templateData: any): Observable<any> {
    return this.apiService.put(
      SERVICE_URL.PUT_SAVE_TEMPLATE.replace('{planId}', planId),
      templateData
    );
  }
  saveMockTemplate() {
    return this.mockService.saveTemplate();
  }

  validateMockFileData(): Observable<any> {
    return this.mockService.getValidationData();
  }
  validateFileData(url: string, planNumber: string, fileData: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_VALIDATE_FILEDATA.replace('{module}', url).replace('{planId}', planNumber),
      fileData
    );
  }
  getMockTemplateDetails(): Observable<any> {
    return this.mockService.getExistingTemplate();
  }
  getTemplateDetails(
    planNumber: string,
    templateId: string,
    importType: string,
    fileType: string
  ): Observable<any> {
    return this.apiService.get(
      SERVICE_URL.GET_TEMPLATE_DETAILS.replace('{planId}', planNumber)
        .replace('{templateId}', templateId)
        .replace('{importType}', importType)
        .replace('{fileType}', fileType)
    );
  }
  confirmData(url: string, planNumber: string, fileData: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_CONFIRM_DATA.replace('{module}', url).replace('{planId}', planNumber),
      fileData
    );
  }
  mockUpdateData(): Observable<any> {
    return this.mockService.getUpdateDataResponse();
  }
  updateData(planNumber: string, templateMapping: any): Observable<any> {
    return this.apiService.post(SERVICE_URL.POST_CONFIRM_DATA.replace('{planId}', planNumber), templateMapping);
  }
}
