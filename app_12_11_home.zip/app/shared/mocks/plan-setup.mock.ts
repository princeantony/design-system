export const planSetup = {
  'status': 'SUCCESS',
  'data':
  {
    'loanMatching': true,
    'copyPayroll': false,
    'disActPartWContrib': true,
    'loanPayoffs': false,
    'leaveOfAbsence': false,
    'submitBatchesInAdvance': false,
    'crossCalendarPayroll': false,
    'negativeContrib': false,
    'nonACH': false,
    'nameChange': false,
    'reportsFolder': 'Default',
    'lastChangedBy': 'Default',
    'pinLength': '',
    'RSD':false,
    'enrollment': '',
    'divSubFunc': 'Default',
    'catchupSrcs':'CP1',
    'catchUp': 'N',
    'participantUpdate': 'N',
    'emailDE': 'VR151',
    'enrollmentStatusCode': '',
    'maskSSN': '999999999',
    'customMask': '',
    'moneySources':[
      {
        'code': '100',
        'shortNameOverride':'anonty',
        'exclude': false,
        'limit': true,
        'contributionCatchUp': false,
        'deferralCatchUp': false,
        'forfeitureAccountFrom': false,
        'forfeitureAccountTo': false,
        'prefundedAccountFrom': false,
        'prefundedAccountTo': false,
        'rothSource': false,
        'preTaxSource': false
      },
      {
        'code': '101',
       'shortNameOverride':'prince',
        'exclude': false,
        'limit': false,
        'contributionCatchUp': true,
        'deferralCatchUp': false,
        'forfeitureAccountFrom': false,
        'forfeitureAccountTo': true,
        'prefundedAccountFrom': false,
        'prefundedAccountTo': false,
        'rothSource': false,
        'preTaxSource': true

      },
      {
        'code': '102',
       'shortNameOverride':'prince',
        'exclude': false,
        'limit': false,
        'contributionCatchUp': true,
        'deferralCatchUp': false,
        'forfeitureAccountFrom': false,
        'forfeitureAccountTo': true,
        'prefundedAccountFrom': false,
        'prefundedAccountTo': false,
        'rothSource': true,
        'preTaxSource': false
      },
      {
        'code': '103',
       'shortNameOverride':'prince',
        'exclude': false,
        'limit': false,
        'contributionCatchUp': true,
        'deferralCatchUp': false,
        'forfeitureAccountFrom': false,
        'forfeitureAccountTo': true,
        'prefundedAccountFrom': false,
        'prefundedAccountTo': false,
        'rothSource': true,
        'preTaxSource': false
      },
      {
        'code': '104',
       'shortNameOverride':'prince',
        'exclude': false,
        'limit': false,
        'contributionCatchUp': true,
        'deferralCatchUp': false,
        'forfeitureAccountFrom': false,
        'forfeitureAccountTo': true,
        'prefundedAccountFrom': false,
        'prefundedAccountTo': false,
        'rothSource': false,
        'preTaxSource': true
      }
    ],
    'investments':[
      {
        'code': '200',
        'longNameOverride': 'Default1',
        'exclude': false
      },
      {
        'code': '201',
        'longNameOverride': 'Default2',
        'exclude': true
      },
      {
        'code': '202',
        'longNameOverride': 'Default3',
        'exclude': false
      }
    ]
  }
  }


  export const moneySources = {
      'status': 'SUCCESS',
      'data': [
      {
        'code': '100',
        'longName': 'Default1',
        'shortName': 'PA'
      },
      {
        'code': '101',
        'longName': 'Default2',
        'shortName': 'AP'
      },
      {
        'code': '102',
        'longName': 'Default3',
        'shortName': 'AP1'
      },
      {
        'code': '103',
        'longName': 'Default4',
        'shortName': 'AP2'
      },
      {
        'code': '104',
        'longName': 'Default',
        'shortName': 'AP3'
      }
    ]
    }

  export const investments = {
    'status': 'SUCCESS',

      'data': [
      {
        'code': '200',
        'longName': 'Default11'
      },
      {
        'code': '201',
        'longName': 'Default22'
      },
      {
        'code': '202',
        'longName': 'Default33'
      }
    ]
  }

  export const enrollmentStatusCode = {
      'status': 'SUCCESS',
      'data': [
        {
          'displayText': 'Default1',
          'statusCode': '101'
        },
        {
          'displayText': 'Default2',
          'statusCode': '201'
        }
      ]
  }

  export const displayOptions = {
      'status': 'SUCCESS',
      'data': {
          'rsd' : true,
          'showCatchUpOptions': true,
          'showDropdown': false,
          'showLOA': true,
          'showPartUpdateOptions': false
      }
  }

   export const planSource =
  {
      'status': 'SUCCESS',
      'data': [
          {
              'code': '101',
              'rothSource': false,
              'preTaxSource': false
          },
          {
              'code': '102',
              'rothSource': true,
              'preTaxSource': false
          },
          {
              'code': '103',
              'rothSource': false,
              'preTaxSource': true
          },
          {
              'code': '104',
              'rothSource': true,
              'preTaxSource': true
          },
          {
              'code': '104',
              'rothSource': false,
              'preTaxSource': false
          }

      ]
  }


