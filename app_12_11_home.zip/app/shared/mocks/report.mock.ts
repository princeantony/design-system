export const reportNames = {
  'status': 'SUCCESS',
  'data':[
     {
          'fileName': 'FBAK20120831-211851',
          'reportDate': '20120831'
      },
      {
          'fileName': 'FBAK20120914-210327',
          'reportDate': '20120914'
      },
      {
          'fileName': 'FBAK20120928-220817',
          'reportDate': '20120928'
      },
      {
          'fileName': 'FBAK20121012-213427',
          'reportDate': '20121012'
      },
      {
          'fileName': 'FBAK20121026-214734',
          'reportDate': '20121026'
      },
      {
          'fileName': 'FBAK20121109-221903',
          'reportDate': '20121109'
      },
      {
          'fileName': 'FBAK20121123-215141',
          'reportDate': '20121123'
      },
      {
          'fileName': 'FBAK20121207-223842',
          'reportDate': '20121207'
      },
      {
          'fileName': 'FBAK20121221-212334',
          'reportDate': '20121221'
      },
      {
          'fileName': 'FBAK20130104-211424',
          'reportDate': '20130104'
      },
      {
          'fileName': 'FBAK20130118-212842',
          'reportDate': '20130118'
      },
      {
          'fileName': 'FBAK20130201-211612',
          'reportDate': '20130201'
      },
      {
          'fileName': 'FBAK20130215-215613',
          'reportDate': '20130215'
      },
      {
          'fileName': 'FBAK20130301-214820',
          'reportDate': '20130301'
      },
      {
          'fileName': 'FBAK20130315-210414',
          'reportDate': '20130315'
      },
      {
          'fileName': 'FBAK20130328-230333',
          'reportDate': '20130328'
      },
      {
          'fileName': 'FBAK20151015-135548',
          'reportDate': '20151015'
      },
      {
          'fileName': 'FBAK20160106-124657',
          'reportDate': '20160106'
      },
      {
          'fileName': 'FBAK20160106-135825',
          'reportDate': '20160106'
      }
  ]
};
export const reportDetils = {
  'status': 'SUCCESS',
  'data': {
      'planName': 'HIGHLAND TELEPHONE COOPERATIVE,',
      'runDate': '01/06/2016',
      'runTime': '12:46:57',
      'attention': '',
      'reportName': 'Bi-Weekly Deferral Change Report',
      'content': [
          {
              'eligibledate': '20140101',
              'partid': '009468266',
              'catchup': '000.00',
              'name': 'FILLION-DP,    MELVIN',
              'beforetax': '06.00',
              'aftertax': '00.00'
          },
          {
              'eligibledate': '20150801',
              'partid': '009583274',
              'catchup': '000.00',
              'name': 'MARCHESE-DP,   IDELL',
              'beforetax': '03.00',
              'aftertax': '05.00'
          },
          {
              'eligibledate': '20130301',
              'partid': '009624396',
              'catchup': '000.00',
              'name': 'BELGRAVE-DP,   ELLI',
              'beforetax': '02.00',
              'aftertax': '09.00'
          },
          {
              'eligibledate': '20140201',
              'partid': '009920123',
              'catchup': '100.00',
              'name': 'DUNN-DP,       REYES',
              'beforetax': '02.00',
              'aftertax': '00.00'
          },
          {
              'eligibledate': '00000000',
              'partid': '010387157',
              'catchup': '004.00',
              'name': 'BRACKEN-DP,    LUCIANO',
              'beforetax': '03.00',
              'aftertax': '00.00'
          },
          {
              'eligibledate': '20140501',
              'partid': '010589577',
              'catchup': '015.00',
              'name': 'KUTZ-DP,       ROBERT',
              'beforetax': '02.00',
              'aftertax': '20.00'
          },
          {
              'eligibledate': '20151101',
              'partid': '010686730',
              'catchup': '002.00',
              'name': 'BRENDEL-DP,    MERLE',
              'beforetax': '15.00',
              'aftertax': '10.00'
          }
      ],
      'headers': [
          {
              'id': 'name',
              'name': 'Name'
          },
          {
              'id': 'partid',
              'name': 'Part Id'
          },
          {
              'id': 'eligibledate',
              'name': 'Eligibility Date'
          },
          {
              'id': 'beforetax',
              'name': 'Before Tax %'
          },
          {
              'id': 'aftertax',
              'name': 'After Tax %'
          },
          {
              'id': 'catchup',
              'name': 'Catchup %'
          }
      ]
  }
};

