import { IMenuItem } from '../interfaces/menu-item.interface';

export const HomeMenuItems: IMenuItem[] = [
  {
    key: 'addEnrollmentPageActive',
    menuHeading: 'Add/Enroll',
    menuSubheading: 'Add/Enroll Participant',
    menuIcon: 'addenroll.svg',
    linkTo: 'participant',
    id: 'addenroll'
  },
  {
    key: 'participantUpdatePageActive',
    menuHeading: 'Participant Update',
    menuSubheading: 'View/Update participant information',
    menuIcon: 'participantupdate.svg',
    linkTo:  'participantUpdateSearch',
    id: 'participantUpdateSearch'
  },
  {
    key: 'batchParticipantUpdatePageActive',
    menuHeading: 'Batch Participant Update',
    menuSubheading: 'Update multiple participants',
    menuIcon: 'batchparticipantupdate.svg',
    linkTo: 'updateBatchParticipant',
    id: 'updateParticipant'
  },
  {
    key: 'contributionPageActive',
    menuHeading: 'Contributions',
    menuSubheading: 'Process contributions to accounts',
    menuIcon: 'contributions.svg',
    linkTo: 'Contribution/Setup',
    id: 'contributions'
  },
  {
    key: 'pendingBatchPageActive',
    menuHeading: 'Pending/Submitted Batches',
    menuSubheading: 'Review batch information',
    menuIcon: 'pendingsubmittedbatches.svg',
    linkTo: 'bankinfo',
    id: 'pendingsubmittedbatches'
  },
  {
    key: 'loanRepaymentPageActive',
    menuHeading: 'Loan Repayment',
    menuSubheading: 'Process loan repayments',
    menuIcon: 'loanrepayment.svg',
    linkTo: 'bankinfo',
    id: 'loanrepayment'
  },
  {
    key: 'bankInfoPageActive',
    menuHeading: 'Bank Information',
    menuSubheading: 'Add or update assigned bank',
    menuIcon: 'bankinformation.svg',
    linkTo: 'bankInfo',
    id: 'bankInfo'
  },
  {
    key: 'adminPageActive',
    menuHeading: 'Administration',
    menuSubheading: 'Review and update your settings',
    menuIcon: 'general-administration.svg',
    linkTo: 'admin',
    id: 'admin'
  },
  {
    key: 'reportsPageActive',
    menuHeading: 'Reports',
    menuSubheading: 'Review generated reports',
    menuIcon: 'report.svg',
    linkTo: 'report',
    id: 'report'
  }
];
export const importActiveConfig = {
  'addEnrollmentPageActive' : 'addEnrollmentImportPageActive',
  'batchParticipantUpdatePageActive': 'batchParticipantUpdateImportPageActive',
  'contributionPageActive': 'contribImportPageActive',
  'loanRepaymentPageActive': 'loanImportPageActive'

};





