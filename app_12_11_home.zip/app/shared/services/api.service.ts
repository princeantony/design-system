import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { SERVICE_URL } from '../../shared/constants/service.constants';
import { IApiService } from '../interfaces/api-service.interface';

// import { HandleError } from './http-error-handler.service';

@Injectable()
export class ApiService implements IApiService {
  appUrl = SERVICE_URL.APP_URL;

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'my-auth-token'
    })
  };
  private multipartHttpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'multipart/form-data',
      Authorization: 'my-auth-token'
      // 'Access-Control-Allow-Origin': '*'
    })
  };
  constructor(private http: HttpClient) {
    // this.handleError = httpErrorHandler.createHandleError('ServiceError');
  }

  get(apiMethod: string): Observable<any> {
    return this.http.get<any>(this.appUrl + apiMethod).pipe();
    // .pipe(catchError(this.handleError<any>(apiMethod)));
  }

  getByParam(
    apiMethod: string,
    paramList: { key: string; value: string }[] = [],
    headersList: { key: string; value: string }[] = []
  ) {
    const params = new HttpParams();
    if (paramList.length > 0) {
      paramList.forEach(param => {
        params.append(param.key, param.value);
      });
    }

    let headers = new HttpHeaders();

    if (headersList.length > 0) {
      headersList.forEach(header => {
        headers = headers.set(header.key, header.value);
      });
    }

    // const headers: HttpHeaders = {} as HttpHeaders;
    /* const headers = new HttpHeaders();
    if (headersList.length > 0) {
      headersList.forEach(header => {
        headers.append(header.key, header.value);
      });
    } */
    let options = {};
    if (paramList.length > 0 && headersList.length === 0) {
      options = { params: params };
    }
    if (headersList.length > 0 && paramList.length === 0) {
      options = { headers: headers };
    }
    if (headersList.length > 0 && paramList.length > 0) {
      options = { params: params, headers: headers };
    }
    return this.http.get<any>(this.appUrl + apiMethod, options);
  }

  getByKey(apiMethod: string, key: string, value: string): Observable<any> {
    // Add safe, URL encoded search parameter if there is a get term
    const options = value ? { params: new HttpParams().set(key, value) } : {};

    return this.http
      .get<any>(this.appUrl + apiMethod, options)
      .pipe
      // catchError(this.handleError<any>('getByKey', []))
      ();
  }
  getByObject(apiMethod: string, paramsObj: any): Observable<any> {
    // Add safe, URL encoded object as parameter if there is a get term
    const options = paramsObj ? { params: paramsObj } : {};

    return this.http
      .get<any>(this.appUrl + apiMethod, options)
      .pipe
      // catchError(this.handleError<any>('getByObject', []))
      ();
  }

  post(apiMethod: string, inputData: any): Observable<any> {
    return this.http
      .post<any>(this.appUrl + apiMethod, inputData, this.httpOptions)
      .pipe
      // catchError(this.handleError('post', hero))
      ();
  }
  postWithFile(apiMethod: string, inputData: any): Observable<any> {
    return this.http
      .post<any>(this.appUrl + apiMethod, inputData, this.multipartHttpOptions)
      .pipe
      // catchError(this.handleError('post', hero))
      ();
  }
  put(apiMethod: string, inputData: any): Observable<any> {
    return this.http
      .put<any>(this.appUrl + apiMethod, inputData, this.httpOptions)
      .pipe
      // catchError(this.handleError('post', hero))
      ();
  }

  handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  delete(apiMethod: string): Observable<any> {
    return this.http
      .delete<any>(this.appUrl + apiMethod, this.httpOptions)
      .pipe
      // catchError(this.handleError('post', hero))
      ();
  }
  deleteByObject(apiMethod: string, paramsObj: any): Observable<any> {
    // Add safe, URL encoded object as parameter if there is a get term
    const options = paramsObj ? { params: paramsObj } : {};

    return this.http
      .delete<any>(this.appUrl + apiMethod, options)
      .pipe
      // catchError(this.handleError<any>('getByObject', []))
      ();
  }
}
