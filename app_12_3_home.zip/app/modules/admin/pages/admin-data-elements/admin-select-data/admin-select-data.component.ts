import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-admin-select-data',
    templateUrl: './admin-select-data.component.html'
  })

export class AdminSelectDataComponent implements OnInit{
    slectDataColumnDefs: any;
    selectData: any;
    hidePageTitle: boolean;
    pageTitle: string;
    planNumber: string;

    ngOnInit(){
        this.slectDataColumnDefs = [
          {headerName: 'Option Id', field: 'ID'},
          {headerName: 'DE Option Text', field: 'optionText'}
        ]

        this.selectData = [
            {ID:1, optionText: "TIER2"},
            {ID:2, optionText: "TIER1"}
        ]

        this.hidePageTitle = false;
        this.pageTitle = 'Select Data Element Option';
        this.planNumber = '559985';
    }
    getOptions()
    {

    }


  }
