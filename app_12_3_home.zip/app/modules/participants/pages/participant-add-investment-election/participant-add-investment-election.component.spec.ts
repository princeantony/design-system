import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantAddInvestmentElectionComponent } from './participant-add-investment-election.component';

describe('ParticipantAddInvestmentElectionComponent', () => {
  let component: ParticipantAddInvestmentElectionComponent;
  let fixture: ComponentFixture<ParticipantAddInvestmentElectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantAddInvestmentElectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantAddInvestmentElectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
