import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-time-info',
  templateUrl: './time-info.component.html'
})
export class TimeInfoComponent implements OnInit {
  delimiter = '-';
  constructor() { }

  ngOnInit() {
  }

}
