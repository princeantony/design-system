import { Injectable } from '@angular/core';
import { NgbDateStruct, NgbDateAdapter } from '@ng-bootstrap/ng-bootstrap';
import {
  isNumber,
  toInteger,
  padNumber
} from 'src/app/shared/utils/pay-admin.utils';

@Injectable({
  providedIn: 'root'
})
export class NgbDateNativeUtcAdapterService extends NgbDateAdapter<string> {
  fromModel(date: string): NgbDateStruct {
    if (date) {
      const dateParts = date.trim().split('/');
      if (dateParts.length === 1 && isNumber(dateParts[0])) {
        return { day: toInteger(dateParts[0]), month: null, year: null };
      } else if (
        dateParts.length === 2 &&
        isNumber(dateParts[0]) &&
        isNumber(dateParts[1])
      ) {
        return {
          day: toInteger(dateParts[1]),
          month: toInteger(dateParts[0]),
          year: null
        };
      } else if (
        dateParts.length === 3 &&
        isNumber(dateParts[0]) &&
        isNumber(dateParts[1]) &&
        isNumber(dateParts[2])
      ) {
        return {
          day: toInteger(dateParts[1]),
          month: toInteger(dateParts[0]),
          year: toInteger(dateParts[2])
        };
      }
    }
    return null;
  }

  toModel(date: NgbDateStruct): string {
    // MM/DD/YYYY
    return date
      ? `${isNumber(date.month) ? padNumber(date.month) : ''}/${
          isNumber(date.day) ? padNumber(date.day) : ''
        }/${date.year}`
      : '';
  }
}

// import { Injectable } from '@angular/core';
// import { NgbDateStruct, NgbDateAdapter } from '@ng-bootstrap/ng-bootstrap';

// @Injectable({
//   providedIn: 'root'
// })
// export class NgbDateNativeUtcAdapterService extends NgbDateAdapter<Date> {
//   fromModel(date: Date): NgbDateStruct {
//     return date && date.getUTCFullYear
//       ? {
//           year: date.getUTCFullYear(),
//           month: date.getUTCMonth() + 1,
//           day: date.getUTCDate()
//         }
//       : null;
//   }

//   toModel(date: NgbDateStruct): Date {
//     return date && date.year && date.month
//       ? new Date(Date.UTC(date.year, date.month - 1, date.day))
//       : null;
//   }
// }
