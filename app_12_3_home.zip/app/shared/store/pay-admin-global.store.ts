import { IPlanLight } from '../interfaces/plan-light.interface';
import { CommonService } from '../services/common.service';

export class PayAdminGlobalState {
  static planNumber: string;
  static planName: string;
  static successMsg: string;
  static planListState: IPlanLight;
  static homeFlagState: any;
  static bankinfo: any;
  static subDiv: any;
  static bankDetails: any;
  static previousPage: string;
  static currentPage: string;
  static divsubId: string;
  static isCatchUp: boolean;
  static StateList: { value: string; displayText: string }[] = [
    { value: '', displayText: 'Select' }
  ];
  static CountryList: { value: string; displayText: string }[] = [
    { value: '', displayText: 'Select' }
  ];
  static importFileData: any;
  static importFileType: string;
  static importColumns: any;
  static moneySource: any;
  static investments: any;
  static importType = 'E';
  static selectedFields: any;
  static participantDiv: any;
  static BatchdivsubEnabled: boolean;
  static loginStatus = false;
  static loginUser: {
    userName: string;
    password: string;
    clientId: string;
    divisionId: string;
  };
  static ClearAll() {
    // to be clear all local states
  }
  constructor(private commonService: CommonService) {}
}
