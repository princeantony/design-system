import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ListPlan } from '../../../../shared/mocks/listPlan';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';

@Component({
  selector: 'app-pay-admin-home',
  templateUrl: './pay-admin-home.component.html'
})
export class PayAdminHomeComponent implements OnDestroy {
hidePageTitle = false;
pageTitleClass = true;
changePlan = true;
 planNumber: string;
 private sub: any;
 planList = ListPlan.data;
 selectedPlan : any;
 planTitle : string;
 message: string = "";
 hasModel = true;
  constructor(private route: ActivatedRoute, private modalService: ModalService) {}

ngOnInit(params) {
  PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
  PayAdminGlobalState.currentPage = "/home";
  this.planNumber = PayAdminGlobalState.planNumber;
  this.sub = this.route.url.subscribe(params => {
    if(params[1] && params[1].path == "success"){
      console.log("in sucess")
      this.message =  PayAdminGlobalState.successMsg;
      PayAdminGlobalState.successMsg = "";
  }
  });
  }
  ngAfterViewChecked()
  {
    if(this.message.length > 0 && this.hasModel)
    {
      this.modalService.open('bankSubmit');
      this.hasModel = false;
    }

  }
   ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
