import { Component, Input, OnInit } from '@angular/core';
import { ColDef, GridOptions } from 'ag-grid-community';

import {
  NumericEditorComponent,
} from '../../../../shared/components/ag-grid/editor/numeric-editor/numeric-editor.component';
import { IParticipantFundSources, ParticipantFundSource, ParticipantFundSourceItem } from '../../model/participant.model';

@Component({
  selector: 'participant-investment-election',
  templateUrl: './participant-investment-election.component.html',
  styleUrls: ['./participant-investment-election.component.scss']
})
export class ParticipantInvestmentElectionComponent implements OnInit {
  private _participantFundSources: IParticipantFundSources = {} as IParticipantFundSources;
  @Input()
  set participantFundSources(value: IParticipantFundSources) {
    this._participantFundSources = value;
    console.log(this._participantFundSources);
  }
  get participantFundSources() {
    return this._participantFundSources;
  }

  public gridOptions: GridOptions;

  constructor() {}
  ngOnInit() {
    this.gridOptions = <GridOptions>{
      rowData: this.createRowData(),
      columnDefs: this.createColumnDefs(),
      context: { componentParent: this },
      frameworkComponents: {
        numericEditorComponent: NumericEditorComponent
      },
      rowHeight: 32,
      singleClickEdit: true,
      stopEditingWhenGridLosesFocus: true
    };
  }

  createColumnDefs() {
    let columnsList = this.participantFundSources.sourceMap;
    let gridColumns: ColDef[] = [];

    // Create First Default FundNameColumn
    gridColumns.push({
      field: 'fundName',
      headerName: 'Fund Name',
      editable: false
    });
    // Push one column for each Source item
    if (columnsList) {
      columnsList.forEach(column => {
        gridColumns.push({
          field: column.sourceID,
          headerName: column.sourceName,
          editable: true,
          cellEditor: 'numericEditorComponent',
          valueFormatter: function percentFormatter(params) {
            return params.value + ' %';
          },
          cellClass: 'number-cell'
        });
      });
    }

    return gridColumns;
  }
  createRowData() {
    const fundSources: ParticipantFundSource[] = this.participantFundSources
      .fundSources;
    let rows = [];
    if (fundSources) {
      fundSources.forEach(fundSrc => {
        const rowItem = Object.assign({ fundName: fundSrc.fundName });
        const sources: ParticipantFundSourceItem[] = fundSrc.sources;

        sources.forEach((src: ParticipantFundSourceItem) => {
          Object.assign(rowItem, { [src.sourceID]: src.value });
        });
        rows.push(rowItem);
      });
    }
    return rows;
  }

  refreshEvenRowsCurrencyData() {
    this.gridOptions.api.forEachNode(rowNode => {
      if (rowNode.data.value % 2 === 0) {
        rowNode.setDataValue(
          'currency',
          rowNode.data.value + Number(Math.random().toFixed(2))
        );
      }
    });
    this.gridOptions.api.refreshCells({ columns: ['currency'] });
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit();
  }
}
