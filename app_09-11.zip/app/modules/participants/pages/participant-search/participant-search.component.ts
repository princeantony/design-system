import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GridOptions } from 'ag-grid-community';
import { SSNDirective } from 'src/app/shared/directives/voya-ssn.directive';
import { VoyaSSNPipe } from 'src/app/shared/pipes/voya-SSN.pipe';
import { ValidatorsService } from 'src/app/shared/services/validators.service';

import { ParticipantItem } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';

enum ParticipantSearchType {
  SSN = 'Search By SSN',
  NAME = 'Search By Last Name'
}
@Component({
  selector: 'app-participant-search',
  templateUrl: './participant-search.component.html',
  styleUrls: ['./participant-search.component.scss'],
  providers: [VoyaSSNPipe, SSNDirective]
})
export class ParticipantSearchComponent implements OnInit {
  private SearchType = ParticipantSearchType;
  private participantSearchTypeList = [];
  private participantSearchForm: FormGroup = new FormGroup({});
  constructor(
    private participantService: ParticipantsService,
    private router: Router,
    private validatorService: ValidatorsService
  ) {}
  private participantList: ParticipantItem[] = [] as ParticipantItem[];
  private participantSearchType: string;
  public gridOptions: GridOptions;
  ngOnInit() {
    this.participantSearchTypeList = [
      { displayText: 'Search By SSN', value: 'SSN' },
      { displayText: 'Search By Last Name', value: 'NAME' }
    ];
    this.participantSearchType = 'SSN';

    this.participantSearchForm = new FormGroup({
      searchSSNInput: new FormControl('', [
        Validators.required
      ]),
      searchLastNameInput: new FormControl(''),
      searchType: new FormControl(this.participantSearchType)
    }, { updateOn: 'submit'});

    this.gridOptions = <GridOptions>{
      rowData: this.participantList,
      columnDefs: [
        {
          field: 'ssn',
          headerName: 'Social Security Number',
          valueFormatter: this.ssnFormatter,
          width: 150
        },
        {
          field: 'name',
          headerName: 'Participant Name'
        }
      ],
      context: { componentParent: this },
      rowHeight: 32
    };
  }

  ssnFormatter(params) {
    const separator = '-';
    let value = params.value;
    let pipedSSN: string = value;
    if (value && value.replace(separator, '').length === 9) {
      value = value.replace(/-/g, ''); // value = 123456789
      pipedSSN =
        value.slice(0, 3) +
        separator +
        value.slice(3, 5) +
        separator +
        value.slice(5);
    }
    return pipedSSN;
  }

  getParticipantList() {
    debugger;
    const searchType = this.participantSearchForm.controls['searchType'].value;
    if (searchType === 'SSN') {
      this.participantList = this.participantService.getParticipantListBySSN(
        this.participantSearchForm.controls['searchSSNInput'].value
      );
    } else if (searchType === 'NAME') {
      this.participantList = this.participantService.getParticipantListByLastName(
        this.participantSearchForm.controls['searchLastNameInput'].value
      );
    }
    this.participantSearchForm.controls['searchSSNInput'].setValue('');
    this.participantSearchForm.controls['searchLastNameInput'].setValue('');
    this.participantSearchForm.controls['searchType'].setValue('SSN');
    
    this.gridOptions.rowData = this.participantList;
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit();
  }

  onParticipantSelect(params) {
    console.log(params.data.ssn);
    this.router.navigate(['participantUpdate']);
  }

  onParticipantSearchByChange(value) {
    this.participantSearchType = value;
  }

  onParticipantSearch() {
    this.getParticipantList();
  }

  onBackClicked() {
    if (this.participantList.length > 0) {
      this.participantList = [];
    }
  }
}
