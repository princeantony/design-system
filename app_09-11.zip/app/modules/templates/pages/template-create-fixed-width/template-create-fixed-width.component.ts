import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import _ from 'lodash';
import { APP_CONST, ENV, SUB_TITLE } from 'src/app/shared/constants/app.constants';
import { templateData } from 'src/app/shared/mocks/template-with-error';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { TemplateGridLinkComponent } from '../../components/template-grid-link/template-grid-link.component';
import { TemplatesService } from '../../services/templates.service';

@Component({
  selector: 'app-template-create-fixed-width',
  templateUrl: './template-create-fixed-width.component.html',
  styleUrls: ['./template-create-fixed-width.component.scss']
})
export class TemplateCreateFWComponent implements OnInit {
  fwtemplateForm = this.fb.group({
    templateId: [],
    headerCount: ['0'],
    trailerCount: ['0']
  });
  fwtemplateFieldForm = this.fb.group({
    fieldType: [],
    startPosition: [],
    fieldLength: []
  });
  planNumber: string;
  subTitle: string;
  importType: string;
  fieldDropdown: any;
  fieldGridColumnDefs: any;
  fieldRowData = [];
  columnDefs = [];
  gridApi: any;
  frameworkComponents: any;
  editType: any;
  rowData: any;
  fileData: any;
  fileType: any;
  rowDataTemp = [];
  successMsg: string;
  constructor(
    private fb: FormBuilder,
    private templateservice: TemplatesService
  ) {}

  ngOnInit() {
    this.subTitle = SUB_TITLE.TEMPLATE_CREATE;
    this.planNumber = PayAdminGlobalState.planNumber;
    this.importType = PayAdminGlobalState.importType;
    this.fileType = PayAdminGlobalState.importFileType;
    this.fieldGridColumnDefs = // GRID_CONFIG.COLUMN_DEFS_FIXED_WIDTH;  commented to avoid build error
    this.fileData = PayAdminGlobalState.importFileData;
    this.frameworkComponents = { linkRenderer: TemplateGridLinkComponent };
    this.editType = 'fullRow';
    if (ENV.TEST) {
      this.getMockFieldList();
    } else {
      this.getFieldList();
    }
  }
  getMockFieldList() {
    this.templateservice
      .getAvailableColsMock(this.planNumber, this.importType)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.fieldDropdown = response.data.availableColumnList;
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }
  getFieldList() {
    this.templateservice
      .getAvailableCols(this.planNumber, this.fileType, this.importType)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.fieldDropdown = response.data.availableColumnList;
          }
        },
        err => {
          console.log('Error', err);
        }
      );

  }
  addRow() {
    const formValue = this.fwtemplateFieldForm.value;
    console.log('-----------formValue', formValue);
    console.log('--------row data', this.fieldRowData);
    if (formValue) {
      if (this.fieldRowData.length <= 0) {
        this.fieldRowData.push({
          fieldType: _.find(this.fieldDropdown, ['value', formValue.fieldType])
            .displayText,
          startPosition: formValue.startPosition,
          fieldLength: formValue.fieldLength
        });
      } else {
        this.gridApi.updateRowData({
          add: [
            {
              fieldType: _.find(this.fieldDropdown, [
                'value',
                formValue.fieldType
              ]).displayText,
              startPosition: formValue.startPosition,
              fieldLength: formValue.fieldLength
            }
          ]
        });
      }
    }
    /* this.fwtemplateFieldForm.setValue({fieldType: [],
      startPosition: [],
      fieldLength: []});
      (<any>Object).values(this.fwtemplateFieldForm.controls).forEach(control => {
        control.markAsUntouched();

      }); */
    // this.fwtemplateFieldForm.value.invalid = false;
    this.fwtemplateFieldForm.reset();
    console.log(this.fwtemplateFieldForm.controls['fieldType'].touched);
  }
  onRowClicked(params) {
    console.log('onRowclicked event', params);
  }
  updateData() {
    const rowDataTemp = [];
    const mappingData = [];
    const fieldDropdown = this.fieldDropdown;
    console.log('----fieldRowData', this.gridApi);
    this.gridApi.forEachNode(function(node) {
      console.log('----------node ', node);
      // {fieldType: "Last Name", startPosition: "17", fieldLength: "6"}
      mappingData.push({
        columnId: _.find(fieldDropdown, ['displayText', node.data.fieldType])
          .value,
        startPosition: node.data.startPosition,
        fieldWidth: node.data.fieldLength
      });
      rowDataTemp.push(node.data);
    });
    this.rowDataTemp = rowDataTemp;

    const templateMapping = {
      templateId: this.fwtemplateForm.value.templateId,
      mappingData: mappingData,
      fileData: this.fileData
    };
    console.log('--------------templateMapping', templateMapping);

    if (ENV.TEST) {
      this.templateservice.mockUpdateData().subscribe(response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.rowData = response.data.fileData;
          this.createGrid(this.rowDataTemp);
        }
      });
    } else {
      this.templateservice.updateData(templateMapping).subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.rowData = response.data.fileData;
            this.createGrid(this.rowDataTemp);
          }
        },
        err => {
          console.log('Error', err);
        }
      );
    }

    console.log('-----------------rowData', this.rowDataTemp);
    console.log('------------drop down', this.fieldDropdown);
    // this.createGrid(rowDataTemp);
  }
  createGrid(rowDataTemp) {
    this.columnDefs = [];

    for (let i = 0; i < rowDataTemp.length; i++) {
      this.columnDefs.push({
        field: _.find(this.fieldDropdown, [
          'displayText',
          rowDataTemp[i].fieldType
        ]).value,
        headerName: rowDataTemp[i].fieldType
      });
    }

    console.log('-------------columndefs', this.columnDefs);
    console.log('------------row data', this.fileData);
    this.fileData = templateData.data.fileData;
    /* this.rowData = [];
    const obj = {};
    for ( let i = 0; i < this.columnDefs.length; i++) {
    for ( let j = 0; j < this.fileData.length; j++) {
      obj[this.columnDefs[i].field] = this.fileData[j][i];

    this.rowData.push(obj);
    }
    } */
    console.log('------------row data', this.rowData);
  }
  saveAndNext() {
    const requestObj = {
      templateId: this.fwtemplateForm.value.templateId,
      importType: this.importType,
      fileData: this.fileData
    };

  }
  saveTemplate() {
    const columnList = [];
    const formVal = this.fwtemplateForm.value;
    console.log('-----------------rowData', this.rowDataTemp);
    for (let i = 0; i < this.rowDataTemp.length; i++) {
      columnList.push({
        value: _.find(this.fieldDropdown, [
          'displayText',
          this.rowDataTemp[i].fieldType
        ]).value,
        startPosition: this.rowDataTemp[i].startPosition,
        fieldWidth: this.rowDataTemp[i].fieldWidth
      });
    }
    const requestObj = {

     'templateId': formVal.templateId,
     'headerCount': formVal.headerCount,
     'trailerCount': formVal.trailerCount,
     'importType': this.importType,
     'fileType': this.fileType,
     'isNewTemplate': true,
     'columnList': columnList
     };
     if (ENV.TEST) {
      this.templateservice.saveMockTemplate().subscribe(response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.successMsg = response.message;
        }
      },
      err => {
        console.log('Error', err);
      });
     } else {
      this.templateservice.saveTemplate(this.planNumber, requestObj).subscribe(response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.successMsg = response.message;
        }
      },
      err => {
        console.log('Error', err);
      });

     }


  }
  onGridReady(params) {
    console.log('----------params', params);
    this.gridApi = params.api;
  }
}
