import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { ModalService } from 'src/app/shared/services/modal.service';

import { FormBuilder, FormGroup } from '../../../../../../node_modules/@angular/forms';
import { APP_CONST, ENV, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { templateData } from '../../../../shared/mocks/template-with-error';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { TemplateGridHeaderComponent } from '../../components/template-grid-header/template-grid-header.component';
import { IcolumnList, ITemplate } from '../../model/template.model';
import { TemplatesService } from '../../services/templates.service';

@Component({
  selector: 'app-template-existing',
  templateUrl: './template-existing.component.html',
  styleUrls: ['./template-existing.component.scss']
})
export class TemplateExistingComponent implements OnInit {
  existingTemplateForm: FormGroup;
  planNumber: string;
  subTitle: string;
  hidePageTitle = false;
  fileData: any;
  fileType: string;
  templateData: ITemplate;
  headerDropdown: any;
  private rowData: any[];
  private columnDefs = [];
  gridApi: any;
  gridColumnApi: any;
  params: any;
  frameworkComponents: any;
  templateId: string;
  columnList: IcolumnList[] = [];
  columnMapping: any;
  isError = false;
  errorObj: any;
  singleClickEdit = false;
  defaultColDef: any;
  suppressClickEdit = true;
  successMessage: string;
  constructor(
    private fb: FormBuilder,
    private templateservice: TemplatesService,
    private route: ActivatedRoute,
    private modalService: ModalService,
    private router: Router
  ) {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.TEMPLATE_EXISTING;
    this.fileData = PayAdminGlobalState.importFileData;
    this.fileType = PayAdminGlobalState.importFileType;
    this.route.params.subscribe(params => {
      console.log('--------params', params);
      this.templateId = params.id;
    });
    if (ENV.TEST) {
      this.getMockColumnList();
    } else {
      this.getColumnList();
    }
  }

  getMockColumnList() {
    this.templateservice.getAvailableColsMock(this.planNumber, 'E').subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.headerDropdown = response.data.availableColumnList;
          this.fileData = templateData.data.fileData;
          this.getMockTemplateDetails();
          // this.createGridData();
        }
      },
      err => {
        console.log('Error', err);
      }
    );
  }
  getMockTemplateDetails() {
    this.templateservice.getMockTemplateDetails().subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          const data = response.data;
          this.existingTemplateForm = this.fb.group({
            templateId: [data.templateId],
            headerCount: [data.headerCount],
            trailerCount: [data.trailerCount]
          });

          this.columnMapping = data.columnList;
          this.fileData = templateData.data.fileData;
          this.createGridData();
        }
      },
      err => {
        console.log('Error', err);
      }
    );
  }

  getColumnList() {
    this.templateservice
      .getAvailableCols(this.planNumber, this.fileType, 'E')
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.headerDropdown = response.data.availableColumnList;
            this.fileData = templateData.data.fileData;
            this.getTemplateDetails();
            // this.createGridData();
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }

  getTemplateDetails() {
    this.templateservice
      .getTemplateDetails(this.planNumber, this.templateId)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            const data = response.data;
            this.existingTemplateForm = this.fb.group({
              templateId: [data.templateId],
              headerCount: [data.headerCount],
              trailerCount: [data.trailerCount]
            });

            this.columnMapping = data.columnList;
            this.fileData = templateData.data.fileData;
            this.createGridData();
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }

  createGridData() {
    console.log('---------------this.testdata', this.fileData);
    // const colNum = this.fileData[0].length;
    for (let index = 0; index < this.columnMapping.length; index++) {
      // const element = array[index];
      this.columnDefs.push({
        field: (index + 1).toString(),
        headerName: this.columnMapping[index].value,
        editable: true,
        headerComponentParams: { options: this.headerDropdown }
      });
      this.defaultColDef = { editable: false };
    }
    const rows = this.fileData;
    this.rowData = [];
    for (let i = 0; i < rows.length; i++) {
      const obj = {};
      for (let j = 0; j < rows[i].length; j++) {
        obj[(j + 1).toString()] = rows[i][j];
      }
      this.rowData.push(obj);
    }
    console.log('---this.rowData', this.rowData);
    // console.log("--------coldef", this.columnDefs);
    this.frameworkComponents = { agColumnHeader: TemplateGridHeaderComponent };
  }

  saveTemplate() {
    console.log('--------save template function', this.existingTemplateForm);
    console.log('------------this.gridApi', this.params);
    this.columnList = [];
    this.successMessage = '';
    this.gridApi.gridOptionsWrapper.gridOptions.columnDefs.forEach(element => {
      this.columnList.push({
        value: element.headerName,
        colNumber: element.field
      });
    });
    this.templateData = this.existingTemplateForm.value;
    this.templateData.importType = PayAdminGlobalState.importType;
    this.templateData.columnList = this.columnList;

    console.log('-----------saveTemplate templateData', this.templateData);
    this.templateservice
      .saveTemplate(this.planNumber, this.templateData)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            console.log(response.message);
            this.successMessage = response.message;
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }
  saveAndCont() {
    this.saveTemplate();
    const fileData = [];
    for (let i = 0; i < this.rowData.length; i++) {
      const a = [];
      _.forEach(this.rowData[i], function(value, key) {
        a.push(value);
      });
      fileData.push(a);
    }
    PayAdminGlobalState.importFileData = fileData;
    const templateFileData = {
      templateId: this.existingTemplateForm.value.templateId,
      importType: PayAdminGlobalState.importType,
      fileData: PayAdminGlobalState.importFileData
    };
    console.log('-----------saveAndCont fileData', templateFileData);
    if (ENV.TEST) {
      this.templateservice.validateMockFileData().subscribe(
        response => {
          console.log('-------------response', response);
          if (response.status === APP_CONST.SUCCESS) {
            if (response.data.validationData) {
              this.isError = true;
              this.errorObj = response.data.validationData;
              this.singleClickEdit = true;
              this.defaultColDef.editable = true;
              console.log('-------------api', this.gridApi);
              this.gridApi.gridOptionsWrapper.gridOptions.suppressClickEdit = false;
              this.gridApi.gridOptionsWrapper.gridOptions.singleClickEdit = true;
              // this.gridApi.setFocusedCell(0, 0);
              /* this.gridApi.forEachNode(node => {
                console.log('-----node', node);
                _.entries(node.data).forEach(element => {
                  console.log('-------------------element', element);
                  this.gridApi.startEditingCell({
                    rowIndex: node.rowIndex,
                    colKey: element[0]
                  });
                });
              }); */
            } else if (response.data.message === 'Success message') {
              PayAdminGlobalState.importFileData = response.data.fileData;
              const cols = [];
              for (let i = 0; i < this.columnDefs.length; i++) {
                cols.push({
                  field: this.columnDefs[i].headerName,
                  headerName: _.find(this.headerDropdown, [
                    'value',
                    this.columnDefs[i].headerName
                  ]).displayText
                });
              }
              PayAdminGlobalState.importColumns = cols;
              this.router.navigate(['/template/verify']);
            }
          }
        },
        err => {
          console.log('Error', err);
        }
      );
    } else {
      this.templateservice
        .validateFileData(this.planNumber, templateFileData)
        .subscribe(
          response => {
            console.log('-------------response', response);
            if (response.status === APP_CONST.SUCCESS) {
              if (response.data.validationData) {
                this.isError = true;
                this.errorObj = response.data.validationData;
                this.singleClickEdit = true;
                this.defaultColDef.editable = true;
                console.log('-------------api', this.gridApi);
                this.gridApi.gridOptionsWrapper.gridOptions.suppressClickEdit = false;
                this.gridApi.gridOptionsWrapper.gridOptions.singleClickEdit = true;
                // this.gridApi.setFocusedCell(0, 0);
                /* this.gridApi.forEachNode(node => {
                console.log('-----node', node);
                _.entries(node.data).forEach(element => {
                  console.log('-------------------element', element);
                  this.gridApi.startEditingCell({
                    rowIndex: node.rowIndex,
                    colKey: element[0]
                  });
                });
              }); */
              } else if (response.data.message === 'Success message') {
                PayAdminGlobalState.importFileData = response.data.fileData;
                const cols = [];
                for (let i = 0; i < this.columnDefs.length; i++) {
                  cols.push({
                    field: this.columnDefs[i].headerName,
                    headerName: _.find(this.headerDropdown, [
                      'value',
                      this.columnDefs[i].headerName
                    ]).displayText
                  });
                }
                PayAdminGlobalState.importColumns = cols;
                this.router.navigate(['/template/verify']);
              }
            }
          },
          err => {
            console.log('Error', err);
          }
        );
    }
  }
  onGridReady(params) {
    console.log('--------onGridReady', params);
    this.params = params;
    this.gridApi = params.api;
    // this.gridApi.stopEditing();
    this.gridColumnApi = params.columnApi;
  }
  openErrorModal() {
    this.modalService.open('error-modal');
  }
  gotoBack() {
    this.router.navigate(['/template/select']);
  }
}
