import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class AdminDataService {
  static dataElementId: string;
  static dataElementNewOrder: string;
  static optionCode: string;
  isValidNewOrder(newOrder) : boolean {
    return true;
  }
}
