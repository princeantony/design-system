import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr/ng2-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
    selector: 'app-admin-data-elements-page',
    templateUrl: './admin-data-elements-page.component.html'
})

export class AdminDataElementsPageComponent implements OnInit {
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    dEColumnDefs: any;
    dEList: any;
    type = 'Data Element';
    modelId = 'deModal';
    selectedDE: any;
    isButtonDisabled = true;
    newOrderNumber: number;
    selectedDEId: string;
    constructor(
      private adminService: AdminService,
      private adminDataService: AdminDataService,
      private router: Router,
      private route: ActivatedRoute,
      private spinner: NgxSpinnerService,
      public toastr: ToastsManager,
      vcr: ViewContainerRef,
      private modalService: ModalService) {
        this.toastr.setRootViewContainerRef(vcr);
        this.dEColumnDefs = GRID_CONFIG.DATA_ELEMENTS.COLUMN_DEFS_ELEMENTS;
    }

    ngOnInit() {
      PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
      PayAdminGlobalState.currentPage = 'admin/dataElements';

      this.hidePageTitle = false;
      this.subTitle = 'Select Data Element Option'; // read from const
      this.planNumber = PayAdminGlobalState.planNumber;
      this.selectedDEId = AdminDataService.dataElementId;
      this.route.url.subscribe(value => {
        const isDelete = _.find(value, ['path', 'delete']);
        if (isDelete) {
        this.onDelete();
        } else {
          this.getDataElementList();
        }
      });

    }

    newElementClick() {
      this.selectedDE = null;
      this.selectedDEId = null;
      AdminDataService.dataElementId = null;
      this.isButtonDisabled = false;
      PayAdminGlobalState.dataElements = null;
      PayAdminGlobalState.dataElement = null;
    }

    getDataElementList() {
      this.spinner.show();
        this.adminService.getDEList(this.planNumber).subscribe(dlList => {
            if (dlList.status === APP_CONST.SUCCESS) {
              this.spinner.hide();
                this.dEList = dlList.data;
                PayAdminGlobalState.dataElements = dlList.data;
                if(this.selectedDEId) {

                  this.getSelectedDataID(this.selectedDEId);
                }
              }
            });
    }
    getSelectedDataID(_deid: string)
    {
      this.isButtonDisabled = false;
      this.selectedDE = _.filter(this.dEList, ['dataElement', _deid])[0];
      PayAdminGlobalState.dataElement = this.selectedDE;
      this.selectedDEId = _deid;
      AdminDataService.dataElementId = _deid;
      console.log('this.selectedDE', this.selectedDEId);
    }
    getNewOrder(newOrder) {
        this.newOrderNumber = newOrder;
        console.log('new order in parent is', newOrder)
      }
    gotoBack() {
      this.router.navigate([PayAdminGlobalState.previousPage]);
    }
    showDeteleModal() {
      PayAdminGlobalState.currentPage = PayAdminGlobalState.previousPage;
      this.modalService.open(this.modelId);
    }
    onDelete() {
      this.spinner.show();
      this.adminService.deleteDE(this.planNumber, this.selectedDEId).subscribe(delRes => {
        if (delRes.status === APP_CONST.SUCCESS) {
         // PayAdminGlobalState.dataElement = null;
         // this.selectedDEId = null;
         this.spinner.hide();
          this.getDataElementList(); // will do this logic in client side later
        }
        else
        {
          this.spinner.hide();
          console.log('Error in onDelete', delRes);
          this.toastr.error(delRes.error.msg, delRes.status + ' !', { showCloseButton: true });
        }
      },
        (err => {

          this.spinner.hide();
          console.log('Error in onDelete outside', err);
          this.toastr.error('Error while deleting Data Element!', err.error.status + ' !', { showCloseButton: true });

        })
      );
  }
    saveDisplayOrder()
    {
      this.spinner.show();
      this.adminService.updateOrderNumber(this.planNumber, this.selectedDEId, this.newOrderNumber).subscribe(saveRes => {
        if (saveRes.status === APP_CONST.SUCCESS) {
          this.spinner.hide();
          this.toastr.success("Override Display Order updated!", 'Success' + ' !', { showCloseButton: true });
          this.getDataElementList(); // will do this logic in client side later
        }
    });
    }
    showOptions() {
      this.router.navigate(['/admin/dataElements/options']);
    }
    onEdit() {
      this.router.navigate(['/admin/dataElements/createOrEdit']);
    }

}

