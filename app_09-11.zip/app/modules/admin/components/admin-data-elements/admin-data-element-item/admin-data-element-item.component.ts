import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import _ from 'lodash';
import {
  AddEnrollmentOptions,
  BatchParticipantOptions,
  ContributionOptions,
  ParticipantOptions,
} from 'src/app/shared/config/data-element.config';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { APP_CONST } from '../../../../../shared/constants/app.constants';
import { ModalService } from '../../../../../shared/services/modal.service';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-data-element-item',
  templateUrl: './admin-data-element-item.component.html'
})

export class AdminDataElementItemComponent implements OnInit {

  hidePageTitle: boolean;
  subTitle: string;
  planNumber: string;
  selectedDataElement: any;
  participantOptions : any;
  addEnrollmentOptions: any;
  contributionOptions: any;
  isButtonDisabled = true;
  batchParticipantOptions: any;
  selectedDEId : string;
  newDataElement: string;
  modelId = 'deModal';
  type = 'Data Element';
  isCreate = true;
  disableAccumulate = true;
  disableUserOverride = false;
  disableAccUserOverride = false;
  showAccumulateDetails = false;

   updateOtionalDataForm = this.fb.group({
    dataElement1: ['', Validators.required],
    dataElement2: ['', Validators.required],
    dataElement3: ['', Validators.required],
    omniName: [''],
    overrideName: [''],
    addEnrollment: ['', Validators.required],
    userOverride: [''],
    accuUserOverride: ['', Validators.required],
    participant: ['', Validators.required],
    contribution: ['', Validators.required],
    batchParticipant: ['', Validators.required],
    accumulate: [''],
    accuOverrideName: ['']
  });
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private modalService: ModalService,
    private adminService: AdminService)
  {

  }
  populateForm(dataElement) {

    this.updateOtionalDataForm.controls['dataElement1'].setValue(dataElement.dataElement1);
    this.updateOtionalDataForm.controls['dataElement2'].setValue(dataElement.dataElement2);
    this.updateOtionalDataForm.controls['dataElement3'].setValue(dataElement.dataElement3);
    this.updateOtionalDataForm.controls['omniName'].setValue(dataElement.omniName);
    this.updateOtionalDataForm.controls['overrideName'].setValue(dataElement.overrideName);
    this.updateOtionalDataForm.controls['userOverride'].setValue(dataElement.userOverride);
    this.updateOtionalDataForm.controls['accuUserOverride'].setValue(dataElement.accuUserOverride);
    this.updateOtionalDataForm.controls['addEnrollment'].setValue(dataElement.addEnrollment);
    this.updateOtionalDataForm.controls['participant'].setValue(dataElement.participant);
    this.updateOtionalDataForm.controls['contribution'].setValue(dataElement.contribution);
    this.updateOtionalDataForm.controls['batchParticipant'].setValue(dataElement.batchParticipant);
    this.updateOtionalDataForm.controls['accumulate'].setValue(dataElement.accumulate);
    this.updateOtionalDataForm.controls['accuOverrideName'].setValue(dataElement.accuOverrideName);
  }
  onStateChange(value: string) {
    console.log("value changed"  + value);
  }
  ngOnInit() {

    this.participantOptions = ParticipantOptions;
    this.addEnrollmentOptions = AddEnrollmentOptions;
    this.contributionOptions = ContributionOptions;
    this.batchParticipantOptions = BatchParticipantOptions;
    if(PayAdminGlobalState.dataElement) {
    this.isButtonDisabled = false;
    this.isCreate = false;
    this.selectedDataElement = PayAdminGlobalState.dataElement;
    this.selectedDEId = PayAdminGlobalState.dataElement.dataElement;
    this.populateForm(this.selectedDataElement);
    this.enableDisableFields(this.selectedDataElement);
    }
  }
  enableDisableFields(dataElement)
  {
   if( _.endsWith(dataElement.dataElement.toUpperCase(), 'PH085')  ||  _.endsWith(dataElement.dataElement.toUpperCase(), 'PH340')){
    this.disableAccumulate = false;
    if(dataElement.accumulate){
    this.showAccumulateDetails = true;
    }
    }
      this.disableUserOverride = dataElement.userOverride;
      this.disableAccUserOverride = dataElement.accuUserOverride;
  }
  onChange(value)
  {
    console.log("this is changed ", value)
  }
  setAccOverRequired()
  {
    this.disableAccUserOverride = !this.disableAccUserOverride;
  }
  setOverRequired()
  {
    this.disableUserOverride = !this.disableUserOverride;
  }
  showAccDetails(){
    if(!this.disableAccumulate){
    this.showAccumulateDetails = !this.showAccumulateDetails;
    }
  }
  onDelete() {
    this.adminService.deleteDE(this.planNumber, this.selectedDEId).subscribe(delRes => {
      if (delRes.status === APP_CONST.SUCCESS) {
        this.router.navigate(['/admin/dataElements']);
      }
  });
  }
  saveDE()
  {
    this.newDataElement = this.updateOtionalDataForm.value;
    console.log("this.newDataElement", this.newDataElement)
    this.adminService.saveDE(this.planNumber, this.selectedDEId, this.isCreate).subscribe(saveRes => {
      if (saveRes.status === APP_CONST.SUCCESS) {
        this.router.navigate(['/admin/dataElements']);
      }
  });
}
  showOptions() {
    this.router.navigate(['/admin/dataElements/options']);
  }
  showDeteleModal() {
    this.modalService.open(this.modelId);
  }
  gotoBack() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
  onClear() {
    this.updateOtionalDataForm.reset();
  }
/*
  get dataElement1() {
    return this.updateOtionalDataForm.get('dataElement1');
  }
  get dataElement2() {
    return this.updateOtionalDataForm.get('dataElement2');
  }
  get dataElement3() {
    return this.updateOtionalDataForm.get('dataElement3');
  }
  get omniName() {
    return this.updateOtionalDataForm.get('omniName');
  }
  get overrideName() {
    return this.updateOtionalDataForm.get('overrideName');
  }
  get Enrollment() {
    return this.updateOtionalDataForm.get('Enrollment');
  }
  get Participant() {
    return this.updateOtionalDataForm.get('Participant');
  }
  get Contribution() {
    return this.updateOtionalDataForm.get('Contribution');
  }
  get batchParticipant() {
    return this.updateOtionalDataForm.get('batchParticipant');
  }*/
}
