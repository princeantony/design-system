export const  validationData = {
    'status': 'SUCCESS',
    'data': {
  'validationData': [
  {
   'ssn' : '123456789',
  'name' : 'John Doe',
  'Error' : 'Birth Date is not a date'
  },
  {
   'ssn' : '123456789',
  'name' : 'John Doe',
  'Error' : 'Participant 123456789 is already on file. If the participant was previously terminated, please be sure to update the re-hire date/adjusted date of hire in the Participant Update Section'
  }
  ],
  'fileData' : [
  [  '123456789JohnDoeAnywhere'],
  [ '123456789JohnDoeAnywhere']
  ]
  }
};

export const updateDataResponse = {
    'status': 'SUCCESS',
  'data': {
  'message' : 'Success message',
  'fileData' : [
  {
  'ssn': '123456789',
  'firstName': 'John',
  'lastName': 'Doe'
  },
  {
  'ssn': 'SSN',
  'firstName': 'Jane',
  'lastName': 'Doe'
  }
]
  }
};
