import { Injectable } from '@angular/core';
import { AbstractControl, FormControl, ValidationErrors, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ValidatorsService {
  constructor() {}

  validateSSN(ctrl: FormControl): ValidationErrors | null {
    return Validators.compose([Validators.pattern('^\\d{3}-?\\d{2}-?\\d{4}$')])(
      ctrl
    );
  }

  validateAllZeroSSN(control: AbstractControl) {
    const curSSN: string = control.value;
    if (curSSN.replace(/-/g, '').length === 9) {
      if (curSSN === '000-00-0000' || curSSN === '000000000') {
        return { InValidAllZeroSSN: true };
      }
    }
    return null;
  }
}
