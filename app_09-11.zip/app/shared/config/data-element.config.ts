export const AddEnrollmentOptions = [
  {
    'displayText': 'Not Displayed',
    'value': 'N'
  },
  {
    'displayText': 'Required',
    'value': 'R'
  },
  {
    'displayText': 'Optional',
    'value': 'O'
  }
  ];


  export const ParticipantOptions = [
    {
      'displayText': 'Not Displayed',
      'value': 'N'
    },
    {
      'displayText': 'Inquiry Only',
      'value': 'I'
    },
    {
      'displayText': 'Updateable',
      'value': 'U'
    },
    {
      'displayText': 'LOA Functionality',
      'value': 'L'
    }
    ];

  export const ContributionOptions = [
    {
      'displayText': 'Not Displayed',
      'value': 'N'
    },
    {
      'displayText': 'Inquiry Only',
      'value': 'I'
    },
    {
      'displayText': 'Updateable',
      'value': 'U'
    }
    ];

    export const BatchParticipantOptions = [
      {
        'displayText': 'Not Displayed',
        'value': 'N'
      },
      {
        'displayText': 'Inquiry Only',
        'value': 'I'
      },
      {
        'displayText': 'Updateable',
        'value': 'U'
      }
      ];

