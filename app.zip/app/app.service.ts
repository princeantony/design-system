import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { SERVICE_URL } from './shared/constants/service.constants';
import { ApiService } from './shared/services/api.service';
import { MockService } from './shared/services/mock.service';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService
  ) {}
postSponsorAuth(): Observable<any> {
    return this.apiService.post(SERVICE_URL.POST_SPONSOR_WEB_AUTH, {});
}
}
