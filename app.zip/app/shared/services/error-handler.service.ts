import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { ApplicationResponse } from '../models/common.model';
import { LoggerService } from './logger.service';
import { MessageService } from './message.service';

@Injectable({
  providedIn: 'root'
})
export class ErrorHandlerService {
  constructor(
    private messageService: MessageService,
    private logger: LoggerService
  ) {}

  erroHandler<T>(serviceName = '', operation = 'operation', result = {} as T) {
    return (error: Error | HttpErrorResponse): Observable<T> => {
      debugger;
      if (error instanceof HttpErrorResponse) {
        // TODO: send the error to remote logging infrastructure
        this.logger.error(error);

        const message =
          error.error instanceof ErrorEvent
            ? error.error.message
            : `server returned code ${error.status} - "${error.statusText}"`;

        // TODO: better job of transforming error for user consumption
        this.messageService.add(
          `${serviceName}: ${operation} failed: ${message}`
        );
        if (error.error.error) {
          if (result instanceof ApplicationResponse) {
            result.error.code = error.error.error.code;
            result.error.msg = error.error.error.msg;
            result.error.type = error.error.error.type;
            result.error.cause = error.error.error.cause;
            if (error.error.data) {
              if (error.error.data.validationErrors) {
                result.error.validations = error.error.data.validationErrors;
              }
            }
          }
        } else if (result instanceof ApplicationResponse) {
          result.error.code = error.error.code;
          result.error.msg = `${serviceName}: ${operation} failed: ${message}`;
        }

        // Let the app keep running by returning a safe result.
        return of(result);
      } else {
        throw error;
        // Handle Client Error (Angular Error, ReferenceError...)
      }
    };
  }

  getErrorMessages(serviceResponses: any[] = []): string[] {
    const messageList: string[] = [];
    serviceResponses.forEach(response => {
      if (response instanceof ApplicationResponse) {
        messageList.push(response.error.msg);
        if (response.error.validations) {
          if (response.error.validations.length > 0) {
            response.error.validations.forEach(validationErr => {
              messageList.push(validationErr);
            });
          }
        }
      }
    });
    return messageList;
  }
}
