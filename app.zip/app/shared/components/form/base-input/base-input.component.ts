import { Component, Input, Output, EventEmitter } from '@angular/core';

const noop = () => {};
@Component({
  selector: 'app-base-input',
  template: ''
})
export class BaseInputComponent {
  // Placeholders for the callbacks
  _onTouchedCallback: (_: any) => void = noop;
  _onChangeCallback: (_: any) => void = noop;
  @Input()
  control;
  @Input()
  id = '';
  @Input()
  controlClass: string;
  @Input()
  controlName: string;
  @Input()
  placeHolderText: string;
  @Input()
  controlLabel: string;
  @Input()
  maxLength = 100;
  @Input()
  controlDisabled = false;
  @Input()
  controlReadOnly = false;
  @Output()
  fieldBlur = new EventEmitter<any>();

  _isRequired = true;
  @Input()
  set isRequired(value: boolean) {
    if (this.controlDisabled || this.controlReadOnly) {
      this._isRequired = false;
    } else {
      this._isRequired = value;
    }
  }
  get isRequired(): boolean {
    return this._isRequired;
  }
}
