import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-confirm-modal',
  templateUrl: './confirm-modal.component.html',
  styleUrls: ['./confirm-modal.component.scss']
})
export class ConfirmModalComponent implements OnInit {
  @Input() modelId;
  @Input() modalHeader;
  @Input() confirmMessage;
  @Input() confirmButton;
  @Input() cancelButton;
  @Output()
  continue = new EventEmitter<any>();
  constructor(private modalService: ModalService) { }

  ngOnInit() {
  }
  closeModal(id) {
    this.modalService.close(id);
  }
  continueTo(id) {
  this.modalService.close(id);
  this.continue.emit();
  }

}
