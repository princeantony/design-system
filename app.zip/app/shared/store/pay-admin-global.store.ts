import { CommonService } from '../services/common.service';

export class PayAdminGlobalState {
  static planNumber: string;
  static planName: string;
  static successMsg: string;
  static planListState: any;
  static homeFlagState: any;
  static bankinfo: any;
  static subDiv: any;
  static bankDetails: any;
  static previousPage: string;
  static currentPage: string;
  static divsubId: string;
  static isCatchUp: boolean;
  static StateList: { value: string; displayText: string }[] = [
    { value: '', displayText: 'Select' }
  ];
  static CountryList: { value: string; displayText: string }[] = [
    { value: '', displayText: 'Select' }
  ];
  static moneySource: any;
  static investments: any;
  static selectedFields: any;
  static participantDiv: any;
  static BatchdivsubEnabled: boolean;
  static loginStatus = false;
  static loginUser: {
    userName: string;
    password: string;
    clientId: string;
    divisionId: string;
  };
  static ClearLogin() {
    this.loginUser = null;
    this.loginStatus = false;
    // to be clear all local states
  }
  static ClearforAdmin() {

    // to be clear all local states
  }
  constructor(private commonService: CommonService) {}
}
