export const moneySources = {
  'status': 'SUCCESS',
    'data': [{
            'code': '1',
            'longName': 'GSR MATCH',
            'shortName': 'GSR MATCH',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': '3',
            'longName': 'ROTH ROLLOVER',
            'shortName': 'ROTH ROLL',
            'shortNameOverride': '',
            'exclude': true,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': true,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': true,
            'preTaxSource': false
        },
        {
            'code': '4',
            'longName': 'SELECT NONELECT',
            'shortName': 'SELECT NE',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': true
        },
        {
            'code': '6',
            'longName': 'MEI-GSR MATCH',
            'shortName': 'MEI-GSR MAT',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': true,
            'preTaxSource': false
        },
        {
            'code': '9',
            'longName': 'ROLLOVER',
            'shortName': 'ROLLOVER',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': true
        },
        {
            'code': 'A',
            'longName': 'EMPLOYEE PRE TAX',
            'shortName': 'EE PRE TAX',
            'shortNameOverride': 'PRETX',
            'exclude': false,
            'limit': true,
            'contributionCatchUp': true,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'D',
            'longName': 'EMPLOYER MATCHING',
            'shortName': 'ER MATCH',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'F',
            'longName': 'EMPLOYER PROFIT SHARING',
            'shortName': 'ER PROFIT',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'G',
            'longName': 'ROTH',
            'shortName': 'ROTH',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'K',
            'longName': 'EMPLOYEE POST TAX FROZEN',
            'shortName': 'EE POST TAX',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'P',
            'longName': 'QNEC',
            'shortName': 'QNEC',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'Q',
            'longName': 'AFTER TAX ROLLOVER',
            'shortName': 'A TAX ROLL',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'U',
            'longName': 'TAKEOVER SOURCE',
            'shortName': 'TAKEOVER',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'X',
            'longName': 'SAFE HARBOR MATCH PRIOR PLAN',
            'shortName': 'SH MATCH PR',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        },
        {
            'code': 'Y',
            'longName': 'PRIOR PLAN MATCH NR',
            'shortName': 'PR PL MAT NR',
            'shortNameOverride': '',
            'exclude': false,
            'limit': false,
            'contributionCatchUp': false,
            'deferralCatchUp': false,
            'forfeitureAccountFrom': false,
            'forfeitureAccountTo': false,
            'prefundedAccountFrom': false,
            'prefundedAccountTo': false,
            'rothSource': false,
            'preTaxSource': false
        }]
};


export const investments = {
    'status': 'SUCCESS',
    'data': [
            {
                'code': '30',
                'longNameOverride': 'one',
                'exclude': false,
                'longName': 'Vanguard Mid-Cap Index Fund Adm'
            },
            {
                'code': '31',
                'exclude': false,
                'longName': 'Vanguard Small-Cap Index Fund Adm'
            },
            {
                'code': '32',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2015 Fnd Inv'
            },
            {
                'code': '33',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2035 Fnd Inv'
            },
            {
                'code': '34',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2045 Fnd Inv'
            },
            {
                'code': '35',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire Income Fnd Inv'
            },
            {
                'code': '36',
                'exclude': false,
                'longName': 'Vanguard Total Bnd Mrkt Ind F Adm'
            },
            {
                'code': '37',
                'exclude': false,
                'longName': 'Vanguard 500 Index Fund Adm'
            },
            {
                'code': '38',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2025 Fnd Inv'
            },
            {
                'code': '49',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2020 Fnd Inv'
            },
            {
                'code': '50',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2030 Fnd Inv'
            },
            {
                'code': '51',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2040 Fnd Inv'
            },
            {
                'code': '52',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2050 Fnd Inv'
            },
            {
                'code': '53',
                'exclude': false,
                'longName': 'American Funds Nw Prspctv R6'
            },
            {
                'code': '54',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2055 Fnd Inv'
            },
            {
                'code': '55',
                'exclude': false,
                'longName': 'Vanguard LifeStrat Cnsrv Grw Fd Inv'
            },
            {
                'code': '56',
                'exclude': false,
                'longName': 'Vanguard LifeStrat Growth Fd Inv'
            },
            {
                'code': '57',
                'exclude': false,
                'longName': 'Vanguard LifeStrat Income Fd Inv'
            },
            {
                'code': '58',
                'exclude': false,
                'longName': 'Vanguard LifeStrat Mod Grwth Fd Inv'
            },
            {
                'code': '59',
                'longNameOverride': '4545',
                'exclude': false,
                'longName': 'Amer Bcn Small Cap Value Fund Inst'
            },
            {
                'code': '60',
                'exclude': false,
                'longName': 'DFA Inflat-Prot Securities Port Inst'
            },
            {
                'code': '61',
                'exclude': false,
                'longName': 'Vanguard Trgt Retire 2060 Fnd Inv'
            },
            {
                'code': '62',
                'exclude': false,
                'longName': 'DFA Commodity Strategy Port Inst'
            },
            {
                'code': '63',
                'exclude': false,
                'longName': 'DFA Global Real Estate Sec Port Inst'
            },
            {
                'code': '64',
                'exclude': false,
                'longName': 'Eagle Small Cap Growth Fund R6'
            },
            {
                'code': '65',
                'exclude': false,
                'longName': 'American Funds New World R6'
            },
            {
                'code': '66',
                'exclude': false,
                'longName': 'PIMCO Income Fund Inst'
            },
            {
                'code': '67',
                'exclude': false,
                'longName': 'Invesco Diversified Dividend Fnd R6'
            },
            {
                'code': '68',
                'exclude': false,
                'longName': 'Pioneer Fundamental Growth Fund K'
            },
            {
                'code': '69',
                'exclude': false,
                'longName': 'Amer Cent Mid Cap Value Fund R6'
            },
            {
                'code': '70',
                'exclude': false,
                'longName': 'AB Global Bond Fund Z'
            },
            {
                'code': '71',
                'exclude': false,
                'longName': 'Prudential High Yield Fund Q'
            },
            {
                'code': '72',
                'exclude': false,
                'longName': 'Prudential Short-Term Corp Bond Fd Q'
            },
            {
                'code': '73',
                'exclude': false,
                'longName': 'Eaton Vance-Atlanta Cap SMID-Cp F R6'
            },
            {
                'code': '74',
                'exclude': false,
                'longName': 'Vanguard Balanced Index Fund Adm'
            },
            {
                'code': '75',
                'exclude': false,
                'longName': 'Oppenheimer Intl Growth Fnd I'
            },
            {
                'code': '76',
                'exclude': false,
                'longName': 'Vanguard Total Intl Stk Index Fd Adm'
            },
            {
                'code': '90',
                'exclude': false,
                'longName': '90'
            },
            {
                'code': 'AA',
                'exclude': false,
                'longName': ''
            },
            {
                'code': 'GP',
                'exclude': false,
                'longName': 'Voya Fixed Account'
            }
        ]
      };
        export const planOptions = {
          'status': 'SUCCESS',
      'data':{
            'showCatchUpOptions': false,
            'showDropdown': true,
            'showLOA': false,
            'showPartUpdateOptions': false,
            'rsd': false
        }}
        ;
        export const planSetup = {
          'status': 'SUCCESS',
         'data':{
            'loanMatching': true,
            'copyPayroll': false,
            'disActPartWContrib': false,
            'loanPayoffs': true,
            'leaveOfAbsence': false,
            'submitBatchesInAdvance': false,
            'crossCalendarPayroll': false,
            'negativeContrib': false,
            'nonACH': false,
            'nameChange': true,
            'reportsFolder': 'Reports',
            'lastChangedBy': '_20181120_00001',
            'pinLength': 4,
            'divLocFunc': 'M',
            'emailDE': 'PH155',
            'enrollmentStatusCode': '04',
            'catchUp': 'N',
            'participantUpdate': 'B',
            'enrollment': 'B',
            'maskSSN': '999999999',
            'customMask': '99xxxxxxx'
    }
  }

  export const enrollmentStatusCode = {
      'status': 'SUCCESS',
      'data': [
        {
          'displayText': 'Env status code 04',
          'statusCode': '04'
        },
        {
          'displayText': 'Env status code 05',
          'statusCode': '05'
        }
      ]
  }




