export const StateListMock = {
  status: 'SUCCESS',
  data: [
    { displayText: 'AB', value: 'AB' },
    { displayText: 'AK', value: 'AK' },
    { displayText: 'AL', value: 'AL' },
    { displayText: 'AR', value: 'AR' },
    { displayText: 'AS', value: 'AS' },
    { displayText: 'AZ', value: 'AZ' },
    { displayText: 'BC', value: 'BC' },
    { displayText: 'CA', value: 'CA' },
    { displayText: 'CO', value: 'CO' },
    { displayText: 'CT', value: 'CT' },
    { displayText: 'CZ', value: 'CZ' },
    { displayText: 'DC', value: 'DC' },
    { displayText: 'DE', value: 'DE' },
    { displayText: 'FL', value: 'FL' },
    { displayText: 'GA', value: 'GA' },
    { displayText: 'GU', value: 'GU' },
    { displayText: 'HI', value: 'HI' },
    { displayText: 'IA', value: 'IA' },
    { displayText: 'ID', value: 'ID' },
    { displayText: 'IL', value: 'IL' },
    { displayText: 'IN', value: 'IN' },
    { displayText: 'KS', value: 'KS' },
    { displayText: 'KY', value: 'KY' },
    { displayText: 'LA', value: 'LA' },
    { displayText: 'LB', value: 'LB' },
    { displayText: 'MA', value: 'MA' },
    { displayText: 'MC', value: 'MC' },
    { displayText: 'MD', value: 'MD' },
    { displayText: 'ME', value: 'ME' },
    { displayText: 'MN', value: 'MN' },
    { displayText: 'MO', value: 'MO' },
    { displayText: 'MS', value: 'MS' },
    { displayText: 'MT', value: 'MT' },
    { displayText: 'NB', value: 'NB' },
    { displayText: 'NC', value: 'NC' },
    { displayText: 'ND', value: 'ND' },
    { displayText: 'NE', value: 'NE' },
    { displayText: 'NF', value: 'NF' },
    { displayText: 'NH', value: 'NH' },
    { displayText: 'NJ', value: 'NJ' },
    { displayText: 'NM', value: 'NM' },
    { displayText: 'NS', value: 'NS' },
    { displayText: 'NT', value: 'NT' },
    { displayText: 'NV', value: 'NV' },
    { displayText: 'NY', value: 'NY' },
    { displayText: 'OK', value: 'OK' },
    { displayText: 'ON', value: 'ON' },
    { displayText: 'OR', value: 'OR' },
    { displayText: 'PA', value: 'PA' },
    { displayText: 'PE', value: 'PE' },
    { displayText: 'PQ', value: 'PQ' },
    { displayText: 'PR', value: 'PR' },
    { displayText: 'RI', value: 'RI' },
    { displayText: 'SC', value: 'SC' },
    { displayText: 'SD', value: 'SD' },
    { displayText: 'SK', value: 'SK' },
    { displayText: 'TN', value: 'TN' },
    { displayText: 'TX', value: 'TX' },
    { displayText: 'UT', value: 'UT' },
    { displayText: 'VA', value: 'VA' },
    { displayText: 'VT', value: 'VT' },
    { displayText: 'WA', value: 'WA' },
    { displayText: 'WI', value: 'WI' },
    { displayText: 'WV', value: 'WV' },
    { displayText: 'WY', value: 'WY' },
    { displayText: 'YT', value: 'YT' }
  ]
};

export const CountryListMock = {
  status: 'SUCCESS',
  data: [
    {
      value: 'USA',
      displayText: 'USA'
    },
    {
      value: 'CA',
      displayText: 'CANADA'
    },
    {
      value: 'AFG',
      displayText: 'AFGHANISTAN'
    },
    {
      value: 'ALB',
      displayText: 'ALBANIA'
    },
    {
      value: 'DZA',
      displayText: 'ALGERIA'
    }
  ]
};

export const MockSuccessResponse = {
  status: 'SUCCESS',
  data: [
    {
      status: 'Good'
    }
  ]
};
