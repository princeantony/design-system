export const ParticipantAdminSettingMockOLD = {
  status: 'SUCCESS',
  data: {
    displayQDIA: true,
    displayMorningStar: true,
    displayEnrollParticipant: true,
    enableEnrollParticipant: true,
    disableQDIA: false,
    disableMorningStar: false,
    morningStarError: true,
    displayEmail: false,
    canLoadOptionalDataElements: true,
    participantMinAge: 15,
    participantMaxAge: 90,
    salaryDataElement: 'PTPH88',
    salaryEffectiveDateDataElement: 'PTPH99',
    statusCode: '04',
    authDivSub: [
      {
        value: '',
        displayText: 'Select'
      },
      {
        value: '4800',
        displayText: '4800 AGRICULTURAL EXPERIMENT STATION'
      },
      {
        value: '4350',
        displayText: '4350 AIR MANAGEMENT'
      },
      {
        value: '1100',
        displayText: '1100 AUDITORS OF PUBLIC ACCOUNTS'
      },
      {
        value: '8835',
        displayText: '8835 BERGIN CORRECTIONAL INST'
      },
      {
        value: '8845',
        displayText: '8845 BROOKLYN CORRECTIONAL INST'
      },
      {
        value: '5720',
        displayText: '5720 BUREAU OF HIGHWAY OPERATIONS'
      },
      {
        value: '4720',
        displayText: '4720 CAPITAL REG DEV AUTH'
      },
      {
        value: 'O!',
        displayText: 'OTHER'
      }
    ],
    otherDivSub: [
      { value: '1246', displayText: 'ALABAMA' },
      { value: '1304', displayText: 'ALABAMA' },
      { value: '1290', displayText: 'ALASKA' },
      { value: '1256', displayText: 'AMERICAN SAMOA' },
      { value: '1247', displayText: 'ARIZONA' },
      { value: '1305', displayText: 'ARIZONA' },
      { value: '1260', displayText: 'ARKANSAS' },
      { value: '1267', displayText: 'CALIFORNIA' },
      { value: '1268', displayText: 'COLORADO' },
      { value: '1253', displayText: 'CONNECTICUT' },
      { value: '1311', displayText: 'CONNECTICUT' },
      { value: '1259', displayText: 'DELAWARE' },
      { value: '1254', displayText: 'DISTRICT OF COLUMBIA' },
      { value: '1312', displayText: 'ESPA OF COLUMBIA' },
      { value: '1265', displayText: 'FEDERATED STATES OF MICRONESIA' },
      { value: '1271', displayText: 'FLORIDA' },
      { value: '1288', displayText: 'GEORGIA' },
      { value: '1272', displayText: 'GUAM' },
      { value: '1285', displayText: 'IDAHO' },
      { value: '1258', displayText: 'ILLINOIS' },
      { value: '1251', displayText: 'INDIANA' },
      { value: '1309', displayText: 'INDIANA' },
      { value: '1257', displayText: 'IOWA' },
      { value: '1284', displayText: 'KANSAS' },
      { value: '1242', displayText: 'KENTUCKY' },
      { value: '1300', displayText: 'KENTUCKY' },
      { value: '1275', displayText: 'LOUISIANA' },
      { value: '1240', displayText: 'MAINE' },
      { value: '1298', displayText: 'MAINE' },
      { value: '1286', displayText: 'MARSHALL ISLANDS' },
      { value: '1274', displayText: 'MARYLAND' },
      { value: '1269', displayText: 'MASSACHUSETTS' },
      { value: '1287', displayText: 'MICHIGAN' },
      { value: '1234', displayText: 'MINNESOTA' },
      { value: '1292', displayText: 'MINNESOTA' },
      { value: '1273', displayText: 'MISSISSIPPI' },
      { value: '1255', displayText: 'MISSOURI' },
      { value: '1313', displayText: 'MISSOURI' },
      { value: '1263', displayText: 'MONTANA' },
      { value: '1261', displayText: 'NEBRASKA' },
      { value: '1235', displayText: 'NEVADA' },
      { value: '1293', displayText: 'NEVADA' },
      { value: '1243', displayText: 'NEW HAMPSHIRE' },
      { value: '1301', displayText: 'NEW HAMPSHIRE' },
      { value: '1280', displayText: 'NEW JERSEY' },
      { value: '1249', displayText: 'NEW MEXICO' },
      { value: '1307', displayText: 'NEW MEXICO' },
      { value: '1276', displayText: 'NEW YORK' },
      { value: '1238', displayText: 'NORTH CAROLINA' },
      { value: '1296', displayText: 'NORTH CAROLINA' },
      { value: '1266', displayText: 'NORTH DAKOTA' },
      { value: '1241', displayText: 'NORTHERN MARIANA ISLANDS' },
      { value: '1299', displayText: 'NORTHERN MARIANA ISLANDS' },
      { value: '1264', displayText: 'OHIO' },
      { value: '1279', displayText: 'OKLAHOMA' },
      { value: '1245', displayText: 'OREGON' },
      { value: '1303', displayText: 'OREGON' },
      { value: '1282', displayText: 'PALAU' },
      { value: '1252', displayText: 'PENNSYLVANIA' },
      { value: '1310', displayText: 'PENNSYLVANIA' },
      { value: '1250', displayText: 'PUERTO RICO' },
      { value: '1308', displayText: 'PUERTO RICO' },
      { value: '1244', displayText: 'RHODE ISLAND' },
      { value: '1302', displayText: 'RHODE ISLAND' },
      { value: '1291', displayText: 'SOUTH CAROLINA' },
      { value: '1239', displayText: 'SOUTH DAKOTA' },
      { value: '1297', displayText: 'SOUTH DAKOTA' },
      { value: '1277', displayText: 'TENNESSEE' },
      { value: '1283', displayText: 'TEXAS' },
      { value: '1237', displayText: 'UTAH' },
      { value: '1295', displayText: 'UTAH' },
      { value: '1248', displayText: 'VERMONT' },
      { value: '1306', displayText: 'VERMONT' },
      { value: '1270', displayText: 'VIRGIN ISLANDS' },
      { value: '1262', displayText: 'VIRGINIA' },
      { value: '1289', displayText: 'WASHINGTON' },
      { value: '1236', displayText: 'WEST VIRGINIA' },
      { value: '1294', displayText: 'WEST VIRGINIA' },
      { value: '1278', displayText: 'WISCONSIN' },
      { value: '1281', displayText: 'WYOMING' }
    ],
    displayLOA: true,
    loaStartDateDataElement: 'PTPH771',
    loaStartReasonDataElement: 'PTPH841',
    loaEndDateDataElement: 'PTPH772',
    loaEndReasonDataElement: 'PTPH842',
    allowNameChange: false
  }
};

export const ParticipantAdminSettingMock = {
  status: 'SUCCESS',
  data: {
    displayQDIA: false,
    displayMorningStar: false,
    displayEnrollParticipant: true,
    disableQDIA: false,
    disableMorningStar: false,
    morningStarError: false,
    enableEnrollParticipant: true,
    displayEmail: false,
    canLoadOptionalDataElements: true,
    participantMinAge: 15,
    participantMaxAge: 90,
    authDivSubs: [],
    allDivSubs: [],
    allDivSubOptionMaxLength: 50,
    statusCode: '04',
    displayLOA: false,
    allowNameChange: false
  }
};

export const ParticipantStatusListMock = {
  status: 'SUCCESS',
  data: [
    {
      value: '00',
      displayText: '00-Active And Eligible'
    },
    {
      value: '01',
      displayText: '01-Active; Awaits Suspension'
    },
    {
      value: '02',
      displayText: '02-Pending Automatic Enrollment'
    },
    {
      value: '03',
      displayText: '03-Ineligible'
    },
    {
      value: '04',
      displayText: '04-Eligible; Not Participate'
    },
    {
      value: '05',
      displayText: '05-Contributions - Qvec Only'
    },
    {
      value: '06',
      displayText: '06-Break In Service'
    },
    {
      value: '07',
      displayText: '07-Susp Contribs Only'
    },
    {
      value: '08',
      displayText: '08-Sup Pretax Contribs Only'
    },
    {
      value: '09',
      displayText: '09-Er Contribs Only'
    },
    {
      value: '10',
      displayText: '10-Susp From Ee Cntrbs Only'
    },
    {
      value: '11',
      displayText: '11-Susp From Er Cntrbs Only'
    },
    {
      value: '12',
      displayText: '12-Susp From Ee & Er Cntrbs'
    },
    {
      value: '13',
      displayText: '13-Susp From Forf Alloc Only'
    },
    {
      value: '14',
      displayText: '14-Susp Forf Allc & Ee Cntrb'
    },
    {
      value: '15',
      displayText: '15-Susp Forf Allc & Er Cntrb'
    },
    {
      value: '16',
      displayText: '16-Susp Forf & Ee & Er Cntrb'
    },
    {
      value: '20',
      displayText: '20-Ret & Rec Inst Payments'
    },
    {
      value: '25',
      displayText: '25-Pending Inst - No Split'
    },
    {
      value: '30',
      displayText: '30-Term & Awaiting Payment'
    },
    {
      value: '31',
      displayText: '31-Term & Paid Out'
    },
    {
      value: '32',
      displayText: '32-Term With Paymnt Deferred'
    },
    {
      value: '33',
      displayText: '33-Term With Paymnt Forf'
    },
    {
      value: '34',
      displayText: '34-Pending Termination'
    },
    {
      value: '35',
      displayText: '35-Pending Term - No Split'
    }
  ]
};

export const ParticipantMorningStar = {
  status: 'SUCCESS',
  data: {
    headers: ['Fund Name', 'Percentage'],
    rows: [['Voya Fixed Account', '100'], ['Some Other Value', '100']]
  }
};

export const ParticipantTerminationReason = {
  status: 'SUCCESS',
  data: [
    {
      value: '1',
      displayText: 'With Cause'
    },
    {
      value: '2',
      displayText: 'Laid Off'
    },
    {
      value: '3',
      displayText: 'Special'
    },
    {
      value: '4',
      displayText: 'Retirement'
    },
    {
      value: '5',
      displayText: 'Permanent Disability'
    },
    {
      value: '6',
      displayText: 'Death'
    },
    {
      value: '7',
      displayText: '100% Withdrawal'
    },
    {
      value: '8',
      displayText: 'Not Transferred Out'
    },
    {
      value: '9',
      displayText: 'Converted'
    },
    {
      value: 'A',
      displayText: 'User Defined 1'
    },
    {
      value: 'B',
      displayText: 'User Defined 2'
    },
    {
      value: 'C',
      displayText: 'User Defined 3'
    },
    {
      value: 'D',
      displayText: 'Converted'
    },
    {
      value: 'E',
      displayText: 'QDRO'
    },
    {
      value: 'F',
      displayText: 'Beneficiary'
    },
    {
      value: 'I',
      displayText: 'Irrevocable Declination'
    },
    {
      value: 'L',
      displayText: 'Leave of Absence'
    },
    {
      value: 'N',
      displayText: 'New Entrant'
    },
    {
      value: 'R',
      displayText: 'Rehire'
    },
    {
      value: 'T',
      displayText: 'Transferred to Other Plan'
    },
    {
      value: 'V',
      displayText: 'Voluntary Termination'
    },
    {
      value: 'X',
      displayText: 'Excluded Class'
    }
  ]
};
export const ParticipantListOLD = {
  status: 'SUCCESS',
  data: []
};
export const ParticipantList = {
  status: 'SUCCESS',
  data: [
    {
      ssn: '608801567',
      name: 'Channa Jehu'
    },
    {
      ssn: '318955455',
      name: 'Fan Oakenfield'
    },
    {
      ssn: '749223948',
      name: 'Maxie Selkirk'
    },
    {
      ssn: '391083418',
      name: 'Kiele Myrick'
    },
    {
      ssn: '211629950',
      name: 'Delmor Acum'
    },
    {
      ssn: '653567140',
      name: 'Burlie Vedenisov'
    },
    {
      ssn: '816469282',
      name: 'Reynold Pedder'
    },
    {
      ssn: '336154052',
      name: 'Shirline Di Biasi'
    },
    {
      ssn: '863606375',
      name: 'Curtis Yakobovitz'
    },
    {
      ssn: '429548444',
      name: 'Pippa Worsnop'
    },
    {
      ssn: '863606375',
      name: 'Curtis Yakobovitz'
    },
    {
      ssn: '429548444',
      name: 'Pippa Worsnop'
    }
  ]
};
export const UpdateParticipantRequiredData = {
  status: 'SUCCESS',
  data: {
    lastName: 'TEST',
    firstName: 'TEST',
    middleInitial: '',
    address1: '123 MAIN',
    address2: 'TEST',
    city: 'ANYWHERE',
    state: 'FL',
    zipCode: '32210',
    country: 'USA',
    email: '',
    statusCode: '30',
    birthDate: '01/01/1982',
    hireDate: '01/01/2018',
    termCode: '',
    termDate: '',
    enrollFlag: false,
    mstarFlag: false,
    qdiaFlag: false,
    termReadOnlyFlag: true,
    displayMakeActive: true
  }
};

export const ParticipantOptionalData = {
  status: 'SUCCESS',
  data: [
    {
      label: 'Test 2',
      componentType: 'text',
      value: '',
      readOnly: false,
      disabled: false,
      option: [],
      required: false,
      type: '',
      key: 'PTPH016',
      length: 0,
      accumulate: false
    },
    {
      label: 'Test',
      componentType: 'text',
      value: '',
      readOnly: false,
      disabled: false,
      option: [],
      required: false,
      type: '',
      key: 'PTPH720',
      length: 0,
      accumulate: false
    }
  ]
};

export const ParticipantOptionalDataOld = {
  status: 'SUCCESS',
  data: [
    {
      label: 'Marital Status',
      componentType: 'dropdown',
      value: '1',
      readOnly: true,
      disabled: false,
      option: [
        {
          value: '1',
          displayText: 'Single'
        },
        {
          value: '2',
          displayText: 'Married'
        }
      ],
      required: true,
      type: '',
      key: 'PTPH023',
      length: 0,
      accumulate: true
    },
    {
      label: 'Gender',
      componentType: 'dropdown',
      value: '1',
      readOnly: true,
      disabled: false,
      option: [
        {
          value: '1',
          displayText: 'Male'
        },
        {
          value: '2',
          displayText: 'Female'
        }
      ],
      required: true,
      type: '',
      key: 'PTPH030',
      length: 0,
      accumulate: true
    },
    {
      label: 'Some Dummy Number Field',
      componentType: 'text',
      value: '1234',
      readOnly: false,
      disabled: false,
      option: [],
      required: true,
      type: 'Integer',
      key: 'PTPH123',
      length: 4,
      accumulate: false
    },
    {
      label: 'current year NUMBER-OF-HOURS  ',
      componentType: 'text',
      value: '0.0',
      readOnly: false,
      disabled: false,
      option: [],
      required: true,
      type: 'Float',
      key: 'XX_PTPH085',
      length: 7,
      accumulate: false
    },
    {
      label: 'YTD  NUMBER-OF-HOURS  ',
      componentType: 'text',
      value: '0.00',
      readOnly: true,
      disabled: false,
      option: [],
      required: true,
      type: 'Float',
      key: 'PTPH085',
      length: 7,
      accumulate: true
    },
    {
      label: 'Current ELIG-HRS-ANNIV',
      componentType: 'text',
      value: '0.0',
      readOnly: false,
      disabled: false,
      option: [],
      required: true,
      type: 'Float',
      key: 'XX_PTPH340',
      length: 11,
      accumulate: false
    },
    {
      label: 'YTD ELIG-HRS-ANNIV    ',
      componentType: 'text',
      value: '0.00',
      readOnly: true,
      disabled: false,
      option: [],
      required: true,
      type: 'Float',
      key: 'PTPH340',
      length: 11,
      accumulate: true
    },
    {
      label: 'REHIRE DATE',
      componentType: 'text',
      value: '',
      readOnly: true,
      disabled: false,
      option: [],
      required: true,
      type: 'String',
      key: 'PTPH740',
      length: 1,
      accumulate: true
    },
    {
      label: 'Leave of Absence Start Date',
      componentType: 'text',
      value: '',
      readOnly: true,
      disabled: false,
      option: [],
      required: false,
      type: 'Date',
      key: 'PTPH771',
      length: 0,
      accumulate: true
    },
    {
      label: 'Leave of Absence End Date  ',
      componentType: 'text',
      value: '',
      readOnly: true,
      disabled: false,
      option: [],
      required: false,
      type: 'Date',
      key: 'PTPH772',
      length: 0,
      accumulate: true
    },
    {
      label: 'Private Salary Supplement  ',
      componentType: 'text',
      value: '0.00',
      readOnly: true,
      disabled: false,
      option: [],
      required: true,
      type: 'Float',
      key: 'PTPH812',
      length: 11,
      accumulate: true
    },
    {
      label: 'Salary Code',
      componentType: 'dropdown',
      value: 'C',
      readOnly: true,
      disabled: false,
      option: [
        {
          value: 'C',
          displayText: 'City'
        },
        {
          value: 'P',
          displayText: 'Private'
        }
      ],
      required: true,
      type: '',
      key: 'PTPH830',
      length: 0,
      accumulate: true
    },
    {
      label: 'Union Code ',
      componentType: 'dropdown',
      value: '2',
      readOnly: true,
      disabled: false,
      option: [
        {
          value: '0',
          displayText: 'Non-Union'
        },
        {
          value: '1',
          displayText: 'DC1707'
        },
        {
          value: '2',
          displayText: 'DC37'
        },
        {
          value: '3',
          displayText: 'CSA '
        },
        {
          value: '4',
          displayText: 'Other '
        }
      ],
      required: false,
      type: '',
      key: 'PTPH835',
      length: 0,
      accumulate: true
    },
    {
      label: 'LOA start reason',
      componentType: 'dropdown',
      value: '',
      readOnly: true,
      disabled: false,
      option: [
        {
          value: 'F',
          displayText: 'FMLA'
        },
        {
          value: 'M',
          displayText: 'Military            '
        },
        {
          value: 'O',
          displayText: 'Other '
        }
      ],
      required: false,
      type: '',
      key: 'PTPH841',
      length: 0,
      accumulate: true
    },
    {
      label: 'LOA return reason',
      componentType: 'dropdown',
      value: '',
      readOnly: true,
      disabled: false,
      option: [
        {
          value: '1',
          displayText: 'with cause'
        },
        {
          value: '2',
          displayText: 'Laid off'
        },
        {
          value: '3',
          displayText: 'Special'
        },
        {
          value: '4',
          displayText: 'retirement'
        },
        {
          value: '5',
          displayText: '100% withdrawl'
        }
      ],
      required: true,
      type: '',
      key: 'PTPH842',
      length: 0,
      accumulate: true
    }
  ]
};

export const ParticipantDivSubFilter = {
  status: 'SUCCESS',
  data: [
    {
      value: 'AE001',
      displayText: 'A - E'
    },
    {
      value: 'FJ002',
      displayText: 'F - J'
    },
    {
      value: 'KO003',
      displayText: 'K - O'
    },
    {
      value: 'PT004',
      displayText: 'P - T'
    },
    {
      value: 'UZ005',
      displayText: 'U - Z'
    }
  ]
};
export const ParticipantOtherExpandedDivSub = {
  status: 'SUCCESS',
  data: [
    {
      value: '4800',
      displayText: '4800 AGRICULTURAL EXPERIMENT STATION'
    },
    {
      value: '4350',
      displayText: '4350 AIR MANAGEMENT'
    },
    {
      value: '1100',
      displayText: '1100 AUDITORS OF PUBLIC ACCOUNTS'
    },
    {
      value: '8835',
      displayText: '8835 BERGIN CORRECTIONAL INST'
    },
    {
      value: '8845',
      displayText: '8845 BROOKLYN CORRECTIONAL INST'
    },
    {
      value: '5720',
      displayText: '5720 BUREAU OF HIGHWAY OPERATIONS'
    },
    {
      value: '4720',
      displayText: '4720 CAPITAL REG DEV AUTH'
    }
  ]
};
export const PariticipantContributionData = {
  status: 'SUCCESS',
  data: {
    contribElectionOptions: [
      {
        value: 'A',
        displayText: 'Dollar'
      },
      {
        value: 'P',
        displayText: 'Percent'
      }
    ],
    contribElection: [
      {
        label: 'EEVOL',
        value: '0.0',
        readOnly: false,
        key: 'E',
        type: 'B',
        defLimit: {
          code: 'E',
          minPercent: 0,
          maxPercent: 92,
          minAmt: 0,
          maxAmt: 17500
        }
      },
      {
        label: 'EEROTH',
        value: '0.0',
        readOnly: false,
        key: 'N',
        type: 'B',
        defLimit: {
          code: 'N',
          minPercent: 0,
          maxPercent: 92,
          minAmt: 0,
          maxAmt: 17500
        }
      }
    ],
    contribMixedDeferrals: false,
    contribDeferralType: 'P',
    contribTotalMaxDefPct: 92,
    contribTotalMaxDefAmt: 17500,
    catchupContribElectionOptions: [],
    catchupContribElection: [],
    catchupContribMixedDeferrals: false,
    catchupContribTotalMaxDefPct: 0,
    catchupContribTotalMinDefPct: 0,
    catchupContribTotalMaxDefAmt: 0,
    catchupContribTotalMinDefAmt: 0,
    investmentElection: [
      {
        label: 'Across ALL Sources Elections (Same as source EEVOL)',
        value: 'true',
        readOnly: true,
        key: 'ALL',
        type: ''
      }
    ],
    allowAcrossAllSources: true,
    sameAsSource: 'EEVOL',
    sameAsSourceId: 'E',
    invElectChangeAllowed: true,
    customEdit: true
  }
};

export const PariticipantContributionDataUpdate = {
  status: 'SUCCESS',
  data: {
    contribElectionOptions: [
      {
        value: 'P',
        displayText: 'Percent'
      }
    ],
    contribElection: [
      {
        label: 'PRETAX',
        value: '0.0',
        readOnly: false,
        key: 'A',
        type: 'P'
      },
      {
        label: 'AFTERTAX',
        value: '0.0',
        readOnly: false,
        key: 'G',
        type: 'P'
      },
      {
        label: 'PRETAX Mock',
        value: '0.0',
        readOnly: false,
        key: 'AM',
        type: 'P'
      },
      {
        label: 'AFTERTAX Mock',
        value: '0.0',
        readOnly: false,
        key: 'GM',
        type: 'P'
      }
    ],
    contribMixedDeferrals: false,
    contribDeferralType: 'P',
    contribTotalMaxDefPct: 22,
    contribTotalMaxDefAmt: 10,
    catchupDeferralType: 'P',
    catchupContribElectionOptions: [
      {
        value: 'P',
        displayText: 'Percent'
      },
      {
        value: 'A',
        displayText: 'Amount'
      }
    ],
    catchupContribElection: [
      {
        label: 'CatchUp Contrib Election 1',
        value: '3.3',
        readOnly: false,
        key: 'CatchUp_Contrib_Election_1',
        type: 'A'
      },
      {
        label: 'CatchUp Contrib Election 2',
        value: '4.4',
        readOnly: false,
        key: 'CatchUp_Contrib_Election_2',
        type: 'A'
      }
    ],
    catchupContribMixedDeferrals: true,
    catchupContribTotalMaxDefPct: 10,
    catchupContribTotalMinDefPct: 10,
    catchupContribTotalMaxDefAmt: 10,
    catchupContribTotalMinDefAmt: 10,
    investmentElection: [
      {
        label: 'Across ALL Sources Elections (Same as source PRETAX)',
        value: false,
        readOnly: false,
        key: 'ALL',
        type: ''
      },
      {
        label: 'PRE-TAX VOL Elections',
        value: false,
        readOnly: false,
        key: 'PRETAX',
        type: ''
      },
      {
        label: 'Profit Share Elections',
        value: false,
        readOnly: false,
        key: 'PROFIT',
        type: ''
      }
    ],
    allowAcrossAllSources: true,
    sameAsSource: 'PRETAX',
    sameAsSourceId: 'A',
    invElectChangeAllowed: false,
    customEdit: false
  }
};
export const ParticipantFundData = {
  status: 'SUCCESS',
  data: {
    fundSources: [],
    invElectChangeAllowed: true,
    readOnlyFieldsExist: false,
    sourceMap: [
      {
        sourceId: 'ALL',
        sourceName: 'Across ALL Sources'
      }
    ]
  }
};
export const ParticipantFundDataOld = {
  status: 'SUCCESS',
  data: {
    fundSources: [
      {
        fundName: 'Voya Large Cap Growth Port Inst',
        showFundName: 'Voya Large Cap Growth Port...',
        percents: [
          {
            investmentId: '30',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY Invesco Eqty & Inc Port I',
        showFundName: 'VY Invesco Eqty & Inc Port...',
        percents: [
          {
            investmentId: '7E',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY Oppenhmr Global Port I',
        percents: [
          {
            investmentId: '7L',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Global Bond Port I',
        percents: [
          {
            investmentId: '7S',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya International Index Port I',
        showFundName: 'Voya International Index P...',
        percents: [
          {
            investmentId: 'C7',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Fixed Plus Account II',
        percents: [
          {
            investmentId: 'G1',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Growth and Income Port I',
        showFundName: 'Voya Growth and Income Por...',
        percents: [
          {
            investmentId: 'MD',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Balanced Portfolio I',
        percents: [
          {
            investmentId: 'MG',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Strategic Alloc Growth Port I',
        showFundName: 'Voya Strategic Alloc Growt...',
        percents: [
          {
            investmentId: 'MH',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Strategic Alloc Moderate Port I',
        showFundName: 'Voya Strategic Alloc Moder...',
        percents: [
          {
            investmentId: 'MI',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Strategic Alloc Conserv Port I',
        showFundName: 'Voya Strategic Alloc Conse...',
        percents: [
          {
            investmentId: 'MJ',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Index Plus LargeCap Portfolio I',
        showFundName: 'Voya Index Plus LargeCap P...',
        percents: [
          {
            investmentId: 'MK',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Small Company Portfolio I',
        showFundName: 'Voya Small Company Portfol...',
        percents: [
          {
            investmentId: 'MO',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Index Plus MidCap Portfolio I',
        showFundName: 'Voya Index Plus MidCap Por...',
        percents: [
          {
            investmentId: 'MU',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Fidelity VIP Equity-Income',
        percents: [
          {
            investmentId: 'RB',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Fidelity VIP Contrafund Port-I',
        showFundName: 'Fidelity VIP Contrafund Po...',
        percents: [
          {
            investmentId: 'RD',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'ING UBS U.S. Lrg Cap Eqty Port I',
        showFundName: 'ING UBS U.S. Lrg Cap Eqty ...',
        percents: [
          {
            investmentId: 'S2',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY TRowePrice Grwth Eqty Port I',
        showFundName: 'VY TRowePrice Grwth Eqty P...',
        percents: [
          {
            investmentId: 'S4',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'ING Growth and Income Core Port I',
        showFundName: 'ING Growth and Income Core...',
        percents: [
          {
            investmentId: 'S5',
            sourceId: 'ALL',
            currentPercent: '10.00',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya SmallCap Opportunities Prt I',
        showFundName: 'Voya SmallCap Opportunitie...',
        percents: [
          {
            investmentId: 'SI',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya International Value Port I',
        showFundName: 'Voya International Value P...',
        percents: [
          {
            investmentId: 'SL',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Calvert VP SRI Balanced Portfolio',
        showFundName: 'Calvert VP SRI Balanced Po...',
        percents: [
          {
            investmentId: 'V1',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY BlackRock Lrg Cp Grw Port Inst',
        showFundName: 'VY BlackRock Lrg Cp Grw Po...',
        percents: [
          {
            investmentId: 'WF',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      }
    ],
    invElectChangeAllowed: true,
    readOnlyFieldsExist: false,
    sourceMap: [
      {
        sourceId: 'ALL',
        sourceName: 'Across ALL Sources'
      },
      {
        sourceId: 'BALL',
        sourceName: 'Across ALL Sources'
      }
    ]
  }
};

export const ParticiapantFinalData = {
  participantInfo: {
    partSSN: '123456',
    firstName: 'Test',
    lastName: 'Test',
    middleInitial: '',
    state: '',
    zipCode: '',
    country: '',
    email: '',
    statusCode: '',
    birthDate: '',
    hireDate: '',
    rehireDate: '',
    termDate: '',
    termCode: '',
    defType: '',
    catchupDefType: '',
    planId: '666006',
    enrollFlag: '',
    newDivsubUpdated: '',
    sameAsSource: '',
    mstarFlag: 'false',
    qdiaFlag: 'false'
  },
  optionalDataElement: [
    {
      code: 'PHPT34',
      value: 'value1'
    },
    {
      code: 'PHPT122',
      value: 'value1'
    }
  ],
  contributionElections: [
    {
      code: 'A',
      value: '0'
    },
    {
      code: 'A',
      value: '0'
    }
  ],
  catchUpContributionElections: [
    {
      code: 'A',
      value: '0'
    },
    {
      code: 'A',
      value: '0'
    }
  ],
  investmentElectionsList: [
    {
      code: 'test',
      newPercent: '19'
    },
    {
      code: 'test2',
      newPercent: '20'
    }
  ]
};

export const ParticipantConfirmationData = {
  ParticipantData: {
    requiredData: {
      lastName: 'Doe',
      firstName: 'John',
      middleInitial: 'E',
      address1: '123 MAIN',
      address2: 'TEST',
      city: 'ANYWHERE',
      state: 'FL',
      zipCode: '32210',
      country: 'USA',
      email: '',
      statusCode: '20',
      birthDate: '01/01/1982',
      hireDate: '01/01/2018',
      termCode: '',
      enrollFlag: false,
      mstarFlag: false,
      qdiaFlag: false,
      termReadOnlyFlag: true,
      displayMakeActive: true,
      ssn: '123456789'
    },
    optionalData: [
      {
        label: 'Marital Status',
        componentType: 'dropdown',
        value: '1',
        readOnly: true,
        disabled: false,
        option: [
          {
            value: '1',
            displayText: 'Single'
          },
          {
            value: '2',
            displayText: 'Married'
          }
        ],
        required: true,
        type: '',
        key: 'PTPH023',
        length: 0,
        accumulate: true
      },
      {
        label: 'Gender',
        componentType: 'dropdown',
        value: '1',
        readOnly: true,
        disabled: false,
        option: [
          {
            value: '1',
            displayText: 'Male'
          },
          {
            value: '2',
            displayText: 'Female'
          }
        ],
        required: true,
        type: '',
        key: 'PTPH030',
        length: 0,
        accumulate: true
      },
      {
        label: 'current year NUMBER-OF-HOURS  ',
        componentType: 'text',
        value: '0.0',
        readOnly: false,
        disabled: false,
        option: [],
        required: true,
        type: 'Float',
        key: 'XX_PTPH085',
        length: 7,
        accumulate: false
      },
      {
        label: 'YTD  NUMBER-OF-HOURS  ',
        componentType: 'text',
        value: '0.00',
        readOnly: true,
        disabled: false,
        option: [],
        required: true,
        type: 'Float',
        key: 'PTPH085',
        length: 7,
        accumulate: true
      },
      {
        label: 'Current ELIG-HRS-ANNIV',
        componentType: 'text',
        value: '0.0',
        readOnly: false,
        disabled: false,
        option: [],
        required: true,
        type: 'Float',
        key: 'XX_PTPH340',
        length: 11,
        accumulate: false
      },
      {
        label: 'YTD ELIG-HRS-ANNIV    ',
        componentType: 'text',
        value: '0.00',
        readOnly: true,
        disabled: false,
        option: [],
        required: true,
        type: 'Float',
        key: 'PTPH340',
        length: 11,
        accumulate: true
      },
      {
        label: 'REHIRE DATE',
        componentType: 'text',
        value: '',
        readOnly: true,
        disabled: false,
        option: [],
        required: true,
        type: 'String',
        key: 'PTPH740',
        length: 1,
        accumulate: true
      },
      {
        label: 'Leave of Absence Start Date',
        componentType: 'text',
        value: '',
        readOnly: true,
        disabled: false,
        option: [],
        required: false,
        type: 'Date',
        key: 'PTPH771',
        length: 0,
        accumulate: true
      },
      {
        label: 'Leave of Absence End Date  ',
        componentType: 'text',
        value: '',
        readOnly: true,
        disabled: false,
        option: [],
        required: false,
        type: 'Date',
        key: 'PTPH772',
        length: 0,
        accumulate: true
      },
      {
        label: 'Private Salary Supplement  ',
        componentType: 'text',
        value: '0.00',
        readOnly: true,
        disabled: false,
        option: [],
        required: true,
        type: 'Float',
        key: 'PTPH812',
        length: 11,
        accumulate: true
      },
      {
        label: 'Salary Code',
        componentType: 'dropdown',
        value: 'C',
        readOnly: true,
        disabled: false,
        option: [
          {
            value: 'C',
            displayText: 'City'
          },
          {
            value: 'P',
            displayText: 'Private'
          }
        ],
        required: true,
        type: '',
        key: 'PTPH830',
        length: 0,
        accumulate: true
      },
      {
        label: 'Union Code ',
        componentType: 'dropdown',
        value: '2',
        readOnly: true,
        disabled: false,
        option: [
          {
            value: '0',
            displayText: 'Non-Union'
          },
          {
            value: '1',
            displayText: 'DC1707'
          },
          {
            value: '2',
            displayText: 'DC37'
          },
          {
            value: '3',
            displayText: 'CSA '
          },
          {
            value: '4',
            displayText: 'Other '
          }
        ],
        required: false,
        type: '',
        key: 'PTPH835',
        length: 0,
        accumulate: true
      },
      {
        label: 'LOA start reason',
        componentType: 'dropdown',
        value: '',
        readOnly: true,
        disabled: false,
        option: [
          {
            value: 'F',
            displayText: 'FMLA'
          },
          {
            value: 'M',
            displayText: 'Military            '
          },
          {
            value: 'O',
            displayText: 'Other '
          }
        ],
        required: false,
        type: '',
        key: 'PTPH841',
        length: 0,
        accumulate: true
      },
      {
        label: 'LOA return reason',
        componentType: 'dropdown',
        value: '',
        readOnly: true,
        disabled: false,
        option: [
          {
            value: '1',
            displayText: 'with cause'
          },
          {
            value: '2',
            displayText: 'Laid off'
          },
          {
            value: '3',
            displayText: 'Special'
          },
          {
            value: '4',
            displayText: 'retirement'
          },
          {
            value: '5',
            displayText: '100% withdrawl'
          }
        ],
        required: true,
        type: '',
        key: 'PTPH842',
        length: 0,
        accumulate: true
      }
    ],
    participantContribution: {
      contribElectionOptions: [
        {
          value: 'P',
          displayText: 'Percent'
        }
      ],
      contribElection: [
        {
          label: 'PRETAX',
          value: '0.0',
          readOnly: false,
          key: 'A',
          type: 'P',
          defLimit: {
            code: 'A',
            minPercent: 0,
            maxPercent: 70,
            minAmt: 0,
            maxAmt: 1420
          }
        },
        {
          label: 'AFTERTAX',
          value: '0.0',
          readOnly: false,
          key: 'G',
          type: 'P',
          defLimit: {
            code: 'G',
            minPercent: 0,
            maxPercent: 90,
            minAmt: 0,
            maxAmt: 1230
          }
        }
      ],
      contribMixedDeferrals: false,
      contribDeferralType: 'P',
      contribTotalMaxDefPct: 22,
      contribTotalMaxDefAmt: 0,
      catchupContribElectionOptions: [],
      catchupContribElection: [
        {
          label: 'PRETAX',
          value: '0.0',
          readOnly: false,
          key: 'A',
          type: 'P'
        },
        {
          label: 'AFTERTAX',
          value: '0.0',
          readOnly: false,
          key: 'G',
          type: 'P'
        }
      ],
      catchupContribMixedDeferrals: false,
      catchupContribTotalMaxDefPct: 0,
      catchupContribTotalMinDefPct: 0,
      catchupContribTotalMaxDefAmt: 0,
      catchupContribTotalMinDefAmt: 0,
      investmentElection: [
        {
          label: 'Across ALL Sources Elections (Same as source PRETAX)',
          value: 'true',
          readOnly: true,
          key: 'ALL',
          type: ''
        }
      ],
      allowAcrossAllSources: true,
      sameAsSource: 'PRETAX',
      sameAsSourceId: 'A',
      invElectChangeAllowed: false,
      customEdit: false
    },

    participantContributionInvestmentData: {
      fundSources: [
        {
          fundName: 'Voya Large Cap Growth Port Inst',
          showFundName: 'Voya Large Cap Growth Port...',
          percents: [
            {
              investmentId: '30',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'VY Invesco Eqty & Inc Port I',
          showFundName: 'VY Invesco Eqty & Inc Port...',
          percents: [
            {
              investmentId: '7E',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'VY Oppenhmr Global Port I',
          percents: [
            {
              investmentId: '7L',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Global Bond Port I',
          percents: [
            {
              investmentId: '7S',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya International Index Port I',
          showFundName: 'Voya International Index P...',
          percents: [
            {
              investmentId: 'C7',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Fixed Plus Account II',
          percents: [
            {
              investmentId: 'G1',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Growth and Income Port I',
          showFundName: 'Voya Growth and Income Por...',
          percents: [
            {
              investmentId: 'MD',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Balanced Portfolio I',
          percents: [
            {
              investmentId: 'MG',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Strategic Alloc Growth Port I',
          showFundName: 'Voya Strategic Alloc Growt...',
          percents: [
            {
              investmentId: 'MH',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Strategic Alloc Moderate Port I',
          showFundName: 'Voya Strategic Alloc Moder...',
          percents: [
            {
              investmentId: 'MI',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Strategic Alloc Conserv Port I',
          showFundName: 'Voya Strategic Alloc Conse...',
          percents: [
            {
              investmentId: 'MJ',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Index Plus LargeCap Portfolio I',
          showFundName: 'Voya Index Plus LargeCap P...',
          percents: [
            {
              investmentId: 'MK',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Small Company Portfolio I',
          showFundName: 'Voya Small Company Portfol...',
          percents: [
            {
              investmentId: 'MO',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya Index Plus MidCap Portfolio I',
          showFundName: 'Voya Index Plus MidCap Por...',
          percents: [
            {
              investmentId: 'MU',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Fidelity VIP Equity-Income',
          percents: [
            {
              investmentId: 'RB',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Fidelity VIP Contrafund Port-I',
          showFundName: 'Fidelity VIP Contrafund Po...',
          percents: [
            {
              investmentId: 'RD',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'ING UBS U.S. Lrg Cap Eqty Port I',
          showFundName: 'ING UBS U.S. Lrg Cap Eqty ...',
          percents: [
            {
              investmentId: 'S2',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'VY TRowePrice Grwth Eqty Port I',
          showFundName: 'VY TRowePrice Grwth Eqty P...',
          percents: [
            {
              investmentId: 'S4',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'ING Growth and Income Core Port I',
          showFundName: 'ING Growth and Income Core...',
          percents: [
            {
              investmentId: 'S5',
              sourceId: 'ALL',
              currentPercent: '10.00',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya SmallCap Opportunities Prt I',
          showFundName: 'Voya SmallCap Opportunitie...',
          percents: [
            {
              investmentId: 'SI',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Voya International Value Port I',
          showFundName: 'Voya International Value P...',
          percents: [
            {
              investmentId: 'SL',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'Calvert VP SRI Balanced Portfolio',
          showFundName: 'Calvert VP SRI Balanced Po...',
          percents: [
            {
              investmentId: 'V1',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        },
        {
          fundName: 'VY BlackRock Lrg Cp Grw Port Inst',
          showFundName: 'VY BlackRock Lrg Cp Grw Po...',
          percents: [
            {
              investmentId: 'WF',
              sourceId: 'ALL',
              currentPercent: '0',
              readOnly: false
            },
            {
              investmentId: '31',
              sourceId: 'BALL',
              currentPercent: '0',
              readOnly: false
            }
          ]
        }
      ],
      invElectChangeAllowed: true,
      readOnlyFieldsExist: false,
      sourceMap: [
        {
          sourceId: 'ALL',
          sourceName: 'Across ALL Sources'
        },
        {
          sourceId: 'BALL',
          sourceName: 'Across ALL Sources'
        }
      ]
    }
  }
};

// *****************************************************

export const testData = {
  participantContributionInvestmentData: {
    fundSources: [
      {
        fundName: 'Voya Large Cap Growth Port Inst',
        showFundName: 'Voya Large Cap Growth Port...',
        percents: [
          {
            investmentId: '30',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY Invesco Eqty & Inc Port I',
        showFundName: 'VY Invesco Eqty & Inc Port...',
        percents: [
          {
            investmentId: '7E',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY Oppenhmr Global Port I',
        percents: [
          {
            investmentId: '7L',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Global Bond Port I',
        percents: [
          {
            investmentId: '7S',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya International Index Port I',
        showFundName: 'Voya International Index P...',
        percents: [
          {
            investmentId: 'C7',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Fixed Plus Account II',
        percents: [
          {
            investmentId: 'G1',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Growth and Income Port I',
        showFundName: 'Voya Growth and Income Por...',
        percents: [
          {
            investmentId: 'MD',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Balanced Portfolio I',
        percents: [
          {
            investmentId: 'MG',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Strategic Alloc Growth Port I',
        showFundName: 'Voya Strategic Alloc Growt...',
        percents: [
          {
            investmentId: 'MH',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Strategic Alloc Moderate Port I',
        showFundName: 'Voya Strategic Alloc Moder...',
        percents: [
          {
            investmentId: 'MI',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Strategic Alloc Conserv Port I',
        showFundName: 'Voya Strategic Alloc Conse...',
        percents: [
          {
            investmentId: 'MJ',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Index Plus LargeCap Portfolio I',
        showFundName: 'Voya Index Plus LargeCap P...',
        percents: [
          {
            investmentId: 'MK',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Small Company Portfolio I',
        showFundName: 'Voya Small Company Portfol...',
        percents: [
          {
            investmentId: 'MO',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya Index Plus MidCap Portfolio I',
        showFundName: 'Voya Index Plus MidCap Por...',
        percents: [
          {
            investmentId: 'MU',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Fidelity VIP Equity-Income',
        percents: [
          {
            investmentId: 'RB',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Fidelity VIP Contrafund Port-I',
        showFundName: 'Fidelity VIP Contrafund Po...',
        percents: [
          {
            investmentId: 'RD',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'ING UBS U.S. Lrg Cap Eqty Port I',
        showFundName: 'ING UBS U.S. Lrg Cap Eqty ...',
        percents: [
          {
            investmentId: 'S2',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY TRowePrice Grwth Eqty Port I',
        showFundName: 'VY TRowePrice Grwth Eqty P...',
        percents: [
          {
            investmentId: 'S4',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'ING Growth and Income Core Port I',
        showFundName: 'ING Growth and Income Core...',
        percents: [
          {
            investmentId: 'S5',
            sourceId: 'ALL',
            currentPercent: '10.00',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya SmallCap Opportunities Prt I',
        showFundName: 'Voya SmallCap Opportunitie...',
        percents: [
          {
            investmentId: 'SI',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Voya International Value Port I',
        showFundName: 'Voya International Value P...',
        percents: [
          {
            investmentId: 'SL',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'Calvert VP SRI Balanced Portfolio',
        showFundName: 'Calvert VP SRI Balanced Po...',
        percents: [
          {
            investmentId: 'V1',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      },
      {
        fundName: 'VY BlackRock Lrg Cp Grw Port Inst',
        showFundName: 'VY BlackRock Lrg Cp Grw Po...',
        percents: [
          {
            investmentId: 'WF',
            sourceId: 'ALL',
            currentPercent: '0',
            readOnly: false
          },
          {
            investmentId: '31',
            sourceId: 'BALL',
            currentPercent: '0',
            readOnly: false
          }
        ]
      }
    ],
    invElectChangeAllowed: true,
    readOnlyFieldsExist: false,
    sourceMap: [
      {
        sourceId: 'ALL',
        sourceName: 'Across ALL Sources'
      },
      {
        sourceId: 'BALL',
        sourceName: 'Across ALL Sources'
      }
    ]
  }
};
