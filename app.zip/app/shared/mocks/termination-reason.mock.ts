export const TerminationReasonList =
{
    "status": "SUCCESS",
    "data": {
        "displayType": "S",
        "terminationReasons": [
            {
                "value": "1",
                "displayText": "With Cause",
                "type": "S"
            },
            {
                "value": "2",
                "displayText": "Laid Off",
                "type": "S"
            },
            {
                "value": "3",
                "displayText": "Special",
                "type": "C"
            },
            {
                "value": "4",
                "displayText": "Retirement",
                "type": "S"
            },
            {
                "value": "5",
                "displayText": "Permanent Disability",
                "type": "C"
            }
        ]
    }
}
