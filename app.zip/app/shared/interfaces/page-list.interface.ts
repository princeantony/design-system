export interface IPage{
    key: string;
    label:string;
    value: boolean;
}
export interface IPageList{
    key: string;
    label: string;
    value: boolean;
    isEnabled: boolean;
    subItems: IPage[];
}
