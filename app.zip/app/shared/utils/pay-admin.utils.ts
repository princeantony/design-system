import { IListItem } from '../interfaces/list-item.interface';


export class Utils {
  constructor() {}
  chunkArray<T>(arr: Array<T>, chunkSize: number): Array<Array<T>> {
    return arr.reduce(
      (prevVal: any, currVal: any, currIndx: number, array: Array<T>) =>
        !(currIndx % chunkSize)
          ? prevVal.concat([array.slice(currIndx, currIndx + chunkSize)])
          : prevVal,
      []
    );
  }
}

export function isEmptyObject(obj) {
  return Object.keys(obj).length === 0;
}
export function isInteger(value: any): value is number {
  return typeof value === 'number' && isFinite(value) && Math.floor(value) === value;
}
export function isNumber(value: any): value is number {
  return !isNaN(toInteger(value));
}
export function toInteger(value: any): number {
  return parseInt(`${value}`, 10);
}
export function padNumber(value: number) {
  if (isNumber(value)) {
    return `0${value}`.slice(-2);
  } else {
    return '';
  }
}
export function getDateObject(value: any): any {
  if (value) {
  const dateArrray = value.split('/');
  return {month: Number(dateArrray[0]), day: Number(dateArrray[1]), year: Number(dateArrray[2])};
  } else {
    return;
  }

}
export function  getVoyaSelectItem(inputItem: any[]): IListItem[] {
  const newList: IListItem[] = [];
  inputItem.forEach(item => {
    newList.push({ displayText: item.displayText, value: item.statusCode });
  });
  return newList;
}
export function  getSelectItemById(inputItem: any[]): IListItem[] {
  const newList: IListItem[] = [];
  inputItem.forEach(item => {
    newList.push({ displayText: item.text, value: item.id });
  });
  return newList;
}
