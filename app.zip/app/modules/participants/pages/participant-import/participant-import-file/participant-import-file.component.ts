import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { TemplatesService } from 'src/app/modules/templates/services/templates.service';
import { TemplatesStore } from 'src/app/modules/templates/store/templates.store';
import { importMapping } from 'src/app/shared/config/template.config';
import { APP_CONST, SUB_TITLE } from 'src/app/shared/constants/app.constants';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

@Component({
  selector: 'app-participant-import-file',
  templateUrl: './participant-import-file.component.html',
  styleUrls: ['./participant-import-file.component.scss']
})
export class ParticipantImportFileComponent implements OnInit {
  importFileItems: any;
  hidePageTitle = false;
  subTitle: string;
  planNumber: string;
  showUpload = false;
  sampleFileUrl: string;
  file: any;
  fileName: string;
  importType: string;
  fileType: string;
  fileError: string;
  fileImportForm = this.fb.group({
    importFile: ['no'],
    importFileName: []
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private templateService: TemplatesService,
    private previousRouteService: PreviousRouteService
  ) {}

  ngOnInit() {
    this.importFileItems = [
      { label: 'Yes', value: 'yes' },
      { label: 'No', value: 'no' }
    ];
    PayAdminGlobalState.previousPage = this.previousRouteService.getPreviousUrl();
    this.planNumber = PayAdminGlobalState.planNumber;
    this.importType = TemplatesStore.importType = 'E';
    console.log('---------import mapping', importMapping);
    this.sampleFileUrl = importMapping[this.importType]['fileUrl'];
    this.subTitle = SUB_TITLE.FILE_IMPORT;
  }

  gotoBack() {
    this.router.navigate(['/home']);
  }

  checkUpload(e: any) {
    console.log('----event', e);
    this.fileError = '';
    this.file = e.target.files;
    if (this.file.length > 0) {
      this.fileName = this.file[0].name;
      if (this.file[0].size === 0) {
        this.fileError = 'File size must be greater than 0';
        this.fileImportForm.setErrors({ invalid: true });
      } else if (this.file[0].size > 5000000) {
        this.fileError = 'File size must be lesser than 5MB';
        this.fileImportForm.setErrors({ invalid: true });
      } else if (this.file[0].size > 0 && this.file[0].size <= 5000000 ) {
        this.fileName = this.file[0].name;
      // this.fileImportForm.setErrors({ invalid: false });
      }
    }

  }
  showUploadFile(e: any) {
    if (this.fileImportForm.value.importFile === 'yes') {
      this.showUpload = true;
      this.fileImportForm.controls['importFileName'].setValue('');
      this.fileName = '';
    } else {
      this.fileError = '';
      this.showUpload = false;
    }
  }

  onSubmit() {
   // debugger
    console.log('-----form', this.file);
    const importFileValue = this.fileImportForm.value.importFile;
    if (importFileValue === 'yes') {
      const fileList: FileList = this.file;
      if (fileList.length > 0) {
        const file: File = fileList[0];
        const fileNameSplit = file.name.split('.');

        const formData: FormData = new FormData();
        TemplatesStore.importFileType = fileNameSplit[fileNameSplit.length - 1];
        console.log(
          '---PayAdminGlobalState.importFileData.fileType',
          TemplatesStore.importFileType
        );
        formData.append('fileName', file);
        formData.append('fileName', file, file.name);
        formData.append('fileType', TemplatesStore.importFileType);
        formData.append('importType', this.importType);
        console.log('----------------formdata', formData);
        this.templateService.uploadFile(formData).subscribe(
          response => {
            console.log('------response', response);
            if (response.status === APP_CONST.SUCCESS) {
              TemplatesStore.rawFileData = response.data.fileData;
              this.fileType = TemplatesStore.importFileType;
              if (this.fileType === 'csv' || this.fileType === 'xls' || this.fileType === 'xlsx' || this.fileType === 'xlsm') {
                TemplatesStore.isFW = false;
              } else {
                TemplatesStore.isFW = true;
              }
              this.router.navigate(['/template/select']);
            }
          },
          err => {
            console.log('Error', err);
          }
        );
      }
    } else {
      this.router.navigate(['/updateBatchParticipant']);
    }
  }

}
