import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { importMapping } from 'src/app/shared/config/template.config';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { URLs } from '../../constants/template.constants';
import { IcolumnList, IFileData, ITemplate } from '../../model/template.model';
import { TemplatesService } from '../../services/templates.service';
import { TemplatesStore } from '../../store/templates.store';
import { TemplateGridHeaderComponent } from '../template-grid-header/template-grid-header.component';

@Component({
  selector: 'app-template-non-fixed-width',
  templateUrl: './template-non-fixed-width.component.html',
  styleUrls: ['./template-non-fixed-width.component.scss']
})
export class TemplateNonFixedWidthComponent implements OnInit {
  @Input() isNewTemplate: boolean;
  templateForm = this.fb.group({
    templateId: [],
    headerCount: ['0'],
    trailerCount: ['0']
  });
  planNumber: string;
  subTitle: string;
  hidePageTitle = false;
  fileData: any;
  fileType: string;
  templateData: ITemplate;
  headerDropdown: any;
  private rowData: any[];
  private columnDefs = [];
  gridApi: any;
  gridColumnApi: any;
  params: any;
  frameworkComponents: any;
  templateId: string;
  columnList: IcolumnList[] = [];
  columnMapping: any;
  isError = false;
  errorObj: any;
  singleClickEdit = false;
  defaultColDef: any;
  suppressClickEdit = true;
  successMessage: string;
  importType: string;
  columnValidationObj: any;
  editType: string;
  rawData: any;
  editableRows = [];
  constructor(
    private fb: FormBuilder,
    private templateservice: TemplatesService,
    private route: ActivatedRoute,
    private modalService: ModalService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private previousRouteService: PreviousRouteService
  ) {}

  ngOnInit() {
    PayAdminGlobalState.previousPage = this.previousRouteService.getPreviousUrl();
    this.planNumber = PayAdminGlobalState.planNumber;
    this.rawData = TemplatesStore.rawFileData;
    this.importType = TemplatesStore.importType;
    this.fileType = TemplatesStore.importFileType;
    // this.templateId = TemplatesStore.templateId;
    this.editType = 'fullRow';
    this.spinner.show();
    this.templateservice.getAvailableColumns().subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.headerDropdown = response.data.availableColumnList;
          if (!this.isNewTemplate) {
            this.templateservice.getTemplateDetails().subscribe(
              template => {
                if (template.status === APP_CONST.SUCCESS) {
                  const data = template.data;
                  /*  this.templateForm = this.fb.group({
                    templateId: [data.templateId],
                    headerCount: [data.headerCount],
                    trailerCount: [data.trailerCount]
                  }); */
                  this.templateForm.controls['templateId'].setValue(
                    data.templateId
                  );
                  this.templateForm.controls['headerCount'].setValue(
                    data.headerCount
                  );
                  this.templateForm.controls['trailerCount'].setValue(
                    data.trailerCount
                  );
                  this.columnMapping = data.columnList;
                  this.createGridData();
                  this.spinner.hide();
                }
              },
              err => {
                this.spinner.hide();
                console.log('Error', err);
              }
            );
          } else {
            this.createGridData();
            this.spinner.hide();
          }
        }
      },
      err => {
        this.spinner.hide();
        console.log('Error', err);
      }
    );
  }
  /* onRowEditingStarted(event) {
    console.log('--------onRowClicked started', event);
    if (this.errorObj) {
    const ssnColumn = _.find(this.columnDefs, [
      'headerName',
      'ssn'
    ]).field;
      if (
        !(_.find(this.errorObj, ['ssn', event.data[ssnColumn]]))
      ) {
        this.gridApi.stopEditing();
      }
  }
  } */
  onRowClicked(event) {
    if (this.errorObj && this.isError) {
      if (_.indexOf(this.editableRows, event.rowIndex) === -1) {
        this.gridApi.stopEditing();
      }
    }
  }
  createGridData() {
    console.log('---------------this.testdata', this.rawData);
    this.frameworkComponents = { agColumnHeader: TemplateGridHeaderComponent };
    // const colNum = this.fileData[0].length;
    let noOfCols = 0;
    if (this.isNewTemplate) {
      for (const row of this.rawData) {
        if (row.length > noOfCols) {
          noOfCols = row.length;
        }
      }
    } else {
      noOfCols = this.columnMapping.length;
    }

    for (let index = 0; index < noOfCols; index++) {
      console.log('-----colnumber', this.columnMapping);
      // const element = array[index];
      this.columnDefs.push({
        field: this.isNewTemplate
          ? (index + 1).toString()
          : this.columnMapping[index].colNumber,
        headerName: this.isNewTemplate ? null : this.columnMapping[index].value,
        editable: true,
        headerComponentParams: { options: this.headerDropdown }
      });
      this.defaultColDef = { editable: false };
    }
    console.log('------columndefs', this.columnDefs);
    const rows = this.rawData;
    this.rowData = [];
    for (let i = 0; i < rows.length; i++) {
      const obj = {};
      for (let j = 0; j < rows[i].length; j++) {
        obj[(j + 1).toString()] = rows[i][j];
      }
      this.rowData.push(obj);
    }
    console.log('---this.rowData', this.rowData);
    // console.log("--------coldef", this.columnDefs);
  }

  saveTemplate() {
    console.log('--------save template function', this.templateForm);
    console.log('------------this.gridApi', this.params);
    this.columnList = [];
    this.successMessage = '';
    this.gridApi.gridOptionsWrapper.gridOptions.columnDefs.forEach(element => {
      this.columnList.push({
        value: element.headerName,
        colNumber: element.field
      });
    });
    this.templateData = this.templateForm.value;
    this.templateData.importType = this.importType;
    this.templateData.fileType = this.fileType;
    this.templateData.isNewTemplate = this.isNewTemplate;
    this.templateData.columnList = this.columnList;

    console.log('-----------saveTemplate templateData', this.templateData);
    this.spinner.show();
    this.templateservice.saveTemplate(this.templateData).subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          console.log(response.message);
          this.successMessage = response.messages[0];
          this.isNewTemplate = false;
          TemplatesStore.templateId = this.templateForm.value.templateId;
          this.spinner.hide();
        }
      },
      err => {
        this.spinner.hide();
        console.log('Error', err);
        if (err.error.msg) {
          this.columnValidationObj = [err.error.error.msg];
        }
      }
    );
  }
  saveAndContinue() {
    this.gridApi.stopEditing();
    this.columnValidationObj = [];
    this.editableRows = [];
    this.isError = false;
    // validation for duplicate column selection
    this.columnList = [];

    console.log(
      '------------columndefs',
      this.gridApi.gridOptionsWrapper.gridOptions.columnDefs
    );
    this.gridApi.gridOptionsWrapper.gridOptions.columnDefs.forEach(element => {
      this.columnList.push({
        value: element.headerName,
        colNumber: element.field
      });
    });
    const mappedArray = this.columnList.map(function(item) {
      return item.value;
    });
    console.log('---mapped array', mappedArray);
    const duplicateCols = [];
    _.filter(mappedArray, function(item, id) {
      console.log(item);
      if (item !== 'na') {
      if (mappedArray.indexOf(item) !== id) {
        console.log(_.indexOf(duplicateCols, item));
        if (_.indexOf(duplicateCols, item) < 0) {
          duplicateCols.push(item);
        }
      }
    }
    });
    const duplicateColNames = [];
    console.log('-------duplicateCols', duplicateCols);
    if (duplicateCols.length > 0) {
      for (let i = 0; i < duplicateCols.length; i++) {
        if (duplicateCols[i]) {
          duplicateColNames.push(
            _.find(this.headerDropdown, ['value', duplicateCols[i]]).displayText
          );
        }
      }
    }

    console.log('----duplicate col', duplicateColNames);
    if (duplicateColNames.length > 0) {
      this.columnValidationObj.push(
        'Duplicate columns found for ' + duplicateColNames
      );
    }
    // validation template name
    const templateId = this.templateForm.value.templateId;
    console.log('-------templateId', templateId);
    if (!templateId) {
      this.columnValidationObj.push('Template name is required');
    }
    console.log('----------column list', this.columnList);
    // validation column selection
    const colnums = [];

    for (const col of this.columnList) {
      if (col.value === null) {
        console.log('----col number', col.colNumber);
        colnums.push('Column ' + col.colNumber + ' ');
      }
    }
    if (colnums.length > 0) {
      this.columnValidationObj.push('Select heading for ' + colnums);
    }
    const ssnCol = _.find(this.columnList, ['value', 'ssn']);
    if (!ssnCol) {
      this.columnValidationObj.push(
        'Please select a column for Social Security Number'
      );
    }

    // validation ends
    if (this.columnValidationObj.length > 0) {
      // alert(duplicateColNames);
      console.log(
        '-------------this.clientValidationObj',
        this.columnValidationObj
      );
      console.log('---------------dropdown', this.headerDropdown);
      console.log(duplicateColNames);
    } else {
      const fileData = [];
      for (let i = 0; i < this.rowData.length; i++) {
        const a = [];
        _.forEach(this.rowData[i], function(value, key) {
          a.push(value);
        });
        fileData.push(a);
      }
      console.log('---------edited file data', fileData);
      // TemplatesStore.importFileData = fileData;
      this.templateData = this.templateForm.value;
      this.templateData.importType = this.importType;
      this.templateData.fileType = this.fileType;
      this.templateData.isNewTemplate = this.isNewTemplate;
      this.templateData.columnList = this.columnList;
      console.log('-----------saveTemplate templateData', this.templateData);
      this.spinner.show();
      this.templateservice.saveTemplate(this.templateData).subscribe(
        templateResponse => {
          if (templateResponse.status === APP_CONST.SUCCESS) {
            console.log(templateResponse.messages);
            // this.successMessage = templateResponse.messages[0];
            this.isNewTemplate = false;
            TemplatesStore.templateId = this.templateForm.value.templateId;
            // const url = importMapping[this.importType]['serviceUrl'];
            /* if (!this.fileData) {
              this.templateservice
                .getMappedData(this.rawData)
                .subscribe(mappedResponse => {
                  if (mappedResponse.status === APP_CONST.SUCCESS) {
                    this.fileData = mappedResponse.data.mappedData;
                    this.rowData = this.fileData;

                    this.valiadateFileData(templateFileData);
                  }
                });
            } else { */

            const columnDefs = this.gridApi.gridOptionsWrapper.gridOptions
              .columnDefs;
            console.log('-----columnDefs', columnDefs);
            console.log('-----rowdata', this.rowData);
            const mappedData = [];
            this.rowData.forEach(row => {
              const mappedRow = {};
              // console.log(row);
              columnDefs.forEach(columnDef => {
                //  console.log(columnDef);
                if (columnDef.headerName === 'na') {
                  mappedRow['col' + columnDef.field] = row[columnDef.field];
                } else {
                  mappedRow[columnDef.headerName] = row[columnDef.field];
                }
                //  console.log(mappedRow);
              });
              mappedData.push(mappedRow);
            });
            const templateFileData: IFileData = {
              templateId: this.isNewTemplate ? this.templateForm.controls['templateId'].value : TemplatesStore.templateId,
              importType: TemplatesStore.importType,
              fileType: this.fileType,
              fileData: mappedData,
              headerCount: this.templateForm.controls['headerCount'].value,
              trailerCount: this.templateForm.controls['trailerCount'].value
            };
            console.log('----------templateFileData', templateFileData);
            this.valiadateFileData(templateFileData);
            // }
          }
        },
        err => {
          this.spinner.hide();
          console.log('Error', err);
        }
      );
    }
  }

  valiadateFileData(templateFileData) {
    this.templateservice.validateFileData(templateFileData).subscribe(
      response => {
        console.log('-------------response', response);
        if (response.status === APP_CONST.SUCCESS) {
          if (response.data.fileData) {
            TemplatesStore.importFileData = response.data.fileData;
            const cols = [];
            console.log('------columndefs', this.columnDefs);
            console.log('-----------header dd', this.headerDropdown);
            const headerValues = this.headerDropdown; // as we cannot use this.headerdropdown directly in the below function

            _.forEach(response.data.fileData[0], function(value, key) {
              cols.push({
                field: key,
                headerName: _.find(headerValues, ['value', key]).displayText
              });
            });

            TemplatesStore.importColumns = cols;
            const url = importMapping[this.importType]['pageUrl'];
            this.spinner.hide();
            this.router.navigate([url + '/template/verify']);
          }
        }
      },
      err => {
        console.log('Error', err);
        this.spinner.hide();
        if (err.error.status === APP_CONST.ERROR) {
          if (err.error.data) {
            if (err.error.data.columnValidationData) {
              this.columnValidationObj = err.error.data.columnValidationData;
            } else if (err.error.data.validationData) {
              this.isError = true;
              this.errorObj = err.error.data.validationData;
              this.singleClickEdit = true;
              this.defaultColDef.editable = true;
              console.log('-------------api', this.gridApi);
              this.gridApi.gridOptionsWrapper.gridOptions.suppressClickEdit = false;
              this.gridApi.gridOptionsWrapper.gridOptions.singleClickEdit = true;
              console.log('---rowdata', this.rowData);
              console.log('---error obj', this.errorObj);
              const ssnColumn = _.find(this.columnDefs, ['headerName', 'ssn'])
                .field;
              this.gridApi.forEachNode(node => {
                console.log('-----node', node);
                if (_.find(this.errorObj, ['ssn', node.data[ssnColumn]])) {
                  this.editableRows.push(node.rowIndex);
                  this.gridApi.startEditingCell({
                    rowIndex: node.rowIndex,
                    colKey: ssnColumn
                  });
                }
              });

              // this.gridApi.setFocusedCell(0, 0);
              /* this.gridApi.forEachNode(node => {
  console.log('-----node', node);
  _.entries(node.data).forEach(element => {
    console.log('-------------------element', element);
    this.gridApi.startEditingCell({
      rowIndex: node.rowIndex,
      colKey: element[0]
    });
  });
}); */
            }
          }
        }
      }
    );
  }
  onGridReady(params) {
    console.log('--------onGridReady', params);
    this.params = params;
    this.gridApi = params.api;
    // this.gridApi.stopEditing();
    this.gridColumnApi = params.columnApi;
  }
  openErrorModal() {
    this.modalService.open('error-modal');
  }
  gotoBack() {
    this.router.navigate([URLs.TEMPLATE_SELECT]);
  }
}
