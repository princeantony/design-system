import { Component, Input, OnInit } from '@angular/core';
import { TEMPLATE_HELP_TEXT } from 'src/app/shared/constants/app.constants';
import { AlertMessage } from 'src/app/shared/interfaces/alert.interface';
import { ModalService } from 'src/app/shared/services/modal.service';

import { FormGroup } from '../../../../../../node_modules/@angular/forms';
import { dropdownItems } from '../../../../shared/config/template.config';
import { IListItem } from '../../../../shared/interfaces/list-item.interface';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.scss']
})
export class TemplateFormComponent implements OnInit {
  @Input() form: FormGroup;
  @Input() maxLength;
  @Input() isDisabled;
  helpText: AlertMessage = new AlertMessage();
  headerItems: IListItem[] = dropdownItems.slice(0);
  trailerItems: IListItem[] = dropdownItems.slice(0);
  constructor(private modalService: ModalService) { }

  ngOnInit() {
    /* console.log('---------templateId', this.form.controls['templateId']);
   if ( this.form.controls['templateId'].value) {
    this.isDisabled = true;
   } */
    this.headerItems.push({displayText: 'No Headers', value: '0'});
    this.trailerItems.push({displayText: 'No Trailers', value: '0'});
  }
  displayHelp(param) {
    this.helpText.title = 'Help';
    this.helpText.content = TEMPLATE_HELP_TEXT[param];
    this.modalService.open('alert-modal');
  }
  enter(param) {
    // setTimeout(() => this.displayHelp(param), 1000);

  }

}
