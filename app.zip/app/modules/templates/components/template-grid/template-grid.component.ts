import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { FormBuilder } from '../../../../../../node_modules/@angular/forms';

@Component({
  selector: 'app-template-grid',
  templateUrl: './template-grid.component.html',
  styleUrls: ['./template-grid.component.scss']
})
export class TemplateGridComponent implements OnInit {
  @Input()
  rowData: any;
  @Input()
  columnDefs: any;
  @Input()
  frameworkComponents: any;
  @Input()
  singleClickEdit: boolean;
  @Input()
  defaultColDef: any;
  @Input()
  suppressClickEdit: boolean;
  @Output()
  onGridReady = new EventEmitter<any>();
  @Output()
  onCellEditingStarted = new EventEmitter<any>();
  @Output()
  onRowClicked = new EventEmitter<any>();
  items: any;
  private gridApi;
  private gridColumnApi;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {}
  gridReady(params) {
    console.log('------ template grid component gridReady', params);
    this.onGridReady.emit(params);
  }
  rowClicked(event) {
    this.onRowClicked.emit(event);
  }
  cellEditingStarted(params) {
    this.onCellEditingStarted.emit(params);
  }
  updateHeaderCount() {
    // String.fromCharCode(65);
  }
  /*  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  } */
}
