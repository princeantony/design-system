import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { importMapping } from 'src/app/shared/config/template.config';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { URLs } from '../../constants/template.constants';
import { IcolumnListFW, IFileData, ITemplate } from '../../model/template.model';
import { TemplatesService } from '../../services/templates.service';
import { TemplatesStore } from '../../store/templates.store';
import { TemplateGridLinkComponent } from '../template-grid-link/template-grid-link.component';

@Component({
  selector: 'app-template-fixed-width',
  templateUrl: './template-fixed-width.component.html',
  styleUrls: ['./template-fixed-width.component.scss']
})
export class TemplateFixedWidthComponent implements OnInit {
  @Input() isNewTemplate: boolean;
  fwtemplateForm = this.fb.group({
    templateId: [],
    headerCount: ['0'],
    trailerCount: ['0']
  });
  fwtemplateFieldForm = this.fb.group({
    fieldType: [],
    startPosition: [],
    fieldLength: []
  });
  planNumber: string;
  subTitle: string;
  importType: string;
  fieldDropdown: any;
  fieldGridColumnDefs: any;
  fieldRowData = [];
  columnDefs = [];
  gridApi: any;
  frameworkComponents: any;
  editType: any;
  rowData: any;
  fileData: any;
  fileType: any;
  rowDataTemp = [];
  successMsg: string;
  templateId: string;
  columnList: IcolumnListFW[];
  isError: boolean;
  errorObj: any;
  columnError: any;
  isMappedData = false;
  constructor(
    private templateService: TemplatesService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private modalService: ModalService,
    private spinner: NgxSpinnerService,
    private previousRouteService: PreviousRouteService,
  ) {}

  ngOnInit() {
    PayAdminGlobalState.previousPage = this.previousRouteService.getPreviousUrl();
    this.templateId = TemplatesStore.templateId;
    this.importType = TemplatesStore.importType;
    this.fileType = TemplatesStore.importFileType;
    this.fieldGridColumnDefs = GRID_CONFIG.COLUMN_DEFS_FIXED_WIDTH;
    this.fileData = TemplatesStore.rawFileData;
    this.frameworkComponents = { linkRenderer: TemplateGridLinkComponent };
    this.editType = 'fullRow';
    this.getAvailableColumns();
  }
  getAvailableColumns() {
    this.spinner.show();
    this.templateService.getAvailableColumns().subscribe(
      columns => {
        if (columns.status === APP_CONST.SUCCESS) {
          this.fieldDropdown = columns.data.availableColumnList;
          if (!this.isNewTemplate) {
            this.templateService.getTemplateDetails().subscribe(
              response => {
                if (response.status === APP_CONST.SUCCESS) {
                  const data = response.data;
                  this.fwtemplateForm.controls['templateId'].setValue(
                    TemplatesStore.templateIDText
                  );
                  this.fwtemplateForm.controls['headerCount'].setValue(
                    data.headerCount
                  );
                  this.fwtemplateForm.controls['trailerCount'].setValue(
                    data.trailerCount
                  );
                  this.columnList = data.columnList;
                  this.fileData = TemplatesStore.rawFileData;
                  this.populateFields();
                }
              },
              err => {
                this.spinner.hide();
                console.log('Error', err);
              }
            );
          }
          this.spinner.hide();
        }
      },
      err => {
        this.spinner.hide();
        console.log('Error', err);
      }
    );
  }
  populateFields() {
    for (let index = 0; index < this.columnList.length; index++) {
      this.fieldRowData.push({
        fieldType: _.find(this.fieldDropdown, [
          'value',
          this.columnList[index].value
        ]).displayText,
        startPosition: this.columnList[index].startPosition,
        fieldLength: this.columnList[index].fieldWidth
      });
    }
    this.spinner.hide();
  }
  addRow() {
    const formValue = this.fwtemplateFieldForm.value;
    console.log('-----------formValue', formValue);
    console.log('--------row data', this.fieldRowData);
    if (formValue) {
      if (this.fieldRowData.length <= 0) {
        this.fieldRowData.push({
          fieldType: _.find(this.fieldDropdown, ['value', formValue.fieldType])
            .displayText,
          startPosition: formValue.startPosition,
          fieldLength: formValue.fieldLength
        });
      } else {
        this.gridApi.updateRowData({
          add: [
            {
              fieldType: _.find(this.fieldDropdown, [
                'value',
                formValue.fieldType
              ]).displayText,
              startPosition: formValue.startPosition,
              fieldLength: formValue.fieldLength
            }
          ]
        });
      }
    }
    /* this.fwtemplateFieldForm.setValue({fieldType: [],
      startPosition: [],
      fieldLength: []});
      (<any>Object).values(this.fwtemplateFieldForm.controls).forEach(control => {
        control.markAsUntouched();

      }); */

    this.fwtemplateFieldForm.reset();
    this.fwtemplateFieldForm.setErrors({ invalid: false });
    //this.fwtemplateFieldForm.vA = false;
    //this.fwtemplateFieldForm.controls['fieldType'].markAsTouched();

    console.log(this.fwtemplateFieldForm.controls['fieldType'].touched);
    console.log(this.fwtemplateFieldForm.controls['fieldType'].invalid);
  }
  updateData() {
    const rowDataTemp = [];
    const columnList = [];
    const fieldDropdown = this.fieldDropdown;
    console.log('----fieldRowData', this.gridApi);

    this.gridApi.forEachNode(function(node) {
      console.log('----------node ', node);
      // {fieldType: "Last Name", startPosition: "17", fieldLength: "6"}

      columnList.push({
        value: _.find(fieldDropdown, [
          'displayText',
          node.data.fieldType
        ]).value,
        startPosition: node.data.startPosition,
        fieldWidth: node.data.fieldLength
      });

      rowDataTemp.push(node.data);
    });
    this.rowDataTemp = rowDataTemp;
    const formVal = this.fwtemplateForm.value;
    const templateObj: ITemplate = {
      templateId: this.isNewTemplate ? formVal.templateId : TemplatesStore.templateId,
      headerCount: formVal.headerCount,
      trailerCount: formVal.trailerCount,
      importType: this.importType,
      fileType: this.fileType,
      isNewTemplate: this.isNewTemplate,
      columnList: columnList
    };
    console.log('-------------templateObj', templateObj);
    this.spinner.show();
    this.templateService.saveTemplate(templateObj).subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.successMsg = response.messages[0];
          this.isNewTemplate = false;
         const updateDataObj = {
            'templateId': this.isNewTemplate ? formVal.templateId : TemplatesStore.templateId,
            'importType': this.importType,
            'fileType': this.fileType,
            'fileData': TemplatesStore.rawFileData
        };
        this.templateService.getMappedData(updateDataObj).subscribe(
          mappedData => {
            if (mappedData.status === APP_CONST.SUCCESS) {
              console.log('---------update data', mappedData.data.fileData);
              this.isMappedData = true;
              this.rowData = mappedData.data.fileData;
              this.createGrid(this.rowDataTemp);
            }

        },
        err => {
          this.spinner.hide();
          if (err.error.status === APP_CONST.ERROR) {
            if (err.error.data) {
              if (err.error.data.columnValidationData) {
                this.columnError = err.error.data.columnValidationData;
              }
            }
          }

        });

      }
    },
    err => {
      this.spinner.hide();
      if (err.error.status === APP_CONST.ERROR) {
        if (err.error.data) {
          if (err.error.data.columnValidationData) {
            this.columnError = err.error.data.columnValidationData;
          }
        } else {
          this.columnError = [err.error.error.msg];
        }
      }

    });

   /*  const rowDataTemp = [];
    const mappingData = [];
    const fieldDropdown = this.fieldDropdown;
    console.log('----fieldRowData', this.gridApi);

    this.gridApi.forEachNode(function(node) {
      console.log('----------node ', node);
      // {fieldType: "Last Name", startPosition: "17", fieldLength: "6"}
      mappingData.push({
        columnId: _.find(fieldDropdown, ['displayText', node.data.fieldType])
          .value,
        startPosition: node.data.startPosition,
        fieldWidth: node.data.fieldLength
      });
      rowDataTemp.push(node.data);
    });
    this.rowDataTemp = rowDataTemp;

    const templateMapping = {
      templateId: this.fwtemplateForm.value.templateId,
      mappingData: mappingData,
      fileData: TemplatesStore.rawFileData
    };
    console.log('--------------templateMapping', templateMapping);
    this.templateService.updateData(templateMapping).subscribe(response => {
      if (response.status === APP_CONST.SUCCESS) {
        console.log('---------update data', response.data.fileData);
        this.isMappedData = true;
        this.rowData = response.data.fileData;
        this.createGrid(this.rowDataTemp);
      }
    }); */
  }
  createGrid(rowDataTemp) {
    this.columnDefs = [];

    for (let i = 0; i < rowDataTemp.length; i++) {
      this.columnDefs.push({
        field: _.find(this.fieldDropdown, [
          'displayText',
          rowDataTemp[i].fieldType
        ]).value,
        headerName: rowDataTemp[i].fieldType
      });
    }

    console.log('-------------columndefs', this.columnDefs);
    console.log('------------row data', this.fileData);
    this.fileData = TemplatesStore.importFileData;
    /* this.rowData = [];
    const obj = {};
    for ( let i = 0; i < this.columnDefs.length; i++) {
    for ( let j = 0; j < this.fileData.length; j++) {
      obj[this.columnDefs[i].field] = this.fileData[j][i];

    this.rowData.push(obj);
    }
    } */
    console.log('------------row data', this.rowData);
    this.spinner.hide();
  }

  saveTemplate(value) {
    const columnList = [];
    const formVal = this.fwtemplateForm.value;
    console.log('-----------------rowData', this.rowDataTemp);
    for (let i = 0; i < this.rowDataTemp.length; i++) {
      columnList.push({
        value: _.find(this.fieldDropdown, [
          'displayText',
          this.rowDataTemp[i].fieldType
        ]).value,
        startPosition: this.rowDataTemp[i].startPosition,
        fieldWidth: this.rowDataTemp[i].fieldLength
      });
    }
    const templateObj: ITemplate = {
      templateId: this.isNewTemplate ? formVal.templateId : TemplatesStore.templateId,
      headerCount: formVal.headerCount,
      trailerCount: formVal.trailerCount,
      importType: this.importType,
      fileType: this.fileType,
      isNewTemplate: this.isNewTemplate,
      columnList: columnList
    };
    console.log('-------------templateObj', templateObj);
    this.spinner.show();
    this.templateService.saveTemplate(templateObj).subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.successMsg = response.messages;
          this.isNewTemplate = false;
          if (value) {
            console.log('---------filedata', this.fileData);
            const fileObj: IFileData = {
              templateId: this.isNewTemplate ? formVal.templateId : TemplatesStore.templateId,
              importType: this.importType,
              fileData: this.rowData,
              fileType: this.fileType,
              headerCount: this.fwtemplateForm.controls['headerCount'].value,
              trailerCount: this.fwtemplateForm.controls['trailerCount'].value
            };
            // const url = importMapping[this.importType]['serviceUrl'];
            this.templateService.validateFileData(fileObj).subscribe(
              fileResponse => {
                console.log('-------------response', fileResponse);
                if (fileResponse.status === APP_CONST.SUCCESS) {
                  TemplatesStore.importColumns = this.columnDefs;
                  TemplatesStore.importFileData = this.rowData;
                  this.spinner.hide();
                  this.router.navigate(['/' + importMapping[this.importType]['pageUrl'] + '/template/verify']);
                }
              },
              err => {
                this.spinner.hide();
                console.log('Error', err);
                if (err.error.data.columnValidationData) {
                  this.columnError = err.error.data.columnValidationData;
                  window.scrollTo(0, 0);
                } else if (err.error.data.validationData) {
                  TemplatesStore.fwDataValidation =  err.error.data.validationData;
                  TemplatesStore.importColumns = this.columnDefs;
                  TemplatesStore.importFileData = this.rowData;
                  this.router.navigate(['/' + importMapping[this.importType]['pageUrl'] + '/template/verify']);
                }
              }
            );
          }
        }
      },
      err => {
        this.spinner.hide();
        console.log('Error', err);
        this.columnError = [err.error.msg];
      }
    );
  }
 /*  saveAndNext() {
    console.log('---------filedata', this.fileData);
    const requestObj = {
      templateId: this.fwtemplateForm.value.templateId,
      importType: this.importType,
      fileData: this.fileData,
      fileType: this.fileType,
      headerCount: this.fwtemplateForm.controls['headerCount'].value,
      trailerCount: this.fwtemplateForm.controls['trailerCount'].value
    };
    // const url = importMapping[this.importType]['serviceUrl'];
    this.templateService.validateFileData(requestObj).subscribe(
      response => {
        console.log('-------------response', response);
        if (response.status === APP_CONST.SUCCESS) {
          if (response.data.validationData) {
            this.isError = true;
            this.errorObj = response.data.validationData;
            // this.singleClickEdit = true;
            // this.defaultColDef.editable = true;
            console.log('-------------api', this.gridApi);
            // this.gridApi.gridOptionsWrapper.gridOptions.suppressClickEdit = false;
            // this.gridApi.gridOptionsWrapper.gridOptions.singleClickEdit = true;
            // this.gridApi.setFocusedCell(0, 0);
            /* this.gridApi.forEachNode(node => {
            console.log('-----node', node);
            _.entries(node.data).forEach(element => {
              console.log('-------------------element', element);
              this.gridApi.startEditingCell({
                rowIndex: node.rowIndex,
                colKey: element[0]
              });
            });
          }); 
          } else if (response.data.message === 'Success message') {
            TemplatesStore.importFileData = response.data.fileData;
             const cols = [];
            for (let i = 0; i < this.columnDefs.length; i++) {
              cols.push({
                field: this.columnDefs[i].headerName,
                headerName: _.find(this.fieldDropdown, [
                  'value',
                  this.columnDefs[i].headerName
                ]).displayText
              });
            }
            TemplatesStore.importColumns = this.columnDefs;
            this.router.navigate(['/template/verify']);
          }
        }
      },
      err => {
        console.log('Error', err);
      }
    );
  } */
  onGridReady(params) {
    console.log('----------params', params);
    this.gridApi = params.api;
    if (!this.isNewTemplate) {
      this.updateData();
    }
  }
  gotoBack() {
    this.router.navigate([URLs.TEMPLATE_SELECT]);
  }
}
