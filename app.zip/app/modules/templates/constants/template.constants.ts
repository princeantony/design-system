export const URLs = {
    TEMPLATE_SELECT: '/template/select',
    HOME: '/home'
  };