import { Component, OnInit } from '@angular/core';
import { importMapping } from 'src/app/shared/config/template.config';

import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { Router } from '../../../../../../node_modules/@angular/router';
import { APP_CONST, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { TemplatesService } from '../../services/templates.service';
import { TemplatesStore } from '../../store/templates.store';

@Component({
  selector: 'app-template-file-import',
  templateUrl: './template-file-import.component.html',
  styleUrls: ['./template-file-import.component.scss']
})
export class TemplateFileImportComponent implements OnInit {
  importFileItems: any;
  hidePageTitle = false;
  subTitle: string;
  planNumber: string;
  showUpload = false;
  sampleFileUrl: string;
  file: any;
  fileName = '';
  importType: string;
  fileType: string;
  fileError: string;
  fileImportForm = this.fb.group({
    importFile: ['no'],
    importFileName: [''],
    fileName: [this.fileName]
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private templateService: TemplatesService
  ) {}

  ngOnInit() {
    this.importFileItems = [
      { label: 'Yes', value: 'yes' },
      { label: 'No', value: 'no' }
    ];

    this.planNumber = PayAdminGlobalState.planNumber;
    this.importType = TemplatesStore.importType;
    console.log('---------import mapping', importMapping);
    this.sampleFileUrl = importMapping[this.importType]['fileUrl'];
    this.subTitle = SUB_TITLE.FILE_IMPORT;
  }

  gotoBack() {
    this.router.navigate(['']);
  }

  checkUpload(e: any) {
    console.log('----event', e);
    this.fileError = '';
    this.file = e.target.files;
    if (this.file.length > 0) {
      this.fileName = this.file[0].name;
      if (this.file[0].size === 0) {
        this.fileError = 'File size must be greater than 0';
        this.fileImportForm.setErrors({ invalid: true });
      } else if (this.file[0].size > 5000000) {
        this.fileError = 'File size must be lesser than 5MB';
        this.fileImportForm.setErrors({ invalid: true });
      } else if (this.file[0].size > 0 && this.file[0].size <= 5000000 ) {
        this.fileName = this.file[0].name;
      // this.fileImportForm.setErrors({ invalid: false });
      }
    }

  }
  showUploadFile(e: any) {
    console.log('--------------this.fileImportForm.value', this.fileImportForm.value);
    if (this.fileImportForm.value.importFile === 'yes') {
     // this.fileImportForm.controls['importFileName'].setValidators([Validators.required]);
     this.fileImportForm.controls['importFileName'].setValue('');
     this.fileName = '';
     this.showUpload = true;
      
    } else {
      this.fileName = '';
      this.showUpload = false;
    }
  }

  onSubmit() {
    console.log('-----form', this.file);
    const importFileValue = this.fileImportForm.value.importFile;
    if (importFileValue === 'yes') {
      const fileList: FileList = this.file;
      if (fileList.length > 0) {
        const file: File = fileList[0];
        const fileNameSplit = file.name.split('.');

        const formData: FormData = new FormData();
        TemplatesStore.importFileType = fileNameSplit[fileNameSplit.length - 1];
        console.log(
          '---PayAdminGlobalState.importFileData.fileType',
          TemplatesStore.importFileType
        );
        formData.append('fileName', file, file.name);
        formData.append('fileType', TemplatesStore.importFileType);
        formData.append('importType', this.importType);
        this.templateService.uploadFile(formData).subscribe(
          response => {
            console.log('------response', response);
            if (response.status === APP_CONST.SUCCESS) {
              TemplatesStore.importFileData = response.data.fileData;
              this.router.navigate(['/template/select']);
            }
          },
          err => {
            console.log('Error', err);
          }
        );
      }
    } else {
      this.router.navigate(['/participant']);
    }
  }
}
