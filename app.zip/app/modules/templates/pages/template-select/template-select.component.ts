import { Component, OnInit } from '@angular/core';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { importMapping } from 'src/app/shared/config/template.config';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';

import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { Router } from '../../../../../../node_modules/@angular/router';
import { APP_CONST, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { TemplatesService } from '../../services/templates.service';
import { TemplatesStore } from '../../store/templates.store';

@Component({
  selector: 'app-template-select',
  templateUrl: './template-select.component.html',
  styleUrls: ['./template-select.component.scss']
})
export class TemplateSelectComponent implements OnInit {
  hidePageTitle = false;
  subTitle: string;
  planNumber: string;
  templateOptions: any;
  isRequired = true;
  isDivSubEnabled = false;
  fileType: string;
  importType: string;
  deleteSuccessMsg: string;
  selectTemplateForm = this.fb.group({
    templateSelect: []
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private templateService: TemplatesService,
    private modalService: ModalService,
    private spinner: NgxSpinnerService,
    private previousRouteService: PreviousRouteService
  ) {}

  ngOnInit() {
    PayAdminGlobalState.previousPage = this.previousRouteService.getPreviousUrl();
    this.planNumber = PayAdminGlobalState.planNumber;
    this.fileType = TemplatesStore.importFileType;
    this.importType = TemplatesStore.importType;
    this.subTitle = SUB_TITLE.TEMPLATE_SELECTION;
    this.getTemplates();

  }
  getTemplates() {
    this.spinner.show();
    this.templateService.getExistingTemplates().subscribe(
      response => {
        console.log('------response', response);
        if (response.status === APP_CONST.SUCCESS) {
          this.isDivSubEnabled = response.data.divsubEnabled;
          this.templateOptions = response.data.options;
          this.spinner.hide();
        }
      },
      err => {
        this.spinner.hide();
        console.log('Error', err);
      }
    );

  }

  createNewTemplate() {
    this.isRequired = false;
      if (TemplatesStore.isFW) {
        this.router.navigate(['/template/createFW']);
      } else {
        this.router.navigate(['/template/create']);
    }
  }
  gotoBack() {
    console.log('--------------importMapping', importMapping[this.importType]['serviceUrl']);
    this.router.navigate([importMapping[this.importType]['pageUrl'] + '/import']);
  }
  gotoExistingTemplate() {
    this.isRequired = true;
    const templateId = this.selectTemplateForm.value.templateSelect;
    if (templateId) {
      TemplatesStore.templateId = templateId;
      TemplatesStore.templateIDText = _.find(this.templateOptions, ['value', templateId]).displayText;
      if (this.fileType === 'csv' || this.fileType === 'xls' || this.fileType === 'xlsx' || this.fileType === 'xlsm') {
        this.router.navigate(['/template/existing/']);
      } else {
        this.router.navigate(['/template/existing/fixedwidth/']);
      }

    }
    console.log('------isRequired', this.isRequired);

    console.log('------isRequired', this.isRequired);
  }
  deleteTemplate() {
    this.isRequired = true;
    this.modalService.open('template-delete-modal');

  }
  continueDelete() {
    const templateID = this.selectTemplateForm.value.templateSelect;
  // TemplatesStore.templateId = templateID;
   this.spinner.show();
    this.templateService.deleteTemplate(templateID).subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.spinner.hide();
          if (response.messages) {
            this.deleteSuccessMsg = 'Template ' + templateID + ' Deleted Successfully';
            // Template test 111220181253 has been deleted successfully
            this.selectTemplateForm.reset();
            this.getTemplates();

          }
        }
      },
      err => {
        this.spinner.hide();
        console.log('Error', err);
      }
    );
  }

}
