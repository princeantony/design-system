import { Component, OnInit } from '@angular/core';

import { FormGroup } from '../../../../../../node_modules/@angular/forms';
import { SUB_TITLE } from '../../../../shared/constants/app.constants';
import { templateData } from '../../../../shared/mocks/template-with-error';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { IcolumnList, ITemplate } from '../../model/template.model';

@Component({
  selector: 'app-template-existing',
  templateUrl: './template-existing.component.html',
  styleUrls: ['./template-existing.component.scss']
})
export class TemplateExistingComponent implements OnInit {
  existingTemplateForm: FormGroup;
  planNumber: string;
  subTitle: string;
  hidePageTitle = false;
  fileData: any;
  fileType: string;
  templateData: ITemplate;
  headerDropdown: any;
  private rowData: any[];
  private columnDefs = [];
  gridApi: any;
  gridColumnApi: any;
  params: any;
  frameworkComponents: any;
  templateId: string;
  columnList: IcolumnList[] = [];
  columnMapping: any;
  isError = false;
  errorObj: any;
  singleClickEdit = false;
  defaultColDef: any;
  suppressClickEdit = true;
  successMessage: string;
  importType: string;
  constructor() {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.TEMPLATE_EXISTING;
  }


}
