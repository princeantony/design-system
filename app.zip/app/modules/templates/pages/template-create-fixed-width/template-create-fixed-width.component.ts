import { Component, OnInit } from '@angular/core';
import { SUB_TITLE } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

@Component({
  selector: 'app-template-create-fixed-width',
  templateUrl: './template-create-fixed-width.component.html',
  styleUrls: ['./template-create-fixed-width.component.scss']
})
export class TemplateCreateFWComponent implements OnInit {
  planNumber: string;
  subTitle: string;
  constructor() {}

  ngOnInit() {
    this.subTitle = SUB_TITLE.TEMPLATE_CREATE;
    this.planNumber = PayAdminGlobalState.planNumber;
  }
}
