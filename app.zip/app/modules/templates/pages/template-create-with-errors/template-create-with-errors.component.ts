import { Component, OnInit } from '@angular/core';

import { SUB_TITLE } from '../../../../shared/constants/app.constants';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';

@Component({
  selector: 'app-template-create-with-errors',
  templateUrl: './template-create-with-errors.component.html',
  styleUrls: ['./template-create-with-errors.component.scss']
})
export class TemplateCreateComponent implements OnInit {
  planNumber: string;
  subTitle: string;
  hidePageTitle = false;
  constructor() {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.TEMPLATE_CREATE;
  }
}
