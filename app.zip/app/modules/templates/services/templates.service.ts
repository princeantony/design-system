import { Injectable } from '@angular/core';
import { ENV } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { Observable } from '../../../../../node_modules/rxjs';
import { MockService } from '../../../shared/services/mock.service';
import { TemplatesStore } from '../store/templates.store';
import { SERVICE_URL } from './../../../shared/constants/service.constants';
import { ApiService } from './../../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class TemplatesService {
  constructor(
    private apiService: ApiService,
    private mockService: MockService
  ) {}

  uploadFile(formData: FormData): Observable<any> {
    return ENV.TEST
      ? this.mockService.postWithFile()
      : this.apiService.postWithFile(
          SERVICE_URL.FILE_IMPORT.replace(
            '{planId}',
            PayAdminGlobalState.planNumber
          )
            .replace('{fileType}', TemplatesStore.importFileType)
            .replace('{importType}', TemplatesStore.importType),
          formData
        );
  }
  getExistingTemplates(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getTemplateOtions()
      : this.apiService.get(
          // SERVICE_URL.GET_TEMPLATE_OPTIONS + planNumber + '/filetype/' + fileType
          // 'common/import/plan/40311K/fileType/FXW/importType/E/templates'
          SERVICE_URL.GET_EXISTING_TEMPLATES.replace(
            '{planId}',
            PayAdminGlobalState.planNumber
          )
            .replace('{fileType}', TemplatesStore.importFileType)
            .replace('{importType}', TemplatesStore.importType)
        );
  }

  deleteTemplate(templateId): Observable<any> {
    return this.apiService.deleteByParam(
      SERVICE_URL.DELETE_TEMPLATE_DELETE.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      ).replace(
        '{fileType}',
        TemplatesStore.importFileType
      ).replace(
        '{importType}',
        TemplatesStore.importType
      ),
      [{key : 'templateId', value: templateId}]
    );
  }
  getAvailableColumns(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getAvailableCols()
      : this.apiService.get(
          SERVICE_URL.GET_AVAILABLE_COLUMNS.replace(
            '{planId}',
            PayAdminGlobalState.planNumber
          ).replace('{importType}', TemplatesStore.importType)
        );
  }
  saveTemplate(templateData: any): Observable<any> {
    return ENV.TEST
      ? this.mockService.saveTemplate()
      : this.apiService.put(
          SERVICE_URL.PUT_SAVE_TEMPLATE.replace(
            '{planId}',
            PayAdminGlobalState.planNumber
          ),
          templateData
        );
  }

  validateFileData(templateFileData: any): Observable<any> {
    return ENV.TEST
      ? this.mockService.getValidationData()
      : this.apiService.post(
          SERVICE_URL.POST_VALIDATE_FILEDATA.replace(
            '{planId}',
            PayAdminGlobalState.planNumber
          ),
          templateFileData
        );
  }
  getMappedData(rawfileData: any) {
    return ENV.TEST
    ? this.mockService.getMappedMockData()
    : this.apiService.post(
      SERVICE_URL.GET_MAPPED_DATA.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      ),
      rawfileData
    );
  }
  getTemplateDetails(): Observable<any> {
    console.log('-------------tempID', TemplatesStore.templateId);
    return ENV.TEST
      ? this.mockService.getExistingTemplate()
      : this.apiService.getByParam(
          SERVICE_URL.GET_TEMPLATE_DETAILS.replace(
            '{planId}',
            PayAdminGlobalState.planNumber
          ).replace('{importType}', TemplatesStore.importType)
            .replace('{fileType}', TemplatesStore.importFileType),
            [{key : 'templateId', value: TemplatesStore.templateId}]
        );
  }
  confirmData(url: string, planNumber: string, fileData: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_CONFIRM_DATA.replace('{module}', url).replace(
        '{planId}',
        planNumber
      ),
      fileData
    );
  }

  updateData(templateMapping: any): Observable<any> {
    return ENV.TEST
      ? this.mockService.getUpdateDataResponse()
      : this.apiService.post(
          SERVICE_URL.POST_UPDATE_DATA.replace(
            '{planId}',
            PayAdminGlobalState.planNumber
          ),
          templateMapping
        );
  }
}
