export class TemplatesStore {
  static importFileData: any;
  static rawFileData: any;
  static importFileType: string;
  static importColumns: any;
  static importType: string;
  static templateId: string;
  static templateIDText: string;
  static fwDataValidation: any;
  static isFW: boolean;
}
