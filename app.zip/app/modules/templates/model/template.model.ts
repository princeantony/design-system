export interface ITemplate {
  templateId: string;
  headerCount: string;
  trailerCount: string;
  importType: string;
  columnList: any;
  fileType: string;
  isNewTemplate: boolean;
}
export interface IcolumnList {
  value: string;
  colNumber: string;
}
export interface IcolumnListFW {
  value: string;
  startPosition: string;
  fieldWidth: string;
}
export interface IFileData {
  fileType: string;
  importType: string;
  templateId: string;
  headerCount: string;
  trailerCount: string;
  fileData: any;
}
