export const CONTRIBUTION_PATH = {
  CONTRIBUTION_SETUP: 'Contribution',
  CONTRIBTUION_PAYROLL: 'Contribution/Payroll'
};
