import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContributionsImportFileComponent } from './contributions-import-file.component';

describe('ContributionsImportFileComponent', () => {
  let component: ContributionsImportFileComponent;
  let fixture: ComponentFixture<ContributionsImportFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContributionsImportFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContributionsImportFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
