import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import {
  ContributionOptionsMock,
  ContributionPreviousBatchListMock,
  ContributionGridDataMock,
  ContributionBatchInfoMock,
  ContributionSubmitDataMock,
  ContributionAuthDivSubMock
} from '../mock/contributions-mock';

@Injectable({
  providedIn: 'root'
})
export class ContributionsMockService {
  constructor() {}

  getContributionOptions(): Observable<any> {
    return of(ContributionOptionsMock).pipe(delay(300));
  }
  getContributionPreviousBatchList(): Observable<any> {
    return of(ContributionPreviousBatchListMock).pipe(delay(300));
  }
  getContributionGridData(): Observable<any> {
    return of(ContributionGridDataMock).pipe(delay(1200));
  }
  UpdateContributionBatchInfo(): Observable<any> {
    return of(ContributionBatchInfoMock).pipe(delay(1200));
  }
  getContributionSubmitData(): Observable<any> {
    return of(ContributionSubmitDataMock).pipe(delay(2000));
  }
  getContributionAuthDivSub(): Observable<any> {
    return of(ContributionAuthDivSubMock).pipe(delay(1000));
  }

  // get(): Observable<any> {
  //   return of(1).pipe(delay(200));
  // }
}
