import { TestBed, inject } from '@angular/core/testing';

import { ContributionsMockService } from './contributions-mock.service';

describe('ContributionsMockService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ContributionsMockService]
    });
  });

  it('should be created', inject([ContributionsMockService], (service: ContributionsMockService) => {
    expect(service).toBeTruthy();
  }));
});
