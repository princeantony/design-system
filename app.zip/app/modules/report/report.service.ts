import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';

import { SERVICE_URL } from '../../shared/constants/service.constants';
import { ApiService } from '../../shared/services/api.service';
import { MockService } from '../../shared/services/mock.service';
import { PayAdminGlobalState } from '../../shared/store/pay-admin-global.store';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService
  ) {}
  getReportNames(): Observable<any> {
    return (ENV.TEST)
    ? this.mockService.getReportNames()
    : this.apiService.get(SERVICE_URL.GET_REPORT_NAMES_URL +  PayAdminGlobalState.planNumber);
  }
  getReport(reportName: string): Observable<any> {
    const url = SERVICE_URL.GET_REPORT_URL.replace('{planNumber}', PayAdminGlobalState.planNumber) + reportName;
    return (ENV.TEST)
    ? this.mockService.getReport()
    : this.apiService.get(url);
    }
}
