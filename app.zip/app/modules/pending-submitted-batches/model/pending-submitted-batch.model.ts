export interface IBatchSaveItem {
    'payrollDate': string;
    'batchName': string;
    'payrollSeqNumber': string;
  }
