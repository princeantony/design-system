import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { ModalService } from 'src/app/shared/services/modal.service';

import { PendingBatchService } from '../../services/pending-batch.service';
import { PendingSubmittedBatchStore } from '../../store/pending-submitted-batch.store';

@Component({
    selector: 'app-submit-batch-page',
    templateUrl: './submit-batch-page.component.html',
    styleUrls: ['./submit-batch-page.component.scss']
})

export class SubmitBatchPageComponent implements OnInit {
    submitDates;
    submitBatchForm;
    dobStartData: any;
    dohStartDate: any;
    enableSchedule: boolean;
    enableDateInput: boolean;
    today: any;
    modelId: any;
    confirMsg: string;
    submitBatchSuccessful: boolean;
    scheduleDate: any;
    errorMessage: any;

    ngOnInit() {
        this.submitDates = [
            { label: 'Submit Now', value: 'submitNow' },
            { label: 'Schedule Date', value: 'scheduleDate' }
        ];

        this.enableSchedule = false;
        this.enableDateInput = false;
        this.modelId = 'submitBatchModal';
        this.submitBatchSuccessful = false;
    }

    constructor(fb: FormBuilder,
        private router: Router,
        private spinner: NgxSpinnerService,
        private modalService: ModalService,
        private pendingBatchService: PendingBatchService) {
        this.submitBatchForm = fb.group({
            remittFund: [''],
            submitDate: [''],
            scheduleDate: [''],
        });
    }

    changeRemittFund(value) {
        console.log('click value', value);
        if (value === 'planFunding') {
            this.enableSchedule = false;
        } else {
            this.enableSchedule = true;
        }
    }

    changeSubmitOption(value: string) {
        console.log('date option value', value, 'form Value', this.submitBatchForm.value, this.submitBatchForm.value.submitDate);
        if (this.submitBatchForm.value.submitDate === 'scheduleDate') {
            this.enableDateInput = true;
        } else {
            this.enableDateInput = false;
        }
    }

    gotoPrevious() {
        this.router.navigate(['pendingSubmittedBatch']);
    }

    scheduleBatch() {

        if (this.enableSchedule && this.enableDateInput) {
            this.scheduleDate = this.submitBatchForm.value.scheduleDate;
            this.today = new Date().toLocaleDateString();
            let _difference = Date.parse(this.scheduleDate) - Date.parse(this.today);
            let _diffHrs = (_difference / 1000 / 60 / 60);

            if (_diffHrs > 360 || _diffHrs < 0) {
                this.submitBatchSuccessful = false;
                if (_diffHrs > 360) {

                    console.log('date must not be greater than 15 days');
                    this.confirMsg = 'Please enter a valid business date less than 15 Calendar days from current date';
                    this.modalService.open(this.modelId);
                } else {
                    console.log('date must not be less than today');
                    this.confirMsg = 'Please enter a valid business date up to 15 Calendar days from current date';
                    this.modalService.open(this.modelId);
                }
            } else {
                this.submitBatchSuccessful = true;
                this.confirMsg = 'Batches submitted successfully on weekends and market holidays, or after 4:00pm ET (or earlier, should the market close for trading prior to 4:00pm ET) on any business day, will not be processed until the following business day.'
                    + '<br/>' + 'Do you wish to continue ?';
                this.modalService.open(this.modelId);

            }
        } else {
            this.submitBatchSuccessful = true;
            this.confirMsg = 'Batches submitted successfully on weekends and market holidays, or after 4:00pm ET (or earlier, should the market close for trading prior to 4:00pm ET) on any business day, will not be processed until the following business day.'
                + '<br/>' + 'Do you wish to continue ?';
            this.modalService.open(this.modelId);

        }
    }

    continue() {
        if (this.submitBatchSuccessful) {
            // Put schedule batch service integration

            console.log('ready to post, POSTING..........');
            const _selected = PendingSubmittedBatchStore.selectedBatch;
            const _scheduleBatchData = {
                datePayroll: _selected.datePayroll,
                idLocation: _selected.locationId,
                nbrSeqPayroll: _selected.nbrSeqPayroll,
                dateSchedule: this.scheduleDate
            };
            console.log(_scheduleBatchData);

            this.pendingBatchService
                .scheduleBatch(_scheduleBatchData)
                .subscribe(
                    batch => {
                        this.spinner.hide();
                        if (batch.status === APP_CONST.SUCCESS) {
                            console.log('Post successful');
                            this.router.navigate(['home']);
                        } else {
                            console.log('submitted Batch', batch);
                            batch.forEach(data => {
                                this.errorMessage.push(data.messagge);
                            });
                        }
                    },
                    err => {
                        this.spinner.hide();
                        console.log('err.error', err.error);
                        const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
                    }
                );

        } else {
            console.log('not submitted');
        }
    }
}


// const templateObj = {
//     templateId: this.selectTemplateForm.value.templateSelect,
//     planId: this.planNumber,
//     fileType: this.fileType
//   };