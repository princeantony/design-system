import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { GridOptions } from 'ag-grid';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { AlertMessage } from 'src/app/shared/interfaces/alert.interface';
import { ModalService } from 'src/app/shared/services/modal.service';

import { IBatchSaveItem } from '../../model/pending-submitted-batch.model';
import { PendingBatchService } from '../../services/pending-batch.service';
import { PendingSubmittedBatchStore } from '../../store/pending-submitted-batch.store';

@Component({
    selector: 'app-pending-batch-info-page',
    templateUrl: './pending-batch-info-page.component.html',
    styleUrls: ['./pending-batch-info-page.component.scss']
})

export class PendingBatchInfoPageComponent implements OnInit {
    batchTypeOptions = [];
    batchList: any;
    errorMessage: any;
    batchGridHeader: any;
    batchGridData: any;
    showPending: boolean;
    isPending: boolean;
    batchHeader: any;
    batchtData: any;
    pendingBatchGridRows: any;
    pendingBatchColumnDefs: any;
    gridApi: any;
    pendingRowData = [];
    submittedRowData = [];
    header = [];
    validationError: boolean;
    errorMsg: any;
    submitBatchData: IBatchSaveItem;
    alertMessage: AlertMessage = new AlertMessage();
    private gridOptions: GridOptions;
    private pendingBatchForm: FormGroup = new FormGroup({});

    // pendingBatchForm = this.fb.group({
    //     participantUsageCode: [this.batchTypeOptions]
    // });

    constructor(
        private router: Router,
        private spinner: NgxSpinnerService,
        private modalService: ModalService,
        private pendingBatchService: PendingBatchService,

    ) { }

    ngOnInit() {
        this.showPending = true;
        this.batchTypeOptions = [
            { displayText: 'Pending', value: 'Pending' },
            { displayText: 'Submitted', value: 'Submitted' }
        ];

        this.pendingBatchForm = new FormGroup(
            {
                batchType: new FormControl('Pending'),
            }
        );

        this.showPending = true;
        this.getPendingSubmittedBatches();
    }


    getPendingSubmittedBatches() {
        this.pendingBatchService.getPendingSubmittedBatches()
            .subscribe(
                batch => {
                    this.spinner.hide();
                    if (batch.status === APP_CONST.SUCCESS) {
                        this.batchList = batch.data;
                        this.createGrid();
                    } else {
                        console.log(' Pending or submitted batches ', batch);
                        batch.forEach(data => {
                            this.errorMessage.push(data.messagge);
                        });
                    }
                },
                err => {
                    console.log('Error in batch list', err);
                    this.spinner.hide();
                }
            );
    }

    gridReady(params) {
        this.gridApi = params.api;
        console.log('grid ready in PB', params.api);
        // this.gridApi.gridOptionsWrapper.gridOptions.getRowStyle(params){
        //     if (params.data.Status === '3') {
        //         return {'background-color': 'yellow'}
        //     }
        //     return null;
        // }

    }



    createGrid() {
        const _batchList = this.batchList;

        this.batchHeader = _batchList[0].headers;
        this.batchtData = _batchList[0].elements;
        PendingSubmittedBatchStore.isDivSubEnabled = _batchList[0].divsubEnabled;


        // creating dynamic header constant for grid
        // radio select
        let radioHeader = {
            headerName: '', field: '', cellRenderer: 'radioRenderer', width: 105, suppressFilter: true,
        };
        this.header.push(radioHeader);

        this.batchHeader.forEach(field => {
            let newHeader = {
                headerName: field.label, field: field.id, width: 150,
            };
            this.header.push(newHeader);
        });

        let linkHeader = {
            headerName: '', field: '', cellRenderer: 'linkRenderer', width: 200, suppressFilter: true,
        };
        this.header.push(linkHeader);

        // creating dynamic rows
        for (let i = 0; i < this.batchtData.length; i++) {
            let _temp = {};

            for (let j = 0; j < (this.batchtData[i].fields).length; j++) {
                const id = this.batchtData[i].fields[j].id;
                const value = this.batchtData[i].fields[j].value;

                if (id === 'cdStatus' && value !== '6') {
                    this.isPending = true;
                } else if (id === 'cdStatus' && value === '6') {
                    this.isPending = false;
                }
                _temp[id] = value;

            }

            if (this.isPending) {
                this.pendingRowData.push(_temp);
            } else if (!this.isPending) {
                this.submittedRowData.push(_temp);
            }


        }
        if (this.showPending) {
            this.pendingBatchGridRows = this.pendingRowData;
        } else if (!this.showPending) {
            this.pendingBatchGridRows = this.submittedRowData;
        }
        this.pendingBatchColumnDefs = this.header;
    }


    onBatchViewByChange(value) {
        PendingSubmittedBatchStore.selectedBatch = '';
        console.log('dropdown changed', value);
        if (value === 'Pending') {
            this.showPending = true;
            this.pendingBatchGridRows = this.pendingRowData;
        } else if (value === 'Submitted') {
            this.showPending = false;
            this.pendingBatchGridRows = this.submittedRowData;
        }
        this.pendingBatchColumnDefs = this.header;
    }

    gotoPrevious() {
        this.router.navigate(['home']);
    }

    runBatch() {
        if (PendingSubmittedBatchStore.selectedBatch === undefined || PendingSubmittedBatchStore.selectedBatch === '') {
            this.alertMessage.title = '';
            this.alertMessage.content = 'please select a batch to continue';
            this.modalService.open('alert-modal');

            // this.validationError = true;
            // this.errorMsg = 'please select a batch to continue';
        } else {
            this.validationError = false;
            console.log('selected Batch', PendingSubmittedBatchStore.selectedBatch);
            let _selected = PendingSubmittedBatchStore.selectedBatch;
            if (_selected.cdStatus === '3') {
                console.log('ready to post, POSTING..........');


                let _submitBatchData = {};
                _submitBatchData['datePayroll'] = _selected.datePayroll;
                _submitBatchData['idLocation'] = _selected.locationId;
                _submitBatchData['nbrSeqPayroll'] = _selected.nbrSeqPayroll;
                console.log(_submitBatchData);

                this.pendingBatchService
                    .submitBatch(_submitBatchData)
                    .subscribe(
                        batch => {
                            this.spinner.hide();
                            if (batch.status === APP_CONST.SUCCESS) {
                                console.log('Post successful');
                                this.router.navigate(['pendingSubmittedBatch/submitBatch']);
                            } else {
                                console.log('submitted Batch', batch);
                                batch.forEach(data => {
                                    this.errorMessage.push(data.messagge);
                                });
                            }
                        },
                        err => {
                            this.spinner.hide();
                            console.log('err.error', err.error);
                            const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
                        }
                    );
            } else {
                console.log('not ready to post');
                // this.validationError = true;
                // this.errorMsg = 'Batch must be Ready to Post before submitting';
                this.alertMessage.title = '';
                this.alertMessage.content = 'Batch must be Ready to Post before submitting';
                this.modalService.open('alert-modal');
            }
        }
    }


}
