export const PendingBatchList =
{
    'status': 'SUCCESS',
        'data': [
            {
                'divsubEnabled': false,
                'headers': [
                    {
                        'id': 'batchType',
                        'label': 'Batch Type'
                    },
                    {
                        'id': 'nmePayroll',
                        'label': 'Batch Name'
                    },
                    {
                        'id': 'datePayroll',
                        'label': 'Payroll Date'
                    },
                    {
                        'id': 'locationId',
                        'label': 'Location ID'
                    },
                    {
                        'id': 'cdStatus',
                        'label': 'Status'
                    },
                    {
                        'id': 'dateSchedule',
                        'label': 'Date Schedule'
                    },
                    {
                        'id': 'contribTotal',
                        'label': 'Contribution Total'
                    },
                    {
                        'id': 'loanTotal',
                        'label': 'Loan Total'
                    },
                    {
                        'id': 'divSub',
                        'label': 'Division/Location'
                    },
                    {
                        'id': '9',
                        'label': 'ROLLOVER'
                    },
                    {
                        'id': 'A',
                        'label': 'EMPLOYEE PRE TAX'
                    },
                    {
                        'id': 'B',
                        'label': 'EMPLOYEE PRE TAX (NY)'
                    },
                    {
                        'id': 'D',
                        'label': 'EMPLOYER'
                    },
                    {
                        'id': 'U',
                        'label': 'TAKEOVER SOURCE'
                    }
                ],
                'elements': [
                    {
                        'fields': [
                            {
                                'id': 'batchType',
                                'value': 'Loan'
                            },
                            {
                                'id': 'nmePayroll',
                                'value': 'Test                          '
                            },
                            {
                                'id': 'datePayroll',
                                'value': 'Wed Aug 08 00:00:00 IST 2018'
                            },
                            {
                                'id': 'locationId',
                                'value': '0   '
                            },
                            {
                                'id': 'cdStatus',
                                'value': '6'
                            },
                            {
                                'id': 'dateSchedule',
                                'value': 'Mon Jan 01 00:00:00 IST 1900'
                            },
                            {
                                'id': 'loanTotal',
                                'value': '0.00'
                            },
                            {
                                'id': 'divSub',
                                'value': 'Mutiple'
                            }
                        ]
                    },
                    {
                        'fields': [
                            {
                                'id': 'batchType',
                                'value': 'Loan'
                            },
                            {
                                'id': 'nmePayroll',
                                'value': 'Test                          '
                            },
                            {
                                'id': 'datePayroll',
                                'value': 'Wed Aug 08 00:00:00 IST 2018'
                            },
                            {
                                'id': 'locationId',
                                'value': '0   '
                            },
                            {
                                'id': 'cdStatus',
                                'value': '3'
                            },
                            {
                                'id': 'dateSchedule',
                                'value': 'Mon Jan 01 00:00:00 IST 1900'
                            },
                            {
                                'id': 'loanTotal',
                                'value': '59.75'
                            },
                            {
                                'id': 'divSub',
                                'value': 'Mutiple'
                            }
                        ]
                    },
                    {
                        'fields': [
                            {
                                'id': 'batchType',
                                'value': 'Contribution'
                            },
                            {
                                'id': 'nmePayroll',
                                'value': 'TEST 24'
                            },
                            {
                                'id': 'datePayroll',
                                'value': 'Wed Oct 24 00:00:00 IST 2018'
                            },
                            {
                                'id': 'locationId',
                                'value': '0   '
                            },
                            {
                                'id': 'cdStatus',
                                'value': '3'
                            },
                            {
                                'id': 'dateSchedule',
                                'value': 'Mon Jan 01 00:00:00 IST 1900'
                            },
                            {
                                'id': '9 ',
                                'value': '0.00'
                            },
                            {
                                'id': 'contribTotal',
                                'value': '0.00'
                            },
                            {
                                'id': 'divSub',
                                'value': 'Mutiple'
                            }
                        ]
                    },
                    {
                        'fields': [
                            {
                                'id': 'batchType',
                                'value': 'Contribution'
                            },
                            {
                                'id': 'nmePayroll',
                                'value': 'TEST 24'
                            },
                            {
                                'id': 'datePayroll',
                                'value': 'Wed Oct 24 00:00:00 IST 2018'
                            },
                            {
                                'id': 'locationId',
                                'value': '0   '
                            },
                            {
                                'id': 'cdStatus',
                                'value': '3'
                            },
                            {
                                'id': 'dateSchedule',
                                'value': 'Mon Jan 01 00:00:00 IST 1900'
                            },
                            {
                                'id': 'A ',
                                'value': '0.00'
                            },
                            {
                                'id': 'contribTotal',
                                'value': '0.00'
                            },
                            {
                                'id': 'divSub',
                                'value': 'Mutiple'
                            }
                        ]
                    },
                    {
                        'fields': [
                            {
                                'id': 'batchType',
                                'value': 'Contribution'
                            },
                            {
                                'id': 'nmePayroll',
                                'value': 'TEST 24'
                            },
                            {
                                'id': 'datePayroll',
                                'value': 'Wed Oct 24 00:00:00 IST 2018'
                            },
                            {
                                'id': 'locationId',
                                'value': '0   '
                            },
                            {
                                'id': 'cdStatus',
                                'value': '6'
                            },
                            {
                                'id': 'dateSchedule',
                                'value': 'Mon Jan 01 00:00:00 IST 1900'
                            },
                            {
                                'id': 'B ',
                                'value': '0.00'
                            },
                            {
                                'id': 'contribTotal',
                                'value': '0.00'
                            },
                            {
                                'id': 'divSub',
                                'value': 'Mutiple'
                            }
                        ]
                    }
                ]
            }
        ]
};
