export const BatchPrintData = {
    'status': 'SUCCESS',
    'data': [{
        'fields': [
            { 'name': 'afdg' },
            { 'ssn': 'afdg' },
            { 'contribution': 'afdg' },
            { 'total': 'afdg' },
            { 'divsub': 'afdg' },
        ]
    },
    {
        'fields': [
            { 'name': 'afdg' },
            { 'ssn': 'afdg' },
            { 'contribution': 'afdg' },
            { 'total': 'afdg' },
            { 'divsub': 'afdg' },
        ]
    },
    {
        'fields': [
            { 'name': 'afdg' },
            { 'ssn': 'afdg' },
            { 'contribution': 'afdg' },
            { 'total': 'afdg' },
            { 'divsub': 'afdg' },
        ]
    }

    ]
};
