import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { ModalService } from 'src/app/shared/services/modal.service';

import { PendingBatchService } from '../../services/pending-batch.service';
import { PendingSubmittedBatchStore } from '../../store/pending-submitted-batch.store';

@Component({
    selector: 'app-batch-print-preview-modal',
    templateUrl: './batch-print-preview-modal.component.html',
    styleUrls: ['./batch-print-preview-modal.component.scss']
})
export class BatchPrintpreviewModalComponent implements OnInit {
    @Input() modelId;
    batchDisplayItems: any;
    batchName;
    planNumber;
    payrollDate;
    payrollSeqNo;
    totalConti;
    toatlLoan;
    status;
    batchType;
    errorMessage;
    batchList;
    sortBy;

    constructor(private modalService: ModalService, fb: FormBuilder,
        private pendingBatchService: PendingBatchService,
        private spinner: NgxSpinnerService) {

    }

    ngOnInit() {



        console.log('sort selected', this.sortBy);
        // this.totalFunding = this.batchDisplayItems.totalFunding;
        if ((PendingSubmittedBatchStore.selectedBatch !== undefined) || (PendingSubmittedBatchStore.selectedBatch = '')) {
            this.batchDisplayItems = PendingSubmittedBatchStore.selectedBatch;
            this.sortBy = PendingSubmittedBatchStore.sortPrintBy;
            this.batchName = this.batchDisplayItems.nmePayroll;
            this.payrollDate = this.batchDisplayItems.datePayroll;
            this.payrollSeqNo = this.batchDisplayItems.nbrSeqPayroll;
            this.status = this.batchDisplayItems.cdStatus;
            this.batchType = this.batchDisplayItems.batchType;

            this.getPrintDetails();
        }

        }

        printScreen() {
            const printContent = document.getElementById("batch-print-content");
            const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');
            WindowPrt.document.write(printContent.innerHTML);
            WindowPrt.document.close();
            WindowPrt.focus();
            WindowPrt.print();
            WindowPrt.close();
            // window.print();
        }

        getPrintDetails() {


            let _submitBatchData = {};
            _submitBatchData['divSub'] = this.batchDisplayItems.divSub;
            _submitBatchData['dtePayroll'] = this.batchDisplayItems.datePayroll;
            _submitBatchData['batchType'] = this.batchDisplayItems.batchType;
            _submitBatchData['idLocation'] = this.batchDisplayItems.locationId;
            _submitBatchData['nbrSeqPayroll'] = this.batchDisplayItems.nbrSeqPayroll;

            this.pendingBatchService.getPrintBatch(this.sortBy, _submitBatchData)
                .subscribe(
                    batch => {
                        this.spinner.hide();
                        if (batch.status === APP_CONST.SUCCESS) {
                            this.batchList = batch.data;
                           
                        } else {
                            console.log(' Pending or submitted batches ', batch);
                            batch.forEach(data => {
                                this.errorMessage.push(data.messagge);
                            });
                        }
                    },
                    err => {
                        console.log('Error in batch list', err);
                        this.spinner.hide();
                    }
                );



        }

        closeModal(id) {
            this.modalService.close(id);
        }
        continueTo(id) {

            this.modalService.close(id);
        }
    }
