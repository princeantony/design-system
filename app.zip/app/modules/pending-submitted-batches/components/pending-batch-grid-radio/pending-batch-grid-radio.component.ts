import { Component, EventEmitter, Output } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';

import { PendingSubmittedBatchStore } from '../../store/pending-submitted-batch.store';

@Component({
  selector: "app-pending-batch-grid-radio",
  templateUrl: "./pending-batch-grid-radio.component.html",
  // styleUrls: ["./admin-grid-radio-button.component.scss"]
})

export class PendingBatchGridRadioComponent implements ICellRendererAngularComp {

  private params: any;
  @Output() change = new EventEmitter<any>();

  agInit(params: any): void {
    this.params = params;

  }

  refresh(params): boolean {
    return false;
  }

  handleChange() {
       PendingSubmittedBatchStore.selectedBatch = this.params.data;
  }
}

