import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ModalService } from 'src/app/shared/services/modal.service';

import { PendingSubmittedBatchStore } from '../../store/pending-submitted-batch.store';

@Component({
  selector: 'app-batch-print-modal',
  templateUrl: './batch-print-modal.component.html',
  styleUrls: ['./batch-print-modal.component.scss']
})
export class BatchPrintModalComponent implements OnInit {
  @Input() modelId;
  @Output()
  continue = new EventEmitter<any>();
  printBatchForm: any;
  sortByValue: any;
  btndisable: any;
  divSubEnabled: any;

  constructor(private modalService: ModalService, fb: FormBuilder) {
    this.printBatchForm = fb.group({
        sortByValue: [''],
    });
  }

  ngOnInit() {
    this.divSubEnabled = PendingSubmittedBatchStore.isDivSubEnabled ;
    this.btndisable = true;
  }

  closeModal(id) {
    this.modalService.close(id);
  }
  continueTo(id) {
  
  this.modalService.close(id);
  this.continue.emit();
  }

  printBySort(value: string) {
    PendingSubmittedBatchStore.sortPrintBy = value;
    this.btndisable = false;
  }

}
