import { Component, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ModalService } from 'src/app/shared/services/modal.service';

import { PendingSubmittedBatchStore } from '../../store/pending-submitted-batch.store';

@Component({
  selector: 'app-pending-batch-grid-link',
  templateUrl: './pending-batch-grid-link.component.html'
})
export class PendingBatchGridLinkComponent implements ICellRendererAngularComp {
  @Output()
  continuePrint = new EventEmitter<any>();
  public params: any;
  public link: string;
  public navParam: string;
  id: string;
  planNumber;
  private sub: any;
  status: any;
  loadModel = false;
  modelId = 'batch-print-modal';
  agInit(params: any): void {
    this.params = params;
    this.status = this.params.data.cdStatus;
    console.log('In grid link', this.params.data.status);
  }

  constructor(
    private modalService: ModalService,
    private router: Router ) { }

  public invokeRouteTo(param) {
    this.params.context.componentParent.routeTo(param);
  }

  editBatch() {
    console.log("param value", this.params.data);
  }

  printBatch() {
    console.log("param value", this.params.data);
    // this.loadModel = true;
    this.modalService.open('batch-print-modal');
    PendingSubmittedBatchStore.selectedBatch = this.params.data;
  }

  deleteBatch() {
    console.log("param value", this.params.data);
  }

  continue() {
    console.log('Print modal closed');
     this.router.navigate(['pendingSubmittedBatch/printBatch']);
   // this.modalService.open('batch-print-preview-modal');
  }

  refresh(): boolean {
    return false;
  }

}
