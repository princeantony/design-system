import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { PendingBatchGridLinkComponent } from '../pending-batch-grid-link/pending-batch-grid-link.component';
import { PendingBatchGridRadioComponent } from '../pending-batch-grid-radio/pending-batch-grid-radio.component';

@Component({
    selector: 'app-pending-batch-grid',
    templateUrl: './pending-batch-grid.component.html',
    // styleUrls: ['./pending-batch-grid.component.scss']
})

export class PendingBatchGridComponent implements OnInit {
    @Input() rowData;
    @Input() columnDefs;
    @Output() onGridReady = new EventEmitter<any>();

    style;

    frameworkComponents: any;
    constructor() {
        // this.style = { width: "83%" };
    }

    ngOnInit() {
        this.frameworkComponents = {
            linkRenderer: PendingBatchGridLinkComponent,
            radioRenderer: PendingBatchGridRadioComponent,
        }
    }

    gridReady(params) {

        this.onGridReady.emit(params);

    }
}