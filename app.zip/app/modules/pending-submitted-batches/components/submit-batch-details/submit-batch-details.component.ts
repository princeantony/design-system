import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { PendingSubmittedBatchStore } from '../../store/pending-submitted-batch.store';

@Component({
    selector: 'app-submit-batch-details',
    templateUrl: './submit-batch-details.component.html',
    styleUrls: ['./submit-batch-details.component.scss']
})

export class SubmitBatchDetailsComponent implements OnInit {
    batchDisplayItems: any;
    batchName;
    planNumber;
    payrollDate;
    payrollSeqNo;
    totalConti;
    toatlLoan;
    planName;
    totalFunding;
    userID;

    ngOnInit() {
        this.batchDisplayItems = PendingSubmittedBatchStore.selectedBatch;
        this.batchName = this.batchDisplayItems.batchName;
        this.payrollDate = this.batchDisplayItems.payrollDate;
        this.payrollSeqNo = this.batchDisplayItems.payrollSeqNo;
        this.totalConti = this.batchDisplayItems.totalConti;
        this.toatlLoan = this.batchDisplayItems.toatlLoan;
        this.totalFunding = this.batchDisplayItems.totalFunding;

        this.planName = PayAdminGlobalState.planName;
        this.planNumber =  PayAdminGlobalState.planNumber;
        this.userID = PayAdminGlobalState.loginUser.userName;
    }

}
