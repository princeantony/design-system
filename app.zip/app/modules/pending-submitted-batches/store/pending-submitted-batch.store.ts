import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PendingSubmittedBatchStore {
    static selectedBatch: any;
    static sortPrintBy: any;
    static isDivSubEnabled: boolean;
  }


