import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';
import { SERVICE_URL } from 'src/app/shared/constants/service.constants';
import { ApiService } from 'src/app/shared/services/api.service';
import { MockService } from 'src/app/shared/services/mock.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { PendingBatchMockService } from './pending-batch-mock.service';

@Injectable({
    providedIn: 'root'
})
export class PendingBatchService {
    selectedFields: string[] = [];
    constructor(private mockServicePB: PendingBatchMockService, private apiService: ApiService, mockService: MockService) { }

    getPendingSubmittedBatches(): Observable<any> {

        console.log(PayAdminGlobalState.planNumber);

        return ENV.TEST ? this.mockServicePB.getPendingBatchMock() :
            this.apiService.get(SERVICE_URL.GET_PENDING_SUBMITTED_BATCH.replace('{planNumber}', PayAdminGlobalState.planNumber));
    }

    // deleteBatch(dataelementID: string, batchObj: any): Observable<any> {
    //     return (ENV.TEST)
    //         ? this.mockServicePB.successMock()
    //         : this.apiService.deleteByObject(SERVICE_URL.GET_OPTIONAL_DE_URL.replace('{planNumber}', PayAdminGlobalState.planNumber),
    //         batchObj);
    // }


    submitBatch(batchData: any): Observable<any> {
        return ENV.TEST ? this.mockServicePB.successMock() :
            this.apiService.put(SERVICE_URL.SUBMIT_PENDING_SUBMITTED_BATCH.replace('{planNumber}',
                PayAdminGlobalState.planNumber), batchData);

    }

    scheduleBatch(batchData: any):  Observable<any> {
        return ENV.TEST ? this.mockServicePB.successMock() :
            this.apiService.put(SERVICE_URL.SCHEDULE_PENDING_SUBMITTED_BATCH.replace('{planNumber}',
                PayAdminGlobalState.planNumber), batchData);

    }
    getPrintBatch(batchData: any, sortby: any): Observable<any> {
        return ENV.TEST ? this.mockServicePB.successMock() :
            this.apiService.post(SERVICE_URL.GET_PRINT_BATCH_DATA.replace('{planNumber}',
             PayAdminGlobalState.planNumber).replace('{sortBy}' , sortby ), batchData);

    }

}

