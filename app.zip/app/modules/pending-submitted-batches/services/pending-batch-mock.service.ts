import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { MockSuccessResponse } from 'src/app/shared/mocks/common-mock';

import { PendingBatchList } from '../mock/pending-batch-list.mock';

@Injectable({
    providedIn: 'root'
})
export class PendingBatchMockService {
    constructor() { }

    getPendingBatchMock(): Observable<any> {
        return of(PendingBatchList).pipe(delay(2000));
    }

    successMock(): Observable<any> {
        return of(MockSuccessResponse).pipe(delay(2000));
    }
}
