import { Component, ElementRef, OnInit, ViewContainerRef } from '@angular/core';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'src/app/shared/services/toastr.service';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { APP_CONST, ENV } from '../../../../shared/constants/app.constants';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { BankInfoService } from '../../services/bank-info.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html'
})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub: any;
  updateTime: any;
  updateDate: any;
  bankDetails: any;
  accType: string;
  divSubs: any;
  divSub: string;
  hidePageTitle: boolean;
  print = false;
  printBtn = false;
  pageTitle: string;
  planNumber: string;
  submitedOn: string;
  bankAddress: string;
  payAdminGlobalState: PayAdminGlobalState;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private printForm: ElementRef,
    private spinner: NgxSpinnerService,
    private modalService: ModalService,
    private bankInfoService: BankInfoService,
   private toastrService: ToastrService,
    vcr: ViewContainerRef
  ) {
    this.toastrService.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
    PayAdminGlobalState.currentPage = '/bankInfo/confirm';

    this.hidePageTitle = false;
    this.pageTitle = 'Bank Information';
    this.planNumber = PayAdminGlobalState.planNumber;
    this.bankDetails = PayAdminGlobalState.bankDetails;
    if(this.bankDetails.bankInfo.address1 && this.bankDetails.bankInfo.address2){
      this.bankAddress = this.bankDetails.bankInfo.address1 + ',' + this.bankDetails.bankInfo.address2;
    } else if(this.bankDetails.bankInfo.address1) {
      this.bankAddress = this.bankDetails.bankInfo.address1;
    }else{
      this.bankAddress = this.bankDetails.bankInfo.address2;
    }
    if (PayAdminGlobalState.divsubId !== '') {
      this.divSubs = PayAdminGlobalState.subDiv;
      this.divSub = _.filter(this.divSubs, [
        'divsub',
        PayAdminGlobalState.divsubId
      ])[0].textOnly;
    }
    if (this.bankDetails.bankInfo.accountType === 'C') {
      this.accType = 'Checking';
    } else {
      this.accType = 'Savings';
    }
    this.route.url.subscribe(value => {
      if (_.find(value, ['path', 'print'])) {
        this.printBtn = true;
        this.print = true;
        this.submitedOn = BankInfoService.submitedOn;
      }
    });
  }
  onPrint() {
    window.print();
    PayAdminGlobalState.successMsg = '';
  }

  onSubmit() {
    const planId = PayAdminGlobalState.planNumber;
    this.spinner.show();
    this.updateDate = new Date().toLocaleDateString();
    this.updateTime = new Date().toLocaleTimeString();
    BankInfoService.submitedOn = this.updateDate + ' '+ this.updateTime;
    const urls = _.split(PayAdminGlobalState.previousPage, '/');

    if (ENV.TEST) {
      this.onMockSubmit();
    } else {
      if (_.includes(PayAdminGlobalState.previousPage, 'edit')) {
        this.bankInfoService
          .updateBankInfo(
            this.bankDetails,
            planId,
            PayAdminGlobalState.divsubId
          )
          .subscribe(
            bankInfo => {
              this.spinner.hide();
              if (bankInfo.status === APP_CONST.SUCCESS) {
                PayAdminGlobalState.successMsg =
                  'Bank Information successfully updated on ' +
                  this.updateDate +
                  ' at ' +
                  this.updateTime +
                  '. For more information,';
                this.router.navigate(['/home/success']);
              } else {
                this.toastrService.showError(bankInfo.error.msg, bankInfo.status + ' !');
              }
            },
            err => {
              this.spinner.hide();
              this.toastrService.showError(err.error.error.msg, err.error.status + ' !');
            }
          );
      } else {
        this.bankInfoService
          .postBankInfo(this.bankDetails, planId, PayAdminGlobalState.divsubId)
          .subscribe(
            bankInfo => {
              this.spinner.hide();
              if (bankInfo.status === APP_CONST.SUCCESS) {
                PayAdminGlobalState.successMsg =
                  'Bank Information successfully created11 on ' +
                  this.updateDate +
                  ' at ' +
                  this.updateTime +
                  '. For more information,';
                this.router.navigate(['/home/success']);
              } else {
                console.log('bankInfor', bankInfo);
                this.toastrService.showError(bankInfo.error.msg, bankInfo.status + ' !');
              }
            },
            err => {
              this.spinner.hide();
              console.log('err.error', err.error);
              const errMessage =
                err.error.error.code === 400
                  ? err.error.error.msg
                  : err.error.error.cause;
              this.toastrService.showError(errMessage, err.error.status + ' !');
            }
          );
      }
    }
  }
  onMockSubmit() {
    if (_.split(PayAdminGlobalState.previousPage, '/')[2] === 'edit') {
      PayAdminGlobalState.successMsg =
        'Bank Information successfully updated on ' +
        this.updateDate +
        ' at ' +
        this.updateTime +
        '. For more information,';
    } else {
      PayAdminGlobalState.successMsg =
        'Bank Information successfully created on ' +
        this.updateDate +
        ' at ' +
        this.updateTime +
        '. For more information,';
    }
    this.router.navigate(['/home/success']);
  }
  onEdit() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
  gotoHome() {
    this.router.navigate(['/home']);
  }
}
