import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';
import { MockService } from 'src/app/shared/services/mock.service';

import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { ApiService } from '../../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private apiService: ApiService, private mockService: MockService) { }
  doAuthenticte(loginUser: any): Observable<any> {
    console.log("loginUser", loginUser)
    return ENV.TEST ?  this.mockService.doAuthenticate() : this.apiService.post(SERVICE_URL.GET_DIRECT_LOGIN_URL, loginUser);
   }
}
