import { Component, EventEmitter, forwardRef, Output } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { ICellRendererAngularComp, INoRowsOverlayAngularComp } from 'ag-grid-angular';
import { NgbDateCustomParserFormatter } from 'src/app/shared/components/form/voya-date/dateformat';

const noop = () => {};

@Component({
    selector: 'batch-grid-date-picker',
    templateUrl: './batch-grid-date-picker.component.html',
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => BatchGridDatePickerComponent),
            multi: true
        },
        { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
    ]

})
export class BatchGridDatePickerComponent implements ICellRendererAngularComp, INoRowsOverlayAngularComp {
    @Output() Click = new EventEmitter<boolean>();
    constructor() { }
    dateOfHire: Date;
    controlClass: string;
    controlName: string;
    isCatchUp = false;
    parent: string;

    dohStartDate: {};


    agInit(params: any): void {
        this.dateOfHire = params.value;
        this.controlClass = 'small';       
        this.controlName = params.colDef.field + '_' + params.rowIndex;
    }



    setStartDates() {
        this.dohStartDate = { year: new Date().getFullYear() - 9, month: 1 };
      }

    isLabelHidden: boolean = true;
    model;
    _onTouchedCallback: (_: any) => void = noop;
    _onChangeCallback: (_: any) => void = noop;

    private _startDate: {
        year: number | null;
        month: number | null;
        day?: number | null;
    } = null;
    private _maxDate: {
        year: number | null;
        month: number | null;
        day?: number | null;
    } = null;
    private _minDate: {
        year: number | null;
        month: number | null;
        day?: number | null;
    } = null;
    private _value: any = '';

    //#region @INPUT() StartDate

    set StartDate(
        value: {
            year: number | null;
            month: number | null;
            day?: number | null;
        } | null
    ) {
        if (value) {
            this._startDate = value;
        } else {
            const curDate: Date = new Date();
            this._startDate = {
                year: curDate.getFullYear(),
                month: curDate.getMonth()
            };
        }
    }
    get StartDate(): {
        year: number | null;
        month: number | null;
        day?: number | null;
    } | null {
        return this._startDate;
    }
    //#endregion

    //#region @INPUT() MaxDate

    set MaxDate(
        value: {
            year: number | null;
            month: number | null;
            day?: number | null;
        } | null
    ) {
        if (value) {
            this._maxDate = value;
        } else {
            const curDate: Date = new Date();
            this._maxDate = {
                year: 2099,
                month: curDate.getMonth()
            };
        }
    }
    get MaxDate(): {
        year: number | null;
        month: number | null;
        day?: number | null;
    } | null {
        return this._maxDate;
    }
    //#endregion

    //#region @INPUT() MinDate

    set MinDate(
        value: {
            year: number | null;
            month: number | null;
            day?: number | null;
        } | null
    ) {
        if (value) {
            this._minDate = value;
        } else {
            const curDate: Date = new Date();
            this._minDate = {
                year: 2099,
                month: curDate.getMonth()
            };
        }
    }
    get MinDate(): {
        year: number | null;
        month: number | null;
        day?: number | null;
    } | null {
        return this._minDate;
    }
    //#endregion

    ngOnInit() {
        this.isLabelHidden = true;
        if (!this.StartDate) {
            this.StartDate = null;
        }
        if (!this.MaxDate) {
            this.MaxDate = null;
        }
        if (!this.MinDate) {
            this.MinDate = null;
        }
    }

    // The internal data model
    // get accessor
    get value(): any {
        return this._value;
    }
    // set accessor including call the onchange callback
    set value(v: any) {
        if (v !== this._value) {
            this._value = v;
            this._onChangeCallback(v);
        }
    }

    // Set touched on blur
    onTouched(event: any) {
        if (event.target.value === '') {
            this.isLabelHidden = true;
        }
        if (event.target.value !== '') {
            this.isLabelHidden = false;
        }
        this._onTouchedCallback(null);
    }
    onFocus() {
        this.isLabelHidden = false;
    }

    writeValue(value: string): void {
        this._value = value || null;
        if (this._value === null) {
            this.isLabelHidden = true;
        }
    }

    registerOnChange(fn: any): void {
        this._onChangeCallback = fn;
    }
    registerOnTouched(fn: any): void {
        this._onTouchedCallback = fn;
    }
    setDisabledState?(isDisabled: boolean): void { }

    showHideLabel(value: any) {
        if (!this.value) {
            this.isLabelHidden = true;
        } else {
            this.isLabelHidden = false;
        }
    }


    refresh(): boolean {
        return false;
    }

    isPopup(): boolean {
        return false;
      }

}

