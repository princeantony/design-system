import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TemplatesService } from 'src/app/modules/templates/services/templates.service';
import { TemplatesStore } from 'src/app/modules/templates/store/templates.store';
import { importMapping } from 'src/app/shared/config/template.config';
import { APP_CONST, ENV, SUB_TITLE } from 'src/app/shared/constants/app.constants';
import { validationData } from 'src/app/shared/mocks/template-fixed-width';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

@Component({
  selector: 'app-batch-participant-verify-data',
  templateUrl: './batch-participant-verify-data.component.html',
  styleUrls: ['./batch-participant-verify-data.component.scss']
})
export class BatchParticipantVerifyDataComponent implements OnInit {
  hidePageTitle = false;
  planNumber: string;
  subTitle: string;
  rowData: any;
  defaultColDef: any;
  columnDefs = [];
  gridApi: any;
  importType: string;
  errorObj: any;
  isError = false;
  errorList: any;

  constructor(private templateService: TemplatesService,
              private modalService: ModalService,
              private previousRouteService: PreviousRouteService,
              private router: Router) {}

  ngOnInit() {
    PayAdminGlobalState.previousPage = this.previousRouteService.getPreviousUrl();
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.ENROLLMENT_AUDIT;
    this.importType = TemplatesStore.importType;
    if (TemplatesStore.fwDataValidation) {
      this.isError = true;
      this.errorObj = TemplatesStore.fwDataValidation;
    }
    if (ENV.TEST) {
      this.rowData = validationData.data.fileData;
      this.columnDefs = this.columnDefs = TemplatesStore.importColumns; /* [
        { field: 'ssn', headerName: 'SSN' },
        { field: 'firstName', headerName: 'First Name' },
        { field: 'lastName', headerName: 'Last Name' }
      ]; */
      this.defaultColDef = { editable: true };
    } else {
      this.rowData = TemplatesStore.importFileData;
      this.columnDefs = TemplatesStore.importColumns;
      console.log('--------filedata', TemplatesStore.importFileData);
      console.log('----------------columnDefs', this.columnDefs);
      this.defaultColDef = { editable: true };
    }

    // const colHeaders = _.keys(this.rowData[0]);
  }

  onGridReady(params) {
    this.gridApi = params.api;
  }

  finish() {
    console.log('-----this api', this.gridApi);
    this.gridApi.stopEditing();
    this.isError =  false;
    const confirmData = {
      fileType: TemplatesStore.importFileType,
      importType: TemplatesStore.importType,
      templateId: TemplatesStore.templateId,
      fileData: this.rowData
    };
    const url = importMapping[this.importType]['serviceUrl'];
    this.templateService.confirmData(url, this.planNumber, confirmData).subscribe(response => {
      console.log(response);
      if (response.status === APP_CONST.SUCCESS) {
        PayAdminGlobalState.successMsg = response.messages;
        this.router.navigate(['/home/success']);

      }

    },
    err => {
      console.log('Error', err);
      if (err.error.data.validationData) {
        this.isError = true;
        this.errorObj = err.error.data.validationData;
      } else if (err.error.data.errorList) {
        this.errorList = err.error.data.errorList;
      }
    });
  }
  gotoBack() {
    if (TemplatesStore.isFW) {
      this.router.navigate(['/template/existing/fixedwidth']);
    } else {
      this.router.navigate(['/template/existing']);
    }

  }
  openErrorModal() {
    this.modalService.open('error-modal');
  }
}

