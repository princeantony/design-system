import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchParticipantImportFileComponent } from './batch-participant-import-file.component';

describe('BatchParticipantImportFileComponent', () => {
  let component: BatchParticipantImportFileComponent;
  let fixture: ComponentFixture<BatchParticipantImportFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchParticipantImportFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchParticipantImportFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
