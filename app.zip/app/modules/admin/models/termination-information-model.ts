export interface ITerminationInfoItem {
    optionId: string;
    optionText: string;
}
