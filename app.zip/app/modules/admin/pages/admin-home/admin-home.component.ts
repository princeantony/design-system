import { Component, OnInit } from '@angular/core';

import { SUB_TITLE } from '../../../../shared/constants/app.constants';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { AdminDataService } from '../../services/admin-data.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html'
})
export class AdminHomeComponent implements OnInit {
  hidePageTitle = false;
  pageTitleClass = false;
  changePlan = false;
  planNumber: string;
  pageTitle: string;
  showPrint = false;
  message: string;

  constructor() {}

  ngOnInit() {
    window.scrollTo(0, 0);
    this.planNumber = PayAdminGlobalState.planNumber;
    this.pageTitle = SUB_TITLE.ADMIN;
    PayAdminGlobalState.currentPage = '/admin';

    if (AdminDataService.successMsg) {
      this.message = AdminDataService.successMsg;
      AdminDataService.successMsg = '';
    }
  }
}
