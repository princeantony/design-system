import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { APP_CONST } from '../../../../../shared/constants/app.constants';
import { GRID_CONFIG } from '../../../../../shared/constants/grid.constants';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-termination-info',
  templateUrl: './admin-termination-info.component.html',
  styleUrls: ['./admin-termination-info.component.scss']
})

export class AdminTerminationInfoComponent implements OnInit {
  private defaultGridApi;
  private clientGridApi;
  appContext = APP_CONST.APP_CONTEXT;
  homeFlag: any;
  termList: any;
  termReasonColumnDefs: any;
  clientSpecificColumnDefs: any;
  width: any;
  type = 'Termination Reason';
  defaultOptionView: boolean;
  clientSpecificView: boolean;
  defaultTermList: any;
  clientTermList: any;
  modelId = 'trModal';
  removeAll: boolean;
  errorMsg: any;
  planNumber: any;
  selectedTrId;
  deleteTrId;
  _trid;
  confirMsg: string;
  validationError;


  TerminateReasonForm = this.fb.group({
    'optionID': new FormControl('', Validators.required),
    'optionText': new FormControl('', Validators.required),
  })

  constructor(private fb: FormBuilder,
    private adminService: AdminService,
    private router: Router,
    private modalService: ModalService,
    private spinner: NgxSpinnerService) {
    this.termReasonColumnDefs = GRID_CONFIG.TERMINATION_REASON.DEFAULT_COLUMN_DEFS_REASON;
    this.clientSpecificColumnDefs = GRID_CONFIG.TERMINATION_REASON.CLIENT_SPEC_COLUMN_DEFS_REASON
    this.width = { width: '98%' };
  }

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.removeAll = false;
    this.validationError = false;
    this.spinner.show();
    this.getTerminationList();
  }

  clientGridReady(params) {
    this.clientGridApi = params.api;
  }

  defaultGridReady(params) {
    this.defaultGridApi = params.api;
  }

  getTerminationList() {
    this.adminService.getTerminationList().subscribe(flags => {
      this.spinner.hide();
      if (flags.status === APP_CONST.SUCCESS) {
        this.termList = flags.data.terminationReasons;
        this.defaultTermList = _.filter(this.termList, ['type', 'S']);
        this.clientTermList = _.filter(this.termList, ['type', 'C']);
        if (flags.data.displayType === 'S') {
          this.defaultOptionView = true;
          this.clientSpecificView = false;
        } else {
          this.defaultOptionView = false;
          this.clientSpecificView = true;
        }
      } else {
        console.log('Termination Information', flags);
        flags.forEach(data => {
          this.validationError = true;
          this.errorMsg.push(data.messagge);
        });
      }
    },
      err => {
        this.validationError = true;
        this.errorMsg = err.error.error.msg;
        this.spinner.hide();
        console.log('err.error', err.error);
        const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
      }
    );
  }



  toggleList() {
    AdminDataService.TerminationOptionID = '';
    this.validationError = false;
    if (this.defaultOptionView) {
      this.clientSpecificView = true;
      this.defaultOptionView = false;
    } else if (!this.defaultOptionView) {
      this.defaultOptionView = true;
      this.clientSpecificView = false;
    }
  }

  gotoPrevious() {
    this.router.navigate(['admin']);
  }

  addNewOption() {
    AdminDataService.editTRID = false;
    this.router.navigate(['terminate/Update']);
  }

  editOption() {
    let _trid = AdminDataService.TerminationOptionID;
    if ((_trid === undefined) || (_trid === '')) {
      this.validationError = true;
      this.errorMsg = 'Please select a Termination Reason to continue';
    } else {
      this.validationError = false;
      this.selectedTrId = _.filter(this.termList, ['value', _trid]);
      AdminDataService.selectedTRID = this.selectedTrId;
      AdminDataService.editTRID = true;
      this.router.navigate(['terminate/Update']);
    }

  }

  confirmDelete() {
    let _trid = AdminDataService.TerminationOptionID;
    if  ((_trid === undefined) || (_trid === '')) {
      this.validationError = true;
      this.errorMsg = 'Please select a Termination Reason to continue';
    } else {
      this.validationError = false;
      this.removeAll = false;
      let _trid = AdminDataService.TerminationOptionID;
      this.selectedTrId = _.filter(this.termList, ['value', _trid]);
      this.deleteTrId = this.selectedTrId[0].value;
      this.confirMsg = 'Are you sure you want to delete the selected ' + this.type + ' ' + this.deleteTrId;
      this.modalService.open(this.modelId);
    }

  }

  deleteOption() {
    this.spinner.show();
    if (this.removeAll) {
      this.adminService.deleteAllTerminationReason().subscribe(flags => {
        this.spinner.hide();
        if (flags.status === APP_CONST.SUCCESS) {
          console.log('Delete successful');
          this.clientGridApi.setRowData([]);
          this.clientTermList = [];

          this.router.navigate(['terminate/reviewUpdate']);

        } else {
          console.log('Termination Information', flags);
          this.validationError = true;
          flags.forEach(data => {
            this.errorMsg.push(data.messagge);
          });
        }
      },
        err => {
          this.validationError = true;
          this.errorMsg = err.error.error.msg;
          this.spinner.hide();
          console.log('err.error', err.error);
          const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
        }
      );


    } else {
      this.adminService.deleteTerminationReason(this.deleteTrId).subscribe(flags => {
        this.spinner.hide();
        if (flags.status === APP_CONST.SUCCESS) {
          let res = this.clientGridApi.updateRowData({ remove: this.selectedTrId });
          console.log('Delete successful');
        } else {
          console.log('Termination Information', flags);
          flags.forEach(data => {
            this.errorMsg.push(data.messagge);
          });
        }
      },
        err => {
          this.validationError = true;
          this.errorMsg = err.error.error.msg;
          this.spinner.hide();
          console.log('err.error', err.error);
          const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
        }
      );
    }
  }


  removeAllTR() {
    this.removeAll = true;
    this.confirMsg = 'Are you sure you wish to remove the customized options?';
    this.modalService.open(this.modelId);
  }

  onSubmit() {
    let _trType = {};
    if (this.defaultOptionView) {
      _trType['type'] = 'S';
    } else {
      _trType['type'] = 'C';
    }
    this.spinner.show();
    this.saveTR(_trType);


  }

  saveTR(_trType) {
    this.adminService
      .saveTerminationReason(_trType)
      .subscribe(
        saveRes => {
          this.spinner.hide();
          if (saveRes.status === APP_CONST.SUCCESS) {
            this.router.navigate(['admin']);
          } else {
            console.log('Error in save termination information', saveRes);
            this.validationError = true;
            saveRes.forEach(data => {
              this.errorMsg.push(data.messagge);
            });

          }
        },
        err => {
          this.validationError = true;
          this.errorMsg = err.error.error.msg;
          this.spinner.hide();
          console.log('Error in save termination information outside', err);
        }
      );
  }


}
