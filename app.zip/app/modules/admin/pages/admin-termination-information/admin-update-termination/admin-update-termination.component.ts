import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';

import { APP_CONST } from '../../../../../shared/constants/app.constants';
import { ITerminationInfoItem } from '../../../models/termination-information-model';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-update-termination',
  templateUrl: './admin-update-termination.component.html',
})

export class AdminUpdateTerminationComponent implements OnInit {
  hidePageTitle: boolean;
  subTitle: string;
  planNumber: string;
  private gridApi;
  appContext = APP_CONST.APP_CONTEXT;
  errorMsg;
  private terminationItem: ITerminationInfoItem[];
  oldID: any;
  validationError: any;

  TerminateReasonForm = this.fb.group({
    'optionId': new FormControl('', Validators.required),
    'optionText': new FormControl('', Validators.required),
  });

  constructor(private fb: FormBuilder, private adminService: AdminService, private router: Router, private spinner: NgxSpinnerService ) { }

  ngOnInit() {
    this.hidePageTitle = false;
    this.subTitle = 'Termination Information';
    this.planNumber = '559985';
    if (AdminDataService.editTRID) {
      this.oldID = AdminDataService.selectedTRID[0].value;

      this.TerminateReasonForm.controls['optionId'].setValue(
        AdminDataService.selectedTRID[0].value);
      this.TerminateReasonForm.controls['optionText'].setValue(
        AdminDataService.selectedTRID[0].displayText);
    }
  }

  onSubmit() {
    this.terminationItem = this.TerminateReasonForm.value;
    if (AdminDataService.editTRID) {
      this.editTermination(this.terminationItem);
    } else {
      this.addTermination(this.terminationItem);
    }
  }

  editTermination(_trItem) {
    this.adminService.editTerminationReason(_trItem, this.oldID).subscribe(flags => {
       this.spinner.hide();
      if (flags.status === APP_CONST.SUCCESS) {
        console.log('Post successful');
        this.router.navigate(['terminate/reviewUpdate']);
      } else {
        console.log('Termination Information', flags);
      }
    },
      err => {
         this.spinner.hide();
        console.log('err.error', err.error);
        const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
      }
    );
  }



  addTermination(_trItem) {
    this.adminService.addTerminationReason(_trItem).subscribe(flags => {
       this.spinner.hide();
      if (flags.status === APP_CONST.SUCCESS) {
        console.log('Post successful');
        this.router.navigate(['terminate/reviewUpdate']);
      } else {
        console.log('Termination Information', flags);
      }
    },
      err => {
        this.validationError = true;
        this.errorMsg = err.error.error.msg;
         this.spinner.hide();
        console.log('err.error', err.error);
        const errMessage = (err.error.error.code === 400 ? err.error.error.msg : err.error.error.cause);
      }
    );
  }


  gotoPrevious() {
    this.router.navigate(['/terminate/reviewUpdate']);
  }




}
