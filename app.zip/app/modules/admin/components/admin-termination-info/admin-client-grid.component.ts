import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { AdminGridRadioComponent } from '../admin-grid-radio/admin-grid-radio.component';


@Component({
    selector: 'app-admin-client-grid',
    templateUrl: './admin-client-grid.component.html',
    //   styleUrls: ['./admin-data-element-grid.component.scss']
})

export class AdminClientGridComponent implements OnInit {
    @Input() rowData;
    @Input() columnDefs;
    @Output() onGridReady = new EventEmitter<any>();
    frameworkComponents: any;
    style;

    constructor() { this.style = { width: "90%" }; }
    ngOnInit() {
        this.frameworkComponents = {
            radiobuttonRender: AdminGridRadioComponent
        };
    }
    gridReady(params) {
        this.onGridReady.emit(params);
    }

}
