import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { AdminGridEditButtonComponent } from "../admin-grid-edit-button/admin-grid-edit-button.component";

@Component({
  selector: "app-admin-grid-edit",
  templateUrl: "./admin-grid-edit.component.html"
})
export class AdminGridEditComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
  @Output() onGridReady = new EventEmitter<any>();
  style;
  editType;

  frameworkComponents: any;
  constructor() {
    this.style = { width: "83%" };
  }

  ngOnInit() {
    this.frameworkComponents = {
      checkboxRenderer: AdminGridEditButtonComponent,
    }
    this.editType= "fullRow";
  }

  gridReady(params){
    console.log("inside grid component", params)
    this.onGridReady.emit(params);

  }
}
