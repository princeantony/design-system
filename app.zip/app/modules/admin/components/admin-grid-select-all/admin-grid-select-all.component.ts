import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

import { VoyaCheckboxComponent } from '../../../../shared/components/form/voya-checkbox/voya-checkbox.component';

@Component({
  selector: "app-admin-grid-select-all",
  templateUrl: "./admin-grid-select-all.component.html" ,
  styleUrls: ['./admin-grid-select-all.component.scss']
})

export class AdminGridSelectAllComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
  @Output()
  onGridReady =new EventEmitter<any>();
  style;

  frameworkComponents: any;
  constructor() { this.style = {width: '94%'};}
  ngOnInit() {
    this.frameworkComponents = {
      checkboxRender: VoyaCheckboxComponent,
    };

  }

  gridReady(params){
    console.log("inside grid component", params)
    this.onGridReady.emit(params);
  }
}
