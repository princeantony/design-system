import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-de-modal',
  templateUrl: './de-modal.component.html',
  styleUrls : ['./de-modal.component.scss']

})
export class DEModalComponent implements OnInit {
  @Input() deId;
  @Input() type;
  @Input() modelId;
  @Input() navigateTo='';
  constructor(private modalService: ModalService,
              private router: Router) { }

  ngOnInit() {
  }

  closeModal(id: string) {
    this.modalService.close(id);
}
continueTo(id: string) {
  this.modalService.close(id);
  this.router.navigate(['/admin/dataElements/'+this.navigateTo+'delete']);
}

}


