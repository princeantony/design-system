import { Component, OnInit } from '@angular/core';

import { CommonService } from '../../../../shared/services/common.service';
import { IParticipantFundSources } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';

@Component({
  selector: 'app-participant-add-investment-election',
  templateUrl: './participant-add-investment-election.component.html',
  styleUrls: ['./participant-add-investment-election.component.scss']
})
export class ParticipantAddInvestmentElectionComponent implements OnInit {
  private participantFundSources: IParticipantFundSources;
  constructor(
    private participantsService: ParticipantsService,
    private common: CommonService
  ) {}

  ngOnInit() {
    this.participantsService
      .getParticipantParticipantFundData()
      .subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.participantFundSources = result.data;
        }
      });
  }
}
