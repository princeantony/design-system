import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantUpdateContributionElectionComponent } from './participant-update-contribution-election.component';

describe('ParticipantUpdateContributionElectionComponent', () => {
  let component: ParticipantUpdateContributionElectionComponent;
  let fixture: ComponentFixture<ParticipantUpdateContributionElectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantUpdateContributionElectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantUpdateContributionElectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
