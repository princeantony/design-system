import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateExistingFixedWidthComponent } from './template-existing-fixed-width.component';

describe('TemplateExistingFixedWidthComponent', () => {
  let component: TemplateExistingFixedWidthComponent;
  let fixture: ComponentFixture<TemplateExistingFixedWidthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateExistingFixedWidthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateExistingFixedWidthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
