export const planSetup = {
"status": "SUCCESS",
"data":
{
  "loanMatching": true,
  "copyPayroll": false,
  "disActPartWContrib": true,
  "loanPayoffs": false,
  "leaveOfAbsence": false,
  "submitBatchesInAdvance": false,
  "crossCalendarPayroll": false,
  "negativeContrib": false,
  "nonACH": false,
  "nameChange": false,
  "reportsFolder": "Default",
  "lastChangedBy": "Default",
  "pinLength": 4,
  "RSD":false,
  "enrollment": "Default",
  "divSubFunc": "Default",
  "catchupSrcs":"CP1",
  "catchUp": "N",
  "participantUpdate": "Default",
  "emailDE": "Default",
  "enrollmentStatusCode": "Default",
  "maskSSN": "Default",
  "customMask": "XXX5555",
  "moneySources":[
    {
      "code": "100",
      "shortNameOverride":"anonty",
      "exclude": false,
      "limit": true,
      "contributionCatchUp": false,
      "deferralCatchUp": false,
      "forfeitureAccountFrom": false,
      "forfeitureAccountTo": false,
      "prefundedAccountFrom": false,
      "prefundedAccountTo": false,
      "rothSource": true,
      "preTaxSource": false
    },
    {
      "code": "101",
     "shortNameOverride":"prince",
      "exclude": false,
      "limit": false,
      "contributionCatchUp": true,
      "deferralCatchUp": false,
      "forfeitureAccountFrom": false,
      "forfeitureAccountTo": true,
      "prefundedAccountFrom": false,
      "prefundedAccountTo": false
    }
  ],
  "investments":[
    {
      "code": "200",
      "longNameOverride": "Default",
      "exclude": false
    },
    {
      "code": "201",
      "longNameOverride": "Default",
      "exclude": true
    }
  ]
}
}


export const moneySources = {
    "status": "SUCCESS",
    "data": [
    {
      "code": "100",
      "longName": "Default",
      "shortName": "PA"
    },
    {
      "code": "101",
      "longName": "Default",
      "shortName": "AP"
    }
  ]
  }

export const investments = {
  "status": "SUCCESS",

    "data": [
    {
      "code": "200",
      "longName": "Default"
    },
    {
      "code": "201",
      "longName": "Default"
    }
  ]
}

export const enrollmentStatusCode = {
    "status": "SUCCESS",
    "data": [
      {
        "displayText": "Default",
        "statusCode": "Default"
      },
      {
        "displayText": "Default",
        "statusCode": "Default"
      }
    ]
}

export const displayOptions = {
    "status": "SUCCESS",
    "data": {
        "rsd" : true,
        "showCatchUpOptions": false,
        "showDropdown": true,
        "showLOA": true,
        "showPartUpdateOptions": false
    }
}

 export const planSource =
{
    "status": "SUCCESS",
    "data": [
        {
            "code": "1",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "3",
            "rothSource": true,
            "preTaxSource": false
        },
        {
            "code": "4",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "6",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "9",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "A",
            "rothSource": false,
            "preTaxSource": true
        },
        {
            "code": "D",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "F",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "G",
            "rothSource": true,
            "preTaxSource": true
        },
        {
            "code": "K",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "P",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "Q",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "U",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "X",
            "rothSource": false,
            "preTaxSource": false
        },
        {
            "code": "Y",
            "rothSource": false,
            "preTaxSource": false
        }
    ]
}


