export const DataElementsList =
{
  'status': 'SUCCESS',
  'data': [
      {
          'objectID': 'pt',
          'subObjectID': 'ph',
          'dataElement': 390,
          'omniName': 'Payroll Frequency             ',
          'overrideName': 'iuyu#$!                       ',
          'contributionUsageCode': 'N',
          'participantUsageCode': 'N',
          'censusUsageCode': 'N',
          'overrideFlag': true,
          'defaultSortOrder': 99,
          'overrideSortOrder': 0,
          'sortOrderOverride': false,
          'accumulate': true,
          'accOverName': '                              ',
          'accOverFlag': true,
          'selected': false,
          'showLOA': true,
          'optionalElementID': 'ptph390',
          'enrollmentUsageCode': 'N',
          'divsubDE': false
      },
      {
          'objectID': 'PT',
          'subObjectID': 'PH',
          'dataElement': 85,
          'omniName': 'Number Of Hours               ',
          'overrideName': '                              ',
          'contributionUsageCode': 'U',
          'participantUsageCode': 'U',
          'censusUsageCode': 'U',
          'overrideFlag': true,
          'defaultSortOrder': 999,
          'overrideSortOrder': 0,
          'sortOrderOverride': false,
          'accumulate': true,
          'accOverName': '                              ',
          'accOverFlag': true,
          'selected': false,
          'showLOA': true,
          'optionalElementID': 'PTPH085',
          'enrollmentUsageCode': 'R',
          'divsubDE': false
      }
  ]
}

export const DataElementOptions =
  {
    'status': 'SUCCESS',
    'data': [
        {
            'valueCode': '3',
            'value': 'married'
        },
        {
            'valueCode': '8',
            'value': 'Tier1'
        }
    ]
}
