
import {BankInfo} from '../models/bank-info.model';

export const bankInfo = { "status": "SUCCESS",
"data": [
     {
        "addressId": "0000000000001",
        "planNumber": "559958",
        "divsub": "0001",
        "bankName": "Bank Name",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "",
        "accountTypeDescription" : "Saving",
        "address1": "Flying BANK Aha",
        "address2": "",
        "city": "Vatican",
        "state": "FL",
        "zipcode": "",
        "valid": true
    },
    {
        "addressId": "0000000001001",
        "divsub": "1001",
        "valid": false
    },
    {
        "addressId": "0000000001002",
        "divsub": "1002",
        "valid": false
    },
    {
        "addressId": "0000000001003",
        "divsub": "1003",
        "valid": false
    },
    {
        "addressId": "0000000001004",
        "divsub": "1004",
        "valid": false
    },
    {
        "addressId": "0000000001005",
        "divsub": "1005",
        "valid": false
    },
    {
        "addressId": "0000000001006",
        "divsub": "1006",
        "valid": false
    },
    {
        "addressId": "0000000001007",
        "divsub": "1007",
        "valid": false
    },
    {
        "addressId": "0000000001008",
        "divsub": "1008",
        "valid": false
    },
    {
        "addressId": "0000000001009",
        "divsub": "1009",
        "valid": false
    },
    {
        "addressId": "0000000001010",
        "divsub": "1010",
        "valid": false
    },
    {
        "addressId": "0000000001011",
        "planNumber": "559958",
        "divsub": "1011",
        "bankName": "Clearcase Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "accountTypeDescription" : "Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001012",
        "planNumber": "559958",
        "divsub": "1012",
        "bankName": "Non3 Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001013",
        "planNumber": "559958",
        "divsub": "1013",
        "bankName": "Non3 Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001014",
        "divsub": "1014",
        "valid": false
    },
    {
        "addressId": "0000000001015",
        "planNumber": "559958",
        "divsub": "1015",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001016",
        "planNumber": "559958",
        "divsub": "1016",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001017",
        "planNumber": "559958",
        "divsub": "1017",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001018",
        "planNumber": "559958",
        "divsub": "1018",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001019",
        "planNumber": "559958",
        "divsub": "1019",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001020",
        "planNumber": "559958",
        "divsub": "1020",
        "bankName": "No Bank",
        "acctNumber": "14000189999",
        "abaNumber": "012345678",
        "accountType": "C   Checking",
        "address1": "",
        "address2": "address2",
        "city": "Flames",
        "state": "PR",
        "zipcode": "00605",
        "valid": true
    },
    {
        "addressId": "0000000001021",
        "divsub": "1021",
        "valid": false
    },
    {
        "addressId": "0000000001022",
        "divsub": "1022",
        "valid": false
    },
    {
        "addressId": "0000000001023",
        "divsub": "1023",
        "valid": false
    },
    {
        "addressId": "0000000001024",
        "divsub": "1024",
        "valid": false
    },
    {
        "addressId": "0000000009999",
        "divsub": "9999",
        "valid": false
    },
    {
        "addressId": "000000000EASE",
        "divsub": "EASE",
        "valid": false
    }

]
}
export const divSub = { "status": "SUCCESS",
"data": [
    {
        "id": "0001",
        "text": "0001 MERUELO ENTERPRISES",
        "name": "",
        "phone": "",
        "textOnly": "MERUELO ENTERPRISES"
    },
    {
        "id": "1001",
        "text": "1001 LA PIZZA LOCA, INC.",
        "name": "",
        "phone": "",
        "textOnly": "LA PIZZA LOCA, INC."
    },
    {
        "id": "1002",
        "text": "1002 LPL DISTRIBUTION, INC.",
        "name": "",
        "phone": "",
        "textOnly": "LPL DISTRIBUTION, INC."
    },
    {
        "id": "1003",
        "text": "1003 MERUELO ENTERPRISES",
        "name": "",
        "phone": "",
        "textOnly": "MERUELO ENTERPRISES"
    },
    {
        "id": "1004",
        "text": "1004 MERONA ENTERPRISES, INC.",
        "name": "",
        "phone": "",
        "textOnly": "MERONA ENTERPRISES, INC."
    },
    {
        "id": "1005",
        "text": "1005 FUJISAN FRANCHISING CORP",
        "name": "",
        "phone": "",
        "textOnly": "FUJISAN FRANCHISING CORP"
    },
    {
        "id": "1006",
        "text": "1006 CANTAMAR PROPERTY MNGMT",
        "name": "",
        "phone": "",
        "textOnly": "CANTAMAR PROPERTY MNGMT"
    },
    {
        "id": "1007",
        "text": "1007 ALISE AVIATION, LLC",
        "name": "",
        "phone": "",
        "textOnly": "ALISE AVIATION, LLC"
    },
    {
        "id": "1008",
        "text": "1008 MERUELO MEDIA HLDG DBA KWHY-22",
        "name": "",
        "phone": "",
        "textOnly": "MERUELO MEDIA HLDG DBA KWHY-22"
    },
    {
        "id": "1009",
        "text": "1009 PACIFIC WHEY HOLDING, LLC",
        "name": "",
        "phone": "",
        "textOnly": "PACIFIC WHEY HOLDING, LLC"
    },
    {
        "id": "1010",
        "text": "1010 HERMAN WEISSKER, INC.",
        "name": "",
        "phone": "",
        "textOnly": "HERMAN WEISSKER, INC."
    },
    {
        "id": "1011",
        "text": "1011 TIDWELL EXCAVATING ACQUISITION",
        "name": "",
        "phone": "",
        "textOnly": "TIDWELL EXCAVATING ACQUISITION"
    },
    {
        "id": "1012",
        "text": "1012 DOTY BROS EQUIPMENT CO",
       "name": "",
        "phone": "",
        "textOnly": "DOTY BROS EQUIPMENT CO"
    },
    {
        "id": "1013",
        "text": "1013 NEAL ELECTRIC",
        "name": "",
        "phone": "",
        "textOnly": "NEAL ELECTRIC"
    },
    {
        "id": "1014",
        "text": "1014 SELECT ELECTRIC INC.",
        "name": "",
        "phone": "",
        "textOnly": "SELECT ELECTRIC INC."
    },
    {
        "id": "1015",
        "text": "1015 FUJI FOODS PRODUCTS, INC.",
        "name": "",
        "phone": "",
        "textOnly": "FUJI FOODS PRODUCTS, INC."
    },
    {
        "id": "1016",
        "text": "1016 HG STAFFING, LLC",
        "name": "",
        "phone": "",
        "textOnly": "HG STAFFING, LLC"
    },
    {
        "id": "1017",
        "text": "1017 MEI-GSR HOLDINGS",
        "name": "",
        "phone": "",
        "textOnly": "MEI-GSR HOLDINGS"
    },
    {
        "id": "1018",
        "text": "1018 MERUELO GROUP LLC",
        "name": "",
        "phone": "",
        "textOnly": "MERUELO GROUP LLC"
    },
    {
        "id": "1019",
        "text": "1019 MERUELO RADIO HOLDINGS",
        "name": "",
        "phone": "",
        "textOnly": "MERUELO RADIO HOLDINGS"
    },
    {
        "id": "1020",
        "text": "1020 MERUELLO MEDIA LLC",
        "name": "",
        "phone": "",
        "textOnly": "MERUELLO MEDIA LLC"
    },
    {
        "id": "1021",
        "text": "1021 MERUELO REAL PROPERTY CORP",
        "name": "",
        "phone": "",
        "textOnly": "MERUELO REAL PROPERTY CORP"
    },
    {
        "id": "1022",
        "text": "1022 ONE CALL CONSTRUCTION",
        "name": "",
        "phone": "",
        "textOnly": "ONE CALL CONSTRUCTION"
    },
    {
        "id": "1023",
        "text": "1023 SOCAL RESTAURANT MANAGEMENT LLC",
        "name": "",
        "phone": "",
        "textOnly": "SOCAL RESTAURANT MANAGEMENT LLC"
    },
    {
        "id": "1024",
        "text": "1024 KPWR RADIO",
        "name": "",
        "phone": "",
        "textOnly": "KPWR RADIO"
    },
    {
        "id": "9999",
        "text": "9999 Forfeiture Account",
        "name": "",
        "phone": "",
        "textOnly": "FORFEITURE ACCOUNT"
    },
    {
        "id": "EASE",
        "text": "EASE EASE Account",
        "name": "",
        "phone": "",
        "textOnly": "EASE ACCOUNT"
    }

]
}
