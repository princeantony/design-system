import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaPagingComponent } from './voya-paging.component';

describe('VoyaPagingComponent', () => {
  let component: VoyaPagingComponent;
  let fixture: ComponentFixture<VoyaPagingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaPagingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaPagingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
