import { Component,ElementRef, OnInit, Input, Renderer2, ViewChild } from "@angular/core";

@Component({
  selector: "voya-button",
  templateUrl: "./voya-button.component.html",
  styleUrls: ["./voya-button.component.scss"]
})
export class VoyaButtonComponent implements OnInit {
  @ViewChild('button') 
  private button: ElementRef;
  btn: any;
  private _text: string;
  @Input()
  set text(value: string) {
    this._text = value || "button";
  }
  get text(): string {
    return this._text;
  }

  private _disabled: boolean;
  @Input()
  set disabled(value: boolean) {
    this._disabled = value || false;
  }
  get disabled(): boolean {
    return this._disabled;
  }

  private _icon: string;
  @Input()
  set icon(value: string) {
    this._icon = value || "";
  }
  get icon(): string {
    return this._icon;
  }

  private _iconLeft: string;
  @Input()
  set iconLeft(value: string) {
    this._iconLeft = value || "";
  }
  get iconLeft(): string {
    return this._iconLeft;
  }

  private _iconRight: string;
  @Input()
  set iconRight(value: string) {
    this._iconRight = value || "";
  }
  get iconRight(): string {
    return this._iconRight;
  }

  private _theme: string;// orange, white, transparent, no-border
  @Input()
  set theme(value: string) {
    this._theme = value || "";
  }
  get theme(): string {
    return this._theme;
  }

  constructor(private renderer: Renderer2) {
    if (!this._text) {
      this._text = "button";
    }
    if (!this._disabled) {
      this._disabled = false;
    }

  }

  ngOnInit() {
    this.btn = this.button.nativeElement;
    this.renderer.setAttribute(this.btn, 'tabindex','-1');
    this.renderer.addClass(this.btn,'voya-button-theme-transparent');

  }
}
