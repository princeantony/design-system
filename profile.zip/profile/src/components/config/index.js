import { queryLanguagePack } from 'axp-global-ducks';

// eslint-disable-next-line import/prefer-default-export
export const loadDataAsProps = ({ store: { dispatch } }) => ({
  language: () => dispatch(queryLanguagePack('axp-network-client-profile')),
});
