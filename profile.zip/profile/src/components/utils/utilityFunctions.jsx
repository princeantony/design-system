/* eslint-disable import/prefer-default-export */

export const formatDate = (date) => {
  if (date) {
    const dateVal = new Date(date);
    const month =
      dateVal.getMonth() + 1 < 10 ? `0${dateVal.getMonth() + 1}` : dateVal.getMonth() + 1;
    const day = dateVal.getDate() < 10 ? `0${dateVal.getDate()}` : dateVal.getDate();
    return `${month}/${day}/${dateVal.getFullYear()}`;
  }
  return date;
};
