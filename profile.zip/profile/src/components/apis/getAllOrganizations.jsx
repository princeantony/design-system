const getOrganizations = (urlSting, handler, errorHandler, options) =>
  fetch(urlSting, options)
    .then(response => Promise.all([response.status, response.json()]))
    .then(([statusCode, data]) => {
      handler(statusCode, data);
    })
    .catch((error) => {
      errorHandler(error);
    });

export default getOrganizations;
