const getInstitution = (urlAndQuerySting, handler, errorHandler, options) =>
  fetch(urlAndQuerySting, options)
    .then(response => Promise.all([response.status, response.json()]))
    .then(([statusCode, data]) => {
      handler(statusCode, data);
    })
    .catch((error) => {
      errorHandler(error);
    });

export default getInstitution;
