import React from 'react';
import PropTypes from 'prop-types';
import { Button, Modal, DatePicker } from 'axp-base';
import styles from '../static/css/ClientProfileMainStyles.scss';

const EditDatesModal = (props, { intl }) => {
  const langPack = intl.messages ? intl.messages : null;
  if (langPack === null) {
    return null;
  }
  return (
    <Modal
      contentCSS={`${styles.modalClass} modal-content`}
      shown={props.isEditDatesModalVisible}
      rootId="root"
      transitionCSS="modal-fade"
      escapable={true}
      closeOnOverlayClick={false}
      closeable={false}
    >
      <div className={`${styles.editModalWrapper} flex flex-column`}>
        <div className="dls-white dls-bright-blue-bg pad text-align-center">
          {langPack['editDates.title']}
          <button
            type="button"
            onClick={props.toggleModal}
            className={`${styles.modalCloseBtn} dls-white alert-close position-absolute margin-r`}
            data-dismiss="alert"
            aria-label="Close"
          />
        </div>
        <div className="flex flex-column pad-2">
          <div className="flex flex-align-center margin-1">
            <div className={`${styles.width100} flex flex-column`}>
              <div className={`${styles.datePicker}`}>
                <DatePicker
                  id="startDate"
                  label={langPack['editDate.newStartDate']}
                  autoHide={true}
                  onChange={props.handleStartDate}
                />
              </div>
              <div className={`${styles.datePicker}`}>
                <DatePicker
                  id="endDate"
                  label={langPack['editDate.newEndDate']}
                  autoHide={true}
                  onChange={props.handleEndDate}
                />
              </div>
            </div>
          </div>
          <div className="flex flex-align-center margin-0-t margin-1-l margin-1-r margin-1-b">
            <Button onClick={props.toggleModal} className={`${styles.width100} btn btn-primary`}>
              <span>{langPack['editDate.submitChange']} </span>
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

EditDatesModal.contextTypes = {
  intl: PropTypes.object,
};

EditDatesModal.propTypes = {
  isEditDatesModalVisible: PropTypes.bool.isRequired,
  toggleModal: PropTypes.func.isRequired,
  handleStartDate: PropTypes.func.isRequired,
  handleEndDate: PropTypes.func.isRequired,
};
export default EditDatesModal;
