import React from 'react';
import { Checkbox } from 'axp-base';

import PropTypes from 'prop-types';

export const Column = ({ rowType, column }) => {
  if (rowType === 'header') {
    return (
      <React.Fragment>
        <th>
          {column.name === 'selectAll' ? <div>{column.value}</div> :
          <div>{column.title}</div>
          }
        </th>
      </React.Fragment>
    );
  }
  return (
    <React.Fragment>
      <td>
        <div>{column}</div>
      </td>
    </React.Fragment>
  );
};

export const Row = ({ rowType, columns }) => {
  if (rowType === 'header') {
    return (
      <React.Fragment>
        <tr>
          {columns.map((item, idx) => (
            <Column key={`header-item-${idx + 1}`} rowType={rowType} column={item} />
          ))}
        </tr>
      </React.Fragment>
    );
  }

  return (
    <React.Fragment>
      <tr>
        {Object.keys(columns).map(
          (item, idx) =>
            item !== 'selected' && (
              <Column key={`body-item-${idx + 1}`} rowType={rowType} column={columns[item]} />
            )
        )}
      </tr>
    </React.Fragment>
  );
};

class Table extends React.Component {
  constructor(props) {
    super(props);
    const header = props.selectable
      ? [
        ...props.data.header,
        {
          name: 'selectAll',
          value: 'checkbox',
          title: 'checkbox',
        },
      ]
      : props.data.header;

    this.state = {
      header,
      isSelectAll: false,
    };
  }

  selectAllHandler = () => {
    const isSelectAll = !this.state.isSelectAll;
    this.setState(prevState => ({
      ...prevState,
      isSelectAll,
    }));
    const rows = this.props.data.body.map(item => ({ ...item, selected: isSelectAll }));
    const selectedRows = rows.filter(item => item.selected === true).map(item => item);
    this.props.selectionHandler(selectedRows, rows);
  };

  toggleRow(idx) {
    const rows = this.props.data.body;
    rows[idx].selected = !rows[idx].selected;
    const selectedRows = rows.filter(item => item.selected === true).map(item => item);
    const isSelectAll = rows.length === selectedRows.length;
    this.setState(prevState => ({
      ...prevState,
      isSelectAll,
    }));
    this.props.selectionHandler(selectedRows, rows);
  }

  render() {
    let { body } = this.props.data;
    const { header } = this.state;
    if (this.props.selectable) {
      const headerIndex = header.findIndex(item => item.name === 'selectAll');
      header[headerIndex].value = (
        <Checkbox
          id="selectAll"
          checked={this.state.isSelectAll}
          onChange={this.selectAllHandler}
        />
      );
      body = body.map((item, idx) => {
        const obj = item;
        const key = `select-${idx}`;
        const toggle = () => this.toggleRow(idx);
        obj.select = (
          <Checkbox key={key} id={`select-${idx}`} checked={item.selected} onChange={toggle} />
        );

        return obj;
      });
    }
    return (
      <table className={this.props.tableClass.trim()}>
        <thead className="table-header">
          <Row rowType="header" columns={header} />
        </thead>
        <tbody className="table-body">
          {body.map((item, idx) => (
            <Row key={`row-item-${idx + 1}`} rowType="body" columns={item} />
          ))}
        </tbody>
      </table>
    );
  }
}

Column.propTypes = {
  rowType: PropTypes.string.isRequired,
  column: PropTypes.oneOfType([PropTypes.string, PropTypes.object]).isRequired,
};

Row.propTypes = {
  rowType: PropTypes.string.isRequired,
  columns: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
};

Table.propTypes = {
  selectable: PropTypes.bool.isRequired,
  selectionHandler: PropTypes.func.isRequired,
  data: PropTypes.shape({
    header: PropTypes.array,
    body: PropTypes.array.isRequired,
  }).isRequired,
  tableClass: PropTypes.string.isRequired,
};

export default Table;
