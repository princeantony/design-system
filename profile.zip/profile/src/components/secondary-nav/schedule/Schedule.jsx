import React from 'react';

export const Schedule = () => (
  <div className="dls-white-bg pad margin">
    <h1 className="text-align-center">Partner Schedule Page</h1>
  </div>
);

export default Schedule;
