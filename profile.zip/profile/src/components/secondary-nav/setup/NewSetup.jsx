import React from 'react';

export const NewSetup = () => (
  <div className="dls-white-bg pad margin">
    <h1 className="text-align-center">New Set Up Page</h1>
  </div>
);

export default NewSetup;
