import React from 'react';

export const Maintenance = () => (
  <div className="dls-white-bg pad margin">
    <h1 className="text-align-center">Network Maintenance Page</h1>
  </div>
);

export default Maintenance;
