import React from 'react';

export const Financial = () => (
  <div className="dls-white-bg pad margin">
    <h1 className="text-align-center">Financial Page</h1>
  </div>
);

export default Financial;
