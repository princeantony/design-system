import React from 'react';

export const Configurations = () => (
  <div className="dls-white-bg pad margin">
    <h1 className="text-align-center">Configurations Management Page</h1>
  </div>
);

export default Configurations;
