import React from 'react';

export const Participant = () => (
  <div className="dls-white-bg pad margin">
    <h1 className="text-align-center">Participant Directory Page</h1>
  </div>
);

export default Participant;
