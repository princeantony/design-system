/* eslint-disable complexity */
import React from 'react';
import Pagination from 'react-js-pagination';
import PropTypes from 'prop-types';
import { Button, DataTable, Icon } from 'axp-base';
import styles from '../../static/css/ClientProfileMainStyles.scss';

class ViewInstitutionRelationships extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      activePage: 1,
      itemsCountPerPage: 10,
      pageRangeDisplayed: 5,
      prevPageText: 'Previous',
      nextPageText: 'Next',
      institutionCollection: [],
    };
    this.handlePageChange = this.handlePageChange.bind(this);
  }

  handlePageChange(pageNumber) {
    const itemCollectionClone = [...this.props.institutionData];
    this.updatePagination(itemCollectionClone, pageNumber);
  }
  updatePagination = (itemCollectionClone, pageNumber) => {
    const pageNo = parseInt(pageNumber, 10);

    const size = this.state.itemsCountPerPage;

    const skip = size * (pageNo - 1);
    const limit = size;
    const paginatedItemCollections = itemCollectionClone.splice(skip, limit);
    this.setState({
      activePage: pageNumber, // updating value
      institutionCollection: paginatedItemCollections,
    });
  };
  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : {};
    if (!langPack || Object.keys(langPack).length === 0) {
      return null;
    }
    let instTableData = this.props.institutionData;
    const tableHeader = this.props.tableHeaders.map((dataItem) => {
      const retObj = Object.assign({}, dataItem);
      retObj.title = langPack[dataItem.title];
      return retObj;
    });

    if (this.props.institutionData.length) {
      if (this.props.detailView) {
        const institutionsList = this.state.institutionCollection.length
          ? this.state.institutionCollection
          : this.props.institutionData.slice(0, this.state.itemsCountPerPage);
        instTableData = institutionsList.map(dataItem => ({
          ...dataItem,
          col_icon_1: <Icon className="dls-icon-business dls-color-info icon-sm" />,
        }));
      }
      const instViewRecords = instTableData.length > 25 ? instTableData.slice(0, 25)
        : instTableData;
      return (
        <div className={this.props.compClasses}>
          {this.props.detailView && (
            <div
              className={`${
            styles.headerPadding
          } flex flex-row flex-justify-between headerPadding dls-color-primary-bg`}
            >
              <h2 className="pad-1 dls-white body-3">{langPack['institutionRelation.title']}</h2>
              <Button
                id="viewAllEditBtn"
                className="btn-icon btn-sm dls-icon-edit"
                onClick={this.props.setEditMode}
              />
            </div>
              ) }

          <DataTable
            columns={tableHeader}
            data={this.props.detailView ? instTableData : instViewRecords}
            className={`${styles.viewCapabilitiesTableOverflow} border-lr`}
          />

          {!this.props.detailView && (
          <div className="text-align-right pad-2-t">
            <Button
              id="viewAllBtn"
              className="btn-sm"
              onClick={this.props.setViewAll}
              label={langPack.viewAll}
            />
          </div>
            )}

          {(this.props.detailView) && (
            <div className="row pad-responsive">
              {this.props.institutionData.length >= 25 &&
              <div className="col-md-8">
                <div className={`${styles.pagination}`}>
                  <Pagination
                    id="profilesPagination"
                    activePage={this.state.activePage}
                    itemsCountPerPage={this.state.itemsCountPerPage}
                    totalItemsCount={this.props.institutionData.length}
                    pageRangeDisplayed={this.state.pageRangeDisplayed}
                    prevPageText={this.state.prevPageText}
                    nextPageText={this.state.nextPageText}
                    hideDisabled={true}
                    onChange={this.handlePageChange}
                  />
                </div>
              </div>
              }
              <div className={this.props.institutionData.length > 25 ? 'col-md-4' : 'col-md-12'}>
                <div className="text-align-right">
                  <Button
                    id="viewAllbackBtn"
                    className="btn-sm"
                    label={langPack.back}
                    onClick={this.props.setViewAll}
                  />
                </div>
              </div>
            </div>
            )}
        </div>
      );
    }
    return <div className="dls-color-warning text-align-center pad-4-tb">{langPack.institutionMsgNoData}</div>;
  }
}

ViewInstitutionRelationships.contextTypes = {
  intl: PropTypes.object,
};

ViewInstitutionRelationships.defaultProps = {
  compClasses: '',
};

ViewInstitutionRelationships.propTypes = {
  institutionData: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.object).isRequired,
    PropTypes.object.isRequired,
  ]).isRequired,
  setViewAll: PropTypes.func.isRequired,
  setEditMode: PropTypes.func.isRequired,
  compClasses: PropTypes.string,
  detailView: PropTypes.bool.isRequired,
  tableHeaders: PropTypes.arrayOf(PropTypes.object).isRequired,
};

export default ViewInstitutionRelationships;
