import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from 'axp-base';
import ViewInstitutionRelationships from './ViewInstitutionRelationships';
import EditInstitutionRelationships from './EditInstitutionRelationships';
import { tableBody, iconArray, columnHeader } from './InstitutionalRelationshipsData';
import styles from '../../static/css/ClientProfileMainStyles.scss';
import AppIcon from '../../common/AppIcon';

export const IndicatorIcons = ({ langPack }) => (
  <div className="flex flex-wrap">
    {iconArray.map((item) => {
      const propName = item.name;
      const name = langPack[propName];
      if (item.inbuild) {
        return (
          <div className={styles.svgOuterDiv}>
            <span className={`pad-1 ${styles.inbuildIconStyle}`} key={item.name}>
              <AppIcon
                iconName={item.inbuildName}
                classes={`${styles.iconSize} ${styles.alignIcon}`}
              />
            </span>
            <div className={styles.svgContent}>- {name}</div>
          </div>
        );
      }
      return (
        <span className="pad-1" key={item.name}>
          <Icon className={`${item.class} ${styles.alignIcon} dls-color-info icon-sm`} /> - {name}
        </span>
      );
    })}
  </div>
);

const InstitutionRelationships = (props, { intl }) => {
  const langPack = intl.messages ? intl.messages : {};
  if (!langPack || Object.keys(langPack).length === 0) {
    return null;
  }
  let tableData = [];
  // Adding Icon to institution data
  if (props.institutionData && props.institutionData.length !== 0) {
    tableData = props.institutionData.map(eachObj =>
      Object.assign({}, eachObj, { col_icon_1: <Icon className="dls-icon-business dls-color-info icon-sm" /> })
    );
  }
  const tableHeader = columnHeader.map((dataItem) => {
    const retObj = Object.assign({}, dataItem);
    retObj.title = langPack[dataItem.title];
    return retObj;
  });
  if (props.isEditmode) {
    return (
      <div>
        <EditInstitutionRelationships
          tableHeaders={tableHeader}
          tableBody={tableBody}
          iconArray={iconArray}
          cancelEditInstitutionRelationships={props.cancelEditInstitutionRelationships}
        />
        <IndicatorIcons langPack={langPack} />
      </div>
    );
  }
  return (
    <div>
      <ViewInstitutionRelationships
        institutionData={tableData}
        detailView={props.detailView}
        setViewAll={props.setViewAll}
        tableHeaders={columnHeader}
        setEditMode={props.setEditMode}
      />
      <IndicatorIcons langPack={langPack} />
    </div>
  );
};
InstitutionRelationships.contextTypes = {
  intl: PropTypes.object,
};
InstitutionRelationships.propTypes = {
  isEditmode: PropTypes.bool.isRequired,
  setViewAll: PropTypes.func.isRequired,
  setEditMode: PropTypes.func.isRequired,
  detailView: PropTypes.bool.isRequired,
  cancelEditInstitutionRelationships: PropTypes.func.isRequired,
  institutionData: PropTypes.arrayOf(PropTypes.object).isRequired,
};

IndicatorIcons.propTypes = {
  langPack: PropTypes.shape({}).isRequired,
};

export default InstitutionRelationships;
