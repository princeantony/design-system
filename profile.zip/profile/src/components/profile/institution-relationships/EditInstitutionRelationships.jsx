import React from 'react';
import PropTypes from 'prop-types';
import { Button, Icon } from 'axp-base';
import Table from '../../common/Table';
import styles from '../../static/css/ClientProfileMainStyles.scss';
import EditDatesModal from '../../common/EditDatesModal';

class EditInstitutionRelationships extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isEditDatesModalVisible: false,
      selectedRows: [],
      allRows: this.tableBody(props.tableBody),
      startDate: '',
      endDate: '',
    };
    this.selectedData = [];
  }

  tableBody = data =>
    data.map(item => (item.selected !== undefined ? { ...item } : { ...item, selected: false }));

  selectionHandler = (selectedRows, allRows) => {
    this.setState(prevState => ({ ...prevState, selectedRows, allRows }));
  };

  handleStartDate = (startDate) => {
    this.setState(prevState => ({ ...prevState, startDate }));
  };

  handleEndDate = (endDate) => {
    this.setState(prevState => ({ ...prevState, endDate }));
  };

  toggleModal = (event) => {
    const fromCloseBtn = event.target.className.search('alert-close') !== -1;
    if (this.state.isEditDatesModalVisible && !fromCloseBtn) {
      const rows = this.state.allRows;
      const newRows = rows.map(obj =>
        (obj.selected === true
          ? { ...obj, startDate: this.state.startDate, endDate: this.state.endDate }
          : { ...obj })
      );
      this.setState({ allRows: newRows });
    }
    this.setState(prevState => ({
      ...prevState,
      isEditDatesModalVisible: !this.state.isEditDatesModalVisible,
    }));
  };

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : null;
    if (langPack === null) {
      return null;
    }
    const body = this.state.allRows;
    const data = body.map(obj => ({
      orgIcon: <Icon className="dls-icon-bank  dls-color-info" />,
      ...obj,
    }));
    const tableData = { header: this.props.tableHeaders, body: data };
    const enableEditBtn = this.state.selectedRows.length > 0;
    return (
      <div className={`${styles.flexGrow} ${styles.editIR} dls-white-bg`}>
        <div className="dls-white dls-bright-blue-bg pad-1">
          {langPack['institutionRelation.title']}
        </div>
        <div className="pad">
          <div className={`${styles.width100} ${styles.autoOverflow}`}>
            <Table
              selectable={true}
              selectionHandler={this.selectionHandler}
              data={tableData}
              tableClass={`${styles.institutionRelationTable} margin-0 table data-table`}
            />
          </div>

          <div className="text-align-right margin margin-2-t">
            <Button
              id="editDates"
              className="btn btn-sm btn-primary margin-2-r"
              label={langPack.editSelected}
              onClick={this.toggleModal}
              disabled={!enableEditBtn}
            />
            <Button
              id="launchEditModal"
              className="btn btn-sm btn-secondary"
              label={langPack.cancel}
              onClick={this.props.cancelEditInstitutionRelationships}
            />
          </div>
        </div>

        <EditDatesModal
          isEditDatesModalVisible={this.state.isEditDatesModalVisible}
          toggleModal={this.toggleModal}
          handleStartDate={this.handleStartDate}
          handleEndDate={this.handleEndDate}
        />
      </div>
    );
  }
}

EditInstitutionRelationships.contextTypes = {
  intl: PropTypes.object,
};

EditInstitutionRelationships.propTypes = {
  tableHeaders: PropTypes.arrayOf(PropTypes.object).isRequired,
  tableBody: PropTypes.arrayOf(PropTypes.object).isRequired,
  cancelEditInstitutionRelationships: PropTypes.func.isRequired,
};

export default EditInstitutionRelationships;
