/* eslint-disable complexity */
import React from 'react';
import PropTypes from 'prop-types';
import { connectAsync } from 'iguazu';
import { Collapsible, Button } from 'axp-base';
import styles from '../static/css/ClientProfileMainStyles.scss';
import { Demographics } from './demographics/Demographics';
import InstitutionRelationships from './institution-relationships/InstitutionRelationships';
import Capabilities from './capabilities/Capabilities';
import { Search } from '../search/Search';
import { queryProfilesOnloadData } from '../query/country';
import LoadingScreen from '../main/LoadingScreen';
import { ProfileSummary } from './ProfileSummary';
import FetchDemographics from '../apis/getDemographicsByOrg';
import FetchCapabilities from '../apis/getCapabilities';
import getInstitutionByOrgId from '../apis/getInstitutionByOrg';
import OrgData from '../profile/demographics/DemoData';

export class ProfileDetails extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      isEditDemographics: false,
      isEditInstitutionRelationships: false,
      isEditCapabilities: false,
      isViewAllCapabilities: false,
      isViewAllInstitutionalRelations: false,
      isViewDemographics: false,
      demographicsDataByOrg: '',
      demographicsDataByInstitution: [],
      institutionData: [],
      capabilitiesData: '',
      searchDemographicsErrMsg: '',
      searchInstitutionErrMsg: '',
      searchCapabilitiesErrMsg: '',
      regionErrMsg: '',
      countryErrMsg: '',
      orgIdToProfileSummary: '',
      orgNameToProfileSummary: '',
      institutionIdToProfileSummary: '',
    };
  }

  handleSearch = (searchDetails) => {
    const orgIdSelected = searchDetails.advancedSearchQueryObj.orgId;
    const institutionIdSelected = searchDetails.advancedSearchQueryObj.institutionID;
    const orgIdInInstitution =
      searchDetails.institutionViewData && searchDetails.institutionViewData.organization
        ? searchDetails.institutionViewData.organization.organization_identifier
        : null;
    const orgIdToProfileSummary = searchDetails.organizationViewData
      ? searchDetails.organizationViewData.organization_identifier
      : '';
    const orgNameToProfileSummary =
      searchDetails.organizationViewData && searchDetails.organizationViewData.organization_name
        ? searchDetails.organizationViewData.organization_name.legal_name
        : '';
    const institutionIdToProfileSummary = searchDetails.institutionViewData
      ? searchDetails.institutionViewData.institution_identifier
      : '';
    this.setState({
      searchDemographicsErrMsg: '',
      searchInstitutionErrMsg: '',
      searchCapabilitiesErrMsg: '',
      isViewDemographics: true,
    });

    if (orgIdSelected && institutionIdSelected) {
      this.setState({
        demographicsDataByOrg: searchDetails.organizationViewData,
        demographicsDataByInstitution: searchDetails.institutionViewData,
        institutionData: searchDetails.institutionViewData,
        orgIdToProfileSummary,
        orgNameToProfileSummary,
        institutionIdToProfileSummary,
      });
      this.fetchCapabilities(institutionIdSelected);
    }
    if (orgIdSelected && !institutionIdSelected) {
      this.setState({
        demographicsDataByOrg: searchDetails.organizationViewData,
        demographicsDataByInstitution: [],
        capabilitiesData: [],
        orgIdToProfileSummary,
        orgNameToProfileSummary,
        institutionIdToProfileSummary: '',
      });
      this.fetchInstitutionByOrgId(orgIdSelected);
    }
    if (!orgIdSelected && institutionIdSelected) {
      const orgNameProfileSummary =
        searchDetails.institutionViewData && searchDetails.institutionViewData.organization
          ? searchDetails.institutionViewData.organization.organization_doing_business_as_name
          : ''; // Need to confirm which field
      if (orgIdInInstitution === null) {
        this.setState({ demographicsDataByOrg: [] });
      } else {
        this.fetchDemographics(orgIdInInstitution);
      }
      this.setState({
        demographicsDataByInstitution: searchDetails.institutionViewData,
        institutionData: searchDetails.institutionViewData,
        orgIdToProfileSummary: orgIdInInstitution,
        orgNameToProfileSummary: orgNameProfileSummary,
        institutionIdToProfileSummary,
      });
      this.fetchCapabilities(institutionIdSelected);
    }
  };

  handleDemographicsSuccess = (statusCode, demographics) => {
    if (statusCode < 200 || statusCode > 299) {
      this.setState({ searchDemographicsErrMsg: demographics });
    } else {
      this.setState({ demographicsDataByOrg: demographics.result });
    }
  };
  handleDemographicsFailure = () => {
    this.setState({ demographicsDataByOrg: null });
    this.setState({ searchDemographicsErrMsg: this.context.intl.messages.apiFailureMsg });
  };
  fetchDemographics = (orgIdSelected) => {
    const { organizations } = this.context.intl.messages.links;
    const url = `${organizations}/${orgIdSelected}`;
    const options = {
      method: 'get',
      headers: { 'Content-Type': 'application/json' },
    };

    return FetchDemographics(
      url,
      this.handleDemographicsSuccess,
      this.handleDemographicsFailure,
      options
    );
  };

  handleInstitutionOnOrgIdSuccess = (statusCode, institution) => {
    if (statusCode < 200 || statusCode > 299) {
      this.setState({ searchInstitutionErrMsg: institution });
    } else {
      this.setState({ institutionData: institution });
    }
  };
  handleInstitutionOnOrgIdFailure = () => {
    this.setState({ institutionData: [] });
    this.setState({ searchInstitutionErrMsg: this.context.intl.messages.apiFailureMsg });
  };
  fetchInstitutionByOrgId = (orgId) => {
    const { institutions } = this.context.intl.messages.links;
    const url = `${institutions}/${orgId}`;
    const options = {
      method: 'get',
      headers: { 'Content-Type': 'application/json' },
    };

    return getInstitutionByOrgId(
      url,
      this.handleInstitutionOnOrgIdSuccess,
      this.handleInstitutionOnOrgIdFailure,
      options
    );
  };

  handleCapabilitiesSuccess = (statusCode, capabilities) => {
    if (statusCode < 200 || statusCode > 299) {
      this.setState({ searchCapabilitiesErrMsg: capabilities });
    } else {
      this.setState({ capabilitiesData: capabilities.capabilities });
    }
  };
  handleCapabilitiesFailure = () => {
    this.setState({ capabilitiesData: null });
    this.setState({ searchCapabilitiesErrMsg: this.context.intl.messages.apiFailureMsg });
  };
  fetchCapabilities = (institutionIdSelected) => {
    const { getCapabilities } = this.context.intl.messages.links;
    const url = `${getCapabilities}/${institutionIdSelected}`;
    const options = {
      method: 'get',
      headers: { 'Content-Type': 'application/json' },
    };

    return FetchCapabilities(
      url,
      this.handleCapabilitiesSuccess,
      this.handleCapabilitiesFailure,
      options
    );
  };

  handleSession = () => {
    this.setState({ isEditDemographics: true });
  };

  handleEditInstitutionRelationships = () => {
    this.setState({ isEditInstitutionRelationships: !this.state.isEditInstitutionRelationships });
  };

  handleCancelDemographics = () => {
    this.setState({ isEditDemographics: false });
  };

  enableEditDemographics = () => {
    this.setState({ isEditDemographics: true });
  };

  handleSessionCapabilities = () => {
    this.setState({ isEditCapabilities: !this.state.isEditCapabilities });
  };

  handleEditInstitutionRelation = () => {
    this.setState({ isEditInstitutionRelationships: !this.state.isEditInstitutionRelationships });
  };

  handleViewAllInstitutionRelation = () => {
    this.setState({ isViewAllInstitutionalRelations: !this.state.isViewAllInstitutionalRelations });
  };

  handleViewAllCapabilities = () => {
    this.setState({ isViewAllCapabilities: !this.state.isViewAllCapabilities });
  };

  isEditOrViewAllCapabilities = () =>
    this.state.isEditCapabilities || this.state.isViewAllCapabilities;

  isEditOrViewAllInstitutionRelations = () =>
    this.state.isEditInstitutionRelationships || this.state.isViewAllInstitutionalRelations;

  render() {
    const isEditOrViewAllCapabilities = this.isEditOrViewAllCapabilities();
    const isEditOrViewAllInstitutionRelations = this.isEditOrViewAllInstitutionRelations();
    const langPack = this.context.intl.messages ? this.context.intl.messages : null;
    if (
      !langPack ||
      Object.keys(langPack).length === 0 ||
      this.props.isLoading(['profilesOnLoadData'])
    ) {
      return <LoadingScreen />;
    }

    return (
      <div>
        <div className="row">
          <div className="margin-0 col-md-12">
            <ProfileSummary
              orgIdToProfileSummary={this.state.orgIdToProfileSummary}
              orgNameToProfileSummary={this.state.orgNameToProfileSummary}
              institutionIdToProfileSummary={this.state.institutionIdToProfileSummary}
            />
          </div>
        </div>
        <div className={`${styles.alignRow} row margin-0`}>
          {!this.state.isEditDemographics &&
            !this.state.isEditInstitutionRelationships &&
            !this.state.isEditCapabilities && (
              <Search
                regionList={this.props.profilesOnLoadData.region}
                onHandleSearch={this.handleSearch}
                countryList={this.props.profilesOnLoadData.countries}
                regionApiErrMsg={this.state.regionErrMsg}
                countryApiErrMsg={this.state.countryErrMsg}
              />
            )}
          <div
            className={`dls-white-bg  ${styles.flexGrow} ${
              styles.resultsContainer
            } margin-1-l margin-t pad-2-t pad-2-lr`}
          >
            {this.state.isViewDemographics && (
              <React.Fragment>
                <div>
                  <div className="pad-1-b">
                    {this.state.isEditDemographics &&
                      !this.state.isEditInstitutionRelationships &&
                      !this.state.isViewAllCapabilities && (
                        <Demographics
                          isEditmode={this.state.isEditDemographics}
                          content={OrgData}
                          handleCancelDemographics={this.handleCancelDemographics}
                        />
                      )}
                    {!this.state.isEditDemographics &&
                      !this.state.isEditInstitutionRelationships &&
                      !this.state.isEditCapabilities &&
                      !this.state.isViewAllCapabilities &&
                      !this.state.isViewAllInstitutionalRelations && (
                        <Collapsible
                          id="demographics"
                          label={langPack.demographics}
                          className={`${styles.customAccordion}`}
                          headerClasses="dls-bright-blue-bg dls-white"
                          privateKey="demographics"
                          open={this.state.isViewDemographics}
                        >
                          <Button
                            id="buttonEditDemographics"
                            className={`${styles.customIcon} btn-icon dls-icon-edit`}
                            onClick={() => this.handleSession()}
                          />
                          <Demographics
                            demographicsDataByOrg={this.state.demographicsDataByOrg}
                            demographicsDataByInstitution={this.state.demographicsDataByInstitution}
                            isEditmode={this.state.isEditDemographics}
                            content={OrgData}
                            handleCancelDemographics={this.handleCancelDemographics}
                            apiErrMsg={this.state.searchDemographicsErrMsg}
                          />
                        </Collapsible>
                      )}
                  </div>
                  <div className="pad-1-b">
                    {!this.state.isEditDemographics &&
                      !this.state.isEditCapabilities &&
                      !this.state.isViewAllCapabilities && (
                        <Collapsible
                          id="collapsibleInstitutionRelationships"
                          label={langPack['institutionRelation.title']}
                          privateKey="institutionRelationship"
                          className={`${styles.customAccordion}`}
                          headerClasses="dls-bright-blue-bg dls-white"
                          open={isEditOrViewAllInstitutionRelations}
                          stripHeader={isEditOrViewAllInstitutionRelations}
                        >
                          {!isEditOrViewAllInstitutionRelations
                          && (this.state.institutionData.length !== 0) && (
                            <Button
                              id="buttonEditIR"
                              className={`${styles.editIcon} btn-icon dls-icon-edit`}
                              onClick={this.handleEditInstitutionRelationships}
                            />
                          )}
                          <InstitutionRelationships
                            institutionData={this.state.institutionData}
                            detailView={this.state.isViewAllInstitutionalRelations}
                            isEditmode={this.state.isEditInstitutionRelationships}
                            setViewAll={this.handleViewAllInstitutionRelation}
                            setEditMode={this.handleEditInstitutionRelationships}
                            cancelEditInstitutionRelationships={
                              this.handleEditInstitutionRelationships
                            }
                            apiErrMsg={this.state.searchInstitutionErrMsg}
                          />
                        </Collapsible>
                      )}
                  </div>
                  <div className="pad-1-b">
                    {!this.state.isEditDemographics &&
                      !this.state.isEditInstitutionRelationships &&
                      !this.state.isViewAllInstitutionalRelations && (
                        <Collapsible
                          id="collapsibleCapabilities"
                          label={langPack.capabilities}
                          privateKey="capabilities"
                          className={`${styles.customAccordion}`}
                          headerClasses="dls-bright-blue-bg dls-white"
                          open={isEditOrViewAllCapabilities}
                          stripHeader={isEditOrViewAllCapabilities}
                        >
                          {!isEditOrViewAllCapabilities && (
                            <Button
                              id="buttonEditCapabilities"
                              className={`${styles.customIcon} btn-icon dls-icon-edit`}
                              onClick={() => this.handleSessionCapabilities()}
                            />
                          )}
                          <Capabilities
                            capabilitiesData={this.state.capabilitiesData}
                            detailView={this.state.isViewAllCapabilities}
                            isEditmode={this.state.isEditCapabilities}
                            setViewAll={this.handleViewAllCapabilities}
                            setEditMode={this.handleSessionCapabilities}
                            onHandleCancel={this.handleSessionCapabilities}
                            apiErrMsg={this.state.searchCapabilitiesErrMsg}
                          />
                        </Collapsible>
                      )}
                  </div>
                </div>
              </React.Fragment>
            )}
          </div>
        </div>
      </div>
    );
  }
}

export const loadDataAsProps = ({ store: { dispatch } }) => ({
  profilesOnLoadData: () => dispatch(queryProfilesOnloadData()),
});

ProfileDetails.contextTypes = {
  intl: PropTypes.object,
};

ProfileDetails.propTypes = {
  isLoading: PropTypes.func.isRequired,
  profilesOnLoadData: PropTypes.shape({
    countries: PropTypes.arrayOf(PropTypes.object),
    region: PropTypes.arrayOf(PropTypes.object),
  }).isRequired,
};

export default connectAsync({ loadDataAsProps })(ProfileDetails);
