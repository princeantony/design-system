import React from 'react';
import PropTypes from 'prop-types';
import styles from '../static/css/ClientProfileMainStyles.scss';

export const SummaryBlock = ({ text, label }) => (
  <div className={`${styles.headerSummaryBlock} ${styles.flexGrow} text-nowrap`}>
    <span className="text-uppercase pad-lr font-weight-bold">{label}: </span>
    <span>{text}</span>
  </div>
);

export class ProfileSummary extends React.Component {
  constructor(props) {
    super(props);
    const orgName = this.props.orgNameToProfileSummary;
    const orgId = this.props.orgIdToProfileSummary;
    const dealType = '';
    const pnType = '';
    const institutionId = this.props.institutionIdToProfileSummary;
    this.state = {
      orgName,
      orgId,
      dealType,
      pnType,
      institutionId,
    };
  }
  componentWillReceiveProps(nextProps) {
    this.profileSummary(
      nextProps.orgIdToProfileSummary,
      nextProps.orgNameToProfileSummary,
      nextProps.institutionIdToProfileSummary
    );
  }

  profileSummary = (
    orgIdToProfileSummary,
    orgNameToProfileSummary,
    institutionIdToProfileSummary
  ) => {
    this.setState({
      orgId: orgIdToProfileSummary,
      orgName: orgNameToProfileSummary,
      institutionId: institutionIdToProfileSummary,
      dealType: 'Text',
      pnType: 'Text',
    });
  };
  render() {
    return (
      <div className={`${styles.headerSummary} dls-white-bg flex flex-align-center`}>
        <SummaryBlock label="Org Name" text={this.state.orgName} />
        <SummaryBlock label="Org ID" text={this.state.orgId} />
        <SummaryBlock label="Deal Type" text={this.state.dealType} />
        <SummaryBlock label="P/N Type" text={this.state.pnType} />
        <SummaryBlock label="Institution ID" text={this.state.institutionId} />
      </div>
    );
  }
}

SummaryBlock.propTypes = {
  label: PropTypes.string.isRequired,
  text: PropTypes.string.isRequired,
};

ProfileSummary.propTypes = {
  orgNameToProfileSummary: PropTypes.string,
  orgIdToProfileSummary: PropTypes.string,
  institutionIdToProfileSummary: PropTypes.string,
};
ProfileSummary.defaultProps = {
  orgNameToProfileSummary: '',
  orgIdToProfileSummary: '',
  institutionIdToProfileSummary: '',
};

export default ProfileSummary;
