import React from 'react';
import PropTypes from 'prop-types';
import styles from '../../static/css/ClientProfileMainStyles.scss';

export const ViewDemographics = ({ content }, { intl }) => (
  <div className={`${styles.flexGrow}`}>
    <div className={`${styles.width100} ${styles.autoOverflow}`}>
      <table className="table-fluid table-lg table-collapse-md-down">
        {/* ROW 1 */}
        <tr className="col-md-12">
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.legalName']}</h4>
            <label htmlFor="legalName" className="label-1 pad-1-t">
              <span id="legalName">{content.legalName}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.dbaName']}</h4>
            <label htmlFor="dbaName" className="label-1 pad-1-t">
              <span id="dbaName">{content.dbaName}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.dealCodeName']}</h4>
            <label htmlFor="dealCodeName" className="label-1 pad-1-t">
              <span id="dealCodeName">{content.dealCodeName}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages.roleType}</h4>
            <label htmlFor="roleType" className="label-1 pad-1-t">
              <span id="roleType">{content.roleType}</span>
            </label>
          </td>
        </tr>
        {/* ROW 1 ENDS */}

        {/* ROW 2 */}
        <tr>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.address']}</h4>
            <label htmlFor="address" className="label-1 pad-1-t">
              <span id="address">{content.address}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.city']}</h4>
            <label htmlFor="city" className="label-1 pad-1-t">
              <span id="city">{content.city}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.stateRegion']}</h4>
            <label htmlFor="stateRegion" className="label-1 pad-1-t">
              <span id="stateRegion">{content.stateRegion}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.postalCode']}</h4>
            <label htmlFor="postalCode" className="label-1 pad-1-t">
              <span id="postalCode">{content.postalCode}</span>
            </label>
          </td>
        </tr>
        {/* ROW 2 ENDS */}

        {/* ROW 3 */}
        <tr>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.country']}</h4>
            <label htmlFor="country" className="label-1 pad-1-t">
              <span id="country">{content.country}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.domicileCountry']}</h4>
            <label htmlFor="domicleCountry" className="label-1 pad-1-t">
              <span id="domicleCountry">{content.domicleCountry}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.regionID']}</h4>
            <label htmlFor="regionID" className="label-1 pad-1-t">
              <span id="regionID">{content.regionID}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.dealConstruct']}</h4>
            <label htmlFor="dealConstruct" className="label-1 pad-1-t">
              <span id="dealConstruct">{content.dealConstruct}</span>
            </label>
          </td>
        </tr>
        {/* ROW 3 ENDS */}

        {/* ROW 4 */}
        <tr>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.businessCenter']}</h4>
            <label htmlFor="businessCenter" className="label-1 pad-1-t">
              <span id="businessCenter">{content.businessCenter}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.doubleByte']}</h4>
            <label htmlFor="doubleByte" className="label-1 pad-1-t">
              <span id="doubleByte">{content.doubleByte}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.productType']}</h4>
            <label htmlFor="productType" className="label-1 pad-1-t">
              <span id="productType">{content.productType}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.postalCode']}</h4>
            <label htmlFor="walletIndicator" className="label-1 pad-1-t">
              <span id="walletIndicator">{content.walletIndicator}</span>
            </label>
          </td>
        </tr>
        {/* ROW 4 ENDS */}

        {/* ROW 5 */}
        <tr>
          <td className="pad-1">
            <h4 className="border-b heading-3">
              {intl.messages['demographics.paymentCategoryCode']}
            </h4>
            <label htmlFor="paymentCategoryCode" className="label-1 pad-1-t">
              <span id="paymentCategoryCode">{content.paymentCategoryCode}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.localTricsCenter']}</h4>
            <label htmlFor="localTricsCenter" className="label-1 pad-1-t">
              <span id="localTricsCenter">{content.localTricsCenter}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">
              {intl.messages['demographics.foreignTricsCenter']}
            </h4>
            <label htmlFor="foreignTricsCenter" className="label-1 pad-1-t">
              <span id="foreignTricsCenter">{content.foreignTricsCenter}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">
              {intl.messages['demographics.primaryInstitution']}
            </h4>
            <label htmlFor="primaryInstitution" className="label-1 pad-1-t">
              <span id="primaryInstitution">{content.primaryInstitution}</span>
            </label>
          </td>
        </tr>
        {/* ROW 5 ENDS */}

        {/* ROW 6 */}
        <tr>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.safekeyRegion']}</h4>
            <label htmlFor="safekeyRegion" className="label-1 pad-1-t">
              <span id="safekeyRegion">{content.safekeyRegion}</span>
            </label>
          </td>
          <td className="pad-1">
            <h4 className="border-b heading-3">{intl.messages['demographics.serviceCenter']}</h4>
            <label htmlFor="serviceCenter" className="label-1 pad-1-t">
              <span id="serviceCenter">{content.serviceCenter}</span>
            </label>
          </td>
        </tr>
        {/* ROW 6 ENDS */}
      </table>
    </div>
  </div>
);

ViewDemographics.contextTypes = {
  intl: PropTypes.object,
};

ViewDemographics.propTypes = {
  content: PropTypes.instanceOf(Object).isRequired,
};

export default ViewDemographics;
