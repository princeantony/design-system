import React from 'react';
import PropTypes from 'prop-types';
import { ViewDemographics } from './ViewDemographics';
import { EditDemographics } from './EditDemographics';

export const Demographics = ({ isEditmode, content, handleCancelDemographics }) => (
  <div>
    {isEditmode ?
      <EditDemographics
        orgData={content}
        handleCancelDemographics={handleCancelDemographics}
      /> :
      <ViewDemographics content={content} /> }
  </div>
);

Demographics.propTypes = {
  isEditmode: PropTypes.bool.isRequired,
  content: PropTypes.instanceOf(Object).isRequired,
  handleCancelDemographics: PropTypes.func.isRequired,
};

export default Demographics;
