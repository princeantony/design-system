import React from 'react';
import PropTypes from 'prop-types';
import { Input, Button, Dropdown, Radio, RadioGroup } from 'axp-base';
import styles from '../../static/css/ClientProfileMainStyles.scss';

const countryCode = [
  { value: 0, code: '840-USA' },
  { value: 1, label: '379-USA' },
  { value: 2, label: '928-USA' },
  { value: 3, label: '752-USA' },
  { value: 4, label: '460-USA' },
];

export class EditDemographics extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selected: '',
    };
  }

  updateSelected = (val) => {
    this.setState({ selected: val });
  };

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : {};
    const { selected } = this.state;
    const { handleCancelDemographics } = this.props;
    return (
      <div className="dls-white-bg">
        <div className="dls-white dls-bright-blue-bg dls-cobrand-schwab-bg-hvr pad">
          {langPack.demographics}
        </div>
        <table className="table-fluid table-collapse-sm-down margin-2-t">
          {/* ROW 1 */}
          <tr>
            <td>
              <h4>{langPack['demographics.legalName']}</h4>
              <Input id="legalName" value={this.props.orgData.legalName} type="text" />
            </td>
            <td>
              <h4>{langPack['demographics.dbaName']}</h4>
              <Input id="dbaName" value={this.props.orgData.dbaName} type="text" />
            </td>
            <td>
              <h4>{langPack['demographics.dealCodeName']}</h4>
              <Input id="dealCodeName" value={this.props.orgData.dealCodeName} type="text" />
            </td>
            <td>
              <h4>{langPack.roleType}</h4>
              <Input id="roleType" value={this.props.orgData.roleType} type="text" />
            </td>
          </tr>
          {/* ROW 1 ENDS */}

          {/* ROW 2 */}
          <tr>
            <td>
              <h4>{langPack['demographics.address']}</h4>
              <Input id="address" value={this.props.orgData.address} type="text" />
            </td>
            <td>
              <h4>{langPack['demographics.city']}</h4>
              <Input id="city" value={this.props.orgData.city} type="text" />
            </td>
            <td>
              <h4>{langPack['demographics.stateRegion']}</h4>
              <Input id="stateRegion" value={this.props.orgData.stateRegion} type="text" />
            </td>
            <td>
              <h4>{langPack['demographics.postalCode']}</h4>
              <Input id="postalCode" value={this.props.orgData.postalCode} type="text" />
            </td>
          </tr>
          {/* ROW 2 ENDS */}

          {/* ROW 3 */}
          <tr>
            <td>
              <h4>{langPack['demographics.country']}</h4>
              <Dropdown id="country" className={`${styles.unsetMaxWidth}`} options={countryCode} />
            </td>
            <td>
              <h4>{langPack['demographics.domicileCountry']}</h4>
              <Dropdown
                id="domicileCountry"
                className={`${styles.unsetMaxWidth}`}
                options={countryCode}
              />
            </td>
            <td>
              <h4>{langPack['demographics.regionID']}</h4>
              <Input id="regionID" value={this.props.orgData.regionID} type="text" />
            </td>
            <td>
              <h4>{langPack['demographics.dealConstruct']}</h4>
              <Input id="dealConstruct" value={this.props.orgData.dealConstruct} type="text" />
            </td>
          </tr>
          {/* ROW 3 ENDS */}

          {/* ROW 4 */}
          <tr>
            <td>
              <h4>{langPack['demographics.businessCenter']}</h4>
              <Input id="businessCenter" value={this.props.orgData.businessCenter} type="text" />
            </td>
            <td>
              <h4>{langPack['demographics.doubleByte']}</h4>
              <RadioGroup selectedValue={selected}>
                <Radio
                  id="doubleByte-yes-radio-option"
                  label="Yes"
                  value="doubleByte-yes"
                  className="display-inline-block margin-tb margin-r"
                  onChange={this.updateSelected}
                />
                <Radio
                  id="doubleByte-no-radio-option"
                  label="No"
                  value="doubleByte-no"
                  className="display-inline-block margin-tb margin-r"
                  onChange={this.updateSelected}
                />
              </RadioGroup>
            </td>
            <td>
              <h4>{langPack['demographics.productType']}</h4>
              <Dropdown
                id="productType"
                className={`${styles.unsetMaxWidth}`}
                options={countryCode}
              />
            </td>
            <td>
              <h4>{langPack['demographics.walletIndicator']}</h4>
              <Dropdown
                id="walletIndicator"
                className={`${styles.unsetMaxWidth}`}
                options={countryCode}
              />
            </td>
          </tr>
          {/* ROW 4 ENDS */}

          {/* ROW 5 */}
          <tr>
            <td>
              <h4>{langPack['demographics.paymentCategoryCode']}</h4>
              <Dropdown
                id="paymentCategoryCode"
                className={`${styles.unsetMaxWidth}`}
                options={countryCode}
              />
            </td>
            <td>
              <h4>{langPack['demographics.localTricsCenter']}</h4>
              <Dropdown
                id="localTricsCenter"
                className={`${styles.unsetMaxWidth}`}
                options={countryCode}
              />
            </td>
            <td>
              <h4>{langPack['demographics.foreignTricsCenter']}</h4>
              <Dropdown
                id="foreignTricsCenter"
                className={`${styles.unsetMaxWidth}`}
                options={countryCode}
              />
            </td>
            <td>
              <h4>{langPack['demographics.primaryInstitution']}</h4>
              <RadioGroup selectedValue={selected}>
                <Radio
                  id="primary-yes-radio-option"
                  label="Yes"
                  value="primary-yes"
                  className="display-inline-block margin-tb margin-r"
                  onChange={this.updateSelected}
                />
                <Radio
                  id="primary-no-radio-option"
                  label="No"
                  value="primary-no"
                  className="display-inline-block margin-tb margin-r"
                  onChange={this.updateSelected}
                />
              </RadioGroup>
            </td>
          </tr>
          {/* ROW 5 ENDS */}

          {/* ROW 6 */}
          <tr>
            <td>
              <h4>{langPack['demographics.safekeyRegion']}</h4>
              <RadioGroup selectedValue={selected}>
                <Radio
                  id="safekey-yes-radio-option"
                  label="Yes"
                  value="safekey-yes"
                  className="display-inline-block margin-tb margin-r"
                  onChange={this.updateSelected}
                />
                <Radio
                  id="safekey-no-radio-option"
                  label="No"
                  value="safekey-no"
                  className="display-inline-block margin-tb margin-r"
                  onChange={this.updateSelected}
                />
              </RadioGroup>
            </td>
            <td>
              <h4>{langPack['demographics.serviceCenter']}</h4>
              <Dropdown
                id="serviceCenter"
                className={`${styles.unsetMaxWidth}`}
                options={countryCode}
              />
            </td>
          </tr>
          {/* ROW 6 ENDS */}
        </table>

        <div className="action-groups">
          <div className="group-primary">
            <Button
              className="btn-block margin-auto-lr btn btn-sm btn-secondary"
              id="cancelButton"
              label={langPack.cancel}
              onClick={handleCancelDemographics}
            />
            <Button
              className="btn-block margin-auto-lr btn btn-sm btn-primary"
              label={langPack['demographics.save']}
            />
          </div>
        </div>
      </div>
    );
  }
}

EditDemographics.contextTypes = {
  intl: PropTypes.object,
};

EditDemographics.propTypes = {
  orgData: PropTypes.instanceOf(Object).isRequired,
  handleCancelDemographics: PropTypes.func.isRequired,
};

export default EditDemographics;
