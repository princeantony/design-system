import React from 'react';
import PropTypes from 'prop-types';
import { Button, Loader } from 'axp-base';
import styles from '../../static/css/ClientProfileMainStyles.scss';

import ViewCapabilities from './ViewCapabilities';

const ViewCapabilitiesAll = (props, { intl }) => {
  const langPack = intl.messages ? intl.messages : {};
  if (!langPack || Object.keys(langPack).length === 0) {
    return null;
  }
  if (props.tableHeaders.length && props.capabilitiesData.tableData.length) {
    return (
      <div className={`${styles.flexGrow} ${styles.viewCapabilities} dls-white-bg `}>
        <div
          className={`${
            styles.headerPadding
          } flex flex-row flex-justify-between headerPadding dls-color-primary-bg`}
        >
          <h2 className="pad-1 dls-white body-3">{langPack.capabilities}</h2>
          <Button
            id="viewAllEditBtn"
            className="btn-icon btn-sm dls-icon-edit"
            onClick={props.setEditMode}
          />
        </div>
        <ViewCapabilities
          className="pad"
          capabilitiesData={props.capabilitiesData}
          detailView={props.detailView}
          compClasses="pad"
          tableHeaders={props.tableHeaders}
        />
        <div className="row pad-responsive">
          <div className="col-md-8">{/* placeholder for pagination addition in future */}</div>
          <div className="col-md-4">
            <div className="text-align-right">
              <div className="text-align-right">
                <Button
                  id="viewAllbackBtn"
                  className="btn btn-sm"
                  label={langPack.back}
                  onClick={props.setViewAll}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return <Loader progress={90} />;
};

ViewCapabilitiesAll.contextTypes = {
  intl: PropTypes.object,
};

ViewCapabilitiesAll.propTypes = {
  capabilitiesData: PropTypes.objectOf(PropTypes.array).isRequired,
  detailView: PropTypes.bool.isRequired,
  setEditMode: PropTypes.func.isRequired,
  setViewAll: PropTypes.func.isRequired,
  tableHeaders: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
};

export default ViewCapabilitiesAll;
