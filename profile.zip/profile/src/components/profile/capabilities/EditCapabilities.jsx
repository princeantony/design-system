import React from 'react';
import PropTypes from 'prop-types';
import { Button, Icon } from 'axp-base';
import Table from '../../common/Table';
import styles from '../../static/css/ClientProfileMainStyles.scss';
import EditDatesModal from '../../common/EditDatesModal';
import { formatDate } from '../../utils/utilityFunctions';

export class EditCapabilities extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isEditDatesModalVisible: false,
      selectedRows: [],
      allRows: this.tableBody(props.tableBody),
      startDate: '',
      endDate: '',
    };
    this.selectedData = [];
  }

  tableBody = data =>
    data.map(item => (item.selected !== undefined ? { ...item } : { ...item, selected: false }));

  selectionHandler = (selectedRows, allRows) => {
    this.setState(prevState => ({ ...prevState, selectedRows, allRows }));
  };

  handleStartDate = (startDate) => {
    this.setState(prevState => ({ ...prevState, startDate }));
  };

  handleEndDate = (endDate) => {
    this.setState(prevState => ({ ...prevState, endDate }));
  };

  toggleModal = (event) => {
    const fromCloseBtn = event.target.className.search('alert-close') !== -1;
    if (this.state.isEditDatesModalVisible && !fromCloseBtn) {
      const rows = this.state.allRows;
      const newRows = rows.map(obj =>
        (obj.selected === true
          ? { ...obj, start_date: this.state.startDate, end_date: this.state.endDate }
          : { ...obj })
      );
      this.setState({ allRows: newRows });
    }
    this.setState(prevState => ({
      ...prevState,
      isEditDatesModalVisible: !this.state.isEditDatesModalVisible,
    }));
  };

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : {};
    const { onHandleCancel } = this.props;
    const body = this.state.allRows;

    let data = body.map(obj => ({
      ...obj,
      col_icon_1: <Icon className="dls-icon-bank  dls-icon-thumbs-up dls-color-info" />,
      col_icon_2: <Icon className="dls-icon-bank  dls-color-info" />,
    }));
    data = data.map((obj) => {
      const formattedObject = obj;
      formattedObject.start_date = formatDate(obj.start_date);
      formattedObject.end_date = formatDate(obj.end_date);
      return formattedObject;
    });
    // let editTableHeaders = this.props.tableHeaders.slice();
    const editTableHeaders = this.props.tableHeaders.map((obj) => {
      const formattedObject = Object.assign({}, obj, {
        name: obj.title,
        value: obj.value,
      });
      // formattedObject.name = ;
      // formattedObject.value = langPack[obj.value];
      return formattedObject;
    });
    editTableHeaders.splice(0, 2, { name: 'orgIcon1', value: '' }, { name: 'orgIcon2', value: '' });
    const tableData = { header: editTableHeaders, body: data };
    const enableEditBtn = this.state.selectedRows.length > 0;
    return (
      <div className={`${styles.border} ${styles.bar}`}>
        <div className={`${styles.flexGrow} ${styles.editIR} dls-white-bg `}>
          <div
            className={`${
              styles.headerPadding
            } flex flex-row flex-justify-between dls-color-primary-bg`}
          >
            <h2 className="pad-1 dls-white body-3">{langPack.capabilities}</h2>
          </div>

          <div className="pad">
            <div
              className={`${styles.width100} ${styles.autoOverflow} ${
                styles.editCapabilitiesTable
              }`}
            >
              <Table
                selectable={true}
                selectionHandler={this.selectionHandler}
                data={tableData}
                tableClass="pad-0 margin-0 table data-table"
              />
            </div>

            <div className="text-align-right margin-2-t">
              <Button
                id="editFields"
                className={`${styles.editButton} margin-2-r btn btn-sm btn-primary"`}
                label={langPack.editSelected}
                onClick={this.toggleModal}
                disabled={!enableEditBtn}
              />

              <Button
                id="openEditModal"
                className="btn btn-sm btn-secondary"
                label={langPack.cancel}
                onClick={onHandleCancel}
              />
            </div>
          </div>
          <EditDatesModal
            isEditDatesModalVisible={this.state.isEditDatesModalVisible}
            toggleModal={this.toggleModal}
            handleStartDate={this.handleStartDate}
            handleEndDate={this.handleEndDate}
          />
        </div>
      </div>
    );
  }
}

EditCapabilities.contextTypes = {
  intl: PropTypes.object,
};

EditCapabilities.propTypes = {
  tableBody: PropTypes.instanceOf(Object).isRequired,
  tableHeaders: PropTypes.instanceOf(Object).isRequired,
  onHandleCancel: PropTypes.func.isRequired,
};

export default EditCapabilities;
