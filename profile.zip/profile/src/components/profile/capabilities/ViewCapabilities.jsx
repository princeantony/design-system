import React from 'react';
import { DataTable, Button, Loader, Icon } from 'axp-base';
import PropTypes from 'prop-types';
import { formatDate } from '../../utils/utilityFunctions';

import styles from '../../static/css/ClientProfileMainStyles.scss';

const ViewCapabilities = (props, { intl }) => {
  const langPack = intl.messages ? intl.messages : {};
  if (!langPack || Object.keys(langPack).length === 0) {
    return null;
  }
  if (props.capabilitiesData.tableData.length) {
    // static data currently used from seperate file
    const tableHeader = props.tableHeaders.map((dataItem) => {
      const retObj = Object.assign({}, dataItem);
      if (retObj.value === 'col_icon_1' || retObj.value === 'col_icon_2') {
        retObj.headerClassName = `${styles.columnWidth}`;
      }
      return retObj;
    });
    // static data currently used from seperate file
    let tableData = props.capabilitiesData.tableData.map(dataItem => ({
      ...dataItem,
      col_icon_1: <Icon className="dls-icon-thumbs-up dls-color-info icon-sm" />,
      col_icon_2: <Icon className="dls-icon-bank dls-color-info icon-sm" />,
    }));
    tableData = tableData.map((obj) => {
      const formattedObject = obj;
      formattedObject.start_date = formatDate(obj.start_date);
      formattedObject.end_date = formatDate(obj.end_date);
      return formattedObject;
    });

    return (
      <div className={props.compClasses}>
        <DataTable
          columns={tableHeader}
          data={tableData}
          className={`${styles.viewCapabilitiesTableOverflow} border-lr`}
        />
        {!props.detailView && (
          <div className="text-align-right pad-2-t">
            <Button
              id="viewAllBtn"
              className="btn btn-sm"
              onClick={props.setViewAll}
              label={langPack.viewAll}
            />
          </div>
        )}
      </div>
    );
  }
  return <Loader progress={90} />;
};

ViewCapabilities.contextTypes = {
  intl: PropTypes.object,
};

ViewCapabilities.defaultProps = {
  setViewAll: () => null, // optional, component call dependent
  compClasses: '',
};

ViewCapabilities.propTypes = {
  capabilitiesData: PropTypes.objectOf(PropTypes.array).isRequired,
  detailView: PropTypes.bool.isRequired,
  setViewAll: PropTypes.func,
  compClasses: PropTypes.string,
  tableHeaders: PropTypes.arrayOf(PropTypes.shape({})).isRequired,
};

export default ViewCapabilities;
