import React from 'react';
import PropTypes from 'prop-types';
import { Icon } from 'axp-base';
import ViewCapabilities from './ViewCapabilities';
import ViewAllCapabilities from './ViewAllCapabilities';
import { EditCapabilities } from './EditCapabilities';
import getDetailViewData from './getViewCapabilitiesData';

import styles from '../../static/css/ClientProfileMainStyles.scss';

export const IndicatorIcons = ({ langPack }) => (
  <div className={`${styles.margin} flex flex-wrap`}>
    {getDetailViewData.informationalIconGroup.map((item) => {
      const propName = item.name;
      const name = langPack[propName];
      return (
        <span className="pad-1" key={item.name}>
          <Icon className={`${item.class} ${styles.alignIcon} dls-color-info icon-sm`} /> - {name}
        </span>
      );
    })}
  </div>
);

const Capabilities = (props, { intl }) => {
  const langPack = intl.messages ? intl.messages : {};
  const tableHeader = getDetailViewData.columnHeader.map((obj) => {
    const formattedObject = Object.assign({}, obj);
    formattedObject.title = langPack[obj.title];
    return formattedObject;
  });

  if (props.isEditmode) {
    return (
      <div>
        <EditCapabilities
          tableBody={getDetailViewData.tableData}
          tableHeaders={tableHeader}
          onHandleCancel={props.onHandleCancel}
        />
        <IndicatorIcons langPack={langPack} />
      </div>
    );
  }
  if (props.detailView) {
    return (
      <div>
        <ViewAllCapabilities
          capabilitiesData={getDetailViewData}
          detailView={props.detailView}
          setViewAll={props.setViewAll}
          setEditMode={props.setEditMode}
          tableHeaders={tableHeader}
        />
        <IndicatorIcons langPack={langPack} />
      </div>
    );
  }
  return (
    <div>
      <ViewCapabilities
        capabilitiesData={getDetailViewData}
        setViewAll={props.setViewAll}
        detailView={props.detailView}
        tableHeaders={tableHeader}
      />
      <IndicatorIcons langPack={langPack} />
    </div>
  );
};

Capabilities.contextTypes = {
  intl: PropTypes.object,
};

IndicatorIcons.propTypes = {
  langPack: PropTypes.shape({}).isRequired,
};

Capabilities.propTypes = {
  isEditmode: PropTypes.bool.isRequired,
  detailView: PropTypes.bool.isRequired,
  setViewAll: PropTypes.func.isRequired,
  setEditMode: PropTypes.func.isRequired,
  onHandleCancel: PropTypes.func.isRequired,
};

export default Capabilities;
