// a temp file to send back view capabilities header, table data and the icon group

const getViewCapabilitiesData = {
  tableData: [
    {
      col_icon_1: '',
      col_icon_2: '',
      capability_type: 'Message Certification_0',
      description: 'Local Market Settlement Reporting - Dap Feed',
      start_date: '2012/10/10',
      end_date: '2020/10/10',
    },
    {
      col_icon_1: '',
      col_icon_2: '',
      capability_type: 'Message Certification_1',
      description: 'Local Market Settlement Reporting - Dap Feed',
      start_date: '2012/10/11',
      end_date: '2020/10/11',
    },
    {
      col_icon_1: '',
      col_icon_2: '',
      capability_type: 'Message Certification_2',
      description: 'Local Market Settlement Reporting - Dap Feed',
      start_date: '2012/10/12',
      end_date: '2020/10/12',
    },
    {
      col_icon_1: '',
      col_icon_2: '',
      capability_type: 'Message Certification_3',
      description: 'Local Market Settlement Reporting - Dap Feed',
      start_date: '2012/10/13',
      end_date: '2020/10/13',
    },
    {
      col_icon_1: '',
      col_icon_2: '',
      capability_type: 'Message Certification_4',
      description: 'Local Market Settlement Reporting - Dap Feed',
      start_date: '2012/10/14',
      end_date: '2020/10/14',
    },
    {
      col_icon_1: '',
      col_icon_2: '',
      capability_type: 'Message Certification_5',
      description: 'Local Market Settlement Reporting - Dap Feed',
      start_date: '2012/10/15',
      end_date: '2020/10/15',
    },
    {
      col_icon_1: '',
      col_icon_2: '',
      capability_type: 'Message Certification_6',
      description: 'Local Market Settlement Reporting - Dap Feed',
      start_date: '2012/10/16',
      end_date: '2020/10/16',
    },
  ],
  informationalIconGroup: [
    { name: 'capabilities.enrolled', class: 'dls-icon-thumbs-up' },
    { name: 'capabilities.available', class: 'dls-icon-alert' },
    { name: 'capabilities.organization', class: 'dls-icon-bank' },
    { name: 'capabilities.institution', class: 'dls-icon-business' },
    { name: 'capabilities.futureIndicator', class: 'dls-icon-geolocation' },
    { name: 'capabilities.modify', class: 'dls-icon-edit' },
    { name: 'capabilities.enroll', class: 'dls-icon-plus-circle' },
    { name: 'capabilities.unEnroll', class: 'dls-icon-minus-circle' },
  ],
  columnHeader: [
    {
      title: '',
      value: 'col_icon_1',
    },
    {
      title: '',
      value: 'col_icon_2',
    },
    {
      title: 'view.capabilities.CAPABILITY_TYPE',
      value: 'capability_type',
    },
    {
      title: 'view.capabilities.DESCRIPTION',
      value: 'description',
    },
    {
      title: 'startDate',
      value: 'start_date',
      className: '',
    },
    {
      title: 'view.endDate',
      value: 'end_date',
    },
  ],
};


export default getViewCapabilitiesData;
