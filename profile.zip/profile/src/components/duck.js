import { composeModules } from 'holocron';

export default function load() {
  return dispatch => dispatch(composeModules([
    { name: 'axp-site-area-nav-container' },
  ]));
}
