import React from 'react';
import PropTypes from 'prop-types';
import oneAmexWrapper from 'one-amex-wrapper';
import { holocronModule, RenderModule, getModule } from 'holocron';
import { compose } from 'redux';
import load from '../duck';
import LoadingScreen from './LoadingScreen';

const icons = {
  home: 'dls-icon-home',
  membership: 'dls-icon-membership',
};

export const SecondaryNav = (props) => {
  const isLoaded = getModule('axp-site-area-nav-container');
  const links = props.lang.secondary_nav_links;
  if (!isLoaded) return <LoadingScreen />;

  return (
    <div className="dls-white-bg pad-1-b">
      <h2 className="pad">Client Profile</h2>
      {/* View for mobile screens */}
      <div>
        <RenderModule
          moduleName="axp-site-area-nav-container"
          props={{
            links,
            icons,
            defaultSelectedText: 'Client Profile',
            moreLinkText: 'More',
          }}
        />
      </div>
    </div>
  );
};

SecondaryNav.propTypes = {
  lang: PropTypes.shape({
    secondary_nav_links: PropTypes.array.isRequired,
  }).isRequired,
};

const hocChain = compose(
  oneAmexWrapper('axp-network-client-profile'),
  holocronModule({
    name: 'axp-network-client-profile',
    load,
  })
);

export default hocChain(SecondaryNav);
