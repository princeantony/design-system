import React from 'react';
import styles from '../static/css/abstracts/_utils.scss';

export default function LoadingScreen() {
  return (
    <div className={styles.loadingScreen}>
      <div className="progress-circle progress-indeterminate progress" />
    </div>
  );
}
