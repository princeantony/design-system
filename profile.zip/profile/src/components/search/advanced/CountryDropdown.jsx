import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Dropdown } from 'axp-base';
import styles from '../../static/css/ClientProfileMainStyles.scss';

class CountryDropdown extends Component {
  constructor(props) {
    super(props);
    this.state = {
      countries: this.props.countryList,
      errorMessage: '',
    };
  }

  componentDidMount() {
    this.getCountriesList();
  }

  getCountriesList() {
    const errorMessage = 'No Data Found';
    if (this.state.countries && this.state.countries.length === 0) {
      this.setState({
        countries: [
          '',
          {
            value: '',
            label: errorMessage,
          },
        ],
      });
    }
    if (this.state.countries === undefined) {
      this.setState({
        countries: [
          '',
          {
            value: '',
            label: 'Request cannot be processed',
          },
        ],
      });
    }
  }

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : {};
    return (
      <div>
        <Dropdown
          id="country-dropdown"
          label={langPack.countryDropdown}
          className={`${styles.unsetMaxWidth} margin-0-b`}
          options={this.state.countries}
          selectClassName="select-fluid"
          warning={this.state.errorMessage}
          value={this.props.countryValue}
          onChange={c => this.props.updateCountry(c)}
        />
      </div>
    );
  }
}

CountryDropdown.propTypes = {
  countryValue: PropTypes.string,
  updateCountry: PropTypes.func.isRequired,
  countryList: PropTypes.arrayOf(PropTypes.object).isRequired,
};

CountryDropdown.defaultProps = {
  countryValue: 'default',
};

CountryDropdown.contextTypes = {
  intl: PropTypes.object,
};

export default CountryDropdown;
