import React from 'react';
import PropTypes from 'prop-types';

const Suggestion = ({ suggestion, onClick }) =>
  (suggestion === undefined || suggestion === '' ? (
    <span className="text-wrap">
      Sorry, but nothing matched your search criteria. Please try again with different keywords.
    </span>
  ) : (
    // eslint-disable-next-line max-len
    // eslint-disable-next-line jsx-a11y/click-events-have-key-events,jsx-a11y/anchor-is-valid,jsx-a11y/no-static-element-interactions,jsx-a11y/no-static-element-interactions
    <a id={suggestion} onClick={onClick}>
      {suggestion.id} - {suggestion.orgName}
    </a>
  ));

Suggestion.propTypes = {
  suggestion: PropTypes.node.isRequired,
  onClick: PropTypes.func.isRequired,
};

export default Suggestion;
