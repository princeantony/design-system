import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Dropdown } from 'axp-base';
import styles from '../../static/css/ClientProfileMainStyles.scss';

class RegionDropdown extends Component {
  constructor(props) {
    super(props);
    this.state = {
      regions: this.props.regionList,
    };
  }

  componentDidMount() {
    this.getRegionsList();
  }

  getRegionsList() {
    const errorMessage = 'No Data Found';

    if (this.state.regions && this.state.regions.length === 0) {
      this.setState({
        regions: [
          '',
          {
            value: '',
            label: errorMessage,
          },
        ],
      });
    }
    if (this.state.regions === undefined) {
      this.setState({
        regions: [
          '',
          {
            value: '',
            label: 'Request cannot be processed',
          },
        ],
      });
    }
  }

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : {};
    return (
      <div>
        <Dropdown
          id="region-dropdown"
          className={`${styles.unsetMaxWidth} margin-0-b`}
          label={langPack.regionDropdown}
          options={this.state.regions}
          selectClassName="select-fluid"
          value={this.props.regionValue}
          onChange={region => this.props.updateRegion(region)}
        />
      </div>
    );
  }
}

RegionDropdown.propTypes = {
  regionList: PropTypes.arrayOf(PropTypes.object).isRequired,
  regionValue: PropTypes.string,
  updateRegion: PropTypes.func.isRequired,
};

RegionDropdown.defaultProps = {
  regionValue: 'default',
};

RegionDropdown.contextTypes = {
  intl: PropTypes.object,
};

export default RegionDropdown;
