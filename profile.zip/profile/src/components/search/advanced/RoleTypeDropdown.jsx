import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Dropdown } from 'axp-base';
import styles from '../../static/css/ClientProfileMainStyles.scss';

class RoleTypeDropdown extends Component {
  roleTypeCodes = ['', 'Issuer ', 'Acquirer'];

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : {};
    const roleTypeCodes = this.roleTypeCodes.map(roleType => ({
      label: roleType,
      value: roleType,
    }));

    return (
      <div>
        <Dropdown
          id="country-roletype-dropdown"
          label={langPack.roleTypeDropdown}
          className={`${styles.unsetMaxWidth} margin-0-b`}
          options={roleTypeCodes}
          selectClassName="select-fluid"
          value={this.props.roleTypeCodeValue}
          onChange={roleType => this.props.updateRoleTypeCode(roleType)}
        />
      </div>
    );
  }
}

RoleTypeDropdown.propTypes = {
  roleTypeCodeValue: PropTypes.string,
  updateRoleTypeCode: PropTypes.func.isRequired,
};

RoleTypeDropdown.defaultProps = {
  roleTypeCodeValue: 'default',
};
RoleTypeDropdown.contextTypes = {
  intl: PropTypes.object,
};

export default RoleTypeDropdown;
