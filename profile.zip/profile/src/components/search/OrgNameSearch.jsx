import React from 'react';
import { SearchInput } from 'axp-base';
import { PropTypes } from 'prop-types';
import Suggestion from '../search/advanced/Suggestion';
import FetchOrganization from '../apis/getAllOrganizations';

class OrgNameSearch extends React.Component {
  constructor(props) {
    super(props);
    const currentOrgValue = '';
    this.state = {
      orgValue: currentOrgValue, // Id or Name of organization
      orgSearchResults: [],
      orgCompleteList: [],
      isSearching: false,
    };
  }

  componentWillReceiveProps = (nextProps) => {
    this.updateRegionCountryID(nextProps.searchQueryObj);
  };

  onOrgBlur = () => {
    this.clear();
  };

  getAutoCompleteData = (value, orgCompleteList) => {
    const self = this;
    const orgFilteredList =
      value === ''
        ? orgCompleteList
        : orgCompleteList.filter((org) => {
          const orgIDorName = Object.values(org);
          return orgIDorName.some(
            idOrName =>
              idOrName
                .toString()
                .toLowerCase()
                .indexOf(value) > -1
          );
        });
    self.setState({
      orgSearchResults: orgFilteredList.length ? orgFilteredList.sort() : [''],
      isSearching: false,
    });
  };

  updateRegionCountryID = ({ countryName, region }) => {
    this.setState({
      selectedCountryId: countryName,
      selectedRegionId: region !== undefined && region !== '' ? region.slice(-3) : '',
    });
  };

  /**
   * Trigger the API call to get auto-complete data
   * @param newOrgValue
   */
  orgChanged = (newOrgValue) => {
    if (newOrgValue === '') {
      // if orgfield is cleared
      this.props.searchQueryObj.orgId = '';
    }
    this.setState({
      orgValue: newOrgValue,
      isSearching: true,
    });
    this.getAutoCompleteData(newOrgValue, this.state.orgCompleteList);
  };

  selectOrg = (e) => {
    this.setState({
      orgValue: e.target.text,
    });
    const orgSelectedDetails = this.state.orgSearchResults.find(
      org =>
        org.id
          .toString()
          .concat(' - ')
          .concat(org.orgName)
          .toLowerCase() === e.target.text.toLowerCase()
    );
    this.props.searchQueryObj.orgId = orgSelectedDetails.id.toString();
    const { organizations } = this.context.intl.messages.links;
    const url = `${organizations}/${orgSelectedDetails.id}`;
    const options = {
      method: 'get',
      headers: { 'Content-Type': 'application/json' },
    };
    this.props.selectOrganization(this.props.searchQueryObj);
    this.clear();
    return FetchOrganization(
      url,
      this.handleOrganizationByIdSuccess,
      this.handleOrganizationByIdError,
      options
    );
  };

  handleOrganizationByIdSuccess = (statusCode, organization) => {
    if (statusCode === 200) {
      this.props.organizationData(organization.result);
    } else {
      this.props.organizationData([]);
    }
  };

  handleOrganizationByIdError = () => {
    this.props.organizationData([]);
  };

  clear = () => {
    this.setState({
      orgSearchResults: [],
    });
  };

  handleOnfocus = () => {
    const { organizations } = this.context.intl.messages.links;
    const url = `${organizations}`;
    const options = {
      method: 'get',
      headers: { 'Content-Type': 'application/json' },
    };
    return FetchOrganization(
      url,
      this.handleOrganizationSuccess,
      this.handleOrganizationFailure,
      options
    );
  };

  handleOrganizationSuccess = (statusCode, organizations) => {
    if (statusCode === 200) {
      const organizationList = this.filterOrgListFunc(
        organizations.result,
        this.state.selectedCountryId,
        this.state.selectedRegionId
      );

      const orgIDAndNameList = organizationList.map(org => ({
        id: org.organization_identifier,
        orgName: org.organization_name.legal_name.toUpperCase(),
      }));
      this.setState({
        orgCompleteList: orgIDAndNameList.length ? orgIDAndNameList : [''],
        isSearching: false,
      });
    } else {
      this.setState({
        orgCompleteList: [],
        orgSearchResults: [''],
        isSearching: false,
      });
    }
  };

  handleOrganizationFailure = () => {
    this.setState({
      orgCompleteList: [],
      orgSearchResults: [],
      isSearching: false,
    });
  };

  filterOrgListFunc = (organizations, countryId, regionId) => {
    let organizationList;
    if (countryId || regionId) {
      organizationList = organizations.filter((org) => {
        if (org.address === undefined) {
          return false;
        }
        if (countryId && !regionId) {
          return org.address.country_code === countryId;
        }
        if (!countryId && regionId) {
          return org.address.region_area_code === regionId;
        }
        return org.address.region_area_code === regionId && org.address.country_code === countryId;
      });
    } else {
      organizationList = organizations;
    }
    return organizationList;
  };

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : null;
    if (langPack === null) {
      return null;
    }

    return (
      <SearchInput
        id="orgNameSearch"
        placeholder={langPack['mainsearch.organization.placeholder']}
        className="margin-0-b"
        value={this.state.orgValue}
        onFocus={this.handleOnfocus}
        onChange={this.orgChanged}
        suggestions={this.state.orgSearchResults}
        Suggestion={Suggestion}
        onClick={this.selectOrg}
        onBlur={this.onOrgBlur}
        searching={this.state.isSearching}
      />
    );
  }
}
const noop = () => null;

OrgNameSearch.contextTypes = {
  intl: PropTypes.object,
};

OrgNameSearch.propTypes = {
  searchQueryObj: PropTypes.shape({
    countryName: PropTypes.string,
    region: PropTypes.string,
    orgId: PropTypes.string,
    institutionID: PropTypes.string,
  }),
  organizationData: PropTypes.func,
  selectOrganization: PropTypes.func,
};

OrgNameSearch.defaultProps = {
  searchQueryObj: {},
  selectOrganization: noop,
  organizationData: noop,
};
export default OrgNameSearch;
