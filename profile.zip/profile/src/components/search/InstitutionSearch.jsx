import React from 'react';
import { SearchInput } from 'axp-base';
import PropTypes from 'prop-types';
import InstitutionSuggestion from './InstitutionSuggestion';
import FetchInstitution from '../apis/getInstitution';

let selectedRoleId = '';
class InstitutionSearch extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      institutionValue: '',
      institutionSearchResults: [],
      completeInstitutionList: [],
      isSearching: false,
      errorMessage: '',
    };
  }

  componentWillReceiveProps = (nextProps) => {
    selectedRoleId = nextProps.searchQueryObj.roleTypeCode.trim();
  };

  onInstitutionBlur = () => {
    this.clear();
  };

  filterInstitutionListFunc = (institutions, roleTypeCode) => {
    let institutionList;
    if (roleTypeCode) {
      institutionList = institutions.filter(
        institution => institution.client_role_type.client_role_type_description === roleTypeCode
      );
    } else {
      institutionList = institutions;
    }
    return institutionList;
  };

  handleOnfocus = () => {
    if (this.props.searchQueryObj && this.props.searchQueryObj.orgId !== '') {
      this.setState({
        isSearching: true,
      });

      const url = `${this.context.intl.messages.links.institutions}/${
        this.props.searchQueryObj.orgId
      }`;
      const options = {
        method: 'get',
        headers: { 'Content-Type': 'application/json' },
      };

      FetchInstitution(url, this.handleInstitutionSuccess, this.handleInstitutionFailure, options);
    } else {
      this.setState({
        isSearching: false,
      });
    }
  };
  handleInstitutionSuccess = (statusCode, institutions) => {
    if (statusCode === 200) {
      const institutionData = institutions.length > 0 ? institutions : [];
      const selectedInst = this.filterInstitutionListFunc(institutionData, selectedRoleId);
      if (selectedInst.length > 0) {
        this.setState({
          completeInstitutionList: selectedInst,
          institutionSearchResults: selectedInst,
          isSearching: false,
        });
      } else {
        this.setState({
          institutionSearchResults: [''],
          isSearching: false,
        });
      }
    } else {
      this.setState({
        institutionSearchResults: [''],
        isSearching: false,
      });
    }
  };

  handleInstitutionFailure = () => {
    this.setState({
      institutionSearchResults: [''],
      isSearching: false,
    });
  };

  handleInstitutionByInstIDSuccess = (statusCode, data) => {
    if (statusCode === 200) {
      const { institution } = data;

      if (institution.length !== 0 && institution[0].institution_identifier) {
        this.setState({
          isSearching: false,
        });
        this.props.searchQueryObj.institutionID = institution[0].institution_identifier;
        this.props.selectInstitution(this.props.searchQueryObj);
        this.props.institutionData(institution);
      } else {
        this.props.searchQueryObj.institutionID = '';
      }
      this.setState({
        isSearching: false,
      });
    } else {
      this.setState({
        institutionSearchResults: [''],
        isSearching: false,
      });
      this.props.searchQueryObj.institutionID = '';
    }
  };

  handleInstitutionByInstIDFailure = () => {
    this.setState({
      institutionSearchResults: [''],
      isSearching: false,
    });
    this.props.searchQueryObj.institutionID = '';
  };

  institutionChanged = (newValue) => {
    // When user types in values to be searched, display only matching entries
    const errorMessage = 'Enter valid institution';
    this.setState({
      institutionValue: newValue,
      isSearching: false,
    });

    if (newValue.length && newValue.length !== 11) {
      this.setState({
        errorMessage,
      });
    } else {
      this.setState({
        errorMessage: '',
      });
      if (this.props.searchQueryObj.orgId) {
        const filteredInstitutionList = this.state.completeInstitutionList.filter(
          institution =>
            institution.institution_identifier
              .toString()
              .toLowerCase()
              .indexOf(newValue) > -1
        );
        this.setState({
          institutionSearchResults: filteredInstitutionList,
          isSearching: false,
        });
        if (newValue === '') {
          // if insitutionfield is cleared
          this.props.searchQueryObj.institutionID = '';
          this.clear();
        }
      } else {
        this.setState({
          institutionSearchResults: [],
          institutionValue: newValue,
          isSearching: true,
        });

        const url = `${this.context.intl.messages.links.getInstitutionById}/${newValue}`;
        const options = {
          method: 'get',
          headers: { 'Content-Type': 'application/json' },
        };

        FetchInstitution(
          url,
          this.handleInstitutionByInstIDSuccess,
          this.handleInstitutionByInstIDFailure,
          options
        );
      }
    }
  };

  selectInstitution = (e) => {
    this.setState({
      institutionValue: e.target.text,
      isSearching: false,
    });

    const institutionSelectedDetails = this.state.institutionSearchResults.find((inst) => {
      if (inst.institution_identifier === e.target.text) {
        return inst;
      }
      return [];
    });

    this.props.searchQueryObj.institutionID = institutionSelectedDetails.institution_identifier;
    this.props.selectInstitution(this.props.searchQueryObj);
    this.props.institutionData(institutionSelectedDetails);
    this.clear();
  };

  clear = () => {
    this.setState({
      institutionSearchResults: [],
    });
  };

  render() {
    const langPack = this.context.intl.messages ? this.context.intl.messages : null;
    if (langPack === null) {
      return null;
    }
    return (
      <SearchInput
        id="institutionSearch"
        placeholder={langPack['mainsearch.institution.placeholder']}
        type="number"
        className="margin-0-b"
        value={this.state.institutionValue}
        onFocus={this.handleOnfocus}
        suggestions={this.state.institutionSearchResults}
        Suggestion={InstitutionSuggestion}
        onChange={this.institutionChanged}
        onClick={this.selectInstitution}
        onBlur={this.onInstitutionBlur}
        searching={this.state.isSearching}
        warning={this.state.errorMessage}
      />
    );
  }
}

InstitutionSearch.propTypes = {
  searchQueryObj: PropTypes.shape({
    countryName: PropTypes.string,
    region: PropTypes.string,
    roleTypeCode: PropTypes.string,
    orgId: PropTypes.string,
    institutionID: PropTypes.string,
  }),
  selectInstitution: PropTypes.func.isRequired,
  institutionData: PropTypes.func.isRequired,
};

InstitutionSearch.defaultProps = {
  searchQueryObj: {},
};

InstitutionSearch.contextTypes = {
  intl: PropTypes.object,
};
export default InstitutionSearch;
