import React from 'react';
import PropTypes from 'prop-types';
import { Button } from 'axp-base';
import InstitutionSearch from './InstitutionSearch';
import styles from '../static/css/ClientProfileMainStyles.scss';
import CountryDropdown from './advanced/CountryDropdown';
import RegionDropdown from './advanced/RegionDropdown';
import RoleTypeDropdown from './advanced/RoleTypeDropdown';
import OrgNameSearch from './OrgNameSearch';

export class Search extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      advancedSearchQueryObj: {
        countryName: '',
        orgId: '',
        region: '',
        institutionID: '',
        roleTypeCode: '',
      },
      organizationViewData: [],
      institutionViewData: [],
    };
  }

  updateRoleTypeCode = (input) => {
    // creating copy of object
    const advancedSearchQueryObj = Object.assign({}, this.state.advancedSearchQueryObj);
    advancedSearchQueryObj.roleTypeCode = input.value; // updating value

    this.setState({ advancedSearchQueryObj });
  };

  updateRegion = (input) => {
    // creating copy of object
    const advancedSearchQueryObj = Object.assign({}, this.state.advancedSearchQueryObj);
    advancedSearchQueryObj.region = input.value; // updating value

    this.setState({ advancedSearchQueryObj });
  };

  updateCountry = (input) => {
    // creating copy of object
    const advancedSearchQueryObj = Object.assign({}, this.state.advancedSearchQueryObj);
    advancedSearchQueryObj.countryName = input.value; // updating value

    this.setState({ advancedSearchQueryObj });
  };

  selectInstitution = (value) => {
    this.setState({ advancedSearchQueryObj: value });
  };

  helperFunc = (value) => {
    this.selectInstitution(value);
  };

  selectOrganization = (value) => {
    this.setState({ advancedSearchQueryObj: value });
  };

  handleInstitutionViewData = (value) => {
    this.setState({
      institutionViewData: value,
    });
  };

  handleOrganizationViewData = (value) => {
    this.setState({
      organizationViewData: value,
    });
  };

  render() {
    // const { onHandleSearch } = this.props;
    const langPack = this.context.intl.messages ? this.context.intl.messages : {};
    const isSearchBtnDisabled =
      !this.state.advancedSearchQueryObj.orgId && !this.state.advancedSearchQueryObj.institutionID;
    return (
      <div className={`${styles.homeMinWidth} card margin-t col-lg-3 col-md-4 col-sm-12`}>
        <div className="card-block">
          <div>
            <h2>{langPack.btnSearch}</h2>
            <OrgNameSearch
              searchQueryObj={this.state.advancedSearchQueryObj}
              selectOrganization={this.selectOrganization}
              organizationData={this.handleOrganizationViewData}
            />
            <InstitutionSearch
              searchQueryObj={this.state.advancedSearchQueryObj}
              selectInstitution={this.helperFunc}
              institutionData={this.handleInstitutionViewData}
            />
          </div>
          <div className="margin-t">
            <RoleTypeDropdown
              roleTypeCodeValue={this.state.advancedSearchQueryObj.roleTypeCode}
              updateRoleTypeCode={this.updateRoleTypeCode}
            />
            <RegionDropdown
              regionList={this.props.regionList}
              regionValue={this.state.advancedSearchQueryObj.region}
              updateRegion={this.updateRegion}
              regionApiErrMsg={this.props.regionApiErrMsg}
            />
            <CountryDropdown
              countryList={this.props.countryList}
              countryValue={this.state.advancedSearchQueryObj.countryName}
              updateCountry={this.updateCountry}
              countryApiErrMsg={this.props.countryApiErrMsg}
            />
          </div>
          <div className={`${styles.searchButtons} btn-stack-a pad-2-t text-align-center`}>
            <Button
              id="searchBtn"
              disabled={isSearchBtnDisabled}
              className="margin-b btn-sm"
              label={langPack.btnSearch}
              onClick={() => this.props.onHandleSearch(this.state)}
            />
            <Button label={langPack.btnClearAll} className="btn-secondary btn-sm" />
          </div>
        </div>
      </div>
    );
  }
}

Search.contextTypes = {
  intl: PropTypes.object,
};

Search.propTypes = {
  onHandleSearch: PropTypes.func.isRequired,
  countryList: PropTypes.arrayOf(PropTypes.object),
  regionList: PropTypes.arrayOf(PropTypes.object),
  regionApiErrMsg: PropTypes.string,
  countryApiErrMsg: PropTypes.string,
};

Search.defaultProps = {
  regionApiErrMsg: '',
  countryApiErrMsg: '',
  countryList: [],
  regionList: [],
};
export default Search;
