import { combineReducers } from 'redux-immutable';
import { configureIguazuREST, resourcesReducer } from 'iguazu-rest';
import { massageProfilesOnloadData } from './country';
import getUrl from './env';

export const profilesOnLoadData = {
  fetch: () => ({
    url: `${getUrl('networkUtilPrefix')}/:id`,
  }),
  transformData: data => massageProfilesOnloadData(data),
};

configureIguazuREST({
  resources: {
    profilesOnLoadData,
  },
  defaultOpts: {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
  },
});

const reducer = combineReducers({
  resources: resourcesReducer,
});

export default reducer;
