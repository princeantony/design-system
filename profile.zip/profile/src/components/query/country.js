import { getResource, queryResource } from 'iguazu-rest';

const mapToDropdownOptions = (data) => {
  const options = [{ value: 'Select', label: 'Select' }];

  data.forEach((record) => {
    options.push({
      value: record.id,
      label: record.name,
    });
  });

  return options;
};

const mapToDropdownRegionOptions = (data) => {
  const options = [{ value: 'Select', label: 'Select' }];

  data.forEach((record) => {
    options.push({
      value: record.id,
      label: record.displayName,
    });
  });

  return options;
};

export const massageProfilesOnloadData = (data) => {
  const result = {};
  result.countries = mapToDropdownOptions(data.countries);
  // result.currencies = mapToDropdownOptions(data.currencies);
  result.region = mapToDropdownRegionOptions(data.region);
  // result.mcc = mapToDropdownOptions(data.mcc);
  return result;
};

export const queryProfilesOnloadData = () => (dispatch, getState) => {
  let data;
  let status;
  let promise;
  // try {
  data = getResource({ resource: 'profilesOnLoadData', id: 'client-setup-load' })(getState());
  // } catch (e) {
  //   data = {};
  // }

  if (data) {
    status = 'complete';
    promise = Promise.resolve;
  } else {
    status = 'loading';
    promise = dispatch(
      queryResource({
        resource: 'profilesOnLoadData',
        id: 'client-setup-load',
      })
    );
    data = {};
  }

  return { data, status, promise };
};
