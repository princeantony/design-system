const E1_URLS = {
  networkUtilPrefix: 'https://networkutil-dev.aexp.com',
};

const E2_URLS = {
  networkUtilPrefix: 'https://networkutil-dev.aexp.com',
};

const E3_URLS = {
  networkUtilPrefix: 'https://networkutil-dev.aexp.com',
};

const PARROT_PREFIX = 'http://app:3002';

const getUrl = (key) => {
  const env = process.env.NODE_ENV;

  if (window.location.href.includes('app:3000')) {
    return PARROT_PREFIX;
  }

  if (env === 'E1') {
    return E1_URLS[key];
  } else if (env === 'E2') {
    return E2_URLS[key];
  } else if (env === 'E3') {
    return E3_URLS[key];
  }

  return E1_URLS[key];
};

export default getUrl;

