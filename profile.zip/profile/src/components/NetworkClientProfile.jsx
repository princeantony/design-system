import React from 'react';
import PropTypes from 'prop-types';
import { compose } from 'redux';
import { holocronModule } from 'holocron';
import oneAmexWrapper from 'one-amex-wrapper';
import { connectAsync } from 'iguazu';
import { queryLanguagePack } from 'axp-global-ducks';
import childRoutes from '../childRoutes';
import Links from './main/SecondaryNav';
import reducer from './query/config';

export const NetworkClientProfile = ({
  children,
  isLoading,
  loadedWithErrors,
}) => {
  if (isLoading()) {
    return null;
  }

  if (loadedWithErrors()) {
    if (process.env.NODE_ENV === 'development') {
      return <div>NetworkClientProfile failed to load some of its asynchronous data</div>;
    }
    return null;
  }
  return (
    <div data-module-name="axp-network-client-profile">
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <Links />
          </div>
        </div>
        <div className="row">
          <div className="col-md-12">
            { children }
          </div>
        </div>
      </div>
    </div>
  );
};

NetworkClientProfile.childRoutes = childRoutes;
NetworkClientProfile.propTypes = {
  isLoading: PropTypes.func.isRequired,
  loadedWithErrors: PropTypes.func.isRequired,
  children: PropTypes.node,
};

NetworkClientProfile.defaultProps = {
  children: null,
};

export function loadDataAsProps({ store: { dispatch } }) {
  return {
    langPack: () => dispatch(queryLanguagePack('axp-network-client-profile')),
  };
}

const hocChain = compose(
  oneAmexWrapper('axp-network-client-profile'),
  holocronModule({
    name: 'axp-network-client-profile',
    reducer,
  }),
  connectAsync({ loadDataAsProps })
);

export default hocChain(NetworkClientProfile);
