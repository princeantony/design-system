/* eslint-disable import/no-named-as-default */
import React from 'react';
import { Route } from 'react-router';
import { Financial } from './components/secondary-nav/financial/Financial';
import { Configurations } from './components/secondary-nav/configurations/Configurations';
import { Exception } from './components/secondary-nav/exception/Exception';
import { Transmission } from './components/secondary-nav/transmission/Transmission';
import { Participant } from './components/secondary-nav/participant/Participant';
import { Accounting } from './components/secondary-nav/accounting/Accounting';
import { Maintenance } from './components/secondary-nav/maintenance/Maintenance';
import { Schedule } from './components/secondary-nav/schedule/Schedule';
import { NewSetup } from './components/secondary-nav/setup/NewSetup';
import ProfileDetails from './components/profile/ProfileDetails';

export default (
  <Route>
    <Route path="profile-details" title="Profile Details" component={ProfileDetails} />
    <Route path="financial" title="CSU Financial" component={Financial} />
    <Route path="configurations" title="CSU Configurations" component={Configurations} />
    <Route path="exception" title="CSU Exceptions" component={Exception} />
    <Route path="transmission" title="CSU Transmission" component={Transmission} />
    <Route path="participant" title="CSU Participant" component={Participant} />
    <Route path="accounting" title="CSU Accounting" component={Accounting} />
    <Route path="maintenance" title="CSU Maintenance" component={Maintenance} />
    <Route path="schedule" title="CSU Schedule" component={Schedule} />
    <Route path="create" title="CSU New Set Up" component={NewSetup} />
  </Route>
);
