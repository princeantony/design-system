// import { configureIguazuREST } from 'iguazu-rest';
import ModuleContainer from './components/NetworkClientProfile';

// export const getActiveLocale = state => state.intl.toJS().activeLocale;

/**
 * TODO: `configureIguazuREST` should be moved to axp-network-root ???
 */
// configureIguazuREST({
//   resources: {
//
//     itemsWithMetadata: {
//       fetch: () => ({
//
//         // We are going to use the EXPRESS API from axp-nemo-ui-starter app:
//         // $ node /axp-nemo-ui-starter/src/components/static/javascript/utility.js
//         url: 'http://localhost:3031/items/:id',
//       }),
//
//       // Optionally massage the data to be more RESTful,
//       // -> collections need to be lists,
//       // -> resources need to be objects
//       // Our Express API response is always:
//       //     -> res = { success: boolean, errors: array_of_strings, data: obj };
//       transformData: (data, { id, actionType, state }) => (data),
//     },
//   },
// });

export default ModuleContainer;
