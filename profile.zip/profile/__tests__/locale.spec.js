// Language pack tests need dynamic requires & eslint erroneously thinks
// that promisify-node is not a dev dependency
/* eslint-disable import/no-dynamic-require */

import path from 'path';
import promisify from 'promisify-node';
import schema from './locale.schema.json';

const glob = promisify('glob');
const localeDir = path.join(__dirname, '../locale');

describe('Language packs', () => {
  let locales = null;
  beforeAll(() =>
    glob('*', { cwd: localeDir }).then((result) => {
      locales = result;
      return locales;
    })
  );

  it('should have the correct schema in each copy file', (done) => {
    const failures = [];
    const aexpEnvs = ['E1'];
    const urlRegExp = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)/;

    locales.forEach((locale) => {
      // eslint-disable-next-line global-require
      const copy = require(`${localeDir}/${locale}/copy.json`);
      try {
        expect(copy).toMatchSchema(schema);
      } catch (error) {
        failures.push(error);
      }
      aexpEnvs.forEach((aexpEnv) => {
        // eslint-disable-next-line global-require
        const links = require(`${localeDir}/${locale}/links/${aexpEnv}.json`);
        try {
          // checking empty since no links are currently added
          expect(links).toEqual({
            clientSetupLoad: expect.stringMatching(urlRegExp),
            getCapabilities: expect.stringMatching(urlRegExp),
            institutions: expect.stringMatching(urlRegExp),
            organizations: expect.stringMatching(urlRegExp),
            getInstitutionById: expect.stringMatching(urlRegExp),
          });
        } catch (error) {
          failures.push(error);
        }
      });
    });

    if (failures.length) {
      done.fail(failures);
    } else {
      done();
    }
  });
});
