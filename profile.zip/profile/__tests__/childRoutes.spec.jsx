import routes from '../src/childRoutes';

describe('childRoutes', () => {
  it('matches snapshot for routes', () => {
    expect(routes).toBeDefined();
  });
});
