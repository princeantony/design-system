import { loadDataAsProps } from '../../../src/components/config';

jest.mock('axp-global-ducks', () => ({
  queryLanguagePack: jest.fn().mockImplementation(() => {}),
}));

describe('config', () => {
  it('loadDataAsProps', () => {
    const store = {
      dispatch: jest.fn(),
    };
    const loadProps = loadDataAsProps({ store });
    expect(loadProps.language).toBeInstanceOf(Function);
    loadProps.language();
    expect(store.dispatch).toHaveBeenCalledTimes(1);
  });
});
