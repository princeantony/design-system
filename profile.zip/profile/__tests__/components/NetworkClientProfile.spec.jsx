import React from 'react';
import { shallow } from 'enzyme';

import Container, {
  NetworkClientProfile,
  loadDataAsProps,
} from '../../src/components/NetworkClientProfile';

jest.mock('axp-global-ducks', () => ({
  queryLanguagePack: jest.fn(module => `lang pack async state for ${module}`),
}));

describe('AXP NetworkClientProfile Component Test', () => {
  let context;
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('should render the loading state correctly', () => {
    const props = {
      isLoading: () => true,
      loadedWithErrors: () => false,
      children: <h1>Hello</h1>,
    };

    const renderedModule = shallow(<NetworkClientProfile {...props} />, { context });
    expect(renderedModule).toMatchSnapshot();
  });

  it('should render the loaded state correctly', () => {
    const props = {
      isLoading: () => false,
      loadedWithErrors: () => false,
      children: <h1>Hello</h1>,
    };

    const renderedModule = shallow(<NetworkClientProfile {...props} />, { context });
    expect(renderedModule).toMatchSnapshot();
  });

  it('should render null if there was an error loading in production', () => {
    process.env.NODE_ENV = 'production';
    const props = {
      isLoading: () => false,
      loadedWithErrors: () => true,
      children: <h1>Hello</h1>,
    };

    const renderedModule = shallow(<NetworkClientProfile {...props} />, { context });
    expect(renderedModule).toMatchSnapshot();
  });

  it('should render an informative message if there was an error loading in development', () => {
    process.env.NODE_ENV = 'development';
    const props = {
      isLoading: () => false,
      loadedWithErrors: () => true,
      children: <h1>Hello</h1>,
    };

    const renderedModule = shallow(<NetworkClientProfile {...props} />, { context });
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });

  describe('loadDataAsProps', () => {
    const dispatch = jest.fn(x => x);
    const loadFuncMap = loadDataAsProps({ store: { dispatch } });

    beforeEach(() => dispatch.mockClear());

    it('should load the language pack', () => {
      const langPackAsyncState = loadFuncMap.langPack();
      expect(langPackAsyncState).toBe('lang pack async state for axp-network-client-profile');
      expect(dispatch).toHaveBeenCalledWith(langPackAsyncState);
    });
  });
});
