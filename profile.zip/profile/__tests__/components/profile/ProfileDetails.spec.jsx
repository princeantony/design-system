import React from 'react';
import { shallow } from 'enzyme';
import { ProfileDetails, loadDataAsProps } from '../../../src/components/profile/ProfileDetails';
import LoadingScreen from '../../../src/components/main/LoadingScreen';

jest.mock('axp-global-ducks', () => ({
  queryProfilesOnloadData: jest.fn(),
}));

const profilesData = {
  countries: [
    { id: '010', name: '010-ANTARCTICA' },
    { id: '004', name: '004-AFGHAN    ' },
    { id: '008', name: '008-ALBANIA   ' },
  ],
  region: [
    {
      id: 'region::000::008',
      type: 'region',
      region_identifier: '000',
      country_iso_numeric_identifier: '008',
      region_area_name_text: 'ALBANIA',
      region_area_abbreviated_name: 'ALBANIA',
      country_region_area_abbreviated_name_text: 'AL',
      region_effective_date: '1988-01-01',
      region_last_transaction_date: '2001-01-16',
      region_last_transaction_code: '',
      region_end_date: '9999-12-31',
    },
    {
      id: 'region::000::004',
      type: 'region',
      region_identifier: '000',
      country_iso_numeric_identifier: '004',
      region_area_name_text: 'AFGHANISTAN',
      region_area_abbreviated_name: 'AFGHAN',
      country_region_area_abbreviated_name_text: 'AF',
      region_effective_date: '1988-01-01',
      region_last_transaction_date: '2000-11-14',
      region_last_transaction_code: '',
      region_end_date: '9999-12-31',
    },
  ],
};

describe('ProfileDetails Component Test', () => {
  let wrapper;
  const { NODE_ENV } = process.env;
  let context;
  let DEFAULT_PROPS;
  beforeEach(() => {
    context = {
      intl: {
        messages: {
          'institutionRelation.title': 'Institution Relationships',
          links: {
            organizations: 'http://dummyurl.com',
            institutions: 'http://dummyurl.com',
            region: 'http://dummyurl.com',
            country: 'http://dummyurl.com',
          },
        },
      },
    };

    DEFAULT_PROPS = {
      isLoading: jest.fn(),
      profilesOnLoadData: profilesData,
    };
  });

  const countryData = [
    { id: '010', name: '010-ANTARCTICA' },
    { id: '004', name: '004-AFGHAN    ' },
    { id: '008', name: '008-ALBANIA   ' },
  ];

  const regionData = [
    {
      id: 'region::000::008',
      type: 'region',
      region_identifier: '000',
      country_iso_numeric_identifier: '008',
      region_area_name_text: 'ALBANIA',
      region_area_abbreviated_name: 'ALBANIA',
      country_region_area_abbreviated_name_text: 'AL',
      region_effective_date: '1988-01-01',
      region_last_transaction_date: '2001-01-16',
      region_last_transaction_code: '',
      region_end_date: '9999-12-31',
    },
    {
      id: 'region::000::004',
      type: 'region',
      region_identifier: '000',
      country_iso_numeric_identifier: '004',
      region_area_name_text: 'AFGHANISTAN',
      region_area_abbreviated_name: 'AFGHAN',
      country_region_area_abbreviated_name_text: 'AF',
      region_effective_date: '1988-01-01',
      region_last_transaction_date: '2000-11-14',
      region_last_transaction_code: '',
      region_end_date: '9999-12-31',
    },
  ];

  const institutionByOrgData = {
    organization: {
      organization_doing_business_as_name: '',
      organization_identifier: 263,
    },
    institution_identifier: '10000000192',
  };

  const institutionByOrgWithoutOrg = {
    // organization: {
    //   organization_identifier: 263,
    // }, Commented the code
    organization: undefined,
    institution_identifier: '10000000192',
  };

  const demographicsData = {
    result: {
      geographic_region_identifier: 'test2',
      organization_identifier: '263',
      organization_name: {
        company_contact_name: 'test1',
        doing_business_as_name: 'test1',
        legal_name: 'test1',
        deal_name: 'test1',
      },
      type: 'organization',
      institution_type_identifier: 1,
      organization_classification_code: 'test1',
      id: '263',
      organization_role: {
        end_date: 'test1',
        referral_type_code: 'test1',
        effective_date: 'test1',
        client_role_description: 'test1',
        authorization_center_code: 'test1',
      },
    },
  };

  const capabilitesData = {
    capabilities: {
      messages: {
        settlement: [
          {
            end_date: '9999-12-31',
            effective_date: '2018-10-03',
            reroute_institution_identifier: '90000000008',
            transaction_class_code: 'A ',
            function_code: '450',
            message_type_identifier: '1442',
          },
        ],
      },
    },
  };

  const organizationData = {
    httpStatus: 200,
    message: 'Organization retrieved',
    result: {
      geographic_region_identifier: 'test2',
      organization_identifier: '263',
      organization_name: {
        company_contact_name: 'test1',
        doing_business_as_name: 'test1',
        legal_name: 'test1',
        deal_name: 'test1',
      },
      type: 'organization',
      institution_type_identifier: 1,
      id: '263',
      organization_role: {
        end_date: 'test1',
        referral_type_code: 'test1',
        effective_date: 'test1',
        client_role_description: 'test1',
        authorization_center_code: 'test1',
      },
    },
    code: '0',
  };

  const searchDetails = {
    advancedSearchQueryObj: {
      countryName: '',
      orgId: '',
      region: '',
      institutionID: '',
      roleTypeCode: '',
    },
    organizationViewData: [],
    institutionViewData: [],
  };

  const mockDataMapping = {
    country: countryData,
    region: regionData,
    institutionByOrg: institutionByOrgData,
    demographics: demographicsData,
    capabilities: capabilitesData,
  };

  const notFoundResp = { status: 404, message: 'Not Found' };

  const mockApiSuccessResponse = apiName =>
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        status: 200,
        json: () => mockDataMapping[apiName],
      })
    );

  const mockApiErrorResponse = () =>
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        status: 500,
      })
    );

  const mockApi404Response = () =>
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        status: 404,
        json: () => notFoundResp,
      })
    );

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    const unloadedContext = {
      context: { intl: {} },
    };

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, unloadedContext);
    expect(wrapper.get(0)).toEqual(<LoadingScreen />);
  });

  it('matches snapshot for ProfileDetails', () => {
    const renderedModule = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.state().isEditDemographics).toEqual(false);
  });

  it('handle session event', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ isViewDemographics: true });
    expect(wrapper.state().isEditDemographics).toEqual(false);
    wrapper.find('#buttonEditDemographics').simulate('click', {
      target: { value: 'newValue' },
    });
    expect(wrapper.state().isEditDemographics).toEqual(true);
  });

  it('handle ViewAll event - capabilities state ', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleViewAllCapabilities();
    expect(wrapper.state('isViewAllCapabilities')).toEqual(true);
  });

  it('handle capabilities edit button click', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ isViewDemographics: true });
    wrapper.find('#buttonEditCapabilities').simulate('click');
    expect(wrapper.state('isEditCapabilities')).toEqual(true);
  });

  it('handle cancel demographics', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });

    wrapper.instance().handleCancelDemographics();
    expect(wrapper.state().isEditDemographics).toEqual(false);
  });

  it('enable edit demographics', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().enableEditDemographics();
    expect(wrapper.state().isEditDemographics).toEqual(true);
  });

  it('validate seteditmode ', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });

    wrapper.instance().handleSessionCapabilities();
    expect(wrapper.state('isEditCapabilities')).toBe(true);
  });

  it('handle ViewAll event - default state for institution', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleViewAllInstitutionRelation();
    expect(wrapper.state('isViewAllInstitutionalRelations')).toEqual(true);
  });

  it('handle session event for Institution Relationships', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ isViewDemographics: true });
    expect(wrapper.state().isEditInstitutionRelationships).toEqual(false);
    // wrapper.find('#buttonEditIR').simulate('click');
    // expect(wrapper.state().isEditInstitutionRelationships).toEqual(true);
  });
  it('handleEditInstitutionRelationships', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    const searchObj = Object.assign(searchDetails, {
      organizationViewData: organizationData,
      institutionViewData: institutionByOrgData,
      advancedSearchQueryObj: {
        orgId: 263,
        institutionID: 10000000192,
      },
    });
    wrapper.setState({ isViewDemographics: true });
    wrapper.setState({ institutionData: searchObj.institutionViewData });
    expect(wrapper.state().isEditInstitutionRelationships).toEqual(false);
    wrapper.find('#buttonEditIR').simulate('click');
    expect(wrapper.state().isEditInstitutionRelationships).toEqual(true);
  });
  it('handle edit institution relation', () => {
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });

    wrapper.instance().handleEditInstitutionRelation();
    expect(wrapper.state('isEditInstitutionRelationships')).toEqual(true);
  });

  it('handle search - organization id and institution id', () => {
    const searchObj = Object.assign(searchDetails, {
      organizationViewData: organizationData,
      institutionViewData: institutionByOrgData,
      advancedSearchQueryObj: {
        orgId: 263,
        institutionID: 10000000192,
      },
    });
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().fetchCapabilities = jest.fn();
    wrapper.instance().handleSearch(searchObj);
    expect(wrapper.state('institutionData')).toEqual(institutionByOrgData);
    expect(wrapper.state('demographicsDataByOrg')).toEqual(organizationData);
  });

  it('handle search - organization id with no institution id', () => {
    global.fetch = mockApiSuccessResponse('institutionByOrg');

    const searchObj = Object.assign(searchDetails, {
      organizationViewData: organizationData,
      advancedSearchQueryObj: {
        orgId: 263,
      },
    });
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleSearch(searchObj);
    expect(wrapper.state('demographicsDataByOrg')).toEqual(organizationData);
    expect(wrapper.state('demographicsDataByInstitution')).toEqual([]);
    expect(wrapper.state('capabilitiesData')).toEqual([]);

    return wrapper
      .instance()
      .fetchInstitutionByOrgId()
      .then(() => {
        expect(wrapper.state().institutionData).toEqual(institutionByOrgData);
      });
  });

  it('handle search - no organization id, and institution id and orgIdInInstitution', () => {
    global.fetch = mockApiSuccessResponse('capabilities');

    const searchObj = Object.assign(searchDetails, {
      institutionViewData: institutionByOrgData,
      advancedSearchQueryObj: {
        institutionID: 10000000192,
      },
    });
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().fetchDemographics = jest.fn();
    // wrapper.setState({ demographicsDataByOrg: [] }); Commented the code
    wrapper.instance().handleSearch(searchObj);
    // expect(wrapper.state('demographicsDataByOrg')).toEqual([]); Commented the code
    expect(wrapper.state('institutionData')).toEqual(institutionByOrgData);
    expect(wrapper.instance().fetchDemographics).toHaveBeenCalled();
    expect(wrapper.state('demographicsDataByInstitution')).toEqual(institutionByOrgData);
    return wrapper
      .instance()
      .fetchCapabilities()
      .then(() => {
        expect(wrapper.state('capabilitiesData')).toEqual(capabilitesData.capabilities);
      });
  });

  it('handle search - no organization id, and institution id and orgIdInInstitution as null', () => {
    const searchObj = {
      institutionViewData: { organization: undefined, institution_identifier: '10000000192' },
      advancedSearchQueryObj: {
        institutionID: 10000000192,
        orgId: '',
      },
    };
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().fetchCapabilities = jest.fn();
    wrapper.instance().handleSearch(searchObj);
    expect(wrapper.state('institutionData')).toEqual(institutionByOrgWithoutOrg);
    expect(wrapper.state('demographicsDataByInstitution')).toEqual(institutionByOrgWithoutOrg);
    expect(wrapper.state('demographicsDataByOrg')).toEqual([]);
    expect(wrapper.instance().fetchCapabilities).toHaveBeenCalled();
  });

  it('handle search - no organizationViewData and no institutionViewData with orgid and institutionid', () => {
    const searchObj = Object.assign(searchDetails, {
      institutionViewData: '',
      organizationViewData: '',
      advancedSearchQueryObj: {
        orgId: 263,
        institutionID: 10000000192,
      },
    });
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleSearch(searchObj);
    expect(wrapper.state('orgIdToProfileSummary')).toEqual('');
    expect(wrapper.state('institutionIdToProfileSummary')).toEqual('');
  });

  it('handle search - should test orgNameToProfileSummary, with orgid and institutionid', () => {
    const searchObj = Object.assign(searchDetails, {
      institutionViewData: '',
      organizationViewData: {
        organization_name: {
          legal_name: 'TEST 3',
        },
      },
      advancedSearchQueryObj: {
        orgId: 263,
        institutionID: 10000000192,
      },
    });
    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleSearch(searchObj);
    expect(wrapper.state('orgNameToProfileSummary')).toEqual('TEST 3');
  });

  it('fetchInstitutionByOrgId - should call api to fetch InstitutionByOrgId result', () => {
    global.fetch = mockApiSuccessResponse('institutionByOrg');

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });

    return wrapper
      .instance()
      .fetchInstitutionByOrgId()
      .then(() => {
        expect(wrapper.state().institutionData).toEqual(institutionByOrgData);
      });
  });

  it('fetchCapabilities - should call api to capabilities result', () => {
    global.fetch = mockApiSuccessResponse('capabilities');

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchCapabilities()
      .then(() => {
        expect(wrapper.state().capabilitiesData).toEqual(capabilitesData.capabilities);
      });
  });

  it('fetchDemographics - should call api to fetch demographics result', () => {
    global.fetch = mockApiSuccessResponse('demographics');

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchDemographics()
      .then(() => {
        expect(wrapper.state().demographicsDataByOrg).toEqual(demographicsData.result);
      });
  });

  it('fetchInstitutionByOrgId - checking error for InstitutionByOrgId result', () => {
    global.fetch = mockApiErrorResponse();

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchInstitutionByOrgId()
      .then(() => {
        expect(wrapper.state().institutionData).toEqual([]);
      });
  });

  it('fetchCapabilities - checking error for capabilities result', () => {
    global.fetch = mockApiErrorResponse();

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchCapabilities()
      .then(() => {
        expect(wrapper.state().capabilitiesData).toEqual(null);
      });
  });

  it('fetchDemographics - checking error for demographics result', () => {
    global.fetch = mockApiErrorResponse();

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchDemographics()
      .then(() => {
        expect(wrapper.state().demographicsDataByOrg).toEqual(null);
      });
  });

  it('fetchInstitutionByOrgId - checking for status <200 / >299 for InstitutionByOrgId result', () => {
    global.fetch = mockApi404Response();

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchInstitutionByOrgId()
      .then(() => {
        expect(wrapper.state().searchInstitutionErrMsg).toEqual(notFoundResp);
      });
  });

  it('fetchCapabilities - checking for status <200 / >299 for capabilities result', () => {
    global.fetch = mockApi404Response();

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchCapabilities()
      .then(() => {
        expect(wrapper.state().searchCapabilitiesErrMsg).toEqual(notFoundResp);
      });
  });

  it('fetchDemographics - checking error for status <200 / >299 demographics result', () => {
    global.fetch = mockApi404Response();

    wrapper = shallow(<ProfileDetails {...DEFAULT_PROPS} />, { context });
    return wrapper
      .instance()
      .fetchDemographics()
      .then(() => {
        expect(wrapper.state().searchDemographicsErrMsg).toEqual(notFoundResp);
      });
  });

  describe('loadDataAsProps', () => {
    const dispatch = jest.fn(x => x);
    const loadFuncMap = loadDataAsProps({ store: { dispatch } });

    beforeEach(() => dispatch.mockClear());

    it('should call profilesOnLoadData', () => {
      const clientSetUpData = loadFuncMap.profilesOnLoadData();
      expect(dispatch).toHaveBeenCalledWith(clientSetUpData);
    });
  });
});
