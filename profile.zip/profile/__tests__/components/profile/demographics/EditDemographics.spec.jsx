import React from 'react';
import { shallow } from 'enzyme';
import { EditDemographics } from './../../../../src/components/profile/demographics/EditDemographics';

describe('AXP Demographics Component Test', () => {
  let wrapper;
  let DEFAULT_PROPS;

  const context = {
    intl: {
      messages: {
        demographics: 'Demographics',
        'demographics.legalName': 'LEGAL NAME',
        'demographics.dbaName': 'DBA NAME',
        'demographics.dealCodeName': 'DEAL CODE NAME',
        roleType: 'ROLE TYPE',
        'demographics.address': 'ADDRESS',
        'demographics.city': 'CITY',
        'demographics.stateRegion': 'STATE/REGION',
        'demographics.postalCode': 'POSTAL CODE',
        'demographics.country': 'COUNTRY',
        'demographics.domicleCountry': 'DOMICLE COUNTRY',
        'demographics.regionID': 'REGION ID',
        'demographics.dealConstruct': 'DEAL CONSTRUCT',
        'demographics.businessCenter': 'BUSINESS CENTER',
        'demographics.doubleByte': 'DOUBLE BYTE',
        'demographics.productType': 'PRODUCT TYPE',
        'demographics.walletIndicator': 'WALLET INDICATOR',
        'demographics.paymentCategoryCode': 'PAYMENT CATEGORY CODE',
        'demographics.localTricsCenter': 'LOCAL TRICS CENTER',
        'demographics.foreignTricsCenter': 'FOREIGN TRICS CENTER',
        'demographics.primaryInstitution': 'PRIMARY INSTITUTION',
        'demographics.safekeyRegion': 'SAFEKEY REGION',
        'demographics.serviceCenter': 'SEREVICE CENTER',
        'demographics.save': 'Save',
        cancel: 'Cancel',
      },
    },
  };

  beforeEach(() => {
    DEFAULT_PROPS = {
      orgData: {
        leagalName: 'Wells Fargo Bank',
        dbaName: 'Wells Fargo',
        dealCodeName: 'GRIZZLY',
        roleType: 'Non-Proprietary Licence/Network Card',
        address: '7000 Vista Drive',
        city: 'West Des Moines',
        stateRegion: '075-IOWA',
        postalCode: '50257',
        country: '840-USA',
        domicleCountry: 'NCL',
        regionID: 'North America',
        dealConstruct: 'None',
        businessCenter: '002-WROC',
        doubleByte: 'NO',
        productType: 'R2L-PERSGREENREVOLVE',
        walletIndicator: 'Non-DPAN',
        paymentCategoryCode: 'N/A',
        localTricsCenter: 'W-WROC',
        foreignTricsCenter: 'W-WROC',
        primaryInstitution: 'No',
        safekeyRegion: 'No',
      },
      selected: jest.fn(),
    };
  });

  it('Should load correctly', () => {
    wrapper = shallow(<EditDemographics {...DEFAULT_PROPS} />, {
      context,
    });
    expect(wrapper.find('div'));
  });

  it('Should updateSelected', () => {
    wrapper = shallow(<EditDemographics {...DEFAULT_PROPS} />, {
      context,
    });
    expect(wrapper.state('selected')).toEqual('');
    wrapper.instance().updateSelected('value-changed');
    expect(wrapper.state('selected')).toEqual('value-changed');
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    const unloadedContext = {
      context: { intl: {} },
    };

    wrapper = shallow(<EditDemographics {...DEFAULT_PROPS} />, unloadedContext);
    expect(wrapper.find('#legalName').prop('input')).toBeFalsy();
  });
});
