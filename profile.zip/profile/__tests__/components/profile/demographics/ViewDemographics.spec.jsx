import React from 'react';
import { shallow } from 'enzyme';
import { ViewDemographics } from '../../../../src/components/profile/demographics/ViewDemographics';

describe('AXP Demographics Component Test', () => {
  let wrapper;
  let DEFAULT_PROPS;
  let context;

  beforeEach(() => {
    DEFAULT_PROPS = {
      content: {
        leagalName: 'Wells Fargo Bank',
        dbaName: 'Wells Fargo',
        dealCodeName: 'GRIZZLY',
        roleType: 'Non-Proprietary Licence/Network Card',
        address: '7000 Vista Drive',
        city: 'West Des Moines',
        stateRegion: '075-IOWA',
        postalCode: '50257',
        country: '840-USA',
        domicleCountry: 'NCL',
        regionID: 'North America',
        dealConstruct: 'None',
        businessCenter: '002-WROC',
        doubleByte: 'NO',
        productType: 'R2L-PERSGREENREVOLVE',
        walletIndicator: 'Non-DPAN',
        paymentCategoryCode: 'N/A',
        localTricsCenter: 'W-WROC',
        foreignTricsCenter: 'W-WROC',
        primaryInstitution: 'No',
        safekeyRegion: 'No',
      },
    };
    context = {
      intl: {
        messages: {
          'demographics.legalName': 'LEGAL NAME',
          'demographics.dbaName': 'DBA NAME',
          'demographics.dealCodeName': 'DEAL CODE NAME',
          roleType: 'ROLE TYPE',
          'demographics.address': 'ADDRESS',
          'demographics.city': 'CITY',
          'demographics.stateRegion': 'STATE/REGION',
          'demographics.postalCode': 'POSTAL CODE',
          'demographics.country': 'COUNTRY',
          'demographics.domicleCountry': 'DOMICLE COUNTRY',
          'demographics.regionID': 'REGION ID',
          'demographics.dealConstruct': 'DEAL CONSTRUCT',
          'demographics.businessCenter': 'BUSINESS CENTER',
          'demographics.doubleByte': 'DOUBLE BYTE',
          'demographics.productType': 'PRODUCT TYPE',
          'demographics.walletIndicator': 'WALLET INDICATOR',
          'demographics.paymentCategoryCode': 'PAYMENT CATEGORY CODE',
          'demographics.localTricsCenter': 'LOCAL TRICS CENTER',
          'demographics.foreignTricsCenter': 'FOREIGN TRICS CENTER',
          'demographics.primaryInstitution': 'PRIMARY INSTITUTION',
          'demographics.safekeyRegion': 'SAFEKEY REGION',
          'demographics.serviceCenter': 'SEREVICE CENTER',
          'demographics.save': 'Save',
          cancel: 'Cancel',
          demographics: 'Demographics',
        },
      },
    };
  });

  it('Should load correctly', () => {
    wrapper = shallow(<ViewDemographics {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('div'));
  });
});
