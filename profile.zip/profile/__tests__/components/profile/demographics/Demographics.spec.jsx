import React from 'react';
import { shallow } from 'enzyme';
import { Demographics } from '../../../../src/components/profile/demographics/Demographics';


describe('Demographics Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Demographics', () => {
    const props = {};
    const renderedModule = shallow(<Demographics {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('matches snapshot for Demographics with editmode as false', () => {
    const props = { isEditmode: true };
    const renderedModule = shallow(<Demographics {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });
});
