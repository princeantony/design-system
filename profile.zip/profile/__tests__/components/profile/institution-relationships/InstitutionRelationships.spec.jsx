import React from 'react';
import { shallow, mount } from 'enzyme';
import InstitutionRelationships, { IndicatorIcons } from '../../../../src/components/profile/institution-relationships/InstitutionRelationships';

describe('InstitutionRelationships Component Test', () => {
  const { NODE_ENV } = process.env;
  const mockInstitutionData = {
    institutionDataArray: [
      {
        institution_name: 'AMERICAN EXPRESS UNITED STATES',
        organization: {
          organization_identifier: 263,
          organization_doing_business_as_name: 'AMERICAN EXPRESS UNITED STATES',
        },
        client_role_type: {
          client_role_type_code: 'AC',
          client_role_type_description: 'Acquirer',
        },
        deal_construct_code: 'PROP',
        product_code: '    ',
        pan_minimum_length_number: 13,
        pan_maximum_length_number: 19,
        client_institution_relationship: [
          {
            institution_identifier: 11000000000,
            institution_name: 'AE - USA                              ',
            client_role_type_code: 'AP',
            client_institution_relationship_type_code: 'PC',
            organization_identifier: 599,
            organization_name: 'AE - USA                              ',
          },
          {
            institution_identifier: 11000000001,
            institution_name: 'AE - USA                              ',
            client_role_type_code: 'AP',
            client_institution_relationship_type_code: 'PC',
            organization_identifier: 599,
            organization_name: 'AE - USA                              ',
          },
        ],
      },
    ],
    institutionSingleData: {
      institution_name: 'AE - USA                              ',
      client_role_type: {
        client_role_type_code: 'AC',
        client_role_type_description: 'Acquirer',
      },
      organization: {
        organization_identifier: 263,
        organization_doing_business_as_name: 'AMERICAN EXPRESS UNITED STATES',
      },
      deal_construct_code: 'PROL',
      product_code: '    ',
      pan_minimum_length_number: 13,
      pan_maximum_length_number: 19,
      client_institution_relationship: [
        {
          institution_identifier: 11000000000,
          institution_name: 'AE - USA                              ',
          client_role_type_code: 'AP',
          client_institution_relationship_type_code: 'PC',
          organization_identifier: 1,
          organization_name: 'AE - USA                              ',
        },
        {
          institution_identifier: 11000000001,
          institution_name: 'AE - USA                              ',
          client_role_type_code: 'AP',
          client_institution_relationship_type_code: 'PC',
          organization_identifier: 1,
          organization_name: 'AE - USA                              ',
        },
      ],
    },
  };
  const mockData = {
    informationalIconGroup: [
      { name: 'Organization', class: 'dls-icon-bank' },
      { name: 'Role', class: 'dls-icon-card' },
      { name: 'Institution', class: 'dls-icon-business' },
      { name: 'Delete Relation', class: 'dls-icon-p2p' },
      { name: 'Primary Institution', class: 'dls-icon-favorite' },
    ],
    columnHeader: [
      {
        value: 'col_icon_1',
        className: '',
      },
      {
        title: 'ORG ID',
        value: 'org_id',
      },
      {
        title: 'ORG DBA NAME',
        value: 'org_dba_name',
      },
      {
        title: 'ROLE TYPE',
        value: 'role_type',
      },
      {
        title: 'INSTITUTION',
        value: 'institution',
      },
      {
        title: 'START DATE',
        value: 'start_date',
      },
      {
        title: 'END DATE',
        value: 'end_date',
      },
    ],
  };

  let wrapper;
  let DEFAULT_PROPS;
  let context;
  beforeEach(() => {
    DEFAULT_PROPS = {
      isEditmode: false,
      tableHeaders: mockData.columnHeader,
      cancelEditInstitutionRelationships: jest.fn(),
      setViewAll: jest.fn(),
      detailView: false,
      institutionData: mockInstitutionData.institutionDataArray,
      //   {
      //   institution: mockInstitutionData.institutionDataArray,
      // },
    };
    context = {
      intl: {
        messages: { 'view_InstitutionalRelationships.btn_view_all': 'View All' },
      },
    };
    context = {
      intl: {
        messages: {
          'institutionRelation.title': 'Institution Relationships',
          editSelected: 'Edit Selected',
          cancel: 'Cancel',
          'dropDown.errorMessage': 'No Data Found',
          'institutionalRelationships.organization': 'Organization',
          'institutionalRelationships.role': 'Role',
          'institutionalRelationships.institution': 'Institution',
          'institutionalRelationships.primaryInstitution': 'Primary Institution',
          'institutionalRelationships.deleteRelation': 'Delete Relation',
        },
      },
    };
  });

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });
  it('matches snapshot for InstitutionRelationships', () => {
    wrapper = shallow(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('EditInstitutionRelationships')).toBeTruthy();
  });

  it('matches  for InstitutionRelationships', () => {
    DEFAULT_PROPS.isEditmode = true;
    DEFAULT_PROPS.viewAllHandle = jest.fn();
    wrapper = shallow(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('ViewInstitutionRelationships')).toBeTruthy();
  });
  it('matches snapshot for InstitutionRelationships with editmode as true', () => {
    const renderedModule = shallow(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.length).toBe(1);
  });

  it('matches snapshot for InstitutionRelationships with editmode as false', () => {
    DEFAULT_PROPS.detailView = true;
    const renderedModule = shallow(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.length).toBe(1);
  });
  it('should call Indicator Icons component ', () => {
    const renderedModule = mount(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.children().find('IndicatorIcons').length).toEqual(1);
  });

  it('should check for InstitutionRelationships when institutionData is empty', () => {
    DEFAULT_PROPS.institutionData = [];
    wrapper = shallow(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('ViewInstitutionRelationships')).toBeTruthy();
  });

  it('should check for InstitutionRelationships when org_dba_name is undefined', () => {
    delete DEFAULT_PROPS.institutionData[0]
      .organization.organization_doing_business_as_name;
    wrapper = shallow(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('ViewInstitutionRelationships')).toBeTruthy();
  });
  it('call Indicator Icons component ', () => {
    const langPack = context.intl.messages;
    const renderedModule = IndicatorIcons({ langPack });
    expect(renderedModule.props.children.length);
  });
  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context = {
      intl: {},
    };

    wrapper = shallow(<InstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.get(0)).toBe(null);
  });
});
