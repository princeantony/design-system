import React from 'react';
import { shallow, mount } from 'enzyme';
import ViewInstitutionRelationships from '../../../../src/components/profile/institution-relationships/ViewInstitutionRelationships';

describe('AXP Institution view Component Test', () => {
  let context;
  const mockInstitutionData = {
    institutionDataArray: [
      {
        institution_name: 'AMERICAN EXPRESS UNITED STATES        ',
        client_role_type: {
          client_role_type_code: 'AC',
          client_role_type_description: 'Acquirer',
        },
        deal_construct_code: 'PROP',
        product_code: '    ',
        pan_minimum_length_number: 13,
        pan_maximum_length_number: 19,
        client_institution_relationship: [
          {
            institution_identifier: 11000000000,
            institution_name: 'AE - USA                              ',
            client_role_type_code: 'AP',
            client_institution_relationship_type_code: 'PC',
            organization_identifier: 599,
            organization_name: 'AE - USA                              ',
          },
          {
            institution_identifier: 11000000001,
            institution_name: 'AE - USA                              ',
            client_role_type_code: 'AP',
            client_institution_relationship_type_code: 'PC',
            organization_identifier: 599,
            organization_name: 'AE - USA                              ',
          },
        ],
      },
    ],
  };
  const clientRelationShip = [
    {
      organization_identifier: 1,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 2,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 3,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 4,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 5,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 6,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 7,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 8,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 9,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 10,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 11,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 12,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 13,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 14,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 15,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 16,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 17,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 18,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 19,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 20,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 21,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 22,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 23,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 24,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 25,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    },
    {
      organization_identifier: 26,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    }, {
      organization_identifier: 27,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    }, {
      organization_identifier: 28,
      orgDbaName: 'WELLS FARGO',
      roleType: 'NC',
      institutionId: 'WF INSTITUTION',
      startDate: '2018/11/13',
      endDate: '9999/12/31',
    }];
  const mockData = {
    columnHeader: [
      {
        value: 'col_icon_1',
        className: '',
      },
      {
        title: 'ORG ID',
        value: 'org_id',
      },
      {
        title: 'ORG DBA NAME',
        value: 'org_dba_name',
      },
      {
        title: 'ROLE TYPE',
        value: 'role_type',
      },
      {
        title: 'INSTITUTION',
        value: 'institution',
      },
      {
        title: 'START DATE',
        value: 'start_date',
      },
      {
        title: 'END DATE',
        value: 'end_date',
      },
    ],
  };
  let DEFAULT_PROPS;
  beforeEach(() => {
    DEFAULT_PROPS = {
      detailView: false,
      instutionalData: mockData,
      isEditmode: false,
      setViewAll: jest.fn(),
      institutionData: mockInstitutionData.institutionDataArray,
      tableHeaders: mockData.columnHeader,
    };
    context = {
      intl: {
        messages: {
          'view_InstitutionalRelationships.btn_view_all': 'View All',
        },
      },
    };
  });
  let wrapper;
  it('Should load correctly', () => {
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, {
      context,
    });
    expect(wrapper.find('div'));
  });

  it('Should find table row', () => {
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, {
      context,
    });
    expect(wrapper.find('tr')).toBeTruthy();
  });

  it('Should find the View All button', () => {
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, {
      context,
    });
    expect(wrapper.find('View All')).toBeTruthy();
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    const unloadedContext = {
      context: { intl: {} },
    };
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, unloadedContext);
    expect(wrapper.find('View All')).toHaveLength(0);
  });

  it('check click event for view all button', () => {
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, {
      context,
    });
    wrapper.find('#viewAllBtn').simulate('click', '');
    expect(DEFAULT_PROPS.setViewAll).toHaveBeenCalled();
  });

  it('should check for not found div when institutionData is empty', () => {
    DEFAULT_PROPS.institutionData = [];
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('div')).toBeTruthy();
  });

  it('should check when detail view is true', () => {
    DEFAULT_PROPS.detailView = true;
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ institutionCollection: mockInstitutionData.institutionDataArray });
    expect(wrapper.find('div')).toBeTruthy();
  });

  it('should call handlePageChange method', () => {
    wrapper = mount(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handlePageChange(1);
    expect(wrapper.state().activePage).toEqual(1);
  });

  it('should check for div when institutionData is greater than 25 records', () => {
    DEFAULT_PROPS.institutionData = clientRelationShip;
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('div')).toBeTruthy();
  });

  it('should check for div when institutionData is less than 25 records', () => {
    DEFAULT_PROPS.institutionData = clientRelationShip.slice(0, 5);
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('div')).toBeTruthy();
  });

  it('should check for div when institutionData is greater than 25 records, detailview', () => {
    DEFAULT_PROPS.institutionData = clientRelationShip;
    DEFAULT_PROPS.detailView = true;
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('div')).toBeTruthy();
  });

  it('should check for div when institutionData is less than 25 records, detailview', () => {
    DEFAULT_PROPS.institutionData = clientRelationShip.slice(0, 5);
    DEFAULT_PROPS.detailView = true;
    wrapper = shallow(<ViewInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('div')).toBeTruthy();
  });
});
