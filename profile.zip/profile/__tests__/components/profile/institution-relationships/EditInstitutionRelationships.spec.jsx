import React from 'react';
import { shallow } from 'enzyme';
import EditInstitutionRelationships from '../../../../src/components/profile/institution-relationships/EditInstitutionRelationships';

describe('AXP EditInstitutionRelationships {...DEFAULT_PROPS} Component Test', () => {
  const context = {
    intl: {
      messages: {
        'institutionRelation.title': 'Institution Relationships',
        editSelected: 'Edit Selected',
        cancel: 'Cancel',
      },
    },
  };

  let DEFAULT_PROPS;

  beforeEach(() => {
    DEFAULT_PROPS = {
      tableHeaders: [
        { value: 'Role Descriptor', name: 'institutionId' },
        { value: 'Start Date', name: 'startDate' },
        { value: 'End Date', name: 'endDate' },
      ],
      tableBody: [
        {
          institutionId: 'WF INSTITUTION',
          startDate: '2018/11/10',
          endDate: '9999/12/31',
          selected: false,
        },
        {
          institutionId: 'WF INSTITUTION',
          startDate: '2018/11/10',
          endDate: '9999/12/31',
          selected: false,
        },
      ],
      iconArray: [{ name: 'Organization', class: 'dls-icon-bank' }],
      cancelEditInstitutionRelationships: jest.fn(),
    };
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    const unloadedContext = {
      context: { intl: {} },
    };

    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, unloadedContext);
    expect(wrapper.get(0)).toBe(null);
  });

  it('should initialize state ', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().isEditDatesModalVisible).toEqual(false);
  });

  it('should show modal button on clicking edit button ', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    const mockedEvent = { target: { className: '' } };
    wrapper.find('#editDates').simulate('click', mockedEvent);
    expect(wrapper.state().isEditDatesModalVisible).toEqual(true);
  });

  it('should set start and end date when modal is closed ', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    const row = [
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    wrapper.setState({
      isEditDatesModalVisible: true,
      allRows: row,
      startDate: '2018/11/10',
      endDate: '2018/11/10',
    });
    const mockedEvent = { target: { className: '' } };
    wrapper.instance().toggleModal(mockedEvent);
    expect(wrapper.state().allRows[0].startDate).toEqual('2018/11/10');
  });

  it('should handle unselected state on edit  ', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    const row = [
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: false,
      },
    ];
    wrapper.setState({
      isEditDatesModalVisible: true,
      allRows: row,
      startDate: '2018/11/10',
      endDate: '2018/11/10',
    });
    const mockedEvent = { target: { className: '' } };
    wrapper.instance().toggleModal(mockedEvent);
    expect(wrapper.state().allRows[1].selected).toEqual(false);
  });

  it('handleStartDate - should set start date  ', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleStartDate('11/01/2018');
    expect(wrapper.state().startDate).toEqual('11/01/2018');
  });

  it('handleEndDate - should set end date', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleEndDate('11/01/2018');
    expect(wrapper.state().endDate).toEqual('11/01/2018');
  });

  it('selectionHandler - should handle values returned by selection handler', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    const selectedRows = [
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    const allRows = [
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    wrapper.setState({ endDate: '11/01/2018' });
    wrapper.instance().selectionHandler(selectedRows, allRows);
    expect(wrapper.state().endDate).toEqual('11/01/2018');
  });

  it('should handle selected rows for undefined value', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    const unSelectedRows = [
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
      },
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    wrapper.setState({ allRows: unSelectedRows });
    expect(wrapper.state().allRows[0].selected).toBe(undefined);
  });

  it('should handle unselected rows', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    const selectedRows = [
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: false,
      },
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: false,
      },
    ];
    wrapper.setState({ allRows: selectedRows });
    expect(wrapper.state().allRows[0].selected).toBe(false);
  });

  it('tableBody - should set initital values for row', () => {
    const wrapper = shallow(<EditInstitutionRelationships {...DEFAULT_PROPS} />, { context });
    const allRows = [
      {
        institutionId: 'WF INSTITUTION',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
      },
    ];
    const returnValue = wrapper.instance().tableBody(DEFAULT_PROPS.tableBody);
    expect(returnValue).toEqual(DEFAULT_PROPS.tableBody);
    const returnValue2 = wrapper.instance().tableBody(allRows);

    expect(returnValue2).toEqual([
      {
        endDate: '9999/12/31',
        institutionId: 'WF INSTITUTION',
        selected: false,
        startDate: '2018/11/10',
      },
    ]);
  });
});
