import React from 'react';
import { shallow, mount } from 'enzyme';
import ViewCapabilities from '../../../../src/components/profile/capabilities/ViewCapabilities';

describe('AXP View Capabilities Component Test', () => {
  const tableData = {
    tableData: [
      {
        col_icon_1: '',
        col_icon_2: '',
        capability_type: 'Message Certification_0',
        description: 'Local Market Settlement Reporting - Dap Feed',
        calculation_indicator: 'N',
        start_date: '2012/10/10',
        end_date: '2020/10/10',
      },
      {
        col_icon_1: '',
        col_icon_2: '',
        capability_type: 'Message Certification_1',
        description: 'Local Market Settlement Reporting - Dap Feed',
        calculation_indicator: 'N',
        start_date: '2012/10/11',
        end_date: '2020/10/11',
      },
    ],
    columnHeader: [
      {
        value: 'col_icon_1',
        className: '',
      },
      {
        value: 'col_icon_2',
        className: '',
      },
      {
        title: 'CAPABILITY TYPE',
        value: 'capability_type',
      },
      {
        title: 'DESCRIPTION',
        value: 'description',
      },
      {
        title: 'CACULATION INDICATOR',
        value: 'calculation_indicator',
      },
      {
        title: 'START DATE',
        value: 'start_date',
      },
      {
        title: 'END DATE',
        value: 'end_date',
      },
    ],
  };

  let DEFAULT_PROPS;
  let context;
  const DEFAULT_EMPTY_DATA = {
    tableData: [],
    columnHeader: [],
  };

  beforeEach(() => {
    DEFAULT_PROPS = {
      capabilitiesData: tableData,
      tableHeaders: tableData.columnHeader,
      detailView: false,
      setViewAll: jest.fn(),
      compClasses: '',
    };
    context = {
      intl: {
        messages: {
          viewAll: 'View All',
          back: 'Back',
        },
      },
    };
  });

  it('should call view component ', () => {
    const wrapper = shallow(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.children().length).toEqual(2);
  });

  it('should load table correctly, there should be 3 rows', () => {
    const wrapper = mount(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('DataTable').find('.row-xs-size').length).toEqual(3);
  });

  it('should not have rows in the the table, when no results are passed ', () => {
    DEFAULT_PROPS.capabilitiesData = DEFAULT_EMPTY_DATA;
    const wrapper = mount(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('DataTable').find('.row-xs-size').length).toEqual(0);
  });

  it('should call loading component ', () => {
    DEFAULT_PROPS.capabilitiesData = DEFAULT_EMPTY_DATA;
    const wrapper = shallow(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.length).toEqual(1);
  });

  it('should be able to display text from lang pack if context is loaded', () => {
    const wrapper = shallow(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('.btn-sm').prop('label')).toBe('View All');
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context = {
      intl: {},
    };
    const wrapper = shallow(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.getElement()).toBe(null);
  });

  it('should simulate onclick for viewall button', () => {
    const wrapper = shallow(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    wrapper.find('#viewAllBtn').simulate('click');
    expect(DEFAULT_PROPS.setViewAll).toHaveBeenCalled();
  });

  it('should test default props', () => {
    delete DEFAULT_PROPS.setViewAll;
    const wrapper = mount(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.prop('setViewAll')).toBeDefined();
    expect(wrapper.prop('setViewAll')()).toBe(null);
  });
  it('should return date in mm/dd/yyyy format when date is sent as yyyy/mm/dd', () => {
    const formatDate = jest.fn((date) => {
      const dateVal = new Date(date);
      const month =
        dateVal.getMonth() + 1 < 10 ? `0${dateVal.getMonth() + 1}` : dateVal.getMonth() + 1;
      const day = dateVal.getDate() < 10 ? `0${dateVal.getDate()}` : dateVal.getDate();
      return `${month}/${day}/${dateVal.getFullYear()}`;
    });
    DEFAULT_PROPS.capabilitiesData.tableData = [
      {
        col_icon_1: '',
        col_icon_2: '',
        capability_type: 'Message Certification_0',
        description: 'Local Market Settlement Reporting - Dap Feed',
        calculation_indicator: 'N',
        start_date: '2012/1/2',
        end_date: '2020/1/10',
      },
    ];
    shallow(<ViewCapabilities {...DEFAULT_PROPS} />, { context });
    expect(formatDate('2012/1/1')).toEqual('01/01/2012');
  });
});
