import React from 'react';
import { shallow, mount } from 'enzyme';
import Capabilities from '../../../../src/components/profile/capabilities/Capabilities';

describe('Capabilities Component Test', () => {
  let DEFAULT_PROPS;
  let context;

  beforeEach(() => {
    DEFAULT_PROPS = {
      detailView: false,
      isEditmode: false,
      setViewAll: jest.fn(),
      setEditMode: jest.fn(),
      onHandleCancel: jest.fn(),
    };
    context = {
      intl: {
        messages: {
          'capabilities.enrolled': 'Enrolled',
          'capabilities.available': 'Available',
          'capabilities.organization': 'Organization',
          institution: 'Institution',
          'capabilities.futureIndicator': ' Future Indicator',
          'capabilities.modify': 'Modify',
          'capabilities.enroll': 'Enroll',
          'capabilities.unEnroll': 'Un Enroll',
        },
      },
    };
  });

  it('Capabilities should load view capabalilities component ', () => {
    const renderedModule = shallow(<Capabilities {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.children().length).toEqual(2);
    expect(renderedModule.childAt(0).name()).toEqual('ViewCapabilities');
  });
  it('Capabilities should load view all capabalilities component ', () => {
    DEFAULT_PROPS = Object.assign({}, DEFAULT_PROPS, { detailView: true });
    const renderedModule = shallow(<Capabilities {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.children().length).toEqual(2);
    expect(renderedModule.childAt(0).name()).toEqual('ViewCapabilitiesAll');
  });
  it('Capabilities should load edit capabalilities component ', () => {
    DEFAULT_PROPS = Object.assign({}, DEFAULT_PROPS, { isEditmode: true });
    const renderedModule = shallow(<Capabilities {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.children().length).toEqual(2);
    expect(renderedModule.childAt(0).name()).toEqual('EditCapabilities');
  });
  it('should call Indicator Icons component ', () => {
    const renderedModule = mount(<Capabilities {...DEFAULT_PROPS} />, { context });
    expect(renderedModule.children().find('IndicatorIcons').length).toEqual(1);
  });
  it('should check unloaded context ', () => {
    context = {
      intl: {},
    };
    mount(<Capabilities {...DEFAULT_PROPS} />, { context });
  });
});
