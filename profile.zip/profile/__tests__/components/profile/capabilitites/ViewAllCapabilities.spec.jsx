import React from 'react';
import { shallow, mount } from 'enzyme';
import ViewAllCapabilities from '../../../../src/components/profile/capabilities/ViewAllCapabilities';

describe('AXP View All Capabilities Component Test', () => {
  const tableData = {
    tableData: [
      {
        col_icon_1: '',
        col_icon_2: '',
        capability_type: 'Message Certification_0',
        description: 'Local Market Settlement Reporting - Dap Feed',
        calculation_indicator: 'N',
        start_date: '2012/10/10',
        end_date: '2020/10/10',
      },
      {
        col_icon_1: '',
        col_icon_2: '',
        capability_type: 'Message Certification_1',
        description: 'Local Market Settlement Reporting - Dap Feed',
        calculation_indicator: 'N',
        start_date: '2012/10/11',
        end_date: '2020/10/11',
      },
    ],
    columnHeader: [
      {
        value: 'col_icon_1',
        className: '',
      },
      {
        value: 'col_icon_2',
        className: '',
      },
      {
        title: 'CAPABILITY TYPE',
        value: 'capability_type',
      },
      {
        title: 'DESCRIPTION',
        value: 'description',
      },
      {
        title: 'CACULATION INDICATOR',
        value: 'calculation_indicator',
      },
      {
        title: 'START DATE',
        value: 'start_date',
      },
      {
        title: 'END DATE',
        value: 'end_date',
      },
    ],
  };

  let DEFAULT_PROPS;
  let context;

  beforeEach(() => {
    DEFAULT_PROPS = {
      capabilitiesData: tableData,
      tableHeaders: tableData.columnHeader,
      detailView: true,
      setViewAll: jest.fn(),
      setEditMode: jest.fn(),
    };
    context = {
      intl: {
        messages: {
          viewAll: 'View All',
          back: 'Back',
          'viewAll.capabilities': 'Capabilities',
        },
      },
    };
  });

  it('should call view All component ', () => {
    const wrapper = shallow(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.children().length).toEqual(3);
  });

  it('should load table correctly, there should be 3 rows', () => {
    const wrapper = mount(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('DataTable').find('.row-xs-size').length).toEqual(3);
  });

  it('should not have rows in the the table, when no results are passed ', () => {
    DEFAULT_PROPS = Object.assign({}, DEFAULT_PROPS, {
      capabilitiesData: { tableData: [], columnHeader: [] },
    });
    const wrapper = mount(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('DataTable').find('.row-xs-size').length).toEqual(0);
  });

  it('should call loading component ', () => {
    DEFAULT_PROPS = Object.assign({}, DEFAULT_PROPS, {
      capabilitiesData: { tableData: [], columnHeader: [] },
    });
    const wrapper = shallow(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.length).toEqual(1);
  });

  it('should be able to display text from lang pack if context is loaded', () => {
    const wrapper = shallow(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('#viewAllbackBtn').prop('label')).toBe('Back');
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context = {
      intl: {},
    };
    const wrapper = shallow(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.getElement()).toBe(null);
  });

  it('should simulate onclick for back button', () => {
    const wrapper = shallow(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    wrapper.find('#viewAllbackBtn').simulate('click');
    expect(DEFAULT_PROPS.setViewAll).toHaveBeenCalled();
  });

  it('should simulate onclick for edit button', () => {
    const wrapper = shallow(<ViewAllCapabilities {...DEFAULT_PROPS} />, { context });
    wrapper.find('#viewAllEditBtn').simulate('click');
    expect(DEFAULT_PROPS.setEditMode).toHaveBeenCalled();
  });
});
