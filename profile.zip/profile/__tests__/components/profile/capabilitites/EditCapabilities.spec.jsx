import React from 'react';
import { shallow } from 'enzyme';
import { EditCapabilities } from '../../../../src/components/profile/capabilities/EditCapabilities';

describe('Edit Capabilities', () => {
  let context;
  let DEFAULT_PROPS;
  beforeEach(() => {
    context = {
      intl: {
        messages: {
          editSelected: 'Edit Selected',
          cancel: 'Cancel',
          'editDates.title': 'Edit Selected Dates',
          'editDate.submitChange': 'Submit Changes',
          'editDate.newStartDate': 'New Start Date',
          'editDate.newEndDate': 'New End Date',
        },
      },
    };
    DEFAULT_PROPS = {
      onHandleCancel: jest.fn(),
      tableHeaders: [
        { name: 'orgIcon1', value: '' },
        { name: 'orgIcon2', value: '' },
        {
          title: 'CAPABILITY TYPE',
          value: 'capability_type',
        },
        {
          title: 'DESCRIPTION',
          value: 'description',
        },
        {
          title: 'CACULATION INDICATOR',
          value: 'calculation_indicator',
        },
        {
          title: 'START DATE',
          value: 'startDate',
        },
        {
          title: 'END DATE',
          value: 'endDate',
        },
      ],
      iconArray: [
        { name: 'Enrolled', class: 'dls-icon-thumbs-up' },
        { name: 'Available', class: 'dls-icon-alert' },
        { name: 'Organization', class: 'dls-icon-bank' },
        { name: 'Institution', class: 'dls-icon-business' },
        { name: 'Future Indicator', class: 'dls-icon-geolocation' },
        { name: 'Modify', class: 'dls-icon-edit' },
        { name: 'Enroll', class: 'dls-icon-plus-circle' },
        { name: 'Disenroll', class: 'dls-icon-minus-circle' },
      ],
      tableBody: [
        {
          capability_type: 'Message Certification_0',
          description: 'Local Market Settlement Reporting - Dap Feed',
          calculation_indicator: 'N',
          startDate: '2012/10/10',
          endDate: '2020/10/10',
        },
        {
          capability_type: 'Message Certification_1',
          description: 'Local Market Settlement Reporting - Dap Feed',
          calculation_indicator: 'N',
          startDate: '2012/10/11',
          endDate: '2020/10/11',
        },
        {
          capability_type: 'Message Certification_6',
          description: 'Local Market Settlement Reporting - Dap Feed',
          calculation_indicator: 'N',
          startDate: '2012/10/16',
          endDate: '2020/10/16',
        },
      ],
    };
  });
  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context.intl = {};
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('#editFields').prop('label')).toBeFalsy();
  });
  it('should initialize state ', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().isEditDatesModalVisible).toEqual(false);
  });
  it('should show modal button on clicking edit button ', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    const mockedEvent = { target: { className: '' } };
    wrapper.find('#editFields').simulate('click', mockedEvent);
    expect(wrapper.state().isEditDatesModalVisible).toEqual(true);
  });
  it('should set start and end date when modal is closed ', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    const row = [
      {
        capability_type: 'Message Certification_0',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    wrapper.setState({
      isEditDatesModalVisible: true,
      allRows: row,
      startDate: '2018/11/10',
      endDate: '2018/11/10',
    });
    const mockedEvent = { target: { className: '' } };
    wrapper.instance().toggleModal(mockedEvent);
    expect(wrapper.state().allRows[0].startDate).toEqual('2018/11/10');
  });
  it('should handle unselected state on edit  ', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    const row = [
      {
        capability_type: 'Message Certification_1',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
      {
        capability_type: 'Message Certification_1',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: false,
      },
    ];
    wrapper.setState({
      isEditDatesModalVisible: true,
      allRows: row,
      startDate: '2018/11/10',
      endDate: '2018/11/10',
    });
    const mockedEvent = { target: { className: '' } };
    wrapper.instance().toggleModal(mockedEvent);
    expect(wrapper.state().allRows[1].selected).toEqual(false);
  });
  it('handleStartDate - should set start date  ', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleStartDate('11/01/2018');
    expect(wrapper.state().startDate).toEqual('11/01/2018');
  });
  it('handleEndDate - should set end date', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleEndDate('11/01/2018');
    expect(wrapper.state().endDate).toEqual('11/01/2018');
  });
  it('selectionHandler - should handle values returned by selection handler', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    const selectedRows = [
      {
        capability_type: 'Message Certification_2',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    const allRows = [
      {
        capability_type: 'Message Certification_2',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    wrapper.setState({ endDate: '11/01/2018' });
    wrapper.instance().selectionHandler(selectedRows, allRows);
    expect(wrapper.state().endDate).toEqual('11/01/2018');
  });
  it('should handle selected rows for undefined value', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    const unSelectedRows = [
      {
        capability_type: 'Message Certification_3',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
      },
      {
        capability_type: 'Message Certification_3',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    wrapper.setState({ allRows: unSelectedRows });
    expect(wrapper.state().allRows[0].selected).toBe(undefined);
  });
  it('should handle unselected rows', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    const selectedRows = [
      {
        capability_type: 'Message Certification_4',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: false,
      },
      {
        capability_type: 'Message Certification_4',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: false,
      },
    ];
    wrapper.setState({ allRows: selectedRows });
    expect(wrapper.state().allRows[0].selected).toBe(false);
  });

  it('tableBody - should set initital values for row', () => {
    const wrapper = shallow(<EditCapabilities {...DEFAULT_PROPS} />, { context });
    const allRows = [
      {
        capability_type: 'Message Certification_5',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    const returnValue = wrapper.instance().tableBody(allRows);
    expect(returnValue).toEqual(allRows);
  });
});
