import React from 'react';
import { shallow } from 'enzyme';
import { ProfileSummary } from './../../../src/components/profile/ProfileSummary';

describe('ProfileSummary Component Test', () => {
  let DEFAULT_PROPS;
  let wrapper;

  beforeEach(() => {
    DEFAULT_PROPS = {
      orgNameToProfileSummary: '',
      orgIdToProfileSummary: '',
      institutionIdToProfileSummary: '',
    };
  });
  it('should test component will recive props', () => {
    wrapper = shallow(<ProfileSummary {...DEFAULT_PROPS} />);
    wrapper.setProps(DEFAULT_PROPS);
  });
});
