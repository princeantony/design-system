import React from 'react';
import { shallow, mount } from 'enzyme';
import mockFetch from 'jest-fetch-mock';

import Container, { Search } from '../../../src/components/search/Search';

jest.mock('node-fetch', () => mockFetch);

describe('AXP Search Component Test', () => {
  let wrapper;
  let context;
  let DEFAULT_PROPS;

  const orgData = [
    {
      message_access_type_code: 'A1234CD',
      maximum_pan_length_number: 20,
      geographic_region_identifier: '9',
      organization_identifier: '210',
      organization_name: {
        company_contact_name: 'Greg-Ragav-Arvind',
        doing_business_as_name: 'US',
        legal_name: 'AMorganiztion',
        deal_name: 'US-AM',
      },
      minimum_pan_length_number: 20,
      type: 'organization',
      institution_type_identifier: 123,
      organization_classification_code: 'A1234',
      create_timestamp: '2018-12-07T20:02Z',
      role_category_code: 'MGR',
      last_update_timestamp: '2018-12-07T20:02Z',
      deal_construct_type_code: 'IS',
      id: '1233',
      organization_role: {
        end_date: '12th nov 2020',
        referral_type_code: '1234-AMORG',
        effective_date: '12th nov 2018',
        client_role_description: 'MNGR',
        authorization_center_code: '1234-AMORG-01',
      },
    },
    {
      message_access_type_code: 'test1',
      maximum_pan_length_number: 1,
      geographic_region_identifier: 'test2',
      organization_identifier: '23',
      organization_name: {
        company_contact_name: 'test1',
        doing_business_as_name: 'test1',
        legal_name: 'test1',
        deal_name: 'test1',
      },
      minimum_pan_length_number: 1,
      type: 'organization',
      institution_type_identifier: 1,
      organization_classification_code: 'test1',
      create_timestamp: '2018-12-03T14:19Z',
      role_category_code: 'test1',
      last_update_timestamp: '2018-12-03T14:19Z',
      deal_construct_type_code: '2',
      id: '1',
      organization_role: {
        end_date: 'test1',
        referral_type_code: 'test1',
        effective_date: 'test1',
        client_role_description: 'test1',
        authorization_center_code: 'test1',
      },
    },
  ];

  const institutionData = {
    status: { code: 0, message: 'institution retrieved successfully' },
    institution: {
      institution_name: 'AE - USA                              ',
      client_role_type: {
        client_role_type_code: 'AC',
        client_role_type_description: 'Acquirer',
      },
      deal_construct_code: 'PROL',
      product_code: '    ',
      pan_minimum_length_number: 13,
      pan_maximum_length_number: 19,
      client_institution_relationship: [
        {
          institution_identifier: '11000000002',
          institution_name: 'AE - USA                              ',
          client_role_type_code: 'AP',
          client_institution_relationship_type_code: 'PC',
          organization_identifier: 1,
          organization_name: 'AE - USA                              ',
        },
        {
          institution_identifier: '11500000001',
          institution_name: 'AE - USA                              ',
          client_role_type_code: 'AT',
          client_institution_relationship_type_code: 'PC',
          organization_identifier: 1,
          organization_name: 'AE - USA                              ',
        },
      ],
      domicile_country: {
        client_domicile_country_iso_alpha_code: 'UNITED STATES OF AMERICA (THE)',
        client_domicile_country_iso_numeric_code: 840,
        client_domicile_country_name: 'USA       ',
      },
      geo_region: {
        geographic_region_identifier: '1',
        geographic_region_name: 'North America',
      },
      payment_category: {
        payment_category_code: 'N/A',
        payment_category_description: null,
      },
      institution_category: {
        institution_category_code: '01',
        institution_category_description: 'Non-DPAN',
      },
      organization: {
        organization_doing_business_as_name: '',
        organization_identifier: 1,
      },
      institution_identifier: '10000000002',
    },
  };

  beforeEach(() => {
    context = {
      intl: {
        messages: {
          btnSearch: 'Search',
          btnClearAll: 'Cancel',
        },
      },
    };
    DEFAULT_PROPS = {
      countryList: [
        { id: '010', name: '010-ANTARCTICA' },
        { id: '004', name: '004-AFGHAN    ' },
        { id: '008', name: '008-ALBANIA   ' },
      ],
      regionList: [
        {
          id: 'region::000::008',
          type: 'region',
          region_identifier: '000',
          country_iso_numeric_identifier: '008',
          region_area_name_text: 'ALBANIA',
          region_area_abbreviated_name: 'ALBANIA',
          country_region_area_abbreviated_name_text: 'AL',
          region_effective_date: '1988-01-01',
          region_last_transaction_date: '2001-01-16',
          region_last_transaction_code: '',
          region_end_date: '9999-12-31',
        },
        {
          id: 'region::000::004',
          type: 'region',
          region_identifier: '000',
          country_iso_numeric_identifier: '004',
          region_area_name_text: 'AFGHANISTAN',
          region_area_abbreviated_name: 'AFGHAN',
          country_region_area_abbreviated_name_text: 'AF',
          region_effective_date: '1988-01-01',
          region_last_transaction_date: '2000-11-14',
          region_last_transaction_code: '',
          region_end_date: '9999-12-31',
        },
      ],
      searchQueryObj: {
        countryName: '',
        orgIdOrName: '',
        region: '',
        institutionID: '',
        orgIdAndName: '',
        roleTypeCode: '',
      },
      onHandleSearch: jest.fn(),
    };
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context.intl = {};
    wrapper = shallow(<Search {...DEFAULT_PROPS} />, { context });
  });

  it('updateRoleType', () => {
    const list = [
      {
        'ORG ID': '1',
        'ORG Name': 'AE - USA',
        'Institution Number': '10000000002',
        Region: 'NORTH AMERICA',
        'Country Name': 'UNITED STATES OF AMERICA (THE)',
        'Role Type Code': 'Issuer',
      },
    ];
    wrapper = shallow(<Search {...DEFAULT_PROPS.searchQueryObj} />, { context });
    let advancedSearchQueryObj = Object.assign({}, wrapper.state().advancedSearchQueryObj);
    advancedSearchQueryObj = list;
    wrapper.instance().updateRoleTypeCode('Issuer');
    wrapper.setState({ advancedSearchQueryObj });
    expect(wrapper.state().advancedSearchQueryObj).not.toEqual([]);
    expect(wrapper.state().advancedSearchQueryObj.region).not.toEqual('');
  });

  it('updateRegion', () => {
    const list = [
      {
        'ORG ID': '1',
        'ORG Name': 'AE - USA',
        'Institution Number': '10000000002',
        Region: 'NORTH AMERICA',
        'Country Name': 'UNITED STATES OF AMERICA (THE)',
      },
    ];
    wrapper = shallow(<Search {...DEFAULT_PROPS.searchQueryObj} />, { context });
    let advancedSearchQueryObj = Object.assign({}, wrapper.state().advancedSearchQueryObj);
    advancedSearchQueryObj = list;
    wrapper.instance().updateRegion('NORTH AMERICA');
    wrapper.setState({ advancedSearchQueryObj });
    expect(wrapper.state().advancedSearchQueryObj).not.toEqual([]);
    expect(wrapper.state().advancedSearchQueryObj.region).not.toEqual('');
  });

  it('updateCountry', () => {
    const list = [
      {
        'ORG ID': '1',
        'ORG Name': 'AE - USA',
        'Institution Number': '10000000002',
        Region: 'NORTH AMERICA',
        'Country Name': 'UNITED STATES OF AMERICA (THE)',
      },
    ];
    wrapper = shallow(<Search {...DEFAULT_PROPS.searchQueryObj} />, { context });
    let advancedSearchQueryObj = Object.assign({}, wrapper.state().advancedSearchQueryObj);
    advancedSearchQueryObj = list;
    wrapper.instance().updateCountry('UNITED STATES OF AMERICA (THE)');
    wrapper.setState({ advancedSearchQueryObj });
    expect(wrapper.state().advancedSearchQueryObj).not.toEqual([]);
    expect(wrapper.state().advancedSearchQueryObj['Country Name']).not.toEqual('');
  });

  it('selectOrganization', () => {
    const value = {
      countryName: 'UNITED STATES OF AMERICA (THE)',
      orgIdOrName: '1 - AE - USA',
      region: 'NORTH AMERICA',
      institutionID: '10000000002',
      orgIdAndName: '',
      roleTypeCode: '',
    };
    wrapper = shallow(<Search {...DEFAULT_PROPS} />, { context });
    wrapper.instance().selectOrganization(value);
    wrapper.setState({ advancedSearchQueryObj: value });
    expect(wrapper.state().advancedSearchQueryObj).toEqual(value);
  });

  it('selectInstitution', () => {
    const value = {
      countryName: 'UNITED STATES OF AMERICA (THE)',
      orgIdOrName: '1 - AE - USA',
      region: 'NORTH AMERICA',
      institutionID: '10000000002',
      orgIdAndName: '',
      roleTypeCode: '',
    };
    wrapper = shallow(<Search {...DEFAULT_PROPS} />, { context });
    wrapper.instance().selectInstitution(value);
    wrapper.setState({ advancedSearchQueryObj: value });
    expect(wrapper.state().advancedSearchQueryObj).toEqual(value);
  });

  // it('selectOrganization #2', () => {
  //   wrapper = mount(<Search />, { context });

  //   expect(wrapper.state().advancedSearchQueryObj).toEqual({
  //     countryName: '',
  //     institutionID: '',
  //     orgIdAndName: '',
  //     orgIdOrName: '',
  //     region: '',
  //     roleTypeCode: '',
  //   });

  //   wrapper.find('#orgNameSearch input').simulate('change',
  // { target: { value: 'NEW_ORG_NAME' } });

  //   expect(wrapper.state().advancedSearchQueryObj).toEqual({
  //     countryName: '',
  //     institutionID: '',
  //     orgIdAndName: '',
  //     orgIdOrName: 'NEW_ORG_NAME',
  //     region: '',
  //     roleTypeCode: '',
  //   });
  // });

  // it('selectInstitution #2', () => {
  //   wrapper = mount(<Search />, { context });

  //   expect(wrapper.state().advancedSearchQueryObj).toEqual({
  //     countryName: '',
  //     institutionID: '',
  //     orgIdAndName: '',
  //     orgIdOrName: '',
  //     region: '',
  //     roleTypeCode: '',
  //   });

  //   wrapper
  //     .find('#institutionSearch input')
  //     .simulate('change', { target: { value: 'NEW_INST_NAME' } });

  //   expect(wrapper.state().advancedSearchQueryObj).toEqual({
  //     countryName: '',
  //     institutionID: 'NEW_INST_NAME',
  //     orgIdAndName: '',
  //     orgIdOrName: '',
  //     region: '',
  //     roleTypeCode: '',
  //   });
  // });

  it('helperFunc', () => {
    wrapper = mount(<Search />, { context });
    const advancedSearchQueryObj = {
      countryName: '',
      orgId: '',
      region: '',
      institutionID: '',
      roleTypeCode: '',
    };
    wrapper.instance().selectInstitution = jest.fn();
    wrapper.instance().helperFunc(advancedSearchQueryObj);
    expect(wrapper.instance().selectInstitution).toHaveBeenCalled();
  });

  it('handleOrgViewData', () => {
    wrapper = shallow(<Search {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleOrganizationViewData(orgData);
    wrapper.setState({ organizationViewData: orgData });
    expect(wrapper.state().organizationViewData).toEqual(orgData);
  });

  it('handleInstitutionViewData', () => {
    wrapper = shallow(<Search {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleInstitutionViewData(institutionData);
    wrapper.setState({ institutionViewData: institutionData });
    expect(wrapper.state().institutionViewData).toEqual(institutionData);
  });

  it('handle simulate click', () => {
    wrapper = shallow(<Search {...DEFAULT_PROPS} />, { context });
    wrapper.find('#searchBtn').simulate('click', DEFAULT_PROPS);
    expect(DEFAULT_PROPS.onHandleSearch).toHaveBeenCalled();
  });
});
