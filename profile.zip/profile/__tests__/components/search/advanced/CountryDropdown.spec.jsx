import React from 'react';
import { shallow } from 'enzyme';

import CountryDropdown from '../../../../src/components/search/advanced/CountryDropdown';

describe('CountryDropdown', () => {
  let DEFAULT_PROPS;
  let wrapper;
  let context;

  beforeEach(() => {
    context = {
      intl: {
        messages: {
          countryDropdown: 'Country',
        },
      },
    };
    DEFAULT_PROPS = {
      countryList: [
        { id: '010', name: '010-ANTARCTICA' },
        { id: '004', name: '004-AFGHAN    ' },
        { id: '008', name: '008-ALBANIA   ' },
        { id: '012', name: '012-ALGERIA   ' },
        { id: '016', name: '016-AM SAMOA  ' },
        { id: '020', name: '020-ANDORRA   ' },
      ],
      countryValue: '',
      updateCountry: jest.fn(),
      countryApiErrMsg: 'Request cannot be processed',
    };
  });

  const noCountryList = [
    '',
    {
      value: '',
      label: 'Request cannot be processed',
    },
  ];
  const countryListEmpty = [
    '',
    {
      value: '',
      label: 'No Data Found',
    },
  ];
  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context.intl = {};
    wrapper = shallow(<CountryDropdown {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('#country-dropdown').prop('label')).toBeFalsy();
  });

  it('foo', () => {
    wrapper = shallow(<CountryDropdown {...DEFAULT_PROPS} />, { context });
    wrapper.find('#country-dropdown').simulate('change', { label: 'Brazil', value: 'Brazil' });
    expect(DEFAULT_PROPS.updateCountry).toHaveBeenCalled();
  });
  it('if countrylist array length is not empty', () => {
    wrapper = shallow(<CountryDropdown {...DEFAULT_PROPS} />, { context });
    wrapper.setProps();
    expect(wrapper.state().countries).toEqual(DEFAULT_PROPS.countryList);
  });
  it('if countrylist array length is empty', () => {
    DEFAULT_PROPS.countryList = [];
    wrapper = shallow(<CountryDropdown {...DEFAULT_PROPS} />, { context });
    wrapper.setProps();
    expect(wrapper.state().countries).toEqual(countryListEmpty);
  });

  it('if countrylist is undefined', () => {
    DEFAULT_PROPS.countryList = undefined;
    wrapper = shallow(<CountryDropdown {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().countries).toEqual(noCountryList);
  });
});
