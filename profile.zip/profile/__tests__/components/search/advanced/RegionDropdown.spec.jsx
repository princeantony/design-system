import React from 'react';
import { shallow } from 'enzyme';

import RegionDropdown from '../../../../src/components/search/advanced/RegionDropdown';

describe('RegionDropdown', () => {
  let DEFAULT_PROPS;
  let wrapper;
  let context;

  beforeEach(() => {
    context = {
      intl: {
        messages: {
          regionDropdown: 'Region',
        },
      },
    };
    DEFAULT_PROPS = {
      regionList: [
        {
          id: 'region::000::008',
          type: 'region',
          region_identifier: '000',
          country_iso_numeric_identifier: '008',
          region_area_name_text: 'ALBANIA',
          region_area_abbreviated_name: 'ALBANIA',
          country_region_area_abbreviated_name_text: 'AL',
          region_effective_date: '1988-01-01',
          region_last_transaction_date: '2001-01-16',
          region_last_transaction_code: '',
          region_end_date: '9999-12-31',
        },
        {
          id: 'region::000::004',
          type: 'region',
          region_identifier: '000',
          country_iso_numeric_identifier: '004',
          region_area_name_text: 'AFGHANISTAN',
          region_area_abbreviated_name: 'AFGHAN',
          country_region_area_abbreviated_name_text: 'AF',
          region_effective_date: '1988-01-01',
          region_last_transaction_date: '2000-11-14',
          region_last_transaction_code: '',
          region_end_date: '9999-12-31',
        },
      ],
      regionValue: '',
      updateRegion: jest.fn(),
      regionApiErrMsg: 'Request cannot be processed',
    };
  });
  const noRegionList = [
    '',
    {
      value: '',
      label: 'Request cannot be processed',
    },
  ];
  const regionListEmpty = [
    '',
    {
      value: '',
      label: 'No Data Found',
    },
  ];
  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context.intl = {};
    wrapper = shallow(<RegionDropdown {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('#region-dropdown').prop('label')).toBeFalsy();
  });

  it('foo', () => {
    wrapper = shallow(<RegionDropdown {...DEFAULT_PROPS} />, { context });
    wrapper.find('#region-dropdown').simulate('change', { label: 'JAPA', value: 'JAPA' });
    expect(DEFAULT_PROPS.updateRegion).toHaveBeenCalled();
  });
  it('if regionlist array length is not empty', () => {
    wrapper = shallow(<RegionDropdown {...DEFAULT_PROPS} />, { context });
    wrapper.setProps();
    expect(wrapper.state().regions).toEqual(DEFAULT_PROPS.regionList);
  });
  it('if regionlist array length is empty', () => {
    DEFAULT_PROPS.regionList = [];
    wrapper = shallow(<RegionDropdown {...DEFAULT_PROPS} />, { context });
    wrapper.setProps();
    expect(wrapper.state().regions).toEqual(regionListEmpty);
  });
  it('if regionlist is undefined', () => {
    DEFAULT_PROPS.regionList = undefined;
    wrapper = shallow(<RegionDropdown {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().regions).toEqual(noRegionList);
  });
});
