import React from 'react';
import { shallow } from 'enzyme';

import Suggestion from '../../../../src/components/search/advanced/Suggestion';


describe('Suggestion', () => {
  let DEFAULT_PROPS;
  let wrapper;


  beforeEach(() => {
    DEFAULT_PROPS = {
      suggestion: { 'ORG ID': 'foo', 'ORG Name': 'bar' },
      onClick: jest.fn(),
    };
  });

  it('default loading with props', () => {
    wrapper = shallow(<Suggestion {...DEFAULT_PROPS} />);
    expect(wrapper).toMatchSnapshot();
  });

  it('empty suggestion', () => {
    const props = {
      suggestion: '',
      onClick: jest.fn(),
    };

    wrapper = shallow(<Suggestion {...props} />);
    expect(wrapper).toMatchSnapshot();
  });
});
