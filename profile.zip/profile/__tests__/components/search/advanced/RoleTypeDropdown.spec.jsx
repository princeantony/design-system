import React from 'react';
import { shallow } from 'enzyme';

import RoleTypeDropdown from '../../../../src/components/search/advanced/RoleTypeDropdown';

describe('RoleTypeDropdown', () => {
  let DEFAULT_PROPS;
  let wrapper;
  let context;

  beforeEach(() => {
    context = {
      intl: {
        messages: {
          regionDropdown: 'Region',
        },
      },
    };
    DEFAULT_PROPS = {
      roleTypeCodeValue: '',
      updateRoleTypeCode: jest.fn(),
    };
  });
  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    context.intl = {};
    wrapper = shallow(<RoleTypeDropdown {...DEFAULT_PROPS} />, { context });
    expect(wrapper.find('#country-roletype-dropdown').prop('label')).toBeFalsy();
  });
  it('foo', () => {
    wrapper = shallow(<RoleTypeDropdown {...DEFAULT_PROPS} />, { context });
    wrapper
      .find('#country-roletype-dropdown')
      .simulate('change', { label: 'Issuer', value: 'Issuer' });
    expect(DEFAULT_PROPS.updateRoleTypeCode).toHaveBeenCalled();
  });
});
