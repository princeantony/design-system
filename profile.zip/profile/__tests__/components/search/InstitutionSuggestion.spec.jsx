import React from 'react';
import { shallow } from 'enzyme';

import Suggestion from '../../../src/components/search/InstitutionSuggestion';


describe('InstitutionSuggestion', () => {
  let DEFAULT_PROPS;
  let wrapper;


  beforeEach(() => {
    DEFAULT_PROPS = {
      suggestion: { 'ORG ID': 'foo', 'ORG Name': 'bar', 'Institution Number': '10000002' },
      onClick: jest.fn(),
    };
  });

  it('default loading with props', () => {
    wrapper = shallow(<Suggestion {...DEFAULT_PROPS} />);
    expect(wrapper).toMatchSnapshot();
  });

  it('empty suggestion', () => {
    const props = {
      suggestion: '',
      onClick: jest.fn(),
    };
    wrapper = shallow(<Suggestion {...props} />);
    expect(wrapper).toMatchSnapshot();
  });
});
