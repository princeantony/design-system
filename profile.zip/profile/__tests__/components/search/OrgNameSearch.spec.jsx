import React from 'react';
import { shallow } from 'enzyme';
import mockFetch from 'jest-fetch-mock';
import sinon from 'sinon';
import OrgNameSearch from '../../../src/components/search/OrgNameSearch';

jest.mock('node-fetch', () => mockFetch);

describe('OrgNameSearch', () => {
  let wrapper;
  let DEFAULT_PROPS;
  const noop = () => null;
  const context = {
    intl: {
      messages: {
        'mainsearch.organization.placeholder': 'Org Name/ID',
        links: {
          organizations: '',
        },
      },
    },
  };

  beforeEach(() => {
    DEFAULT_PROPS = {
      searchQueryObj: {},
      selectOrganization: noop,
      organizationData: noop,
      orgValueByInstitution: '',
    };
    fetch.resetMocks();
  });

  it('Should load correctly', () => {
    fetch.mockResponse(
      JSON.stringify({
        success: true,
        errors: [],
        data: {
          organizations: [{ org: 123 }, { org: 456 }],
        },
      }),
      { status: 200 }
    );

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    expect(wrapper).toMatchSnapshot();
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    const unloadedContext = {
      context: { intl: {} },
    };

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, unloadedContext);
    expect(wrapper.get(0)).toBe(null);
  });

  it('should handle organizations fetch error', async () => {
    fetch.mockResponse(new Error('FETCH ERROR'));

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().orgSearchResults).toEqual([]);
  });

  it('should handle fetch organizations error again', async () => {
    fetch.mockResponse(new Error('FETCH ERROR'));
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().orgSearchResults).toEqual([]);
  });

  it('orgChanged- when user types a value the details should be fetched', () => {
    DEFAULT_PROPS = {
      searchQueryObj: {
        countryName: '',
        orgIdOrName: '',
        region: '',
        institutionID: '',
        orgIdAndName: '',
      },
    };

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().orgValue).toEqual('');
    wrapper.find('#orgNameSearch').simulate('change', {
      target: { value: 'newValue' },
    });
    expect(wrapper.state().orgValue).not.toEqual('');
  });

  it('orgChanged- when user clears org field', () => {
    DEFAULT_PROPS = {
      searchQueryObj: {
        countryName: '',
        orgIdOrName: '',
        region: '',
        institutionID: '',
        orgIdAndName: '',
      },
    };

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.find('#orgNameSearch').simulate('change', '');
    expect(wrapper.state().orgValue).toEqual('');
  });

  it('selectOrg  - when an organization is selected, update states and clear suggestions', async () => {
    DEFAULT_PROPS = {
      searchQueryObj: {
        countryName: '',
        orgIdOrName: '',
        region: '',
        institutionID: '',
        orgIdAndName: '',
      },
    };

    fetch.mockResponse(
      JSON.stringify({
        success: true,
        errors: [],
        data: {
          results: [
            {
              organization_identifier: '001',
              organization_name: { legal_name: 'Amorganization' },
              address: { country_code: '123', region_area_code: '123' },
            },
          ],
        },
      }),
      { status: 200 }
    );

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const orgSearchResults = [
      {
        id: '1',
        orgName: 'AE - USA',
      },
    ];

    wrapper.setState({ orgSearchResults });
    expect(orgSearchResults).not.toEqual([]);
    expect(wrapper.state().orgSearchResults).not.toEqual([]);

    const orgSelectedDetails = wrapper
      .state()
      .orgSearchResults.find(org => org.id.concat(' - ').concat(org.orgName) === '1 - AE - USA');
    wrapper.find('#orgNameSearch').simulate('click', {
      target: { text: '1 - AE - USA' },
    });
    expect(orgSelectedDetails.id).toEqual('1');
    expect(orgSelectedDetails.orgName).toEqual('AE - USA');
    expect(wrapper.state().orgValue).not.toEqual('');
    expect(wrapper.state().orgSearchResults).toEqual([]);
  });

  it('handleOnfocus- to fetch the data when the autocomplete field gets focus', () => {
    const orglist = [
      {
        id: '1',
        orgName: 'AE - USA',
      },
    ];
    // setup the fetch mock
    fetch.mockResponse(
      JSON.stringify({
        success: true,
        errors: [],
        data: {
          organizations: [
            {
              countryName: 'Brazil',
              orgIdOrName: 'bradesco',
              region: 'LAC',
              institutionID: '10000000002',
              orgIdAndName: '1 - AE - USA',
            },
          ],
        },
      }),
      { status: 200 }
    );
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    expect(wrapper.state().orgSearchResults).toEqual([]);
    wrapper.find('#orgNameSearch').simulate('focus');
    wrapper.setState({ orgCompleteList: orglist, isSearching: false });
    expect(wrapper.state().orgCompleteList).toEqual(orglist);
    expect(wrapper.state().isSearching).toEqual(false);
  });

  it('handleOnfocus- 500 status', () => {
    // setup the fetch mock
    fetch.mockResponse(
      JSON.stringify({
        json: () => ({
          message: 'Server error',
          status: 500,
        }),
      })
    );
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.find('#orgNameSearch').simulate('focus');
    expect(wrapper.state().orgCompleteList).toEqual([]);
    expect(wrapper.state().orgCompleteList).toEqual([]);
    expect(wrapper.state().isSearching).toEqual(false);
  });

  it('onOrgBlur  - onBlur , Clear off suggestions list', async () => {
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const list = [];
    list.push('listValue');

    wrapper.state().orgSearchResults = list;
    expect(wrapper.state().orgSearchResults).not.toEqual([]);

    wrapper.find('#orgNameSearch').simulate('blur', {
      target: { value: 'newValue' },
    });
    expect(wrapper.state().orgSearchResults).toEqual([]);
  });

  it('change organization with value', () => {
    let orgName = '123';
    const region = 'reg123';
    const instance = new OrgNameSearch();
    const spy = sinon.stub(instance, 'componentWillReceiveProps');
    DEFAULT_PROPS.searchQueryObj = { countryName: '111', region: 'reg123' };
    const component = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    orgName = '456';
    component.setProps({ orgName, region });
    expect(spy.calledOnce === true);
  });

  it('change organization with value #2', () => {
    const instance = new OrgNameSearch();
    const spy = sinon.stub(instance, 'componentWillReceiveProps');
    DEFAULT_PROPS.searchQueryObj = { countryName: '111', region: 'reg123' };
    const component = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const orgName = '456';
    component.setProps({ orgName, region: 'reg123' });
    expect(spy.calledOnce === true);
  });

  it('change organization with value #4', () => {
    const func = jest.fn();

    DEFAULT_PROPS = {
      searchQueryObj: { countryName: '123', region: 'test456' },
      selectOrganization: func,
      orgValueByInstitution: 'foo',
    };

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().componentWillReceiveProps = jest.fn();

    expect(wrapper.instance().componentWillReceiveProps).not.toHaveBeenCalled();

    wrapper.setProps({ countryName: 'bar' });
    wrapper.setProps({ region: 'reg123' });
    expect(wrapper.instance().componentWillReceiveProps).toHaveBeenCalledTimes(2);
  });

  it('should update country and region on receiving new props', () => {
    DEFAULT_PROPS.searchQueryObj = { countryName: '123', region: 'test456' };
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().updateRegionCountryID({ region: '', countryName: '123' });
    expect(wrapper.state().selectedRegionId).toBe('');
  });

  it('filter organization drop down list based on country', () => {
    DEFAULT_PROPS = {
      searchQueryObj: { countryName: '', region: '' },
    };
    const cId = '123';
    const rId = '';
    const orgRes = [
      {
        organization_identifier: '001',
        organization_name: { legal_name: 'Amorganization' },
        address: { country_code: '123', region_area_code: '' },
      },
    ];
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const result = wrapper.instance().filterOrgListFunc(orgRes, cId, rId);
    expect(result).toEqual(orgRes);
  });

  it('filter organization drop down list based on region', () => {
    DEFAULT_PROPS = {
      searchQueryObj: { countryName: '', region: '' },
    };
    const cId = '';
    const rId = '123';
    const orgRes = [
      {
        organization_identifier: '001',
        organization_name: { legal_name: 'Amorganization' },
        address: { country_code: '', region_area_code: '123' },
      },
    ];
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const result = wrapper.instance().filterOrgListFunc(orgRes, cId, rId);
    expect(result).toEqual(orgRes);
  });

  it('filter organization drop down list based on region and country', () => {
    DEFAULT_PROPS = {
      searchQueryObj: { countryName: '', region: '' },
    };
    const cId = '123';
    const rId = '123';
    const orgRes = [
      {
        organization_identifier: '001',
        organization_name: { legal_name: 'Amorganization' },
        address: { country_code: '123', region_area_code: '123' },
      },
    ];
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const result = wrapper.instance().filterOrgListFunc(orgRes, cId, rId);
    expect(result).toEqual(orgRes);
  });

  it('filter organization drop down list when no country and region available are selected', () => {
    DEFAULT_PROPS = {
      searchQueryObj: { countryName: '', region: '' },
    };
    const cId = '';
    const rId = '';
    const orgRes = [
      {
        organization_identifier: '001',
        organization_name: { legal_name: 'Amorganization' },
        address: { country_code: '123', region_area_code: '123' },
      },
    ];
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const result = wrapper.instance().filterOrgListFunc(orgRes, cId, rId);
    expect(result).toEqual(orgRes);
  });

  it('filter organization drop down list when there is no address object', () => {
    DEFAULT_PROPS = {
      searchQueryObj: { countryName: '', region: '' },
    };
    const cId = '123';
    const rId = '';
    const orgRes = [
      {
        organization_identifier: '001',
        organization_name: { legal_name: 'Amorganization' },
      },
    ];
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    const result = wrapper.instance().filterOrgListFunc(orgRes, cId, rId);
    expect(result).toEqual([]);
  });

  it('getAutoCompleteData- filter the organization list on change', () => {
    const value = '004';
    const orgCompleteList = [
      {
        id: '123',
        orgName: 'org1',
      },
      {
        id: '004',
        orgName: 'org2',
      },
    ];
    const searchRes = [
      {
        id: '004',
        orgName: 'org2',
      },
    ];

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().getAutoCompleteData(value, orgCompleteList);
    expect(wrapper.state('orgSearchResults')).toEqual(searchRes);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('getAutoCompleteData- filter the organization list on change, when value param is empty string', () => {
    const value = '';
    const orgCompleteList = [
      {
        id: '123',
        orgName: 'org1',
      },
      {
        id: '004',
        orgName: 'org2',
      },
    ];
    const searchRes = [{ id: '123', orgName: 'org1' }, { id: '004', orgName: 'org2' }];

    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().getAutoCompleteData(value, orgCompleteList);
    expect(wrapper.state('orgSearchResults')).toEqual(searchRes);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('handleOrganizationSuccess - success', () => {
    const organizations = {
      result: [
        {
          organization_identifier: '001',
          organization_name: { legal_name: 'Amorganization' },
          address: { country_code: '123', region_area_code: '123' },
        },
      ],
    };
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().filterOrgListFunc = jest.fn(() => organizations.result);
    wrapper.instance().handleOrganizationSuccess(200, organizations);
    expect(wrapper.instance().filterOrgListFunc).toHaveBeenCalled();
    expect(wrapper.state('orgCompleteList')).toEqual([{ id: '001', orgName: 'AMORGANIZATION' }]);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('handleOrganizationSuccess - empty org array', () => {
    const organizations = {
      result: [],
    };
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().filterOrgListFunc = jest.fn(() => organizations.result);
    wrapper.instance().handleOrganizationSuccess(200, organizations);
    expect(wrapper.instance().filterOrgListFunc).toHaveBeenCalled();
    expect(wrapper.state('orgCompleteList')).toEqual(['']);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('handleOrganizationSuccess - error code', () => {
    const organizations = {
      result: [],
    };
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().filterOrgListFunc = jest.fn(() => organizations.result);
    wrapper.instance().handleOrganizationSuccess(201, organizations);
    expect(wrapper.instance().filterOrgListFunc).toHaveBeenCalledTimes(0);
  });

  it('handleOrganizationByIdSuccess - success ', () => {
    DEFAULT_PROPS.organizationData = jest.fn();
    const organizations = {
      result: [
        {
          organization_identifier: '001',
          organization_name: { legal_name: 'Amorganization' },
          address: { country_code: '123', region_area_code: '123' },
        },
      ],
    };
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleOrganizationByIdSuccess(200, organizations.result);
    expect(DEFAULT_PROPS.organizationData).toHaveBeenCalled();
  });

  it('handleOrganizationByIdSuccess - empty org list', () => {
    DEFAULT_PROPS.organizationData = jest.fn();
    const organizations = {
      result: [],
    };
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleOrganizationByIdSuccess(201, organizations.result);
    expect(DEFAULT_PROPS.organizationData).toHaveBeenCalledTimes(1);
  });

  it('handleOrganizationByIdError - server error', () => {
    DEFAULT_PROPS.organizationData = jest.fn();
    wrapper = shallow(<OrgNameSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleOrganizationByIdError();
    expect(DEFAULT_PROPS.organizationData).toHaveBeenCalledTimes(1);
  });
});
