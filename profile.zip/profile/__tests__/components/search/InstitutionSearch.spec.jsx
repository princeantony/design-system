import React from 'react';
import { shallow } from 'enzyme';
import mockFetch from 'jest-fetch-mock';
import InstitutionSearch from '../../../src/components/search/InstitutionSearch';

jest.mock('node-fetch', () => mockFetch);

describe('Institution Search Component Test', () => {
  let context;
  let DEFAULT_PROPS;
  const noop = () => null;
  beforeEach(() => {
    DEFAULT_PROPS = {
      searchQueryObj: {
        countryName: '',
        orgId: '',
        region: '',
        institutionID: '',
        orgIdAndName: '',
        roleTypeCode: '',
      },
      selectInstitution: noop,
      institutionData: noop,
    };
    context = {
      intl: {
        messages: {
          'mainsearch.institution.id': 'institutionSearch',
          'mainsearch.institution.placeholder': 'Institution ID',
          links: {
            institutions: 'http://dummyurl.com',
          },
        },
      },
    };
  });
  const institutionData = {
    status: { code: 0, message: 'institution retrieved successfully' },
    institution: {
      institution_name: 'AE - USA                              ',
      client_role_type: {
        client_role_type_code: 'AC',
        client_role_type_description: 'Acquirer',
      },
      deal_construct_code: 'PROL',
      product_code: '    ',
      pan_minimum_length_number: 13,
      pan_maximum_length_number: 19,
      client_institution_relationship: [
        {
          institution_identifier: '11000000002',
          institution_name: 'AE - USA                              ',
          client_role_type_code: 'AP',
          client_institution_relationship_type_code: 'PC',
          organization_identifier: 1,
          organization_name: 'AE - USA                              ',
        },
        {
          institution_identifier: '11500000001',
          institution_name: 'AE - USA                              ',
          client_role_type_code: 'AT',
          client_institution_relationship_type_code: 'PC',
          organization_identifier: 1,
          organization_name: 'AE - USA                              ',
        },
      ],
      domicile_country: {
        client_domicile_country_iso_alpha_code: 'UNITED STATES OF AMERICA (THE)',
        client_domicile_country_iso_numeric_code: 840,
        client_domicile_country_name: 'USA       ',
      },
      geo_region: {
        geographic_region_identifier: '1',
        geographic_region_name: 'North America',
      },
      payment_category: {
        payment_category_code: 'N/A',
        payment_category_description: null,
      },
      institution_category: {
        institution_category_code: '01',
        institution_category_description: 'Non-DPAN',
      },
      organization: {
        organization_doing_business_as_name: '',
        organization_identifier: 1,
      },
      institution_identifier: '10000000002',
    },
  };

  const mockApiSuccessResponse = () =>
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        status: 200,
        json: () => institutionData,
      })
    );

  const mockApiErrorResponse = () =>
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        status: 500,
      })
    );

  const mockApiEmptyResponse = () =>
    jest.fn().mockImplementation(() =>
      Promise.resolve({
        status: 200,
        json: () => [],
      })
    );

  it('should not display text of lang pack if intl.messages is not loaded from context', () => {
    context.intl = {};
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    expect(wrapper.get(0)).toBe(null);
  });

  it('institutionFocus orgid is not available', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleOnfocus();
  });

  it('institutionFocus orgid is not undefined', () => {
    delete DEFAULT_PROPS.searchQueryObj.orgId;
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleOnfocus();
  });

  it('institutionFocus', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '263';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleOnfocus();
    expect(wrapper.state('isSearching')).toEqual(true);
  });

  it('institutionFocus with roletypecode', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '263';
    DEFAULT_PROPS.searchQueryObj.roleTypeCode = 'AC';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setProps(DEFAULT_PROPS);

    global.fetch = mockApiSuccessResponse();

    const apiResponse = [...institutionData.institution];
    wrapper.instance().handleOnfocus();
    expect(wrapper.state('institutionSearchResults')).toEqual(apiResponse);
  });

  it('institutionFocus with roletypecode and empty org id', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '';
    DEFAULT_PROPS.searchQueryObj.roleTypeCode = 'AC';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setProps(DEFAULT_PROPS);

    global.fetch = mockApiSuccessResponse();

    const apiResponse = [...institutionData.institution];
    wrapper.instance().handleOnfocus();
    expect(wrapper.state('institutionSearchResults')).toEqual(apiResponse);
  });

  it('institutionFocus error response', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '263';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    global.fetch = mockApiErrorResponse();
    wrapper.instance().handleOnfocus();
    expect(wrapper.state('isSearching')).toEqual(true);
  });

  it('institutionFocus empty response', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '263';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    global.fetch = mockApiEmptyResponse();
    wrapper.instance().handleOnfocus();
    expect(wrapper.state('institutionSearchResults')).toEqual([]);
    expect(wrapper.state('isSearching')).toEqual(true);
  });

  it('institutionChange', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    global.fetch = mockApiSuccessResponse();
    wrapper.find('SearchInput').simulate('change', '10000000002');
  });

  it('institutionChanged to empty with valid orgid', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '263';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    global.fetch = mockApiSuccessResponse();
    wrapper.find('SearchInput').simulate('change', '');
  });

  it('institutionChangeWithOrgID', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '263';
    const completeInstitutionList = [institutionData.institution];
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ completeInstitutionList });
    global.fetch = mockApiSuccessResponse();
    wrapper.find('SearchInput').simulate('change', '10000000002');
  });

  it('institutionChange - should set state to loading and call api to fetch search result', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    global.fetch = mockApiSuccessResponse();
    wrapper.find('SearchInput').simulate('change', '');
    expect(wrapper.state('institutionSearchResults')).toEqual([]);
  });

  it('institutionClick', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });

    global.fetch = mockApiSuccessResponse();
    const institutionSearchResults = [institutionData.institution];
    wrapper.setState({ institutionSearchResults });
    wrapper.find('SearchInput').simulate('click', {
      target: { text: '10000000002' },
    });
    expect(wrapper.state('institutionValue')).toEqual('10000000002');
  });

  it('institutionClick for wrong input', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });

    global.fetch = mockApiErrorResponse();
    const institutionSearchResults = [institutionData.institution];
    wrapper.setState({ institutionSearchResults });
    wrapper.find('SearchInput').simulate('click', {
      target: { text: '1000000000' },
    });
    expect(wrapper.state('institutionValue')).toEqual('1000000000');
  });

  it('institutionChanged - empty inst val', () => {
    const newValue = '';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().institutionChanged('');
    expect(wrapper.state('institutionValue')).toEqual(newValue);
    expect(wrapper.state('isSearching')).toEqual(true);
    expect(wrapper.state('institutionSearchResults')).toEqual([]);
  });

  it('institutionChanged value with invalid id and orgid is available', () => {
    const newValue = '1000000000';
    DEFAULT_PROPS.searchQueryObj.orgId = '1';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().institutionChanged(newValue);
    expect(wrapper.state('isSearching')).toEqual(false);
    expect(wrapper.state('institutionSearchResults')).toEqual([]);
  });

  it('institutionChanged value with  id length is 11 and orgid is not available', () => {
    const completeInstitutionList = [institutionData.institution];
    DEFAULT_PROPS.searchQueryObj.orgId = undefined;
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ completeInstitutionList });
    wrapper.instance().institutionChanged('11111111111');
    expect(wrapper.state('isSearching')).toEqual(true);
  });

  it('institutionChanged value with  id length is less than 11 and orgid is not available', () => {
    const completeInstitutionList = [institutionData.institution];
    DEFAULT_PROPS.searchQueryObj.orgId = undefined;
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ completeInstitutionList });
    wrapper.instance().institutionChanged('1111111111');
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('institutionChanged value with valid org id ', () => {
    const completeInstitutionList = [institutionData.institution];
    DEFAULT_PROPS.searchQueryObj.orgId = '1';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ completeInstitutionList });
    wrapper.instance().institutionChanged(DEFAULT_PROPS.searchQueryObj.orgId);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('institutionChanged value with invalid institution id and org id ', () => {
    const completeInstitutionList = [institutionData.institution];
    DEFAULT_PROPS.searchQueryObj.orgId = undefined;
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ completeInstitutionList });
    wrapper.instance().institutionChanged('111');
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('institutionChanged value with empty institution id and org id ', () => {
    const completeInstitutionList = [institutionData.institution];
    DEFAULT_PROPS.searchQueryObj.orgId = undefined;
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ completeInstitutionList });
    wrapper.instance().institutionChanged('');
    expect(wrapper.state('isSearching')).toEqual(true);
  });

  it('institutionChanged value with empty response', () => {
    DEFAULT_PROPS.searchQueryObj.orgId = '';
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.find('SearchInput').simulate('focus');
    expect(wrapper.state('institutionSearchResults')).toEqual([]);
  });

  it('institutionChanged value with institution id', () => {
    const completeInstitutionList = { institution: [{ institution_identifier: '123' }] };
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleInstitutionByInstIDSuccess(200, completeInstitutionList);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('institutionChanged value without institution id', () => {
    const completeInstitutionList = { institution: [{ institution_identifier: undefined }] };
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleInstitutionByInstIDSuccess(200, completeInstitutionList);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('handleInstitutionByInstIDSuccess call ', () => {
    const completeInstitutionList = { institution: { institution_identifier: undefined } };
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleInstitutionByInstIDSuccess(400, completeInstitutionList);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('should call handleInstitutionSuccess with in-valid statusCode ', () => {
    const completeInstitutionList = { institution: { institution_identifier: undefined } };
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleInstitutionSuccess(400, completeInstitutionList);
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('should call handleInstitutionSuccess', () => {
    const completeInstitutionList = [institutionData.institution];
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().filterInstitutionListFunc = jest.fn(() => [1, 2]);
    wrapper.instance().handleInstitutionSuccess(200, completeInstitutionList);
    expect(wrapper.state().completeInstitutionList).toEqual([1, 2]);
  });

  it('should call handleInstitutionSuccess when institution list is empty after applying filter', () => {
    const completeInstitutionList = [institutionData.institution];
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().filterInstitutionListFunc = jest.fn(() => []);
    wrapper.instance().handleInstitutionSuccess(200, completeInstitutionList);
    expect(wrapper.state().institutionSearchResults).toEqual(['']);
  });

  it('should call handleInstitutionSuccess when institution list is empty', () => {
    const completeInstitutionList = [];
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().filterInstitutionListFunc = jest.fn(() => []);
    wrapper.instance().handleInstitutionSuccess(200, completeInstitutionList);
    expect(wrapper.state().institutionSearchResults).toEqual(['']);
  });

  it('should call handleInstitutionFailure', () => {
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleInstitutionFailure();
    expect(wrapper.state('isSearching')).toEqual(false);
  });

  it('should call oninstitutionblur', () => {
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().onInstitutionBlur();
    wrapper.find('SearchInput').simulate('blur');
    expect(wrapper.state('institutionSearchResults')).toEqual([]);
  });

  it('should call handleInstitutionByInstIDFailure', () => {
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().handleInstitutionByInstIDFailure();
    expect(wrapper.state('institutionSearchResults')).toEqual(['']);
  });

  it('should call filterInstitutionListFunc with wrong roleTypeCode', () => {
    const completeInstitutionList = [institutionData.institution];
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    const filteredList = wrapper
      .instance()
      .filterInstitutionListFunc(completeInstitutionList, 'AB');
    expect(filteredList.length).toBe(0);
  });

  it('should call filterInstitutionListFunc without roleTypeCode', () => {
    const completeInstitutionList = [institutionData.institution];
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    const filteredList = wrapper
      .instance()
      .filterInstitutionListFunc(completeInstitutionList, null);
    expect(filteredList.length).toBe(1);
  });

  it('call clear', () => {
    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.instance().clear();
    expect(wrapper.state('institutionSearchResults')).toEqual([]);
  });

  it('selectInstitution - success ', () => {
    DEFAULT_PROPS.institutionData = jest.fn();
    const institutionSearchResults = [institutionData.institution];

    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ institutionSearchResults });
    wrapper.instance().selectInstitution({ target: { text: '10000000002' } });
    expect(DEFAULT_PROPS.institutionData).toHaveBeenCalled();
  });

  it('selectInstitution - empty institution array ', () => {
    DEFAULT_PROPS.institutionData = jest.fn();
    const institutionSearchResults = [institutionData.institution];

    const wrapper = shallow(<InstitutionSearch {...DEFAULT_PROPS} />, { context });
    wrapper.setState({ institutionSearchResults });
    wrapper.instance().selectInstitution({ target: { text: '1000000000' } });
    expect(DEFAULT_PROPS.institutionData).toHaveBeenCalled();
  });
});
