import { formatDate } from '../../../src/components/utils/utilityFunctions';

describe('Utility Functions Test', () => {
  it('should return date in mm/dd/yyyy format when date is sent as yyyy/mm/dd', () => {
    const startDate = '2012/1/1';
    expect(formatDate(startDate)).toEqual('01/01/2012');
  });

  it('should return date in mm/dd/yyyy format', () => {
    const startDate = '2012/11/11';
    expect(formatDate(startDate)).toEqual('11/11/2012');
  });

  it('should return null', () => {
    const startDate = null;
    expect(formatDate(startDate)).toEqual(null);
  });

  it('should return blank', () => {
    const startDate = '';
    expect(formatDate(startDate)).toEqual('');
  });
});
