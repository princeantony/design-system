import { getResource, queryResource } from 'iguazu-rest';
import { queryProfilesOnloadData, massageProfilesOnloadData } from '../../../src/components/query/country';

jest.mock('iguazu-rest', () => ({
  getResource: jest.fn(),
  queryResource: jest.fn(),
}));

describe('Profiles Api Query', () => {
  it('massageProfilesOnloadData - should map api response data to dropdown options', () => {
    const apiData = {
      countries: [{
        id: '004',
        name: 'AFGHANISTAN - 004',
      }],
      region: [{
        id: '0742',
        name: '0742 - VETERINARY SERVICE',
      }],
    };

    const massagedData = {
      countries: [{ value: 'Select', label: 'Select' },
        { value: '004', label: 'AFGHANISTAN - 004' }],
      region: [{ value: 'Select', label: 'Select' },
        { value: '0742' }],
    };

    const result = massageProfilesOnloadData(apiData);
    expect(result).toEqual(massagedData);
  });

  it('queryProfilesOnloadData - should return data, completed status and resolved promise if data already present', () => {
    const testData = { test: 'value' };
    getResource.mockImplementation(() => () => testData);

    const result = queryProfilesOnloadData()(jest.fn(), jest.fn());

    expect(result.data).toEqual(testData);
    expect(result.status).toEqual('complete');
    expect(result.promise).toEqual(Promise.resolve);
  });

  it('queryProfilesOnloadData - should call api to fetch data if data is not there already', () => {
    getResource.mockImplementation(() => () => null);

    const dispatchPromise = Promise.resolve('test data');
    const mockDispatch = jest.fn().mockImplementation(() => dispatchPromise);

    const result = queryProfilesOnloadData()(mockDispatch, jest.fn());

    expect(result.data).toEqual({});
    expect(result.status).toEqual('loading');
    expect(result.promise).toEqual(dispatchPromise);
    expect(mockDispatch).toHaveBeenCalled();
    expect(queryResource).toHaveBeenCalled();
  });
});
