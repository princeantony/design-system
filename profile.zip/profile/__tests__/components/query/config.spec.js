import { profilesOnLoadData } from '../../../src/components/query/config';
import { massageProfilesOnloadData } from '../../../src/components/query/country';

jest.mock('../../../src/components/query/country', () => ({
  massageProfilesOnloadData: jest.fn(),
}));

describe('Api Query Config', () => {
  it('profilesOnLoadData - fetch should returne correct url', () => {
    const urlObj = profilesOnLoadData.fetch();

    expect(urlObj.url).toEqual('https://networkutil-dev.aexp.com/:id');
  });

  it('profilesOnLoadData - transform data should call correct method', () => {
    const testData = { test: 'value' };
    profilesOnLoadData.transformData(testData);

    expect(massageProfilesOnloadData).toHaveBeenCalledWith(testData);
  });
});

