import getUrl from '../../../src/components/query/env';

describe('Profiles Api Query', () => {
  it('getUrl - should return e1 url if node env is E1', () => {
    process.env.NODE_ENV = 'E1';
    expect(getUrl('networkUtilPrefix')).toEqual('https://networkutil-dev.aexp.com');
  });

  it('getUrl - should return e2 url if node env is E2', () => {
    process.env.NODE_ENV = 'E2';
    expect(getUrl('networkUtilPrefix')).toEqual('https://networkutil-dev.aexp.com');
  });

  it('getUrl - should return e3 url if node env is E3', () => {
    process.env.NODE_ENV = 'E3';
    expect(getUrl('networkUtilPrefix')).toEqual('https://networkutil-dev.aexp.com');
  });

  it('getUrl - should return e1 url if node env is not E1, E2, or E3 (local dev)', () => {
    process.env.NODE_ENV = 'development';
    expect(getUrl('networkUtilPrefix')).toEqual('https://networkutil-dev.aexp.com');
  });

  it('getUrl - should return parrot mock end point if for browser testing', () => {
    delete window.location;

    Object.defineProperty(window, 'location', {
      value: {
        href: 'http://app:3000',
      },
    });

    expect(getUrl('networkUtilPrefix')).toEqual('http://app:3002');
  });
});
