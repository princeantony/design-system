import load from '../../src//components/duck';

describe('load', () => {
  it('should call dispatch once', () => {
    const dispatch = jest.fn(() => Promise.resolve(true));
    return load()(dispatch).then(() => {
      expect(dispatch).toHaveBeenCalledTimes(1);
    });
  });

  it('should dispatch composeModules', () => {
    const dispatch = jest.fn(() => Promise.resolve(true));
    return load()(dispatch).then(() => {
      expect(dispatch.mock.calls[0].length).toBe(1);
      expect(dispatch.mock.calls[0][0]).toEqual({
        type: 'COMPOSE_MODULES',
        modules: ['axp-site-area-nav-container'],
      });
    });
  });
});
