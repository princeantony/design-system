import React from 'react';
import { mount } from 'enzyme';
import AppIcon from '../../../src/components/common/AppIcon';

describe('AppIcon Component Test', () => {
  let DEFAULT_PROPS;
  beforeEach(() => {
    DEFAULT_PROPS = {
      classes: 'dls-icon-thumbs-up',
      iconName: 'capabilities.enrolled',
    };
  });
  it('should test AppIcon ', () => {
    const renderedModule = mount(<AppIcon {...DEFAULT_PROPS} />);
    expect(renderedModule.children().find('Enrolled').length).toEqual(0);
  });
});
