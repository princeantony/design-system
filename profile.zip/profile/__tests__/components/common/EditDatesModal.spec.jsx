import React from 'react';
import { shallow } from 'enzyme';
import EditDatesModal from '../../../src/components/common/EditDatesModal';

describe('AXP EditDatesModal Component Test', () => {
  const context = {
    intl: {
      messages: {
        'editDates.title': 'Edit Selected Dates',
        'editDate.submitChange': 'Submit Changes',
        'editDate.newStartDate': 'New Start Date',
        'editDate.newEndDate': 'New End Date',
      },
    },
  };

  let DEFAULT_PROPS;

  beforeEach(() => {
    DEFAULT_PROPS = {
      isEditDatesModalVisible: true,
      toggleModal: jest.fn(),
      handleStartDate: jest.fn(),
      handleEndDate: jest.fn(),
    };
  });

  it('should not be able to display text from lang pack if intl.messages is not loaded from context', () => {
    const unloadedContext = {
      context: { intl: {} },
    };
    const wrapper = shallow(<EditDatesModal {...DEFAULT_PROPS} />, unloadedContext);
    expect(wrapper.get(0)).toBe(null);
  });

  it('should show modal on receiving props ', () => {
    const wrapper = shallow(<EditDatesModal {...DEFAULT_PROPS} />, { context });
    expect(wrapper.props().shown).toEqual(true);
  });

  it('should not display modal on receiving props ', () => {
    DEFAULT_PROPS.isEditDatesModalVisible = false;
    const wrapper = shallow(<EditDatesModal {...DEFAULT_PROPS} />, { context });
    expect(wrapper.props().shown).toEqual(false);
  });
});
