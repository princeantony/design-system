import React from 'react';
import { shallow, mount } from 'enzyme';
import Table, { Row, Column } from '../../../src/components/common/Table';

describe('AXP Table Component Test', () => {
  let DEFAULT_PROPS;
  let ROW_DEFAULT_PROPS;
  let ROW_COL_DEFAULT_PROPS;
  let COL_DEFAULT_PROPS;
  beforeEach(() => {
    DEFAULT_PROPS = {
      selectable: true,
      selectionHandler: jest.fn(),
      data: {
        header: [
          { value: 'Org DBA Name', name: 'orgDbaName' },
          { value: 'Start Date', name: 'startDate' },
          { value: 'End Date', name: 'endDate' },
        ],
        body: [
          { orgDbaName: 'WELLS FARGO', startDate: '2018/11/10', endDate: '9999/12/31' },
          { orgDbaName: 'WELLS FARGO', startDate: '2018/11/10', endDate: '9999/12/31' },
        ],
      },
      tableClass: 'data-table',
    };

    ROW_DEFAULT_PROPS = {
      rowType: 'header',
      columns: [{ value: 'Org DBA Name', name: 'orgDbaName' }],
    };

    ROW_COL_DEFAULT_PROPS = {
      rowType: 'body',
      columns: { value: 'Org DBA Name', name: 'orgDbaName' },
    };

    COL_DEFAULT_PROPS = {
      rowType: 'column',
      column: 'Org DBA Name',
    };
  });

  it('should initialize table state based on props (additional column ) ', () => {
    const wrapper = shallow(<Table {...DEFAULT_PROPS} />);
    expect(wrapper.state().header.length).toBe(4);
  });

  it('selectAllHandler - selectionHandler should have been called', () => {
    const wrapper = shallow(<Table {...DEFAULT_PROPS} />);
    wrapper.instance().selectAllHandler();
    expect(DEFAULT_PROPS.selectionHandler).toHaveBeenCalled();
  });

  it('toggleRow - show select the row with the specified index and set select all when all rows are selected', () => {
    const rows = [
      {
        orgDbaName: 'WELLS FARGO',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: false,
      },
      {
        orgDbaName: 'WELLS FARGO',
        startDate: '2018/11/10',
        endDate: '9999/12/31',
        selected: true,
      },
    ];
    DEFAULT_PROPS.data.body = rows;
    const wrapper = mount(<Table {...DEFAULT_PROPS} />);
    wrapper.instance().toggleRow(0);
    expect(wrapper.state().isSelectAll).toBe(true);
  });

  it('should not add checkbox when selectable is set to false', () => {
    DEFAULT_PROPS.selectable = false;
    const wrapper = mount(<Table {...DEFAULT_PROPS} />);
    expect(wrapper.find('select').exists()).toBeFalsy();
  });

  it('should enable select all only when all the rows are selected', () => {
    const wrapper = mount(<Table {...DEFAULT_PROPS} />);
    wrapper.find('Checkbox#select-0').simulate('change');
    wrapper.find('Checkbox#select-1').simulate('change');
    expect(wrapper.state().isSelectAll).toBeFalsy();
  });

  it('Row - should render table header from Column component', () => {
    const wrapper = mount(<Row {...ROW_DEFAULT_PROPS} />);
    expect(wrapper.find('tr').exists()).toBe(true);
  });

  it('Row - COL should render table header from Column component', () => {
    const wrapper = mount(<Row {...ROW_COL_DEFAULT_PROPS} />);
    expect(wrapper.find('tr').exists()).toBe(true);
  });

  it('Column - should render table data from Column component based on type value ', () => {
    const wrapper = mount(<Column {...COL_DEFAULT_PROPS} />);
    expect(wrapper.find('th').exists()).toBe(false);
    expect(wrapper.find('td').exists()).toBe(true);
  });
  it('Column - should render table header from Column component based on type value ', () => {
    COL_DEFAULT_PROPS.rowType = 'header';
    const wrapper = mount(<Column {...COL_DEFAULT_PROPS} />);
    expect(wrapper.find('th').exists()).toBe(true);
    expect(wrapper.find('td').exists()).toBe(false);
  });

  it('should check if table cell values are populated correctly', () => {
    const wrapper = mount(<Table {...DEFAULT_PROPS} />);

    const rows = wrapper.find('.data-table tbody tr');
    expect(rows.length).toEqual(2);

    const firstRowColumns = rows
      .first()
      .find('td')
      .map(column => column.text());
    wrapper.find('input#selectAll').simulate('change', jest.fn());
    wrapper.find('input#select-0').simulate('change', jest.fn());
    wrapper.find('input#select-1').simulate('change', jest.fn());
    expect(firstRowColumns.length).toEqual(4);
    expect(firstRowColumns[0]).toEqual('WELLS FARGO');
    expect(firstRowColumns[1]).toEqual('2018/11/10');
    expect(firstRowColumns[2]).toEqual('9999/12/31');
  });
});
