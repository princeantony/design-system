import React from 'react';
import { shallow } from 'enzyme';
import Container, { Accounting } from '../../../src/components/secondary-nav/accounting/Accounting';


describe('AXP Accounting Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Accounting', () => {
    const props = {};
    const renderedModule = shallow(<Accounting {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
