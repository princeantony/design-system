import React from 'react';
import { shallow } from 'enzyme';
import Container, { Configurations } from '../../../src/components/secondary-nav/configurations/Configurations';


describe('AXP Configurations Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Configurations', () => {
    const props = {};
    const renderedModule = shallow(<Configurations {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
