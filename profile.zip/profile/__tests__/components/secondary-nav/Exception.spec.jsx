import React from 'react';
import { shallow } from 'enzyme';
import Container, { Exception } from '../../../src/components/secondary-nav/exception/Exception';


describe('AXP Exception Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Exception', () => {
    const props = {};
    const renderedModule = shallow(<Exception {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
