import React from 'react';
import { shallow } from 'enzyme';
import Container, { NewSetup } from '../../../src/components/secondary-nav/setup/NewSetup';


describe('AXP NewSetup Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for NewSetup', () => {
    const props = {};
    const renderedModule = shallow(<NewSetup {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
