import React from 'react';
import { shallow } from 'enzyme';
import Container, { Participant } from '../../../src/components/secondary-nav/participant/Participant';


describe('AXP Participant Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Participant', () => {
    const props = {};
    const renderedModule = shallow(<Participant {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
