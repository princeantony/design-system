import React from 'react';
import { shallow } from 'enzyme';
import Container, { Financial } from '../../../src/components/secondary-nav/financial/Financial';


describe('AXP Financial Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Financial', () => {
    const props = {};
    const renderedModule = shallow(<Financial {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
