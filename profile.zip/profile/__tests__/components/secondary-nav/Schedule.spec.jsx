import React from 'react';
import { shallow } from 'enzyme';
import Container, { Schedule } from '../../../src/components/secondary-nav/schedule/Schedule';


describe('AXP Schedule Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Schedule', () => {
    const props = {};
    const renderedModule = shallow(<Schedule {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
