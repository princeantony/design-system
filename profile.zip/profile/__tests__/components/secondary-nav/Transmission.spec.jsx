import React from 'react';
import { shallow } from 'enzyme';
import Container, { Transmission } from '../../../src/components/secondary-nav/transmission/Transmission';


describe('AXP Transmission Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for Transmission', () => {
    const props = {};
    const renderedModule = shallow(<Transmission {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
