import React from 'react';
import { shallow } from 'enzyme';
import Container, { ProfileSummary, SummaryBlock } from '../../../src/components/profile/ProfileSummary';


describe('AXP ProfileSummary Component Test', () => {
  const { NODE_ENV } = process.env;

  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });

  it('matches snapshot for ProfileSummary', () => {
    const props = {};
    const renderedModule = shallow(<ProfileSummary {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('matches snapshot for SummaryBlock', () => {
    const props = {
      label: 'ORG NAME',
      text: 'TARGET',
    };
    const renderedModule = shallow(<SummaryBlock {...props} />);
    expect(renderedModule).toMatchSnapshot();
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
