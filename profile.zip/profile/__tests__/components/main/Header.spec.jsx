import React from 'react';
import { shallow } from 'enzyme';
import Container, { SecondaryNav } from '../../../src/components/main/SecondaryNav';


describe('AXP SecondaryNav Component Test', () => {
  const { NODE_ENV } = process.env;
  const myProps = {
    lang: {
      secondary_nav_links: [test],
    },
  };
  afterEach(() => {
    process.env.NODE_ENV = NODE_ENV;
  });
  function renderHeader(props) {
    return shallow(<SecondaryNav {...props} />);
  }
  it('should render the loading screen if the modules are not loaded', () => {
    // global require necessary for mocking
    // eslint-disable-next-line prefer-destructuring
    const getModule = require('holocron').getModule; // eslint-disable-line global-require
    getModule.mockImplementationOnce(() => undefined);

    const tree = renderHeader(myProps);
    expect(tree).toHaveLength(1);
  });
  it('should render the secondaryNav if the modules are loaded', () => {
    const tree = renderHeader(myProps);
    expect(tree).toHaveLength(1);
  });

  it('default export should return a function', () => {
    expect(Container).toBeInstanceOf(Function);
  });
});
