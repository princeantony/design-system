import React from 'react';
import { shallow } from 'enzyme';
import LoadingScreen from '../../../src/components/main/LoadingScreen';

describe('LoadingScreen', () => {
  it('should render the expected output', () => {
    const tree = shallow(<LoadingScreen />);
    expect(tree).toMatchSnapshot();
  });
});
