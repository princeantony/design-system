/**
 * Tests that validate your module's behavior when served up in axp-app
 * See https://one-dev.aexp.com/v2/guide/browser-test-recipes.html for more details and recipes
 */

import { toMatchImageSnapshot } from 'jest-image-snapshot';
import { getWebdriverClient } from 'one-amex-test-utils';

const APP_HOSTNAME = 'http://app:3000';
const moduleUrl = `${APP_HOSTNAME}/demo/axp-network-client-profile`;
let client;

beforeAll(() => {
  expect.extend({ toMatchImageSnapshot });
  client = getWebdriverClient();

  return client.init();
});

describe('NetworkClientProfile module', () => {
  describe('look and feel in browser', () => {
    beforeAll(async () => {
      await client
        .url(moduleUrl);
    });

    it('renders correctly on desktop sized viewport', async () => {
      const desktopView = await client
        .windowHandleSize({ width: 1366, height: 768 })
        .saveScreenshot();

      expect(desktopView).toMatchImageSnapshot();
    });

    it('renders correctly on tablet sized viewport', async () => {
      const tabletView = await client
        .windowHandleSize({ width: 1024, height: 768 })
        .saveScreenshot();

      expect(tabletView).toMatchImageSnapshot();
    });

    it('renders correctly on mobile sized viewport', async () => {
      const mobileView = await client
        .windowHandleSize({ width: 375, height: 667 })
        .saveScreenshot();

      expect(mobileView).toMatchImageSnapshot();
    });
  });
});

afterAll(() => client.end());
