import { holocronModule, RenderModule } from 'holocron';

const moduleRegistry = {
  'axp-site-area-nav-container': () => 'axp-site-area-nav-container',
};

const getModule = jest.fn(moduleName => moduleRegistry[moduleName]);

export function composeModules(modules) {
  return {
    type: 'COMPOSE_MODULES',
    modules: modules.map(module => module.name),
  };
}

export { holocronModule, RenderModule, getModule };
