const iguazuHolocron = jest.genMockFromModule('iguazu-holocron');

iguazuHolocron.queryModule = jest.fn();

export default iguazuHolocron;
