# axp-network-client-profile
[One Amex](https://one-dev.aexp.com) Holocron module for Network Client Profile module

## Pre-requisites
Must have `axp-app` cloned and installed locally as described in [axp-app's README](https://stash.aexp.com/stash/projects/ONE/repos/axp-app/browse/README.md) in order to run this module locally

## Usage
Assuming `axp-app` is cloned and installed locally:
```bash
git clone ssh://git@stash.aexp.com/AIM500000846/axp-network-client-profile.git
cd axp-network-client-profile
npm install
npm run build
cd <into-axp-app-directory>
npm run serve-module <path-to-axp-network-client-profile>
npm start
```

## Test
After cloning, installing, and building as described above unit tests, browser tests, and linting can be run as follows:
```bash
npm test
```

And if you just want to run unit tests:
```bash
npm run test:unit
```

Or if you just want to run browser tests:
```bash
npm run test:browser
```

Make sure to have [Docker](https://docs.docker.com/engine/installation/) installed for browser tests to run

## Contributing

See [One Amex contributing guidelines](https://stash.aexp.com/stash/projects/ONE/repos/axp-app/browse/CONTRIBUTING.md)