import { Component, OnInit} from '@angular/core';
import {ListPlan} from '../../../../shared/mocks/listPlan';
import {COLUMN_DEFS} from '../../../../shared/constants/app.constants';
@Component({
  selector: 'app-list-plans',
  templateUrl: './list-plans.component.html',
  styleUrls: ['./list-plans.component.css']
})
export class ListPlansComponent implements OnInit {

  constructor() { }
  rowData=ListPlan;
  columnDefs = COLUMN_DEFS.LIST_PLAN;
  ngOnInit() {
  }

}
