import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

import {ApiService} from '../../../shared/services/api.service';

export class PlanService
{
   
    constructor (
        private apiService: ApiService
      ) {}
    getListPlan()
    {

    }
}