import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  constructor(private modalService: ModalService) { }

  ngOnInit() {
  }

  openModal(id: string) {
    console.log("----------------openModal",id);
    this.modalService.open(id);
}



}
