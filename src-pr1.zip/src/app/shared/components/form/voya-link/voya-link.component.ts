import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-voya-link',
  templateUrl: './voya-link.component.html',
  styleUrls: ['./voya-link.component.css']
})
export class VoyaLinkComponent implements OnInit {
@Input() text: string;
  constructor() {
    
   }
  component = "/"; // should get it for param
  ngOnInit() {
  console.log("text", this.text)
  }

}
