import { Component, OnInit } from '@angular/core';

import * as Participant from '../../../participants/model/participant.model';
import { ParticipantsService } from '../../../participants/service/participants.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-participant-confirmation',
  templateUrl: './participant-confirmation.component.html',
  styleUrls: ['./participant-confirmation.component.scss']
})
export class ParticipantConfirmationComponent implements OnInit {
  private participantData: Participant.ParticipantData = {} as Participant.ParticipantData;

  constructor(
    private participantsService: ParticipantsService,
    private router: Router
  ) {}

  ngOnInit() {
    this.participantData = this.participantsService.getParticipantData();
  }
}
