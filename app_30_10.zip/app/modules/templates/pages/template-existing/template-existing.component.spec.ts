import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateExistingComponent } from './template-existing.component';

describe('TemplateExistingComponent', () => {
  let component: TemplateExistingComponent;
  let fixture: ComponentFixture<TemplateExistingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateExistingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateExistingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
