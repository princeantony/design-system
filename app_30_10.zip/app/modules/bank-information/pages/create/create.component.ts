import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';

import { BankStates } from '../../../../shared/config/state.config';
import { IBankInfo } from '../../../../shared/interfaces/bank.interface';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html'
})
export class CreateComponent implements OnInit {
  updateInfo: IBankInfo;
  bankStates: any;
  bankInfo: any;
  divSubs: any;
  bankNames: any;
  copyToAll = false;
  accountTypeItems: any[];
  isRoutingMatching = true;
  isAccMatching = true;
  bankInfoForm = this.fb.group({
    bankName: ['', Validators.required],
    city: ['', Validators.required],
    state: ['', Validators.required],
    zipcode: [''],
    address1: [''],
    address2: [''],
    abaNumber: ['', Validators.required],
    confirmAbaNumber: [''],
    acctNumber: ['', Validators.required],
    confirmAcctNumber: [''],
    accountType: ['', Validators.required],
    copyToAll: [false]
  });
  hidePageTitle: boolean;
  subTitle: string;
  pageHeading: string;
  planNumber: string;
  emptyBanknames: any;
  sub: any;
  divsubId = '';
  divsub: string;
  url: any;
  isCreate = false;
  selectedBank: any;
  divsubText = '';
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private modalService: ModalService
  ) {}

  get bankName() {
    return this.bankInfoForm.get('bankName');
  }
  get city() {
    return this.bankInfoForm.get('city');
  }
  get state() {
    return this.bankInfoForm.get('state');
  }
  get abaNumber() {
    return this.bankInfoForm.get('abaNumber');
  }
  get address1() {
    return this.bankInfoForm.get('address1');
  }
  get address2() {
    return this.bankInfoForm.get('address2');
  }
   get confirmAbaNumber() {
    return this.bankInfoForm.get('confirmAbaNumber');
  }

  get acctNumber() {
    return this.bankInfoForm.get('acctNumber');
  }
  get confirmAcctNumber() {
    return this.bankInfoForm.get('confirmAcctNumber');
  }
  get accountType() {
    return this.bankInfoForm.get('accountType');
  }

  openHelpModal() {
    this.modalService.open('helpModal');
  }
  validateRoutingMatch() {
    if ((this.abaNumber.value !== this.confirmAbaNumber.value) && (this.abaNumber.value && this.confirmAbaNumber.value)) {
    this.isRoutingMatching = false;
    } else {
    this.isRoutingMatching = true;
    }
  }
   validateAccountMatch() {
    if ((this.acctNumber.value !== this.confirmAcctNumber.value ) && (this.acctNumber.value && this.confirmAcctNumber.value)) {
    this.isAccMatching = false;
    } else {
    this.isAccMatching = true;
    }
  }

  ngOnInit() {
    this.hidePageTitle = false;
    this.subTitle = 'Bank Information';
    this.planNumber = PayAdminGlobalState.planNumber;

    this.bankStates = BankStates;

    this.divSubs = PayAdminGlobalState.subDiv;

    this.bankInfo = PayAdminGlobalState.bankinfo;
    this.accountTypeItems = [
      { label: 'Saving', value: 'S' },
      { label: 'Checking', value: 'C' }
    ];

    this.route.url.subscribe(value => {
      this.url = _.find(value, ['path', 'create']);
      if (this.url) {
        this.isCreate = true;
        this.pageHeading = 'You do not have any bank accounts on file. Add banking information to establish ACH Debit.';
      }
      else {
        this.pageHeading = 'Please update the existing bank information as needed.';
      }
      if(value.length === 3)
      {
        PayAdminGlobalState.previousPage = '/bankInfo';
        this.divsubId  =  value[2].path;
        PayAdminGlobalState.currentPage = value[0].path + '/' + value[1].path + '/' + value[2].path;
        this.divsub = _.filter(this.bankInfo, ['divsub', this.divsubId])[0];
        PayAdminGlobalState.divsubId = this.divsubId;
      }
      else
      {
        PayAdminGlobalState.previousPage = '/home';
      PayAdminGlobalState.currentPage = value[0].path + '/' + value[1].path;
      PayAdminGlobalState.divsubId = '';
      }


    });

      if (PayAdminGlobalState.bankDetails) {
        this.populateForm(PayAdminGlobalState.bankDetails.bankInfo);
        this.bankInfoForm.controls['copyToAll'].setValue(
          PayAdminGlobalState.bankDetails.copyToAll
        );
      } else {
        if (!this.isCreate) {
            if (this.divsubId !== ''){
            this.selectedBank = _.filter(this.bankInfo, ['divsub', this.divsubId])[0];
            } else {
              this.selectedBank = this.bankInfo[0];
            }
            this.populateForm(this.selectedBank);
        }
      }

    this.bankNames = _.filter(this.bankInfo, 'bankName');
  }
  populateForm(bankObj) {
    this.bankInfoForm.controls['bankName'].setValue(bankObj.bankName);
    this.bankInfoForm.controls['address1'].setValue(bankObj.address1);
    this.bankInfoForm.controls['address2'].setValue(bankObj.address2);
    this.bankInfoForm.controls['city'].setValue(bankObj.city);
    this.bankInfoForm.controls['state'].setValue(bankObj.state);
    this.bankInfoForm.controls['zipcode'].setValue(bankObj.zipcode);
    this.bankInfoForm.controls['acctNumber'].setValue(bankObj.acctNumber);
    this.bankInfoForm.controls['confirmAcctNumber'].setValue(bankObj.acctNumber);
    this.bankInfoForm.controls['accountType'].setValue(_.split(bankObj.accountType, ' ')[0]);
    this.bankInfoForm.controls['abaNumber'].setValue(bankObj.abaNumber);
    this.bankInfoForm.controls['confirmAbaNumber'].setValue(bankObj.abaNumber);
  }

  onSubmit() {

    this.bankInfoForm.removeControl('confirmAbaNumber');
    this.bankInfoForm.removeControl('confirmAcctNumber');
    if(!this.bankInfoForm.controls['copyToAll'])
    {

      this.copyToAll = PayAdminGlobalState.bankDetails.copyToAll;
      this.bankInfoForm.addControl('copyToAll', new FormControl(this.copyToAll));
    } else{
    this.copyToAll = this.bankInfoForm.controls['copyToAll'].value;
    this.bankInfoForm.removeControl('copyToAll');
    }
    this.updateInfo = this.bankInfoForm.value;

    PayAdminGlobalState.bankDetails = {
      bankInfo: this.updateInfo,
      copyToAll: this.copyToAll
    };
    if(this.copyToAll)
    this.modalService.open('subdivModel');
    else
    this.router.navigate(['bankInfo/confirm/']);
  }
  onSelect(event) {
    let bankInfoTemp = _.filter(this.bankNames, ["id", event.id])[0];
    this.populateForm(bankInfoTemp);
  }
  gotoBack() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
}
