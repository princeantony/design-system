import { Component } from '@angular/core';

import { CommonService } from '../app/shared/services/common.service';
import { PayAdminGlobalState } from '../app/shared/store/pay-admin-global.store';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'PayAdmin';
  date = new Date().toLocaleDateString();
  constructor(private commonService: CommonService) {}

  ngOnInit(): void {
    if (!PayAdminGlobalState.stateList) {
      this.commonService.getStateList().subscribe(result => {
        if (result.status === 'SUCCESS') {
          PayAdminGlobalState.stateList = result.data;
        }
      });
    }
    if (!PayAdminGlobalState.countryList) {
      this.commonService.getCountryList().subscribe(result => {
        if (result.status === 'SUCCESS') {
          PayAdminGlobalState.countryList = result.data;
        }
      });
    }
  }
}
