export const ParticipantAdminSettingMock = {
  status: 'SUCCESS',
  data: {
    displayQDIA: true,
    displayMorningStar: false,
    displayEnrollParticipant: true,
    enableEnrollParticipant: true,
    disableQDIA: false,
    disableMorningStar: false,
    morningStarError: false,
    displayEmail: false,
    canLoadOptionalDataElements: true,
    participantMinAge: 15,
    participantMaxAge: 90
  }
};

export const ParticipantMorningStar = {
  status: 'SUCCESS',
  data: {
    headers: ['Fund Name', 'Percentage'],
    rows: ['Voya Fixed Account', '100']
  }
};

export const ParticipantList = {
  status: 'SUCCESS',
  data: [
    {
      ssn: '608801567',
      name: 'Channa Jehu'
    },
    {
      ssn: '318955455',
      name: 'Fan Oakenfield'
    },
    {
      ssn: '749223948',
      name: 'Maxie Selkirk'
    },
    {
      ssn: '391083418',
      name: 'Kiele Myrick'
    },
    {
      ssn: '211629950',
      name: 'Delmor Acum'
    },
    {
      ssn: '653567140',
      name: 'Burlie Vedenisov'
    },
    {
      ssn: '816469282',
      name: 'Reynold Pedder'
    },
    {
      ssn: '336154052',
      name: 'Shirline Di Biasi'
    },
    {
      ssn: '863606375',
      name: 'Curtis Yakobovitz'
    },
    {
      ssn: '429548444',
      name: 'Pippa Worsnop'
    },
    {
      ssn: '781410026',
      name: 'Nixie Leuty'
    },
    {
      ssn: '673190827',
      name: 'Carita Ivchenko'
    },
    {
      ssn: '327949491',
      name: 'Niels Swabey'
    },
    {
      ssn: '814114959',
      name: 'Lola Ratke'
    },
    {
      ssn: '697664454',
      name: 'Ella Pennuzzi'
    },
    {
      ssn: '355098385',
      name: 'Davey Farady'
    },
    {
      ssn: '411171525',
      name: 'Nicko Benkhe'
    },
    {
      ssn: '339124197',
      name: 'Hinze Leggs'
    },
    {
      ssn: '154473178',
      name: 'Celia Dodshun'
    },
    {
      ssn: '384871905',
      name: 'Lorelle Garioch'
    },
    {
      ssn: '684130789',
      name: 'Jenilee Mellhuish'
    },
    {
      ssn: '838109650',
      name: 'Steffi Hallows'
    },
    {
      ssn: '555157464',
      name: 'Lorens Denniston'
    },
    {
      ssn: '271919370',
      name: 'Pearla Jocelyn'
    },
    {
      ssn: '640782211',
      name: 'Stavro Swindells'
    },
    {
      ssn: '513264482',
      name: 'Lyle Baack'
    },
    {
      ssn: '671979456',
      name: 'Benny Ventura'
    },
    {
      ssn: '655403657',
      name: 'Freddy Peckitt'
    },
    {
      ssn: '793402653',
      name: 'Peria McAless'
    },
    {
      ssn: '339809289',
      name: 'Elli Gulberg'
    },
    {
      ssn: '549334813',
      name: 'Paola Carlyon'
    },
    {
      ssn: '358848415',
      name: 'Juana Cona'
    },
    {
      ssn: '770459182',
      name: 'Mort Bolles'
    },
    {
      ssn: '253022669',
      name: 'Delmore Juggings'
    },
    {
      ssn: '481928167',
      name: 'Pauline Bowmen'
    },
    {
      ssn: '357392334',
      name: 'Anjanette Foden'
    },
    {
      ssn: '321671902',
      name: 'Tamiko Aulds'
    },
    {
      ssn: '631525310',
      name: 'Mae Harcus'
    },
    {
      ssn: '334393298',
      name: 'Bunnie Addyman'
    },
    {
      ssn: '576809482',
      name: 'Audy Scheffler'
    },
    {
      ssn: '813239233',
      name: 'Beaufort Ledgister'
    },
    {
      ssn: '639266401',
      name: 'Vernon Panting'
    },
    {
      ssn: '557741126',
      name: 'Alexander Barsby'
    },
    {
      ssn: '258368375',
      name: 'Elene Stimpson'
    },
    {
      ssn: '144673917',
      name: 'Consalve Piddletown'
    },
    {
      ssn: '426068071',
      name: 'Charissa Dufour'
    },
    {
      ssn: '107359566',
      name: 'Frederica Hawse'
    },
    {
      ssn: '842673582',
      name: 'Thorvald Rushford'
    },
    {
      ssn: '368900646',
      name: 'Vilma Seeney'
    },
    {
      ssn: '408475213',
      name: 'Milzie Hedge'
    },
    {
      ssn: '758316615',
      name: 'Chet Petasch'
    },
    {
      ssn: '251043900',
      name: 'Moyra Greenough'
    },
    {
      ssn: '616388224',
      name: 'Catarina Jorry'
    },
    {
      ssn: '797481988',
      name: 'Courtney Courtliff'
    },
    {
      ssn: '443606729',
      name: 'Ingram Sygroves'
    },
    {
      ssn: '258917729',
      name: 'Mill Simmon'
    },
    {
      ssn: '554079130',
      name: 'Pegeen Buckel'
    },
    {
      ssn: '279032290',
      name: 'Lara Pesic'
    },
    {
      ssn: '271716863',
      name: 'Hughie Bickerstasse'
    },
    {
      ssn: '569548233',
      name: 'Lutero Foulger'
    },
    {
      ssn: '423321430',
      name: 'Mareah Kuhnhardt'
    },
    {
      ssn: '696913262',
      name: 'Caesar Milverton'
    },
    {
      ssn: '441438905',
      name: 'Mollie Marielle'
    },
    {
      ssn: '128871997',
      name: 'Goldarina Spring'
    },
    {
      ssn: '244081392',
      name: 'Bradford Americi'
    },
    {
      ssn: '134162837',
      name: 'Ursola Beardshall'
    },
    {
      ssn: '208203818',
      name: 'Emalee Denton'
    },
    {
      ssn: '269237849',
      name: 'Farlie Drepp'
    },
    {
      ssn: '102587087',
      name: 'Cecile Tuther'
    },
    {
      ssn: '632269867',
      name: 'Ophelia Tooting'
    },
    {
      ssn: '23380537',
      name: 'Nessi Haselup'
    },
    {
      ssn: '649241906',
      name: 'Thibaud Mourbey'
    },
    {
      ssn: '803041448',
      name: 'Dollie Danielou'
    },
    {
      ssn: '596751124',
      name: 'Bruis Barwis'
    },
    {
      ssn: '330937474',
      name: 'Reeva Faircliff'
    },
    {
      ssn: '485084028',
      name: 'Alta Milier'
    },
    {
      ssn: '286615544',
      name: 'Haven Scohier'
    },
    {
      ssn: '428039479',
      name: 'Bentley Huffer'
    },
    {
      ssn: '735110488',
      name: 'Emlyn Gutridge'
    },
    {
      ssn: '656879883',
      name: 'Ofella Fyndon'
    },
    {
      ssn: '488228321',
      name: 'Euell Pirolini'
    },
    {
      ssn: '706461817',
      name: 'Artie Caughtry'
    },
    {
      ssn: '348474730',
      name: 'Bucky Adey'
    },
    {
      ssn: '650373969',
      name: 'Tiebout Sanper'
    },
    {
      ssn: '182442716',
      name: 'Carver Karlik'
    },
    {
      ssn: '345093224',
      name: 'Barbe Chritchley'
    },
    {
      ssn: '327016511',
      name: 'Nikolas Casoni'
    },
    {
      ssn: '353461376',
      name: 'Flem Chatenier'
    },
    {
      ssn: '157310446',
      name: 'Mohandis Bruckmann'
    },
    {
      ssn: '266833734',
      name: 'Nessy Castro'
    },
    {
      ssn: '575038120',
      name: 'Adolphe Kubczak'
    },
    {
      ssn: '154990173',
      name: 'Magdalen O Brian'
    },
    {
      ssn: '862715922',
      name: 'Julio Dulanty'
    },
    {
      ssn: '403864881',
      name: 'Geri Iron'
    },
    {
      ssn: '755636977',
      name: 'Marris Gergely'
    },
    {
      ssn: '685477454',
      name: 'Nettie McGown'
    },
    {
      ssn: '816776605',
      name: 'Ame Sabin'
    },
    {
      ssn: '443779029',
      name: 'Ludovika Cragg'
    },
    {
      ssn: '348815112',
      name: 'Konstanze Biggadike'
    },
    {
      ssn: '105069877',
      name: 'Jarvis OCorhane'
    }
  ]
};

export const ParticipantOptionalData = {
  status: 'SUCCESS',
  data: [
    {
      label: 'Current year hours',
      componentType: 'text',
      value: '',
      readOnly: false,
      disabled: true,
      option: [],
      required: true,
      type: 'Float',
      key: 'PTPH85',
      length: 0
    },
    {
      label: 'Current elig hours',
      componentType: 'text',
      value: '',
      readOnly: false,
      disabled: false,
      option: [],
      required: true,
      type: 'Float',
      key: 'PTPH340',
      length: 0
    },
    {
      label: 'Some Date Field',
      componentType: 'text',
      value: '',
      readOnly: false,
      disabled: false,
      option: [],
      required: true,
      type: 'Date',
      key: 'PTPH740',
      length: 0
    },
    {
      label: 'Division/Location',
      componentType: 'dropdown',
      value: '',
      readOnly: false,
      disabled: false,
      option: [
        {
          value: '',
          displayText: 'Select'
        },
        {
          value: '4800',
          displayText: '4800 AGRICULTURAL EXPERIMENT STATION'
        },
        {
          value: '4350',
          displayText: '4350 AIR MANAGEMENT'
        },
        {
          value: '1100',
          displayText: '1100 AUDITORS OF PUBLIC ACCOUNTS'
        },
        {
          value: '8835',
          displayText: '8835 BERGIN CORRECTIONAL INST'
        },
        {
          value: '8845',
          displayText: '8845 BROOKLYN CORRECTIONAL INST'
        },
        {
          value: '5720',
          displayText: '5720 BUREAU OF HIGHWAY OPERATIONS'
        },
        {
          value: '4720',
          displayText: '4720 CAPITAL REG DEV AUTH'
        },
        {
          value: 'O!',
          displayText: 'OTHER'
        }
      ],
      required: true,
      type: '',
      key: 'PTPH244',
      length: 0
    },
    {
      label: 'Adjusted Date of hire',
      componentType: 'text',
      value: '',
      readOnly: false,
      disabled: false,
      option: [],
      required: true,
      type: 'date',
      key: 'PTPH840',
      length: 0
    }
  ]
};

export const PariticipantContributionData = {
  status: 'SUCCESS',
  data: {
    invElectChangeAllowed: false,
    mstarFlag: true,
    contribElection: {
      type: 'Percent',
      list: [
        {
          key: 'contriEEPreTax',
          label: 'EE Pre Tax',
          value: '15',
          readonly: false
        },
        {
          key: 'contrRoth',
          label: 'Roth',
          value: '2',
          readonly: false
        }
      ]
    },
    catchupContribElection: {
      type: 'Amount',
      list: [
        {
          key: 'catchEEPreTax',
          label: 'EE Pre Tax Catch Up',
          value: '25',
          readonly: false
        },
        {
          key: 'catchRoth',
          label: 'Roth Catch Up',
          value: '10',
          readonly: false
        }
      ]
    },
    investmentElection: {
      acrossAllSourceElectionFlg: 'true',
      list: [
        {
          key: 'allSource',
          label: 'Across ALL Sources Elections',
          value: 'true',
          readonly: false
        },
        {
          key: 'contriEEPreTax',
          label: 'Pre Tax Vol Elections',
          value: 'true',
          readonly: false
        },
        {
          key: 'contrRoth',
          label: 'Profit Share Elections',
          value: 'true',
          readonly: false
        }
      ]
    }
  }
};

export const ParticipantFundData = {
  status: 'SUCCESS',
  data: {
    fundSources: [
      {
        fundName: 'VY Invesco Eqty & Inc Port I',
        sources: [
          {
            sourceID: 'ALL', //this will change
            value: '25',
            readonly: true
          },
          {
            sourceID: 'CurrentPreTaxVOL',
            value: '50',
            readonly: true
          }
        ]
      },
      {
        fundName: 'Voya Fixed Plus Account II',
        sources: [
          {
            sourceID: 'ALL',
            value: '50',
            readonly: true
          },
          {
            sourceID: 'CurrentPreTaxVOL',
            value: '15',
            readonly: true
          }
        ]
      },
      {
        fundName: 'Voya Index Plus LargeCap Portfolio I',
        sources: [
          {
            sourceID: 'ALL',
            value: '25',
            readonly: true
          },
          {
            sourceID: 'CurrentPreTaxVOL',
            value: '75',
            readonly: true
          }
        ]
      }
    ],
    sourceMap: [
      {
        sourceID: 'ALL',
        sourceName: 'Across ALL Sources'
      },
      {
        sourceID: 'CurrentPreTaxVOL',
        sourceName: 'Current Pre-Tax VOL'
      }
    ],
    invElectChangeAllowed: false,
    readOnlyFieldsExist: true
  }
};
