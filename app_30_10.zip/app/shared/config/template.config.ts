import { IListItem } from '../interfaces/list-item.interface';



export const dropdownItems: IListItem[] = [
  { displayText: '1', value: '1' },
  { displayText: '2', value: '2' },
  { displayText: '3', value: '3' },
  { displayText: '4', value: '4' },
  { displayText: '5', value: '5' },
  { displayText: '6', value: '6' },
  { displayText: '7', value: '7' },
  { displayText: '8', value: '8' },
  { displayText: '9', value: '9' }
];

export const importMapping = {
  C: {
    fileUrl:
      'https://paystation.accp.voya.com/static/epaystation/pdf/contrib-import-sample.pdf',
    serviceUrl: ''
  },
  E: {
    fileUrl:
      'https://paystation.accp.voya.com/static/epaystation/pdf/enroll-import-sample.pdf',
    serviceUrl: 'participant'
  },
  P: {
    fileUrl:
      'https://paystation.accp.voya.com/static/epaystation/pdf/census-import-sample.pdf',
    serviceUrl: ''
  },
  L: {
    fileUrl:
      'https://paystation.accp.voya.com/static/epaystation/pdf/loan-import-sample.pdf',
    serviceUrl: ''
  }
};
/* P - Participant Update
E - Add Participant/Enroll Participant
C - Contribution
L - Loan */
