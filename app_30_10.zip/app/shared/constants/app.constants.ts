export const MESSAGES = {
  VOYA_WORKING_TIME: 'The voya office timing message',
  VOYA_APP_NAME: 'Payroll/Administration',
  SERVICE_ERROR: 'There is an error occurred while calling the service!',
  SERVICE_SUCCESS: 'Service call succeeded!',
  SERVICE_START: 'Please wait... Service call in progress!'
};


export const APP_CONST =
{
    APP_CONTEXT: 'Voya-PayAdmin/',
    SUCCESS: 'SUCCESS'

};

export const ROUTER_CONST = {
  ADD_BANK: 'Add Bank',
  EDIT_BANK: 'Edit'
};

export enum INPUT_TYPE {
  text = 'text',
  alphabets = 'alphabets',
  alphanumeric = 'alphanumeric',
  number = 'number',
  ssn = 'ssn',
  email = 'email',
  zip = 'zip',
  percentage = 'percentage',
  currency = 'currency'
}

export const SUB_TITLE = {
  APP_TITLE: 'Payroll/Administration',
  PLAN_SELECTION: 'Plan Selection',
  ADMIN: ' Administration',
  BANK_INFO: ' Bank Information',
  PAGE_SECURITY: ' Page Security',
  UPDATE_PLAN: ' Update Plan Setup Information',
  FILE_IMPORT: '  Import a File',
  TEMPLATE_SELECTION: 'Select Template',
  TEMPLATE_CREATE: 'Create Template',
  ENROLLMENT_AUDIT: 'Enrollment Audit'
};

// ===================== Admin ========================
export const ADMIN_CONFIG = {
SSN_ITEMS : [
    { label: 'No Mask (999999999)', value: '999999999' },
    { label: 'Standard Mask Left (xxxxxx9999)', value: 'xxxxx9999' },
    { label: 'Standard Mask Right (99999xxxxx)', value: '99999xxxxx' },
    { label: 'Custom Mask', value: 'Custom' }
   ],
CUSTOM_MASK_VALUE : 'customMask'
  };
// ====================== Admin Ends ===================

// ===================== For Mock service call -=================
export const ENV = {
  TEST : true
};
