import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import { Link } from 'react-router'
class MainApp extends Component {
   render() {
      return (
         <div>
            <ul>
               <li><Link to="/home">Create ToDos</Link></li>
               <li><Link to="/emp">Create Employees</Link></li>
                <li><Link to="/ext">External Employees</Link></li>
               <li><Link to="/all">Show All Details</Link></li>
            </ul>
				    <hr />
           {this.props.children}
         </div>
      )
   }
}
export default MainApp

