import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {connect} from 'react-redux';
import TodoList from '../components/todo-list';
import EmployeeList from '../components/employee-list';
import ExtEmployeeList from '../components/external-emp-list';

class ShowAll extends Component {
    render() {
        return (
            <div>
                <div className="default-todo">
                    <h1>Default ToDo Details </h1>
                    <TodoList toDoItems={this.props.todosDefault} />
                </div>
                <div className="new-todo">
                    <h1>New ToDo Details </h1>
                    <TodoList toDoItems={this.props.todosNew} />
                </div>
                <div className="new-employee">
                    <h1>New Employees Details </h1>
                    <EmployeeList employees={this.props.employeesNew}/>
                </div>
                <div className="ext-employee">
                    <h1>External Employees Details </h1>
                    <ExtEmployeeList employees={this.props.employeesExternal}/>
                </div>
            </div>
        );
    }

}
function mapStateToProps(state) {
    return {
        todosDefault: state.defaultTodo,
        todosNew : ((state.companyInfo != null && state.companyInfo.ToDos != null ) ? state.companyInfo.ToDos : [] ),
        employeesNew : ((state.companyInfo != null && state.companyInfo.Employees != null ) ? state.companyInfo.Employees : [] ),
        employeesExternal : ((state.companyInfo != null && state.companyInfo.ExtEmployees != null ) ? state.companyInfo.ExtEmployees : [] )
    };
}
export default connect(mapStateToProps)(ShowAll);


