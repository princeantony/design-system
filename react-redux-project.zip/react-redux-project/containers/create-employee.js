import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {saveEmployee, removeEmployee} from '../actions/employee-action'
import EmployeeList from '../components/employee-list';
import {isValid} from '../utils/common';
import {EMPLOYEE_CONSTANT} from '../constants/app-constants';
import _ from "lodash";

class CreateEmployee extends Component {
  constructor(props) {
    super(props);
    this.state = {items: []};
  }
  // A component life cycle event -
  // it will be called each time the component load (will not call each render occured by setState)
   componentWillMount() {
       this.setState({items: this.props.existingEmployees})
   }
   //To create a new Employee
   createEmployee(e) {
    e.preventDefault();
    const fname = this.refs.txtFName.value;
    const lname = this.refs.txtLName.value;
    const phone = this.refs.txtPhone.value;
    const email = this.refs.txtEmail.value;
    
    // do a validation to check its empty or not
    if(isValid(fname) && isValid(lname) && isValid(phone) && isValid(phone) )
    {
      var newItem = {
        empFname: fname,
        empLname: lname,
        empPhone: phone,
        empEmail: email,
        id: Date.now()
      };
      this.setState((prevState) => ({
        items: prevState.items.concat(newItem)
      }));
      // to clean the textboxes
      this.refs.txtFName.value = '';
      this.refs.txtLName.value = '';
      this.refs.txtPhone.value = '';
      this.refs.txtEmail.value = '';
    }
  }
  
  saveToReducer(e)
  {
    e.preventDefault();
    this.props.actions.saveEmployee(this.state.items);
  }
  removeFromLocalState(e)
  {
    e.preventDefault();
    const updatedEmployee = _.slice(this.state.items, 0, this.state.items.length - 1);
    this.setState({items: updatedEmployee})   
  }
   removeFromReducer(e)
  {
    e.preventDefault();
    const updatedEmployee = _.slice(this.state.items, 0, this.state.items.length - 1);
    this.setState({items: updatedEmployee})   
    this.props.actions.removeEmployee(updatedEmployee);
  }
  render() {
    return (
      <div className="new-employee">
        <h3>Employee Component</h3>
        <EmployeeList employees={this.state.items} /><br/><br />
          <form>
              {EMPLOYEE_CONSTANT.FIRST_NAME} <input type= "text" ref="txtFName" /><br />
              {EMPLOYEE_CONSTANT.LAST_NAME}  <input type= "text" ref="txtLName" /><br />
              {EMPLOYEE_CONSTANT.PHONE_NUMBER}  <input type= "text" ref="txtPhone" /><br />
              <div className="input-group">{EMPLOYEE_CONSTANT.EMAIL} 
              <span className="input-group-addon">
                <i className="fa fa-envelope-o fa-fw"></i></span>
                <input type= "text" ref="txtEmail" placeholder="Email address"/></div>
              <br/><br />
                <button onClick={this.createEmployee.bind(this)}>Add Local State  </button>
                <button onClick={this.removeFromLocalState}>Remove from Local State </button>
              <br/><br />
                <button onClick={this.saveToReducer.bind(this)}>Save to Reducer</button>
                <button onClick={this.removeFromReducer.bind(this)}>Remove from Reducer</button>
         </form>
      </div>
    );
  }


}
function mapStateToProps(state) {
    return {
       existingEmployees: ((state.companyInfo != null && state.companyInfo.Employees != null ) ? state.companyInfo.Employees : [] )
    };
}

function matchDispatchToProps(dispatch){
    return {actions : bindActionCreators({saveEmployee, removeEmployee}, dispatch)};
}

export default connect(mapStateToProps, matchDispatchToProps)(CreateEmployee);