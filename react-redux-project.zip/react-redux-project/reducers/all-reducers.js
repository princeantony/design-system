import {combineReducers} from 'redux';
import InitialReducer from './default-todo-reducer';
import CompanyReducer from './company-reducer';

const allReducers = combineReducers({
    defaultTodo: InitialReducer,
    companyInfo: CompanyReducer
});

export default allReducers
