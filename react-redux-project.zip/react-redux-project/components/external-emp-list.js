import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {BootstrapTable, TableHeaderColumn} from "react-bootstrap-table";
class ExtEmployeeList extends Component {
  render() {
    const {employees} = this.props;
    debugger;
     const options = {
        page: 1,  // which page you want to show as default
         sizePerPageList: [ 5, 10, 15, 25, 50, 100 ], // you can change the dropdown list for size per page
         sizePerPage: 10,  // which size per page you want to locate as default
         pageStartIndex: 0, // where to start counting the pages
         paginationSize: 3,  // the pagination bar size.
         prePage: "Prev", // Previous page button text
         nextPage: "Next", // Next page button text
         firstPage: "First", // First page button text
         lastPage: "Last", // Last page button text
         paginationShowsTotal: false, // Accept bool or function,
         expandRowBgColor: 'rgb(242, 255, 163)',
         onMouseEnter: function() {
        console.log('mouse enter to table');
      }
        };
        const emptyOptions = {
            sizePerPageList: [0],
            noDataText: (<div className="font-size-11px"><span>There are no external employees yet.</span></div>)
        };
    return (
            <BootstrapTable data={employees} options={((employees.length!=0)?(options):(emptyOptions))} 
                            pagination={true}>
                <TableHeaderColumn  
                    isKey={true}
                    dataSort={true}
                    filter={((employees.length!=0)?({type: "TextFilter", placeholder: "Please enter a name"}):({}))}
                    dataField="name">Name</TableHeaderColumn>
                <TableHeaderColumn  dataField="username" columnClassName="">User Name</TableHeaderColumn>
                <TableHeaderColumn  dataField="email"columnClassName="" >Email</TableHeaderColumn>
            </BootstrapTable>
    );
  }
}
export default ExtEmployeeList;