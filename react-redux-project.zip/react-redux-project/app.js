// React and Redux development modules
import 'babel-polyfill'; // For browser compatibilityimport 'babel-polyfill'; // For browser compatibility
import React from 'react'; // For jsx and other react development build in components
import ReactDOM from "react-dom"; // For rendering on browser
import {Provider} from 'react-redux'; // To connect to store to components/containers
import createLogger from 'redux-logger'; // Loggrer module which will shows data in F12 developer tool
import {createStore, applyMiddleware} from 'redux'; // To create a store 
import thunk from 'redux-thunk'; // for api call
import promise from 'redux-promise'; // for api call async calls
/* User defined modules */
//Root module were we will define all the navigation (Routers) details
import RootApp from './routers/root-app';

// A main reducer module which will have all other reducers
import allReducers from './reducers/all-reducers';

// Create a logger object - it will help us to see the reducer information in F12
const logger = createLogger();

//Create a store object
const store = createStore(
    allReducers,
    applyMiddleware(thunk, promise, logger)
);

// To render on Browser, we need to assign to a main html element like div 'id'. 
ReactDOM.render(
    <Provider store={store}>
        <RootApp />
    </Provider>,
    document.getElementById('root')
);
