import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgSelectModule } from '@ng-select/ng-select';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AgGridModule } from 'ag-grid-angular';
import { NgxSpinnerModule } from 'ngx-spinner';
import { environment } from '../environments/environment';
import { AppComponent } from './app.component';
import { ApiService } from './shared/services/api.service';
import { ModalService } from './shared/services/modal.service';
import { PlanModule } from './modules/plans/plan.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HomeModule } from './modules/home/home.module';
import { BankModule } from './modules/bank-information/bank.module';
import { LoginModule } from './modules/login/login.module';
import { AdminModule } from './modules/admin/admin.module';
import { ParticipantModule } from './modules/participants/participant.module';
import { TemplateModule } from './modules/templates/template.module';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { HeaderComponent } from './shared/components/layout/header/header.component';
import { BrowserInfoComponent } from './shared/components/browser-info/browser-info.component';
import { Routes, RouterModule } from '@angular/router';

const appRoutes: Routes = [
  {
    path: 'app',
    component: AppComponent,
    data: { title: 'Pay Admin App' }
  }
]
@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HeaderComponent,
    BrowserInfoComponent,

  ],
  imports: [
    BrowserModule,
    PlanModule,
    HomeModule,
    BankModule,
    LoginModule,
    AdminModule,
    TemplateModule,
    ParticipantModule,
    BrowserModule,
    NgxSpinnerModule,
    HttpClientModule,
    NgSelectModule,
    FormsModule,
    BrowserAnimationsModule,

    RouterModule.forRoot(appRoutes),
    ReactiveFormsModule,
    NgbModule
  ],
  providers: [ModalService, ApiService],
  bootstrap: [AppComponent]
})
export class AppModule {}
