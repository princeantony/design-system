import { Component, OnInit } from '@angular/core';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
import _ from 'lodash';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalService } from '../../../../../shared/services/modal.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastsManager } from 'ng6-toastr';

@Component({
    selector: 'app-admin-options-data',
    templateUrl: './admin-options-data.component.html'
  })

export class AdminOptionsDataComponent implements OnInit{
    slectDataColumnDefs: any;
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    dataelementID: string;
    isButtonDisabled: false;
    selectedOptionId : string;
    selectedOption: any;
    dataElementOptions: any;
    type = 'Data Element Option';
    modelId = 'deOptionModal';
    navigateTo = 'options/';
    constructor(
      private adminService: AdminService,
      private route: ActivatedRoute,
      private modalService: ModalService,
      private spinner: NgxSpinnerService,
      public toastr: ToastsManager,
       private router: Router) {}
    ngOnInit(){
        this.slectDataColumnDefs = GRID_CONFIG.DATA_ELEMENTS.OPTIONS;
        this.hidePageTitle = false;
        this.subTitle = 'Select Data Element Option';
        this.planNumber = PayAdminGlobalState.planNumber;
        this.dataelementID =  AdminDataService.dataElementId;
        PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
        PayAdminGlobalState.currentPage = 'admin/dataElements/options';
        this.route.url.subscribe(value => {
          const isDelete = _.find(value, ['path', 'delete']);
          if (isDelete) {
          this.onDelete();
          } else {
            this.getOptions();
          }
        });
    }
    getSelectedOptionId(selectedId: string) {
      this.isButtonDisabled = false;
      this.selectedOption = _.filter(this.dataElementOptions, ['valueCode', selectedId])[0];
      AdminDataService.dataElementOption = this.selectedOption;
      this.selectedOptionId = selectedId;
    }
    selectNew()
    {
      this.selectedOption = null;
      this.selectedOptionId = '';
      this.isButtonDisabled = false;
      AdminDataService.dataElementOption = null;
    }
    getOptions()
    {
      this.adminService.getDEOptions(this.planNumber, this.dataelementID).subscribe(options => {
        this.spinner.hide();
        if (options.status === APP_CONST.SUCCESS) {
            this.dataElementOptions = options.data;
          } else {
            console.log('Error in get options', options);
            this.toastr.error(options.error.msg, options.status + ' !', { showCloseButton: true });
          }
        },
        (err => {
          this.spinner.hide();
          console.log('Error in get options outside', err);
          this.toastr.error('Error while fetching Data Element Optoins !', err.error.status + ' !', { showCloseButton: true });
        })
      );
      }
    showDeteleModal() {
      PayAdminGlobalState.currentPage = PayAdminGlobalState.previousPage;
      this.modalService.open('deOptionModal');
    }
    onDelete() {
      this.adminService.deleteDE(this.planNumber, this.selectedOptionId).subscribe(delRes => {
        if (delRes.status === APP_CONST.SUCCESS) {
          this.getOptions(); // can be done through client logic
        } else {
          this.spinner.hide();
          console.log('Error in deleteDE options', delRes);
          this.toastr.error(delRes.error.msg, delRes.status + ' !', { showCloseButton: true });
        }
      },
      (err => {
        this.spinner.hide();
        console.log('Error in deleteDE options outside', err);
        this.toastr.error('Error while deleting Data Element Optoin !', err.error.status + ' !', { showCloseButton: true });
      })
    );
    }
    onEdit() {
      this.router.navigate(['/admin/dataElements/options/createOrEdit']);
    }
    gotoBack() {
      this.router.navigate([PayAdminGlobalState.previousPage]);
    }

  }
