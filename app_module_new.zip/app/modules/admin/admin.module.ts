
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonModule } from '@angular/common';
import { AdminPlanCopyComponent } from './pages/admin-plan-copy/admin-plan-copy.component';
import { AdminOptionsDataComponent } from './pages/admin-data-elements/admin-options-data/admin-options-data.component';
import { AdminOptionDataComponent } from './pages/admin-data-elements/admin-Option-data/admin-Option-data.component';
import { AdminDataElementSelectComponent } from './pages/admin-data-elements/admin-data-element-select/admin-data-element-select.component';
import { AdminDataElementsPageComponent } from './pages/admin-data-elements/admin-data-elements-page/admin-data-elements-page.component';
import { AdminPlanSetupComponent } from './pages/admin-plan-setup/admin-plan-setup.component';
import { AdminPageSecurityComponent } from './pages/admin-page-security/admin-page-security.component';
import { AdminHomeComponent } from './pages/admin-home/admin-home.component';
import { AdminMenuComponent } from './components/admin-menu/admin-menu.component';
import { AdminPageSetupComponent } from './components/admin-page-setup/admin-page-setup.component';
import { AdminGridCheckboxComponent } from './components/admin-grid-checkbox/admin-grid-checkbox.component';
import { AdminGridTextboxComponent } from './components/admin-grid-textbox/admin-grid-textbox.component';
import { AdminPlanSetupGridComponent } from './components/admin-plan-setup-grid/admin-plan-setup-grid.component';
import { AdminDataElementItemComponent } from './components/admin-data-elements/admin-data-element-item/admin-data-element-item.component';
import { AdminOptionsDataGridComponent } from './components/admin-data-elements/admin-options-data-grid/admin-options-data-grid.component';
import { AdminGridSelectAllComponent } from './components/admin-grid-select-all/admin-grid-select-all.component';
import { AdminReviewUpdateComponent } from './pages/admin-termination-information/admin-review-update/admin-review-update.component';
import { AdminGridEditComponent } from './components/admin-grid-edit/admin-grid-edit.component';
import { AdminGridEditButtonComponent } from './components/admin-grid-edit-button/admin-grid-edit-button.component';
import { AdminClientSpecificComponent } from './pages/admin-termination-information/admin-client-specific/admin-client-specific.component';
import { AdminGridRadioComponent } from './components/admin-grid-radio/admin-grid-radio.component';
import { AdminDataElementGridComponent } from './components/admin-data-elements/admin-data-element-grid/admin-data-element-grid.component';
import { AdminClientGridComponent } from './components/admin-termination-info/admin-client-grid.component';
import { DataElementTextboxComponent } from './components/admin-data-elements/admin-data-element-textbox/data-element-textbox.component';
import { DEModalComponent } from './components/data-element-modal/de-modal.component';
import { AgGridModule } from 'ag-grid-angular';

const bankRoutes: Routes = [

  {
    path: 'admin',
    component: AdminHomeComponent
  },
  {
    path: 'admin/pageSecurity',
    component: AdminPageSecurityComponent
  },
  {
    path: 'admin/planSetup',
    component: AdminPlanSetupComponent
  },

  {
    path: 'admin/dataElements',
    component: AdminDataElementsPageComponent
  },
  {
    path: 'admin/dataElements/delete',
    component: AdminDataElementsPageComponent
  },
  {
    path: 'admin/dataElements/createOrEdit',
    component: AdminDataElementSelectComponent
  },
  {
    path: 'admin/dataElements/options',
    component: AdminOptionsDataComponent
  },
  {
    path: 'admin/dataElements/options/createOrEdit',
    component: AdminOptionDataComponent
  },

  {
    path: 'admin/dataElements/options/delete',
    component: AdminOptionsDataComponent
  },
  {
    path: 'admin/planCopy',
    component: AdminPlanCopyComponent
  }
];
@NgModule({
  declarations: [
    AdminMenuComponent,
    AdminHomeComponent,
    AdminPageSetupComponent,
    AdminPageSecurityComponent,
    AdminPlanSetupComponent,
    AdminGridCheckboxComponent,
    AdminGridTextboxComponent,
    AdminPlanSetupGridComponent,
    AdminDataElementItemComponent,
    AdminOptionsDataGridComponent,
    AdminOptionDataComponent,
    AdminOptionsDataComponent,
    AdminDataElementSelectComponent,
    AdminPlanCopyComponent,
    AdminGridSelectAllComponent,
    AdminReviewUpdateComponent,
    AdminGridEditComponent,
    AdminGridEditButtonComponent,
    AdminClientSpecificComponent,
    AdminGridRadioComponent,
    AdminDataElementsPageComponent,
    AdminDataElementGridComponent,
    AdminClientGridComponent,
    DataElementTextboxComponent,
    DEModalComponent,

   ],
  exports: [
    AdminMenuComponent,
    AdminHomeComponent,
    AdminPageSetupComponent,
    AdminPageSecurityComponent,
    AdminPlanSetupComponent,
    AdminGridCheckboxComponent,
    AdminGridTextboxComponent,
    AdminPlanSetupGridComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forRoot(
      bankRoutes,
    ),
    AgGridModule.withComponents([
      AdminGridCheckboxComponent,
      AdminGridTextboxComponent,
      DataElementTextboxComponent,
      AdminGridEditButtonComponent,
      AdminGridRadioComponent
    ]),
  ],
})
export class AdminModule {}
