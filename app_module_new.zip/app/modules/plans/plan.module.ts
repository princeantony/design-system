
import { NgModule } from '@angular/core';
import { PlanListComponent } from './components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './pages/plan-selection/plan-selection.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonModule } from '@angular/common';
import { AgGridModule } from 'ag-grid-angular';
const planRoutes: Routes = [
  {
    path: 'plans',
    component: PlanSelectionComponent,
    data: { title: 'Plan List' }
  }];
@NgModule({
  declarations: [
    PlanListComponent,
    PlanSelectionComponent
   ],
  exports: [
    PlanListComponent,
    PlanSelectionComponent

  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forRoot(
      planRoutes
    ),
    AgGridModule.withComponents([
      PlanListComponent,
      PlanSelectionComponent
    ])
  ],
})
export class PlanModule {}
