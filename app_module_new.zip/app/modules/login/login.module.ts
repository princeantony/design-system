
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonModule } from '@angular/common';
import { LoginPageComponent } from './pages/login-page.component';
import { LoginComponent } from './components/login.component';


const loginRoutes: Routes = [
  {
    path: '**',
    component: LoginPageComponent,
    data: { title: 'Pay Admin Login' }
  }];
@NgModule({
  declarations: [
    LoginPageComponent,
    LoginComponent
   ],
  exports: [
    LoginPageComponent,
    LoginComponent
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forRoot(
      loginRoutes,
    )
  ],
})
export class LoginModule {}
