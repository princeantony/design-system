
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonModule } from '@angular/common';
import { BankModalComponent } from '../bank-information/components/bank-modal/bank-modal.component';
import { ConfirmationComponent } from './pages/confirmation/confirmation.component';
import { CreateComponent } from './pages/create/create.component';
import { BankAvailableComponent } from './pages/bank-available/bank-available.component';
import { GridLinkComponent } from './components/grid-link/grid-link.component';
import { DisclosureComponent } from './components/disclosure/disclosure.component';
import { HelpComponent } from './components/help/help.component';
import { BankListComponent } from './components/bank-list/bank-list.component';
import { SubDivModalComponent } from './components/subdiv-modal/subdiv-modal.component';

const bankRoutes: Routes = [

  {
    path: 'home/print',
    component: ConfirmationComponent
  },

  {
    path: 'bankInfo/edit/:divsubId',
    component: CreateComponent
  },
  {
    path: 'bankInfo/edit',
    component: CreateComponent
  },
  {
    path: 'bankInfo/create/:divsubId',
    component: CreateComponent
  },
  {
    path: 'bankInfo/create',
    component: CreateComponent
  },
  {
    path: 'bankInfo',
    component: BankAvailableComponent
  },
  {
    path: 'bankInfo/confirm',
    component: ConfirmationComponent
  }
];
@NgModule({
  declarations: [
    BankModalComponent,
    GridLinkComponent,
    BankAvailableComponent,
    BankListComponent,
    ConfirmationComponent,
    CreateComponent,
    DisclosureComponent,
    HelpComponent,
    SubDivModalComponent
   ],
  exports: [
    BankModalComponent,
    GridLinkComponent,
    BankAvailableComponent,
    BankListComponent,
    ConfirmationComponent,
    CreateComponent,
    DisclosureComponent,
    HelpComponent,
    SubDivModalComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forRoot(
      bankRoutes,
    )
  ],
})
export class BankModule {}
