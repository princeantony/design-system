import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-bank-submit',
  template: '<h1></h1>',
  styleUrls: ['./bank-submit.component.scss']
})
export class BankSubmitComponent implements OnInit {

  constructor(private modalService :  ModalService) { }

  ngOnInit() {
  }

  closeModal(id){

    this.modalService.close(id);

  }

}
