
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonModule } from '@angular/common';
import { ParticipantAddComponent } from './pages/participant-add/participant-add.component';
import { ParticipantUpdateComponent } from './pages/participant-update/participant-update.component';
import { ParticipantAddOptionalComponent } from './pages/participant-add-optional/participant-add-optional.component';
import { ParticipantAddContributionElectionComponent } from './pages/participant-add-contribution-election/participant-add-contribution-election.component';
import { ParticipantAddInvestmentElectionComponent } from './pages/participant-add-investment-election/participant-add-investment-election.component';
import { ParticipantConfirmationComponent } from './pages/participant-confirmation/participant-confirmation.component';
import { ParticipantImportFileComponent } from './pages/participant-import/participant-import-file/participant-import-file.component';
import { ParticipantSearchComponent } from './pages/participant-search/participant-search.component';
import { ParticipantContributionElectionComponent } from './components/participant-contribution-election/participant-contribution-election.component';
import { ParticipantUpdateContributionElectionComponent } from './pages/participant-update-contribution-election/participant-update-contribution-election.component';
import { ParticipantUpdateInvestmentElectionComponent } from './pages/participant-update-investment-election/participant-update-investment-election.component';
import { ParticipantUpdateOptionalComponent } from './pages/participant-update-optional/participant-update-optional.component';
import { ParticipantRequiredDataComponent } from './components/participant-required-data/participant-required-data.component';
import { ParticipantInvestmentElectionComponent } from './components/participant-investment-election/participant-investment-election.component';
import { ParticipantOptionalDataComponent } from './components/participant-optional-data/participant-optional-data.component';
import { ContributionInputGroupComponent } from './components/participant-contribution-election/contribution-input-group/contribution-input-group.component';
import { ParticipantVerifyDataComponent } from './pages/participant-import/participant-verify-data/participant-verify-data.component';


const participantRoutes: Routes = [
  {
    path: 'participant',
    component: ParticipantAddComponent // ParticipantAddComponent
  },
  {
    path: 'participantUpdate',
    component: ParticipantUpdateComponent
  },
  {
    path: 'addParticipant/Optional',
    component: ParticipantAddOptionalComponent
  },
  {
    path: 'addParticipant/ContributionElection',
    component: ParticipantAddContributionElectionComponent
  },
  {
    path: 'addParticipant/ContributionInvestment',
    component: ParticipantAddInvestmentElectionComponent
  },
  {
    path: 'addParticipant/Confirmation',
    component: ParticipantConfirmationComponent
  },
  {
    path: 'participant/import',
    component: ParticipantImportFileComponent
  },
  // Update participant Module
  {
    path: 'participantUpdateSearch',
    component: ParticipantSearchComponent
  }];
@NgModule({
  declarations: [
    ParticipantAddComponent,
    ParticipantAddOptionalComponent,
    ParticipantContributionElectionComponent,
    ParticipantAddInvestmentElectionComponent,
    ParticipantAddContributionElectionComponent,
    ParticipantUpdateContributionElectionComponent,
    ParticipantUpdateInvestmentElectionComponent,
    ParticipantUpdateOptionalComponent,
    ParticipantUpdateComponent,
    ParticipantRequiredDataComponent,
    ParticipantOptionalDataComponent,
    ParticipantInvestmentElectionComponent,
    ContributionInputGroupComponent,
    ParticipantConfirmationComponent,
    ParticipantSearchComponent,
    ParticipantImportFileComponent,
    ParticipantVerifyDataComponent,
   ],
  exports: [
    ParticipantAddComponent,
    ParticipantAddOptionalComponent,
    ParticipantContributionElectionComponent,
    ParticipantAddInvestmentElectionComponent,
    ParticipantAddContributionElectionComponent,
    ParticipantUpdateContributionElectionComponent,
    ParticipantUpdateInvestmentElectionComponent,
    ParticipantUpdateOptionalComponent,
    ParticipantUpdateComponent,
    ParticipantRequiredDataComponent,
    ParticipantOptionalDataComponent,
    ParticipantInvestmentElectionComponent,
    ContributionInputGroupComponent,
    ParticipantConfirmationComponent,
    ParticipantSearchComponent,
    ParticipantImportFileComponent,
    ParticipantVerifyDataComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forRoot(
      participantRoutes,
    )
  ],
})
export class ParticipantModule {}
