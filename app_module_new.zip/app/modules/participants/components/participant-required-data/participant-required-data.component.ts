import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { CommonService } from 'src/app/shared/services/common.service';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import {
  IParticipantRequiredData,
  ParticipantData,
  ParticipantOptionSetting
} from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'participant-required-data',
  templateUrl: './participant-required-data.component.html',
  styleUrls: ['./participant-required-data.component.scss']
})
export class ParticipantRequiredDataComponent implements OnInit {
  private _editMode = false;
  private statusText: string;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }
  countryChanged = new Subject<string>();
  participantData = new ParticipantData();
  participantRequiredDataForm: FormGroup;
  requiredData: IParticipantRequiredData;
  participantOptionSetting: ParticipantOptionSetting;
  countryList: { value: string; displayText: string }[];
  stateList: { value: string; displayText: string }[];
  // parameter to set dataofBirth start Date
  dobStartData: {};
  dohStartDate: {};
  today: number = Date.now();

  accountTypeItems: { value: string; label: string }[];
  constructor(
    private formBuilder: FormBuilder,
    private participantsService: ParticipantsService,
    private router: Router,
    private commonService: CommonService
  ) {}
  ngOnInit() {
    this.today = Date.now();
    this.EditMode = false;
    // Get Country List
    this.countryList = PayAdminGlobalState.countryList;
    this.stateList = PayAdminGlobalState.stateList;

    // Get Admin Settings
    this.getParticipantOptionSetting();
    this.setStartDates();
    // Initialize Form
    this.initFrom();
    this.onChanges();
  }

  getParticipantOptionSetting() {
    this.participantOptionSetting = this.participantsService.getParticipantOptionSetting();
    this.statusText = this.participantsService.getParticipantStatus();
  }

  initFrom() {
    if (this.EditMode) {
      // TODO: pull participant Data to update
      // this.participantData = from service
    }
    this.participantData = this.participantsService.getParticipantData();
    console.log(this.participantData);
    this.participantRequiredDataForm = this.formBuilder.group({
      ssn: [this.participantData.requiredData.ssn],
      email: [this.participantData.requiredData.email],
      lastName: [this.participantData.requiredData.lastName],
      firstName: [this.participantData.requiredData.firstName],
      mName: [this.participantData.requiredData.mName],
      addressLine1: [this.participantData.requiredData.addressLine1],
      addressLine2: [this.participantData.requiredData.addressLine2],
      city: [this.participantData.requiredData.city],
      zip: [this.participantData.requiredData.zip],
      state: [this.participantData.requiredData.state],
      country: [this.participantData.requiredData.country],
      dateOfBirth: [this.participantData.requiredData.dateOfBirth],
      dateOfHire: [this.participantData.requiredData.dateOfHire],
      terminationDate: [
        this.participantData.requiredData.terminationDate
      ],
      terminationReason: [
        this.participantData.requiredData.terminationReason
      ],
      makeParticipantActive: [
        this.participantData.requiredData.makeParticipantActive
      ],
      absenceStartDate: [
        this.participantData.requiredData.absenceStartDate
      ],
      absenceStartDateReason: [
        this.participantData.requiredData.absenceStartDateReason
      ],
      absenceEndDate: [
        this.participantData.requiredData.absenceEndDate
      ],
      absenceEndDateReason: [
        this.participantData.requiredData.absenceEndDateReason
      ],
      enrollFlag: [this.participantData.requiredData.enrollFlag],
      mstarFlag: [this.participantData.requiredData.mstarFlag],
      qdiaFlag: [this.participantData.requiredData.qdiaFlag]
    });
  }

  onChanges() {
    this.participantRequiredDataForm.controls['mName'].valueChanges.subscribe(
      val => {
        this.participantRequiredDataForm.controls['mName'].setValue(
          val.toUpperCase(),
          { emitEvent: false }
        );
        this.validateNameMaxlengthExceeded();
      }
    );
    this.participantRequiredDataForm.controls[
      'lastName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'firstName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
  }

  validateNameMaxlengthExceeded() {
    if (
      this.participantRequiredDataForm.controls['mName'].value.length +
        this.participantRequiredDataForm.controls['firstName'].value.length +
        this.participantRequiredDataForm.controls['lastName'].value.length >
      30
    ) {
      this.participantRequiredDataForm.controls['lastName'].setErrors({
        MaxLengthExceeded: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    }
  }
  setStartDates() {
    this.dobStartData = { year: new Date().getFullYear() - 19 - 9, month: 1 };
    this.dohStartDate = { year: new Date().getFullYear() - 9, month: 1 };
  }

  onSubmit() {
    this.setParticipantRequiredData();
    if (this.participantRequiredDataForm.value.enrollFlag) {
      if (this.participantOptionSetting.canLoadOptionalDataElements) {
        this.router.navigate(['addParticipant/Optional']);
      } else {
        this.router.navigate(['addParticipant/ContributionElection']);
      }
    } else {
      this.router.navigate(['addParticipant/Confirmation']);
    }
  }

  onStateChange(value: string) {}

  onCountryChange(value: string) {
    this.commonService.countryChanged.next(value);
  }

  setParticipantRequiredData() {
    const data: IParticipantRequiredData = this.participantRequiredDataForm
      .value;
    console.log(data);
    this.requiredData = data;
    this.participantsService.addParticpantRequiredData(
      this.requiredData
    );
  }
}
