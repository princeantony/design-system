
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonModule } from '@angular/common';
import { PayAdminHomeComponent } from './pages/pay-admin-home/pay-admin-home.component';
import { PayAdminMenuComponent } from './components/pay-admin-menu/pay-admin-menu.component';
import { BankSubmitComponent } from '../bank-information/components/bank-submit/bank-submit.component';

const homeRoutes: Routes = [
  {
    path: 'home',
    component: PayAdminHomeComponent
  },
  {
    path: 'home/success',
    component: PayAdminHomeComponent
  }];
@NgModule({
  declarations: [
    PayAdminHomeComponent,
    PayAdminMenuComponent,
    BankSubmitComponent
   ],
  exports: [
    PayAdminHomeComponent,
    PayAdminMenuComponent,
    BankSubmitComponent
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forRoot(
      homeRoutes,
    )
  ],
})
export class HomeModule {}
