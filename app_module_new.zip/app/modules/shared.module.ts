import { NgModule } from '@angular/core';
import { ToastModule, ToastOptions } from 'ng6-toastr';
import { NgxSpinnerModule } from 'ngx-spinner';
import { HttpClientModule } from '@angular/common/http';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { GridComponent } from '../shared/components/form/voya-grid/grid.component';
import { NumericEditorComponent } from '../shared/components/ag-grid/editor/numeric-editor/numeric-editor.component';
import { SquareRenderer } from '../shared/components/ag-grid/renderer/square-renderer.component';
import { TimeInfoComponent } from '../shared/components/time-info/time-info.component';
import { PageTitleComponent } from '../shared/components/layout/page-title/page-title.component';
import { TitleMessageComponent } from '../shared/components/layout/title-message/title-message.component';
import { BrowserModule } from '@angular/platform-browser';
import { SpinnerComponent } from '../shared/components/layout/spinner/spinner.component';
import { ModalComponent } from '../shared/directives/modal.component';
import { VoyaCurrencyDirective } from '../shared/directives/voya-currency.directive';
import { SSNDirective } from '../shared/directives/voya-ssn.directive';
import { NumberDirective } from '../shared/directives/voya-number.directive';
import { VoyaCurrencyPipe } from '../shared/pipes/voya-currency.pipe';
import { VoyaSSNPipe } from '../shared/pipes/voya-SSN.pipe';
import { VoyaTextboxComponent } from '../shared/components/form/voya-textbox/voya-textbox.component';
import { VoyaLabelComponent } from '../shared/components/form/voya-label/voya-label.component';
import { VoyaButtonComponent } from '../shared/components/form/voya-button/voya-button.component';
import { VoyaLinkComponent } from '../shared/components/form/voya-link/voya-link.component';
import { VoyaEmailComponent } from '../shared/components/form/voya-email/voya-email.component';
import { VoyaZipComponent } from '../shared/components/form/voya-zip/voya-zip.component';
import { VoyaSelectComponent } from '../shared/components/form/voya-select/voya-select.component';
import { VoyaPagingComponent } from '../shared/components/form/voya-paging/voya-paging.component';
import { VoyaSsnComponent } from '../shared/components/form/voya-ssn/voya-ssn.component';
import { VoyaRoutingNumberComponent } from '../shared/components/form/voya-routing-number/voya-routing-number.component';
import { VoyaCheckboxComponent } from '../shared/components/form/voya-checkbox/voya-checkbox.component';
import { VoyaRadioComponent } from '../shared/components/form/voya-radio/voya-radio.component';
import { VoyaDateComponent } from '../shared/components/form/voya-date/voya-date.component';
import { VoyaAccountNumberComponent } from '../shared/components/form/voya-account-number/voya-account-number.component';
import { PageHeaderComponent } from '../shared/components/layout/page-header/page-header.component';
import { DateDirective } from '../shared/directives/date.directive';
import { VoyaSelectNewComponent } from '../shared/components/form/voya-select-new/voya-select-new.component';
import { BaseInputComponent } from '../shared/components/form/base-input/base-input.component';
import { Utils } from '../shared/utils/pay-admin.utils';

@NgModule({
  declarations: [
    GridComponent,
    TimeInfoComponent,
    PageTitleComponent,
    TitleMessageComponent,
    SpinnerComponent,
    ModalComponent,
    VoyaCurrencyDirective,
    SSNDirective,
    NumberDirective,
    VoyaCurrencyPipe,
    VoyaSSNPipe,
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent,
    VoyaLinkComponent,
    VoyaEmailComponent,
    VoyaZipComponent,
    VoyaSelectComponent,
    VoyaPagingComponent,
    VoyaSsnComponent,
    VoyaRoutingNumberComponent,
    VoyaCheckboxComponent,
    VoyaRadioComponent,
    DateDirective,
    VoyaDateComponent,
    NumericEditorComponent,
    VoyaSelectNewComponent,
    VoyaAccountNumberComponent,
    SquareRenderer,
    PageHeaderComponent,
    BaseInputComponent,
   ],
  exports: [
    GridComponent,
    TimeInfoComponent,
    PageTitleComponent,
    TitleMessageComponent,
    SpinnerComponent,
    ModalComponent,
    VoyaCurrencyDirective,
    SSNDirective,
    NumberDirective,
    VoyaCurrencyPipe,
    VoyaSSNPipe,
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent,
    VoyaLinkComponent,
    VoyaEmailComponent,
    VoyaZipComponent,
    VoyaSelectComponent,
    VoyaPagingComponent,
    VoyaSsnComponent,
    VoyaRoutingNumberComponent,
    VoyaCheckboxComponent,
    VoyaRadioComponent,
    BaseInputComponent,
    VoyaDateComponent,
    NumericEditorComponent,
    DateDirective,
    VoyaSelectNewComponent,
    VoyaAccountNumberComponent,
    SquareRenderer,
    PageHeaderComponent,
  ],
  imports: [
    BrowserModule,
    NgxSpinnerModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    ToastModule.forRoot(),
    NgbModule,
    ToastModule
  ],
  providers: [ Utils, ToastOptions],

})
export class SharedModule {}
