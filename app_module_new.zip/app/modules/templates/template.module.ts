
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared.module';
import { CommonModule } from '@angular/common';
import { TemplateGridLinkComponent } from './components/template-grid-link/template-grid-link.component';
import { TemplateExistingFixedWidthComponent } from './pages/template-existing-fixed-width/template-existing-fixed-width.component';
import { TemplateFileImportComponent } from './pages/template-file-import/template-file-import.component';
import { TemplateCreateFWComponent } from './pages/template-create-fixed-width/template-create-fixed-width.component';
import { TemplateExistingComponent } from './pages/template-existing/template-existing.component';
import { TemplateGridHeaderComponent } from './components/template-grid-header/template-grid-header.component';
import { TemplateGridTextboxComponent } from './components/template-grid-textbox/template-grid-textbox.component';
import { TemplateModalErrorComponent } from './components/template-modal-error/template-modal-error.component';
import { TemplateVerificationComponent } from './pages/template-verification/template-verification.component';
import { TemplateFormComponent } from './components/template-form/template-form.component';
import { TemplateGridComponent } from './components/template-grid/template-grid.component';
import { TemplateCreateComponent } from './pages/template-create-with-errors/template-create-with-errors.component';
import { TemplateModalHelpComponent } from './components/template-modal-help/template-modal-help.component';
import { TemplateSelectComponent } from './pages/template-select/template-select.component';
import { AdminReviewUpdateComponent } from '../admin/pages/admin-termination-information/admin-review-update/admin-review-update.component';
import { AdminClientSpecificComponent } from '../admin/pages/admin-termination-information/admin-client-specific/admin-client-specific.component';
import { AgGridModule } from 'ag-grid-angular';

const templateRoutes: Routes = [
  {
    path: 'fileImport',
    component: TemplateFileImportComponent
  },
  {
    path: 'template/select',
    component: TemplateSelectComponent
  },
  {
    path: 'template/create',
    component: TemplateCreateComponent
  },
  {
    path: 'template/createFW',
    component: TemplateCreateFWComponent
  },
  {
    path: 'template/existing/:id',
    component: TemplateExistingComponent
  },
  {
    path: 'template/verify',
    component: TemplateVerificationComponent
  },

  {
    path: 'terminate/reviewUpdate',
    component: AdminReviewUpdateComponent
  },
  {
    path: 'terminate/clientSpecific',
    component: AdminClientSpecificComponent
  },];
@NgModule({
  declarations: [

    TemplateGridLinkComponent,
    TemplateModalHelpComponent,
    TemplateExistingFixedWidthComponent,
    TemplateFileImportComponent,
    TemplateCreateComponent,
    TemplateCreateFWComponent,
    TemplateSelectComponent,
    TemplateGridComponent,
    TemplateExistingComponent,
    TemplateGridHeaderComponent,
    TemplateGridTextboxComponent,
    TemplateFormComponent,
    TemplateModalErrorComponent,
    TemplateVerificationComponent,
   ],
  exports: [

    TemplateGridLinkComponent,
    TemplateModalHelpComponent,
    TemplateExistingFixedWidthComponent,
    TemplateFileImportComponent,
    TemplateCreateComponent,
    TemplateCreateFWComponent,
    TemplateSelectComponent,
    TemplateGridComponent,
    TemplateExistingComponent,
    TemplateGridHeaderComponent,
    TemplateGridTextboxComponent,
    TemplateFormComponent,
    TemplateModalErrorComponent,
    TemplateVerificationComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    AgGridModule.withComponents([
      TemplateGridHeaderComponent,
      TemplateGridTextboxComponent,
      TemplateGridLinkComponent,
    ]),
    RouterModule.forRoot(
      templateRoutes,
    )
  ],
})
export class TemplateModule {}
