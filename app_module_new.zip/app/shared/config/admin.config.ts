import { IMenuItem } from '../interfaces/menu-item.interface';

    export const AdminMenuItems: IMenuItem[] = [
      {
        key: 'generalAdministrationPageActive',
        menuHeading: 'General Administration',
        menuSubheading: 'General plan information',
        menuIcon: 'general-administration.svg',
        linkTo: 'admin/planSetup',
        id: 'generalAdministrationPage'
      },
      {
        key: 'terminationInformationPageActive',
        menuHeading: 'Termination Information',
        menuSubheading: 'Add/Modify termination codes',
        menuIcon: 'termination-information.svg',
        linkTo: 'bankinfo',
        id: 'terminationInformationPage'
      },
      {
        key: 'matchingPageActive',
        menuHeading: 'Matching',
        menuSubheading: 'Specify employer matching',
        menuIcon: 'matching.svg',
        linkTo: 'bankinfo',
        id: 'matchingPage'
      },
      {
        key: 'errorSuppressionPageActive',
        menuHeading: 'Error Suppression',
        menuSubheading: 'Create custom error messages',
        menuIcon: 'error-suppression.svg',
        linkTo: 'bankinfo',
        id: 'errorSuppressionPage'
      },
      {
        key: 'optionalDataElementsPageActive',
        menuHeading: 'Optional Data Elements',
        menuSubheading: 'Update participant header and source date',
        menuIcon: 'optional-data-elements.svg',
       linkTo: 'admin/dataElements',
       id: 'optionalDataElementsPage'
      },
      {
        key: 'pageSecurityPageActive',
        menuHeading: 'Page Security',
        menuSubheading: 'Customize plan level sections',
        menuIcon: 'page-security.svg',
        linkTo: 'admin/pageSecurity',
        id: 'pageSecurity'
      },
      {
        key: 'copyPlanInfoToOtherPlansPageActive',
        menuHeading: 'Copy Plan Info To Other Plans',
        menuSubheading: '',
        menuIcon: 'copy-planInfo.svg',
        linkTo: 'admin/planCopy',
        id: 'copyPlanInfo'

      },
      {
        key: 'updateUserProfilePageActive',
        menuHeading: 'Update User Profile',
        menuSubheading: '',
        menuIcon: 'update-user-profile.svg',
        linkTo: 'bankinfo',
        id: 'updateUserProfilePage'
      }
    ];
