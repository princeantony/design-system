import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../services/modal.service';
@Component({
  selector: 'app-browser-info',
  templateUrl: './browser-info.component.html',
  styleUrls: ['./browser-info.component.scss']
})
export class BrowserInfoComponent implements OnInit {
imagePath: string;
  constructor(private modalService: ModalService) {
    this.imagePath =  'assets/images/browser/';
  }
  ngOnInit() {
  }
  closeModal(id: string) {
    this.modalService.close(id);
}
}
