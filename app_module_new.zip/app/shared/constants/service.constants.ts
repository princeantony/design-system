export const SERVICE_URL = {
  APP_URL: 'http://localhost:4200/payadmin/ws/ers/service/', // for local db testing
  // APP_URL: 'http://10.170.80.178:2608/payadmin/ws/ers/service/', // enable this before check-in, comment the above one

  //#region Common URL
  GET_COUNTRY: 'participant/countrylist',
  GET_STATE: 'common/country',
  //#endregion

  //#region Login URL
  GET_DIRECT_LOGIN_URL: 'login/direct',
  //#endregion

  //#region Plan & Home
  GET_LISTPLAN_URL: 'plans',
  GET_HOME_URL: 'plans/plan/',
  //#endregion

  //#region Bank Module
  GET_SUB_DIV_URL: 'plans/plan/{planNumber}divsub/',
  GET_BANK_INFO_URL: 'bankinfo/plan/',
  POST_BANK_INFO_URL: 'bankinfo/plan/',
  PUT_BANK_INFO_URL: 'bankinfo/plan/',
  //#endregion

  //#region Add Participant
  GET_ParticipantAdminSetting: '/service/participant/plan/{id}/options',
  //#endregion

  //#region Update Participant
  // NOTE:  Add all your update participant url here
  //#endregion

  //#region Batch Participant Update
  // NOTE:  Add all your Batch Participant Update url here
  //#endregion

  //#region File Import
  // NOTE:  Add all your File Import url here
  GET_TEMPLATE_NEW: 'participant/import/template/new/plan/',
  GET_TEMPLATE_OPTIONS: 'participant/import/template/plan/',
  POST_TEMPLATE_DELETE: 'participant/import/template/delete/plan/',
  POST_VALIDATE_FILEDATA: 'participant/import/plan/',
  FILEIMPORT_MAIN: 'common/import/plan/',
  POST_TEMPLATE_VERIFY: 'import/template/verify',
  //#endregion

  //#region Admin
  // NOTE:  Add all your Admin url here
  GET_PAGE_INFO_URL: 'admin/page/plan/',
  GET_PLAN_SETUP_URL: 'admin/plansetup/plan/',
  GET_OPTIONAL_DE_URL: 'admin/optionalde/plan/'
  //#endregion
};
