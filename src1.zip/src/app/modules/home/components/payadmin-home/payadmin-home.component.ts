import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payadmin-home',
  templateUrl: './payadmin-home.component.html',
  styleUrls: ['./payadmin-home.component.css']
})
export class PayAdminHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
