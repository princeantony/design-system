import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayadminHomeComponent } from './payadmin-home.component';

describe('PayadminHomeComponent', () => {
  let component: PayadminHomeComponent;
  let fixture: ComponentFixture<PayadminHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayadminHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayadminHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
