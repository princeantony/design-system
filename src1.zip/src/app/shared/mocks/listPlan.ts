export const ListPlan = [
    {
    "planId": 111111,
    "planName": "ABC Plan1"
    },
    {
        "planId": 22222,
        "planName": "ABC Plan2"
    },
    {
        "planId": 33333,
        "planName": "ABC Plan3"
    },
    {
        "planId": 444444,
        "planName": "ABC Plan4"
    },
    {
        "planId": 555555,
        "planName": "ABC Plan5"
    }

]