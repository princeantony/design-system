import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListPlansComponent } from '../../modules/plans/components/list-plans/list-plans.component';
import { PayAdminHomeComponent } from '../../modules/home/components/payadmin-home/payadmin-home.component';
const payAdmiinRoutes: Routes = [
  {
    path: 'plan',
    component: ListPlansComponent,
    outlet: 'popup'
  },
  {
    path: 'home/:id',
    component: PayAdminHomeComponent
  },
  
];

@NgModule({
  imports: [
    RouterModule.forRoot(payAdmiinRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    
    
  ]
})
export class PayAdminRoutingModule { }
export const PayAdminRoutingComponents = [ListPlansComponent, PayAdminHomeComponent];