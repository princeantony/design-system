export class Plan {
    planNumber: number;
    planText: string;
  }
  