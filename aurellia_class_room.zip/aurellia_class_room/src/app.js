import _ from 'lodash';
import {inject} from 'aurelia-framework';
import {UserService} from './services/user-service';
@inject(UserService)
export class App{
    constructor(userservice){
       userservice.getUsers().then(data =>  {this.users = data});
        //userservice.userList.then(data =>  {this.users = data});
        this.search = "";
        this.userList = [];
        this.newUser = {name: "prince"}
    }
    getSerchResult(e)
    {
        //this.userList = this.users.filter( user=> user.login.startsWith(this.search)); 
        this.userList = _.filter(this.users, user=> user.login.startsWith(this.search)); 
    };
    configureRouter(config, router) {
        config.map([
          { route: '', name: 'home', moduleId: PLATFORM.moduleName('./home/home') },
          { route: 'details/:login', name: 'details', moduleId: PLATFORM.moduleName('./details/userdetails') }
        ]);

        this.router = router;
      }
}
