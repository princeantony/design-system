export class About {     
  constructor() {
    this.message = 'about page';
  }

}