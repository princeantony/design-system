import {PLATFORM} from 'aurelia-pal';
export function configure(config) {
  config.globalResources([
    PLATFORM.moduleName('./value-converters/json'),
    PLATFORM.moduleName('./value-converters/filter'),
    PLATFORM.moduleName('./attributes/highlighter')
  ]);
}
