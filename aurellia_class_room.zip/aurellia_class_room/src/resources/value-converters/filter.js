export class FilterValueConverter {
  toView(value, query) {
     return value.filter(user=> user.name.startsWith(query)); 
  }
  fromView(value) {

  }
}

