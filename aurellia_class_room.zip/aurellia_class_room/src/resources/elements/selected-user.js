import {bindable} from 'aurelia-framework';

export class SelectedUser {
  @bindable value;
  @bindable title;
  valueChanged(newValue, oldValue) {
  }
}

