import {inject} from 'aurelia-framework';
import {AppService} from '../../app.service';
@inject(AppService)
export class userlist {
  constructor(appservice){
  this.users = appservice.getUsers();
  }
  showDetails(user)
  {
    this.selectedUser = user;
  }
}
