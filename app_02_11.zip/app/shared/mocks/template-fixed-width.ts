export const templateFW = {
                        "status": "SUCCESS",
                        "data": {
                            "columnList": [
                                {
                                    "key" : "ssn",
                                    "value" : "SSN",
                                    "startPosition" : "",
                                    "fieldWidth":""
                                },
                                {
                                    "key" : "divsub",
                                    "value" : "DivSub",
                                    "startPosition" : "",
                                    "fieldWidth":""
                                },
                                {
                                    "key" : "roth",
                                    "value" : "Roth",
                                    "startPosition" : "",
                                    "fieldWidth":""
                                },
                                {
                                    "key" : "firstName",
                                    "value" : "First Name",
                                    "startPosition" : "",
                                    "fieldWidth":""
                                }
                            ]
                    
                    }

}
  