export const templateData = {
  status: 'SUCCESS',
  data: {
    fileData: [['123456789', 'John'],
               ['123446785', 'Jane', 'Doe'],
               ['123446785', 'Jane', 'Doe'],
               ['123446785', 'Jane', 'Doe'],
               ['123446785', 'Jane', 'Doe'],
               ['123446785', 'Jane', 'Doe'],
              ['123446785', 'Jane', 'Doe'],
              ['123446785', 'Jane', 'Doe'],
              ['123446785', 'Jane', 'Doe'],
              ['123446785', 'Jane', 'Doe'],
              ['123446785', 'Jane', 'Doe']]
  }
};

export const templateOptions = {
  status: 'SUCCESS',
  data: {
    divsubEnabled: 'true',
    options: [
      {
        displayText: 'Template1',
        value: 'Template1'
      },

      {
        displayText: 'Template2',
        value: 'Template2'
      }
    ]
  }
};

export const newTemplate = {
  status: 'SUCCESS',
  data: {
    headerDropdownList: [
      {
        value: 'SSN',
        label: 'SSN'
      },
      {
        value: 'firstName',
        label: 'First Name'
      },
      {
        value: 'lastName',
        label: 'Last Name'
      },
      {
        value: 'lastName',
        label: 'Last Name'
      },
      {
        value: 'lastName',
        label: 'Last Name'
      },
      {
        value: 'lastName',
        label: 'Last Name'
      },
      {
        value: 'lastName',
        label: 'Last Name'
      },
      {
        value: 'lastName',
        label: 'Last Name'
      },
      {
        value: 'lastName',
        label: 'Last Name'
      }
    ],
    fileData: [['123456789', 'John', 'Doe'], ['123446785', 'Jane', 'Doe']]
  }
};

export const columnList = {
  status: 'SUCCESS',
  data: {
    availableColumnList: [
      {
        displayText: 'SSN',
        value: 'ssn'
      },
      {
        value: 'firstName',
        displayText: 'First Name'
      },
      {
        value: 'lastName',
        displayText: 'Last Name'
      },
      {
        value: 'firstName',
        displayText: 'First Name'
      },
      {
        value: 'firstName',
        displayText: 'First Name'
      },
      {
        value: 'firstName',
        displayText: 'First Name'
      },
      {
        value: 'firstName',
        displayText: 'First Name'
      },
      {
        value: 'lastName',
        displayText: 'Last Name'
      }
    ]
  }
};

export const validationData = {
  status: 'SUCCESS',
  data: {
    message: 'Success message',
    fileData: [
      {
        ssn: '123456789',
        firstName: 'John',
        lastName: 'Doe'
      },
      {
        ssn: '123446785',
        firstName: 'Jane',
        lastName: 'Doe'
      }
    ]
  }
};

export const validationDataWithErrors = {
  status: 'SUCCESS',
  data: {
    validationData: [
      {
        ssn: '123456789',
        name: 'John Doe',
        Error: 'Birth Date is not a date'
      },
      {
        ssn: '123456789',
        name: 'John Doe',
        Error:
          'Participant 123456789 is already on file. If the participant was previously terminated, please be sure to update the re-hire date/adjusted date of hire in the Participant Update Section'
      },
      {
        ssn: '123456789',
        name: 'John Doe',
        Error: 'Birth Date is not a date'
      },
      {
        ssn: '123456789',
        name: 'John Doe',
        Error:
          'Participant 123456789 is already on file. If the participant was previously terminated, please be sure to update the re-hire date/adjusted date of hire in the Participant Update Section'
      },
      {
        ssn: '123456789',
        name: 'John Doe',
        Error: 'Birth Date is not a date'
      },
      {
        ssn: '123456789',
        name: 'John Doe',
        Error:
          'Participant 123456789 is already on file. If the participant was previously terminated, please be sure to update the re-hire date/adjusted date of hire in the Participant Update Section'
      },
      {
        ssn: '123456789',
        name: 'John Doe',
        Error: 'Birth Date is not a date'
      },
      {
        ssn: '123456789',
        name: 'John Doe',
        Error:
          'Participant 123456789 is already on file. If the participant was previously terminated, please be sure to update the re-hire date/adjusted date of hire in the Participant Update Section'
      }
    ],

    fileData: [['123456789', 'John', 'Doe'], ['123446785', 'Jane', 'Doe']]
  }
};
export const existingTemplate = {
  status: 'SUCCESS',
  data: {
    templateId: 'mytemplate',
    headerCount: '1',
    trailerCount: '0',
    columnList: [
      {
        value: 'ssn',
        colNumber: '1'
      },
      {
        value: 'firstName',
        colNumber: '2'
      }
    ]
  }
};
export const saveTemplateResponse = {
  status: 'SUCCESS',
  message: 'Template last saved on Friday, September 28th, 2018 6:37:54 AM'
};
