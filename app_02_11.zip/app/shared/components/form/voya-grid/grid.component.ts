import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

import { PayAdminGlobalState } from '../../../store/pay-admin-global.store';



const pageSlot = 10;
@Component({
  selector: "voya-grid",
  templateUrl: "./grid.component.html"
})
export class GridComponent implements OnInit {
  @Input()
  rowData: any;
  @Input()
  columnDefs: any;
  @Input()
  context: any;
  @Input()
  frameworkComponents: any;
  @Input()
  rowClick: boolean;
  @Input()
  floatingFilter: boolean;
  @Input()
  rowStyle;
  @Input()
  headerHeight: any;
  @Input()
  hidePagination: boolean;
  @Input()
  rowMultiSelectWithClick: boolean;
  @Input()
  rowSelection: boolean;
  @Input()
  suppressRowClickSelection: boolean;
  @Input()
  enableTotalFooter: boolean;
  @Input()
  singleClickEdit: boolean;
  @Input()
  defaultColDef: any;
  @Input()
  suppressClickEdit: boolean;
  @Input() paginationPageSize = 20;
  @Input() style = 'width: 100%';
  @Output()
  onRowClicked = new EventEmitter<any>();
  @Output()
  onSelectionChanged =new EventEmitter<any>();
  @Output()
  onGridReady =new EventEmitter<any>();

  payAdminGlobal: PayAdminGlobalState;
  private gridApi;

  nextStatus = false;
  prevStatus = true;
  selectedPage = 1;
  btnNum = [];
  totalPages;
  minPage;
  maxPage;

  constructor(private router: Router) {}
  rowClicked(params) {
       this.onRowClicked.emit(params);
   }
   selectionChanged(event){
     this.onSelectionChanged.emit(event);
   }
   gridReady(params){
     this.onGridReady.emit(params);
     this.gridApi = params.api;
     if (this.gridApi) {
       this.initPagination();
     }
   }
  ngOnInit() {}
  initPagination(){
    this.totalPages = this.gridApi.paginationGetTotalPages();
      if (this.totalPages > pageSlot) {
        this.createPageSlot(0, pageSlot);
      } else {
        this.createPageSlot(0, this.totalPages);
        //this.nextStatus = true;
      }

  }
  createPageSlot(minNum: number, maxNum: number) {
    this.btnNum = [];
    this.minPage = minNum;
    this.maxPage = maxNum;
    for (let i = minNum; i < maxNum; i++) {
      //debugger;
      if (i + 1 <= this.totalPages) {
        this.btnNum.push(i + 1);
      } else {
        //this.nextStatus = true;
      }

    }

  }
  gotoPage(pageNum) {

    this.gridApi.paginationGoToPage(pageNum - 1);
    this.selectedPage = pageNum;
    if(this.selectedPage >1){
      this.prevStatus = false;
    }
    if(this.selectedPage === this.totalPages){
      this.nextStatus = true;
    }
  }

  gotoPrev() {
    this.nextStatus = false;
    if(this.selectedPage ===1){
      this.prevStatus = true;

    }
    else{
      this.selectedPage-=1;
      if(this.selectedPage<this.minPage+1){
        this.nextStatus = false;
        let firstNum = this.btnNum[0] - (pageSlot + 1);
        let lastNum = firstNum + pageSlot;
        this.createPageSlot(firstNum, lastNum);

      }
      this.gotoPage(this.selectedPage);
    }
  }
  gotoNext() {
    if(this.selectedPage === this.totalPages){
      this.nextStatus = true;
    }
    else{
      this.selectedPage +=1;
      if(this.selectedPage>this.maxPage){
        this.prevStatus = false;
      let minNum = this.btnNum[pageSlot - 1];
      let maxNum = minNum + pageSlot;
      this.createPageSlot(minNum, maxNum);
      }
      this.gotoPage(this.selectedPage);

  }
  }
  onPaginationChanged() {
    if (this.gridApi) {
      this.initPagination();
    }
  }
}
