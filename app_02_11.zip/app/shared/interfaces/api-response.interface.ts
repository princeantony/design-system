export interface IApiResponse{
    status: string,
    data: any
}