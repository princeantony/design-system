import { Component, OnInit } from '@angular/core';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { AdminService } from '../../../services/admin.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-admin-data-elements-page',
    templateUrl: './admin-data-elements-page.component.html'
})

export class AdminDataElementsPageComponent implements OnInit {
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    dEColumnDefs: any;
    dEList: any;

    constructor(private adminService: AdminService,     private router: Router) {
        this.dEColumnDefs = GRID_CONFIG.DATA_ELEMENTS.COLUMN_DEFS_ELEMENTS;
    }

    ngOnInit() {
      PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
      PayAdminGlobalState.currentPage = '/admin/dataElements';
        this.hidePageTitle = false;
        this.subTitle = 'Select Data Element Option'; // read from const
        this.planNumber = PayAdminGlobalState.planNumber;
        this.getDataElementList();
        console.log("header" + this.dEColumnDefs + "Row Data" + this.dEList);
    }

    handleChange() {
        console.log("New DE selected");
    }

    getDataElementList() {
        this.adminService.getDEList(this.planNumber).subscribe(flags => {
            if (flags.status === APP_CONST.SUCCESS) {
                this.dEList = flags.data;
                console.log("---------this.dEList", this.dEList);
            }
        });
    }
    gotoBack() {
      this.router.navigate([PayAdminGlobalState.previousPage]);
    }
}

