import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';
import {  GRID_CONFIG  } from '../../../../shared/constants/grid.constants';

@Component({
    selector: 'app-admin-plan-copy',
    templateUrl: './admin-plan-copy.component.html',
    styleUrls: ['./admin-plan-copy.component.scss']
  })

export class AdminPlanCopyComponent implements OnInit{
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    planCopyColumnDefs:any;
    planCopyData:any;
    private gridApi;
    selected:boolean = true;


    planCopyForm = this.fb.group({
      'allSegments': new FormControl('', Validators.required),
      'generalPlanInfo': new FormControl('', Validators.required),
      'planSources': new FormControl('', Validators.required),
      'planPages': new FormControl('', Validators.required),
      'planErrors': new FormControl('', Validators.required),
      'planDataElements': new FormControl('', Validators.required),

     
    });

   


    constructor( private fb: FormBuilder){ this.planCopyColumnDefs = GRID_CONFIG.PLAN_COPY.COLUMN_DEFS_PLANS;}

    ngOnInit() {
      this.hidePageTitle = false;
      this.subTitle = 'Plan Copy';
      this.planNumber ='559985';    
  
      this.planCopyData = [
          {planNumber:247632, planName: "ABC Plan" , plan: ""},
          {planNumber:247632, planName: "DEF Plan", plan: ""}
      ]
        
    }

    onSubmit(){
      console.log (this.gridApi.getSelectedRows());
    }

    gridReady(params) {
      console.log(params.api);
      this.gridApi = params.api;      
    }

    selectAll(value: any) {
      if (value == true){        
        this.planCopyForm.controls['generalPlanInfo'].setValue(true);
        this.planCopyForm.controls['planSources'].setValue(true);
        this.planCopyForm.controls['planPages'].setValue(true);
        this.planCopyForm.controls['planErrors'].setValue(true);
        this.planCopyForm.controls['planDataElements'].setValue(true);
      }

      if (value == false){
        this.planCopyForm.controls['generalPlanInfo'].setValue(false);
        this.planCopyForm.controls['planSources'].setValue(false);
        this.planCopyForm.controls['planPages'].setValue(false);
        this.planCopyForm.controls['planErrors'].setValue(false);
        this.planCopyForm.controls['planDataElements'].setValue(false);
      }

    
    }
}