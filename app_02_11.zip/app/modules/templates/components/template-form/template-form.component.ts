import { Component, Input, OnInit } from '@angular/core';

import { FormGroup } from '../../../../../../node_modules/@angular/forms';
import { dropdownItems } from '../../../../shared/config/template.config';
import { IListItem } from '../../../../shared/interfaces/list-item.interface';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.scss']
})
export class TemplateFormComponent implements OnInit {
  @Input() form: FormGroup;
  isDisabled: boolean;
  headerItems: IListItem[] = dropdownItems.slice(0);
  trailerItems: IListItem[] = dropdownItems.slice(0);
  constructor() { }

  ngOnInit() {
    this.form.controls['templateId'].disable();
    this.headerItems.push({displayText: 'No Headers', value: '0'});
    this.trailerItems.push({displayText: 'No Trailers', value: '0'});
  }

}
