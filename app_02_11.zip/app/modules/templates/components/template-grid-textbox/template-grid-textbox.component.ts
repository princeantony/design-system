import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from '../../../../../../node_modules/ag-grid-angular';

@Component({
  selector: 'app-template-grid-textbox',
  templateUrl: './template-grid-textbox.component.html',
  styleUrls: ['./template-grid-textbox.component.scss']
})
export class TemplateGridTextboxComponent implements ICellRendererAngularComp {
  params: any;
  value:any;
  api: any;

  constructor() { }

  agInit(params: any): void {
    this.api = params.api;
    this.params = params;
    params.value=this.value;
     this.value= params.value;
}

  refresh(): boolean {
    this.params.value= this.value;
    return true;
}
setValue(){
  this.params.data[this.params.colDef.field]=this.value;

}



}
