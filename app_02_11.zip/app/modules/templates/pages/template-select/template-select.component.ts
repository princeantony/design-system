import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import {
  SUB_TITLE,
  ENV,
  APP_CONST
} from '../../../../shared/constants/app.constants';
import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { Router } from '../../../../../../node_modules/@angular/router';
import { TemplatesService } from '../../services/templates.service';

@Component({
  selector: 'app-template-select',
  templateUrl: './template-select.component.html',
  styleUrls: ['./template-select.component.scss']
})
export class TemplateSelectComponent implements OnInit {
  hidePageTitle = false;
  subTitle: string;
  planNumber: string;
  templateOptions: any;
  isRequired = true;
  isDivSubEnabled = false;
  fileType: string;
  importType: string;
  selectTemplateForm = this.fb.group({
    templateSelect: []
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private templateService: TemplatesService
  ) {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.fileType = PayAdminGlobalState.importFileType;
    this.importType = PayAdminGlobalState.importType;
    this.subTitle = SUB_TITLE.TEMPLATE_SELECTION;
    if (ENV.TEST) {
      this.getMockTemplateList();
    } else {
      this.getTemplateList();
    // this.templateOptions = templateOptions;
    }
  }
  getMockTemplateList() {
    this.templateService.getMockTemplateOptions().subscribe(
      response => {
        console.log('------response', response);
        if (response.status === APP_CONST.SUCCESS) {
          this.isDivSubEnabled = response.data.divsubEnabled;
          this.templateOptions = response.data.options;
        }
      },
      err => {
        console.log('Error', err);
      }
    );
  }
  getTemplateList() {
    this.templateService
      .getTemplateOptions(this.planNumber, this.fileType, this.importType)
      .subscribe(
        response => {
          console.log('------response', response);
          if (response.status === APP_CONST.SUCCESS) {
            this.templateOptions = response.data.options;
            this.isDivSubEnabled = response.data.divsubEnabled;
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }

  createNewTemplate() {
    this.isRequired = false;
    if (
      this.fileType === 'csv' ||
      this.fileType === 'xls' ||
      this.fileType === 'xlsx' ||
      this.fileType === 'xlsm'
    )
      this.router.navigate(['/template/create']);
    else this.router.navigate(['/template/createFW']);
  }
  gotoBack() {
    this.router.navigate(['/fileImport']);
  }
  gotoExistingTemplate() {
    this.isRequired = true;
    let templateId = this.selectTemplateForm.value.templateSelect;
    if (templateId) this.router.navigate(['/template/existing/' + templateId]);
    console.log('------isRequired', this.isRequired);

    console.log('------isRequired', this.isRequired);
  }
  deleteTemplate() {
    this.isRequired = true;
    let templateObj = {
      templateId: this.selectTemplateForm.value.templateSelect,
      planId: this.planNumber,
      fileType: this.fileType
    };
    console.log('--------templateObj', templateObj);
    this.templateService.deleteTemplate(this.planNumber, templateObj).subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
        }
      },
      err => {
        console.log('Error', err);
      }
    );
  }
}
