import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


import { Observable } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';


import { HttpErrorHandler, HandleError } from './http-error-handler.service';



@Injectable()
export class ApiService {
  appUrl = '';  // URL to web api need to get if from config/run time
  private handleError: HandleError;


  constructor(private http: HttpClient,httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError('ServiceError');
  }
  

  private setHeaders(): Headers {
    const headersConfig = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  
    return new Headers(headersConfig);
  }
  get(apiMethod: string): Observable<any> {  
    return this.http.get<any>(this.appUrl + apiMethod)
      .pipe(
        catchError(this.handleError<any>('get', []))
      );
  }
  getByKey(apiMethod: string, key: string, value: string): Observable<any> {
    // Add safe, URL encoded search parameter if there is a get term
    const options = value ?{ params: new HttpParams().set(key, value) } : {};

    return this.http.get<any>(this.appUrl+apiMethod,  options)
      .pipe(
        catchError(this.handleError<any>('getByKey', []))
      );
  }
  getByObject(apiMethod: string, paramsObj: any): Observable<any> {
    // Add safe, URL encoded object as parameter if there is a get term
    const options = paramsObj ? { params: paramsObj } : {};

    return this.http.get<any>(this.appUrl+apiMethod, options)
      .pipe(
        catchError(this.handleError<any>('getByObject', []))
      );
  }

}