import { MenuItem } from "../interfaces/menu-item.interface";

export const MenuItems: MenuItem[] = [
  { menuHeading: "Add/Enroll", menuSubheading: "Add/Enroll Participants" },
  { menuHeading: "Participant Update", menuSubheading: "View/Update participant information" },
  { menuHeading: "Batch Participant Update", menuSubheading: "Update multiple participant" },
  { menuHeading: "Contributions", menuSubheading: "Process contributions to accounts" },
  { menuHeading: "Pending/Submitted Batches", menuSubheading: "Review batch information" },
  { menuHeading: "Loan Repayment", menuSubheading: "Process loan repayments" },
  { menuHeading: "Bank Information", menuSubheading: "Add or update assigned bank" },
  { menuHeading: "Administration", menuSubheading: "Review and update your settings" }
];

