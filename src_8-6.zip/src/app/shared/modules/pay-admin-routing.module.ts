import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlanSelectionComponent } from '../../modules/plans/pages/plan-selection/plan-selection.component';
import { PayAdminHomeComponent } from '../../modules/home/pages/pay-admin-home/pay-admin-home.component';

const payAdmiinRoutes: Routes = [
  {
    path: '',
    component: PlanSelectionComponent,
    data: { title: 'Plan List' }
  },
  {
    path: 'home/:planId',
    component: PayAdminHomeComponent
  },
  { 
    path: '**',
     component: PlanSelectionComponent 
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(payAdmiinRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    
    
  ]
})
export class PayAdminRoutingModule { }
export const PayAdminRoutingComponents = [PlanSelectionComponent, PayAdminHomeComponent];