import { ActionReducer, Action } from '@ngrx/store';
import{ACTION_TYPE} from '../../constants/app.constants';
export function PayAdminReducer(state: null, action) {
	 switch (action.type) {
        case ACTION_TYPE.LIST_PLAN:
            return Object.assign({}, state, {PlanList: action.plans});

		default:
			return state;
	}
}