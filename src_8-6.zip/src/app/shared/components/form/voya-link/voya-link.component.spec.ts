import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaLinkComponent } from './voya-link.component';

describe('VoyaLinkComponent', () => {
  let component: VoyaLinkComponent;
  let fixture: ComponentFixture<VoyaLinkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaLinkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
