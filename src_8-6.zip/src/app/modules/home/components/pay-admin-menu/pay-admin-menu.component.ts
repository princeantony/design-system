import { Component, OnInit } from '@angular/core';
import { MenuItem } from "../../../../shared/interfaces/menu-item.interface";
import { MenuItems } from "../../../../shared/mocks/menuItems-mock";
import Utils from "../../../../shared/utils/pay-admin.utils";
@Component({
  selector: 'app-pay-admin-menu',
  templateUrl: './pay-admin-menu.component.html',
  styleUrls: ['./pay-admin-menu.component.css'],
  providers: [Utils]
})
export class PayAdminMenuComponent implements OnInit {

  menuItems: MenuItem[];
  menuItemRows: Array<MenuItem[]>;

  constructor(private utils: Utils) {}

  ngOnInit() {
    this.menuItems = MenuItems;
    this.menuItemRows = this.utils.chunkArray(this.menuItems, 3);
    console.log(this.menuItemRows);
  }

}
