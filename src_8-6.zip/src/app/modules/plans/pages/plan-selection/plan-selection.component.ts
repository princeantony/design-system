import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plan-selection',
  templateUrl: './plan-selection.component.html',
  styleUrls: ['./plan-selection.component.scss']
})
export class PlanSelectionComponent implements OnInit {
  hidePageTitle: boolean = true;
  pageTitle = "Plan Selection"
  constructor() {
   }
  ngOnInit() {
  }
}
