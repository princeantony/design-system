import{ACTION_TYPE} from '../../../shared/constants/app.constants';
import {ListPlan} from '../../../shared/mocks/listPlan';

import {MockService} from '../../../shared/services/mock.service';

export function planListAction () {
let planList = null//MockService.getListPlans(); // should get if from actual service
    return {
        type: ACTION_TYPE.LIST_PLAN,
        plans: planList
    }
};