import { Store } from '@ngrx/store';
import { Component, OnInit} from '@angular/core';

import {COLUMN_DEFS} from '../../../../shared/constants/app.constants';
import {planListAction} from '../../../plans/actions/plan-list.action';
import {MockService} from '../../../../shared/services/mock.service';
import {ListPlan} from '../../../../shared/mocks/listPlan';
@Component({
  selector: 'app-list-plans',
  templateUrl: './list-plans.component.html',
  styleUrls: ['./list-plans.component.css']
})
export class ListPlansComponent implements OnInit {
//planLight : any = null;
constructor(){}
/*
  constructor(private store: Store<any>, private mockService: MockService){
		this.planLight = store.select('PayAdminReducer');
    if(!this.planLight)
    {
     this.planLight = this.getPlans();
    }
	}

  getPlans(): any {
    this.mockService.getListPlans()
        .subscribe(plans => this.planLight = plans);
  }
  */
  rowData=ListPlan;
  columnDefs = COLUMN_DEFS.LIST_PLAN;
  ngOnInit() {
  }

}
