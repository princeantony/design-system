import { Component} from '@angular/core';
import { ICellRendererAngularComp  } from 'ag-grid-angular';

@Component({
  selector: 'app-link',
  templateUrl: './plan-link.component.html',
  styleUrls: ['./plan-link.component.css']
})
export class PlanLinkComponent implements ICellRendererAngularComp  {
  constructor() {
   }
  public planNo: any;
 
  agInit(params: any): void {
      this.planNo = params;
  }
  refresh(): boolean {
      return false;
  }

}
