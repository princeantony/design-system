import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  NgForm
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';

import { CommonService } from '../../../../shared/services/common.service';
import { isEmptyObject } from '../../../../shared/utils/pay-admin.utils';
import { ParticipantContribution } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';
import { CONTRIBUTION_TYPE } from './contribution-input-group/contribution-input-group.component';

interface Item {
  label: string;
  value: string;
  readOnly: boolean;
  key: string;
  type: string;
}

interface FormControlMetadata {
  checkBoxLabel: string;
  checkBoxValue: string;
  controlLabel: string;
  controlName: string;
  controlValue: string;
  controlType: string;
  isReadOnly: boolean;
  controlValueType: string;
  formSection: string;
}

@Component({
  selector: 'participant-contribution-election',
  templateUrl: './participant-contribution-election.component.html',
  styleUrls: ['./participant-contribution-election.component.scss']
})
export class ParticipantContributionElectionComponent
  implements OnInit, AfterViewInit {
  constructor(
    private fb: FormBuilder,
    private participantsService: ParticipantsService,
    private common: CommonService,
    private router: Router,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager
  ) {}

  participantContributionForm: FormGroup;
  contributions: ParticipantContribution = {} as ParticipantContribution;
  contribElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  catchUpContribElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  investmentElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  contribElectionFormArray: FormArray = this.fb.array([]);
  catchUpContribElectionFormArray: FormArray = this.fb.array([]);
  investmentElectionFromArray: FormArray = this.fb.array([]);
  MaxContributionElectionExceeded = false;
  MaxCatchUpContributionElectionExceeded = false;
  MinCatchUpContributionElectionDeceeded = false;
  totalCatchUpContribElection = 0;
  totalContribElections = 0;
  private _editMode = false;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }
  ngOnInit() {
    this.spinner.show();
    if (
      isEmptyObject(ParticipantStore.ParticipantData.participantContribution)
    ) {
      this.participantsService
        .getParticipantContributionData$(this.EditMode)
        .subscribe(result => {
          if (result.status === 'SUCCESS') {
            this.contributions = result.data;
            ParticipantStore.ParticipantData.participantContribution =
              result.data;
          }
        });
      this.initForm();
    } else {
      this.contributions =
        ParticipantStore.ParticipantData.participantContribution;
      this.initForm();
    }
  }
  initForm() {
    // FormBuilding :Blue Print
    this.participantContributionForm = this.fb.group({
      contributionElection: this.contribElectionFormArray,
      catchUpContributionElection: this.catchUpContribElectionFormArray,
      investmentElection: this.investmentElectionFromArray
    });
    // TODO: if not items move to next screen
    // Add items to each section FromArray
    this.createContribElectionFormArray();
    this.createCatchUpContribElectionFormArray();
    this.createInvestmentElectionFromArray();
    this.spinner.hide();
  }

  ngAfterViewInit() {
    this.onChanges();
  }
  onChanges() {
    this.contribElections.forEach((_control, i) => {
      _control.valueChanges.subscribe(val => {
        if (!this.validateContribElection()) {
          _control.setErrors({ MaxContributionElectionExceeded: true });
          this.participantContributionForm.setErrors({ invalid: true });
        } else {
          this.participantContributionForm.setErrors({ invalid: false });
        }
      });
    });
    this.catchUpContribElections.forEach((_control, i) => {
      _control.valueChanges.subscribe(val => {
        this.getTotalCatchUpContribElections();
        if (!this.validateCatchUpContribElection()) {
          _control.setErrors({ CatchUpContribElectionRangeError: true });
          this.participantContributionForm.setErrors({ invalid: true });
        } else {
          this.participantContributionForm.setErrors({ invalid: false });
        }
      });
    });
  }

  validateContribElection() {
    this.MaxContributionElectionExceeded = false;
    this.getTotalContribElections();
    if (this.contributions.customEdit) {
      if (this.contributions.contribDeferralType === 'A') {
        if (
          this.totalContribElections > this.contributions.contribTotalMaxDefAmt
        ) {
          this.MaxContributionElectionExceeded = true;
          return false;
        }
      }
      if (this.contributions.contribDeferralType === 'P') {
        if (
          this.totalContribElections > this.contributions.contribTotalMaxDefPct
        ) {
          this.MaxContributionElectionExceeded = true;
          return false;
        }
      }
      return true;
    }
    return true;
  }
  validateCatchUpContribElection() {
    this.MaxCatchUpContributionElectionExceeded = false;
    this.MinCatchUpContributionElectionDeceeded = false;
    this.getTotalCatchUpContribElections();
    if (this.contributions.catchupDeferralType === 'A') {
      if (
        this.totalCatchUpContribElection >
        this.contributions.catchupContribTotalMaxDefAmt
      ) {
        this.MaxCatchUpContributionElectionExceeded = true;
        return false;
      }
      if (
        this.totalCatchUpContribElection <
        this.contributions.catchupContribTotalMinDefAmt
      ) {
        this.MinCatchUpContributionElectionDeceeded = true;
        return false;
      }
    }
    if (this.contributions.catchupDeferralType === 'P') {
      if (
        this.totalCatchUpContribElection >
        this.contributions.catchupContribTotalMaxDefPct
      ) {
        this.MaxCatchUpContributionElectionExceeded = true;
        return false;
      }
      if (
        this.totalCatchUpContribElection <
        this.contributions.catchupContribTotalMinDefPct
      ) {
        this.MinCatchUpContributionElectionDeceeded = true;
        return false;
      }
    }
    return true;
  }

  getTotalContribElections() {
    this.totalContribElections = 0;
    this.contribElections.forEach((_control, i) => {
      let curValue;
      curValue = (<FormGroup>_control).controls[
        this.contribElectionMetaDataList[i].controlName
      ].value;
      if (!curValue) {
        curValue = 0;
      }
      // Update Contribution Model
      this.contributions.contribElection[i].value = curValue;
      this.totalContribElections += parseFloat(curValue);
    });
  }

  getTotalCatchUpContribElections() {
    this.totalCatchUpContribElection = 0;
    this.catchUpContribElections.forEach((_control, i) => {
      let curValue;
      curValue = (<FormGroup>_control).controls[
        this.catchUpContribElectionMetaDataList[i].controlName
      ].value;
      if (!curValue) {
        curValue = 0;
      }
      this.contributions.catchupContribElection[i].value = curValue;
      this.totalCatchUpContribElection += parseFloat(curValue);
    });
  }

  createContribElectionFormArray() {
    this.contributions.contribElection.forEach(contributionElectionItem => {
      // Fill the metatdata to build the form
      this.contribElectionMetaDataList.push(
        this.addToFormControlMetaDataList(
          contributionElectionItem,
          this.contributions.contribDeferralType,
          'contribElection',
          'text'
        )
      );
      const controlKey: string = contributionElectionItem.key;
      const amountValue: string = parseFloat(
        contributionElectionItem.value
      ).toFixed(2);
      const percentValue: number = parseInt(contributionElectionItem.value, 10);
      contributionElectionItem.value =
        this.contributions.contribDeferralType === 'A'
          ? amountValue.toString()
          : percentValue.toString();
      const control: FormControl = new FormControl(
        contributionElectionItem.value
      );
      const controlGroup: FormGroup = this.fb.group({});
      controlGroup.addControl(controlKey, control);
      this.contribElectionFormArray.push(controlGroup);
    });
  }
  createCatchUpContribElectionFormArray() {
    this.contributions.catchupContribElection.forEach(
      catchUpContributionElectionItem => {
        // Fill the metatdata to build the form
        this.catchUpContribElectionMetaDataList.push(
          this.addToFormControlMetaDataList(
            catchUpContributionElectionItem,
            this.contributions.catchupDeferralType,
            'catchUpContribElection',
            'text'
          )
        );
        const controlKey: string = catchUpContributionElectionItem.key;
        const control: FormControl = new FormControl(
          catchUpContributionElectionItem.value
        );
        const controlGroup: FormGroup = this.fb.group({});
        controlGroup.addControl(controlKey, control);
        this.catchUpContribElectionFormArray.push(controlGroup);
      }
    );
  }
  createInvestmentElectionFromArray() {
    this.contributions.investmentElection.forEach(investmentElectionItem => {
      // Fill the metatdata to build the form
      this.investmentElectionMetaDataList.push(
        this.addToFormControlMetaDataList(
          investmentElectionItem,
          '',
          'investmentElection',
          'checkbox'
        )
      );
      const controlKey: string = investmentElectionItem.key;
      const control: FormControl = new FormControl(
        investmentElectionItem.value
      );
      const controlGroup: FormGroup = this.fb.group({});
      controlGroup.addControl(controlKey, control);
      this.investmentElectionFromArray.push(controlGroup);
    });
  }

  get contribElections() {
    return (<FormArray>(
      this.participantContributionForm.controls['contributionElection']
    )).controls;
  }

  get catchUpContribElections() {
    return (<FormArray>(
      this.participantContributionForm.controls['catchUpContributionElection']
    )).controls;
  }

  get investmentElections() {
    return (<FormArray>(
      this.participantContributionForm.controls['investmentElection']
    )).controls;
  }

  addToFormControlMetaDataList(
    item: Item,
    valueType: string,
    section: string,
    type: string
  ): FormControlMetadata {
    const _formControlMetaData: FormControlMetadata = {} as FormControlMetadata;
    _formControlMetaData.formSection = section;
    _formControlMetaData.controlType = type;
    _formControlMetaData.isReadOnly = item.readOnly;
    _formControlMetaData.controlName = item.key;
    _formControlMetaData.controlValueType = valueType;
    if (type === 'text') {
      _formControlMetaData.controlLabel = item.label;
      _formControlMetaData.controlValue = item.value;
    }
    if (type === 'checkbox') {
      _formControlMetaData.checkBoxLabel = item.label;
      _formControlMetaData.checkBoxValue = item.value;
    }
    return _formControlMetaData;
  }

  onContributionElectionTypeChanged(value: string) {
    this.contributions.contribDeferralType =
      value === CONTRIBUTION_TYPE.AMOUNT ? 'A' : 'P';
    this.MaxContributionElectionExceeded = false;
    for (let i = 0; i < this.contribElections.length; i++) {
      const control = this.contribElections[i] as FormGroup;
      const controlName = this.contribElectionMetaDataList[i].controlName;
      control.get(controlName).setValue('0');
    }
  }
  onCatchUpContributionElectionTypeChanged(value: string) {
    this.contributions.catchupDeferralType =
      value === CONTRIBUTION_TYPE.AMOUNT ? 'A' : 'P';
    for (let i = 0; i < this.catchUpContribElections.length; i++) {
      const control = this.catchUpContribElections[i] as FormGroup;
      const controlName = this.catchUpContribElectionMetaDataList[i]
        .controlName;
      control.get(controlName).setValue('0');
    }
  }

  onSubmit(form: NgForm) {
    // Update store
    ParticipantStore.ParticipantData.participantContribution = this.contributions;
    this.navigateToNext();
  }
  onBackClicked() {
    if (ParticipantStore.ParticipantOptionSetting.canLoadOptionalDataElements) {
      if (this.EditMode) {
        this.router.navigate(['UpdateParticipant/Optional']);
      } else {
        this.router.navigate(['addParticipant/Optional']);
      }
    } else {
      if (this.EditMode) {
        this.router.navigate(['UpdateParticipant']);
      } else {
        this.router.navigate(['participant']);
      }
    }
  }
  navigateToNext() {
    if (this.EditMode) {
      this.router.navigate(['UpdateParticipant/ContributionInvestment']);
    } else {
      this.router.navigate(['addParticipant/ContributionInvestment']);
    }
  }

  hasContributionData() {
    return true;
  }
}
