import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { Router } from '../../../../../../node_modules/@angular/router';
import { SUB_TITLE } from '../../../../shared/constants/app.constants';
import { SERVICE_URL } from '../../../../shared/constants/service.constants';

@Component({
  selector: 'app-plan-selection',
  templateUrl: './plan-selection.component.html'
})
export class PlanSelectionComponent implements OnInit {
  hidePageTitle  = false;
  pageTitleClass =  true;
  planNumberStatus = false;
  pageTitle = SUB_TITLE.PLAN_SELECTION;
  subTitle = SUB_TITLE.PLAN_SELECTION;
  constructor(private router: Router) {}
  ngOnInit() {
    PayAdminGlobalState.currentPage = SERVICE_URL.GET_LISTPLAN_URL;
    if (PayAdminGlobalState.planNumber) {
      this.planNumberStatus = true;
    }
  }
  gotoBack() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
}

