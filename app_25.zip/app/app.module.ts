import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbDateAdapter, NgbDateParserFormatter, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AgGridModule } from 'ag-grid-angular';
import { ToastModule, ToastOptions } from 'ng6-toastr/ng2-toastr';
import { NgxSpinnerModule } from 'ngx-spinner';
import {
  TextEditorComponent,
} from 'src/app/shared/components/ag-grid/editor/text-editor-max-forty/text-editor-max-forty.component';

import { environment } from '../environments/environment';
import { AppComponent } from './app.component';
import {
  AdminDataElementGridComponent,
} from './modules/admin/components/admin-data-elements/admin-data-element-grid/admin-data-element-grid.component';
import {
  AdminDataElementItemComponent,
} from './modules/admin/components/admin-data-elements/admin-data-element-item/admin-data-element-item.component';
import {
  DataElementTextboxComponent,
} from './modules/admin/components/admin-data-elements/admin-data-element-textbox/data-element-textbox.component';
import {
  AdminOptionsDataGridComponent,
} from './modules/admin/components/admin-data-elements/admin-options-data-grid/admin-options-data-grid.component';
import { AdminGridCheckboxComponent } from './modules/admin/components/admin-grid-checkbox/admin-grid-checkbox.component';
import {
  AdminGridEditButtonComponent,
} from './modules/admin/components/admin-grid-edit-button/admin-grid-edit-button.component';
import { AdminGridEditComponent } from './modules/admin/components/admin-grid-edit/admin-grid-edit.component';
import { AdminGridRadioComponent } from './modules/admin/components/admin-grid-radio/admin-grid-radio.component';
import {
  AdminGridSelectAllComponent,
} from './modules/admin/components/admin-grid-select-all/admin-grid-select-all.component';
import { AdminGridTextboxComponent } from './modules/admin/components/admin-grid-textbox/admin-grid-textbox.component';
import { AdminMenuComponent } from './modules/admin/components/admin-menu/admin-menu.component';
import { AdminPageSetupComponent } from './modules/admin/components/admin-page-setup/admin-page-setup.component';
import {
  AdminPlanCopyModalComponent,
} from './modules/admin/components/admin-plan-copy-modal/admin-plan-copy-modal.component';
import {
  AdminPlanSetupGridComponent,
} from './modules/admin/components/admin-plan-setup-grid/admin-plan-setup-grid.component';
import { AdminClientGridComponent } from './modules/admin/components/admin-termination-info/admin-client-grid.component';
import { DEModalComponent } from './modules/admin/components/data-element-modal/de-modal.component';
import { PlanSetupModalComponent } from './modules/admin/components/plan-setup-modal/plan-setup-modal.component';
import {
  AdminDataElementSelectComponent,
} from './modules/admin/pages/admin-data-elements/admin-data-element-select/admin-data-element-select.component';
import {
  AdminDataElementsPageComponent,
} from './modules/admin/pages/admin-data-elements/admin-data-elements-page/admin-data-elements-page.component';
import {
  AdminOptionDataComponent,
} from './modules/admin/pages/admin-data-elements/admin-option-data/admin-option-data.component';
import {
  AdminOptionsDataComponent,
} from './modules/admin/pages/admin-data-elements/admin-options-data/admin-options-data.component';
import { AdminHomeComponent } from './modules/admin/pages/admin-home/admin-home.component';
import { AdminPageSecurityComponent } from './modules/admin/pages/admin-page-security/admin-page-security.component';
import { AdminPlanCopyComponent } from './modules/admin/pages/admin-plan-copy/admin-plan-copy.component';
import { AdminPlanSetupComponent } from './modules/admin/pages/admin-plan-setup/admin-plan-setup.component';
import {
  AdminClientSpecificComponent,
} from './modules/admin/pages/admin-termination-information/admin-client-specific/admin-client-specific.component';
import {
  AdminReviewUpdateComponent,
} from './modules/admin/pages/admin-termination-information/admin-review-update/admin-review-update.component';
import { BankListComponent } from './modules/bank-information/components/bank-list/bank-list.component';
import { BankModalComponent } from './modules/bank-information/components/bank-modal/bank-modal.component';
import { BankSubmitComponent } from './modules/bank-information/components/bank-submit/bank-submit.component';
import { DisclosureComponent } from './modules/bank-information/components/disclosure/disclosure.component';
import { GridLinkComponent } from './modules/bank-information/components/grid-link/grid-link.component';
import { HelpComponent } from './modules/bank-information/components/help/help.component';
import { SubDivModalComponent } from './modules/bank-information/components/subdiv-modal/subdiv-modal.component';
import { BankAvailableComponent } from './modules/bank-information/pages/bank-available/bank-available.component';
import { ConfirmationComponent } from './modules/bank-information/pages/confirmation/confirmation.component';
import { CreateComponent } from './modules/bank-information/pages/create/create.component';
import {
  BatchGridDatePickerComponent,
} from './modules/batch-participant/components/batch-grid-date-picker/batch-grid-date-picker.component';
import {
  BatchGridDropdownComponent,
} from './modules/batch-participant/components/batch-grid-dropdown/batch-grid-dropdown.component';
import { BatchGridLinkComponent } from './modules/batch-participant/components/batch-grid-link/batch-grid-link.component';
import {
  BatchUpdateGridComponent,
} from './modules/batch-participant/components/batch-update-grid/batch-update-grid.component';
import {
  BatchParticipantActiveComponent,
} from './modules/batch-participant/pages/batch-participant-active/batch-participant-active.component';
import {
  BatchParticipantUpdateComponent,
} from './modules/batch-participant/pages/batch-participant-update/batch-participant-update.component';
import { PayAdminMenuComponent } from './modules/home/components/pay-admin-menu/pay-admin-menu.component';
import { PayAdminHomeComponent } from './modules/home/pages/pay-admin-home/pay-admin-home.component';
import { LoginComponent } from './modules/login/components/login.component';
import { LoginPageComponent } from './modules/login/pages/login-page.component';
import {
  ContributionInputGroupComponent,
} from './modules/participants/components/participant-contribution-election/contribution-input-group/contribution-input-group.component';
import {
  ParticipantContributionElectionComponent,
} from './modules/participants/components/participant-contribution-election/participant-contribution-election.component';
import {
  ParticipantInvestmentElectionComponent,
} from './modules/participants/components/participant-investment-election/participant-investment-election.component';
import {
  ParticipantModalQDIAComponent,
} from './modules/participants/components/participant-modal-qdia/participant-modal-qdia.component';
import {
  ParticipantOptionalDataComponent,
} from './modules/participants/components/participant-optional-data/participant-optional-data.component';
import {
  ParticipantRequiredDataComponent,
} from './modules/participants/components/participant-required-data/participant-required-data.component';
import {
  ParticipantAddContributionElectionComponent,
} from './modules/participants/pages/participant-add-contribution-election/participant-add-contribution-election.component';
import {
  ParticipantAddInvestmentElectionComponent,
} from './modules/participants/pages/participant-add-investment-election/participant-add-investment-election.component';
import {
  ParticipantAddOptionalComponent,
} from './modules/participants/pages/participant-add-optional/participant-add-optional.component';
import { ParticipantAddComponent } from './modules/participants/pages/participant-add/participant-add.component';
import {
  ParticipantConfirmationComponent,
} from './modules/participants/pages/participant-confirmation/participant-confirmation.component';
import {
  ParticipantImportFileComponent,
} from './modules/participants/pages/participant-import/participant-import-file/participant-import-file.component';
import {
  ParticipantVerifyDataComponent,
} from './modules/participants/pages/participant-import/participant-verify-data/participant-verify-data.component';
import { ParticipantSearchComponent } from './modules/participants/pages/participant-search/participant-search.component';
import {
  ParticipantUpdateContributionElectionComponent,
} from './modules/participants/pages/participant-update-contribution-election/participant-update-contribution-election.component';
import {
  ParticipantUpdateInvestmentElectionComponent,
} from './modules/participants/pages/participant-update-investment-election/participant-update-investment-election.component';
import {
  ParticipantUpdateOptionalComponent,
} from './modules/participants/pages/participant-update-optional/participant-update-optional.component';
import { ParticipantUpdateComponent } from './modules/participants/pages/participant-update/participant-update.component';
import { PlanListComponent } from './modules/plans/components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';
import { TemplateFormComponent } from './modules/templates/components/template-form/template-form.component';
import {
  TemplateGridHeaderComponent,
} from './modules/templates/components/template-grid-header/template-grid-header.component';
import { TemplateGridLinkComponent } from './modules/templates/components/template-grid-link/template-grid-link.component';
import {
  TemplateGridTextboxComponent,
} from './modules/templates/components/template-grid-textbox/template-grid-textbox.component';
import { TemplateGridComponent } from './modules/templates/components/template-grid/template-grid.component';
import {
  TemplateModalConfirmDeleteComponent,
} from './modules/templates/components/template-modal-confirm-delete/template-modal-confirm-delete.component';
import {
  TemplateModalErrorComponent,
} from './modules/templates/components/template-modal-error/template-modal-error.component';
import {
  TemplateModalHelpComponent,
} from './modules/templates/components/template-modal-help/template-modal-help.component';
import {
  TemplateCreateFWComponent,
} from './modules/templates/pages/template-create-fixed-width/template-create-fixed-width.component';
import {
  TemplateCreateComponent,
} from './modules/templates/pages/template-create-with-errors/template-create-with-errors.component';
import {
  TemplateExistingFixedWidthComponent,
} from './modules/templates/pages/template-existing-fixed-width/template-existing-fixed-width.component';
import { TemplateExistingComponent } from './modules/templates/pages/template-existing/template-existing.component';
import { TemplateFileImportComponent } from './modules/templates/pages/template-file-import/template-file-import.component';
import { TemplateSelectComponent } from './modules/templates/pages/template-select/template-select.component';
import {
  TemplateVerificationComponent,
} from './modules/templates/pages/template-verification/template-verification.component';
import { TestPocComponent } from './modules/test-poc/test-poc.component';
import { DateEditorComponent } from './shared/components/ag-grid/editor/date-editor/date-editor.component';
import { FloatEditorComponent } from './shared/components/ag-grid/editor/float-editor/float-editor.component';
import { NumericEditorComponent } from './shared/components/ag-grid/editor/numeric-editor/numeric-editor.component';
import { SquareRenderer } from './shared/components/ag-grid/renderer/square-renderer.component';
import { AlertModalComponent } from './shared/components/alert-modal/alert-modal.component';
import { BrowserInfoComponent } from './shared/components/browser-info/browser-info.component';
import { BaseInputComponent } from './shared/components/form/base-input/base-input.component';
import { VoyaAccountNumberComponent } from './shared/components/form/voya-account-number/voya-account-number.component';
import { VoyaButtonComponent } from './shared/components/form/voya-button/voya-button.component';
import { VoyaCheckboxComponent } from './shared/components/form/voya-checkbox/voya-checkbox.component';
import { NgbDateCustomParserFormatter } from './shared/components/form/voya-date/dateformat';
import { NgbDateNativeUtcAdapterService } from './shared/components/form/voya-date/ngb-date-native-utc-adapter.service';
import { VoyaDateComponent } from './shared/components/form/voya-date/voya-date.component';
import { VoyaEmailComponent } from './shared/components/form/voya-email/voya-email.component';
import { GridComponent } from './shared/components/form/voya-grid/grid.component';
import { VoyaLabelComponent } from './shared/components/form/voya-label/voya-label.component';
import { VoyaLinkComponent } from './shared/components/form/voya-link/voya-link.component';
import { VoyaPagingComponent } from './shared/components/form/voya-paging/voya-paging.component';
import { VoyaRadioComponent } from './shared/components/form/voya-radio/voya-radio.component';
import { VoyaRoutingNumberComponent } from './shared/components/form/voya-routing-number/voya-routing-number.component';
import { VoyaSelectNewComponent } from './shared/components/form/voya-select-new/voya-select-new.component';
import { VoyaSelectComponent } from './shared/components/form/voya-select/voya-select.component';
import { VoyaSsnComponent } from './shared/components/form/voya-ssn/voya-ssn.component';
import { VoyaTextboxComponent } from './shared/components/form/voya-textbox/voya-textbox.component';
import { VoyaZipComponent } from './shared/components/form/voya-zip/voya-zip.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { HeaderComponent } from './shared/components/layout/header/header.component';
import { PageHeaderComponent } from './shared/components/layout/page-header/page-header.component';
import { PageTitleComponent } from './shared/components/layout/page-title/page-title.component';
import { SpinnerComponent } from './shared/components/layout/spinner/spinner.component';
import { TitleMessageComponent } from './shared/components/layout/title-message/title-message.component';
import { TimeInfoComponent } from './shared/components/time-info/time-info.component';
import { DateDirective } from './shared/directives/date.directive';
import { ModalComponent } from './shared/directives/modal.component';
import { VoyaCurrencyDirective } from './shared/directives/voya-currency.directive';
import { NumberDirective } from './shared/directives/voya-number.directive';
import { SSNDirective } from './shared/directives/voya-ssn.directive';
import { PayAdminRoutingComponents, PayAdminRoutingModule } from './shared/modules/pay-admin-routing.module';
import { VoyaCurrencyPipe } from './shared/pipes/voya-currency.pipe';
import { VoyaDatePipe } from './shared/pipes/voya-date.pipe';
import { VoyaSSNPipe } from './shared/pipes/voya-SSN.pipe';
import { ApiService } from './shared/services/api.service';
import { ModalService } from './shared/services/modal.service';
import { Utils } from './shared/utils/pay-admin.utils';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    PlanListComponent,
    PlanSelectionComponent,
    HeaderComponent,
    GridComponent,
    PayAdminHomeComponent,
    PayAdminRoutingComponents,
    TimeInfoComponent,
    PageTitleComponent,
    PayAdminMenuComponent,
    VoyaLinkComponent,
    BrowserInfoComponent,
    BankAvailableComponent,
    BankListComponent,
    BankSubmitComponent,
    ConfirmationComponent,
    CreateComponent,
    VoyaPagingComponent,
    GridLinkComponent,
    BankModalComponent,
    DisclosureComponent,
    TitleMessageComponent,
    HelpComponent,
    SpinnerComponent,

    ParticipantAddComponent,
    ParticipantAddOptionalComponent,
    ParticipantContributionElectionComponent,
    ParticipantAddInvestmentElectionComponent,
    ParticipantAddContributionElectionComponent,
    ParticipantUpdateContributionElectionComponent,
    ParticipantUpdateInvestmentElectionComponent,
    ParticipantUpdateOptionalComponent,
    ParticipantUpdateComponent,
    ParticipantRequiredDataComponent,
    ParticipantOptionalDataComponent,
    ParticipantInvestmentElectionComponent,
    ModalComponent,
    VoyaCurrencyDirective,
    SSNDirective,
    NumberDirective,
    VoyaCurrencyPipe,
    VoyaSSNPipe,
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent,
    GridComponent,
    VoyaLinkComponent,
    VoyaEmailComponent,
    VoyaZipComponent,
    VoyaSelectComponent,
    VoyaPagingComponent,
    VoyaSsnComponent,
    VoyaRoutingNumberComponent,
    ContributionInputGroupComponent,
    AdminMenuComponent,
    AdminHomeComponent,
    AdminPageSetupComponent,
    AdminPageSecurityComponent,
    VoyaCheckboxComponent,
    VoyaRadioComponent,
    AdminPlanSetupComponent,
    AdminGridCheckboxComponent,
    AdminGridTextboxComponent,
    VoyaDateComponent,
    NumericEditorComponent,
    AdminPlanSetupGridComponent,
    VoyaAccountNumberComponent,
    SquareRenderer,
    PageHeaderComponent,
    ParticipantConfirmationComponent,
    TemplateFileImportComponent,
    TemplateCreateComponent,
    TemplateCreateFWComponent,
    TemplateSelectComponent,
    TemplateGridComponent,
    TemplateExistingComponent,
    TemplateGridHeaderComponent,
    TemplateGridTextboxComponent,
    TemplateFormComponent,
    TemplateModalErrorComponent,
    TemplateVerificationComponent,
    ParticipantSearchComponent,
    SubDivModalComponent,
    AdminDataElementItemComponent,
    AdminOptionsDataGridComponent,
    AdminOptionDataComponent,
    AdminOptionsDataComponent,
    AdminDataElementSelectComponent,
    LoginPageComponent,
    LoginComponent,
    DateDirective,
    TemplateGridLinkComponent,
    ParticipantImportFileComponent,
    ParticipantVerifyDataComponent,
    TemplateModalHelpComponent,
    BaseInputComponent,
    AdminPlanCopyComponent,
    AdminGridSelectAllComponent,
    AdminReviewUpdateComponent,
    AdminGridEditComponent,
    DateDirective,
    VoyaSelectNewComponent,
    AdminGridEditButtonComponent,
    AdminClientSpecificComponent,
    AdminGridRadioComponent,
    AdminDataElementsPageComponent,
    AdminDataElementGridComponent,
    AdminClientGridComponent,
    DataElementTextboxComponent,
    TemplateExistingFixedWidthComponent,
    DEModalComponent,
    TemplateModalConfirmDeleteComponent,
    BatchParticipantUpdateComponent,
    BatchParticipantActiveComponent,
    BatchGridLinkComponent,
    BatchUpdateGridComponent,
    BatchGridDropdownComponent,
    BatchGridDatePickerComponent,
    DateEditorComponent,
    FloatEditorComponent,
    PlanSetupModalComponent,
    AdminPlanCopyModalComponent,
    ParticipantModalQDIAComponent,
    AlertModalComponent,
    TestPocComponent,
    TextEditorComponent,
    VoyaDatePipe
  ],
  imports: [
    BrowserModule,
    PayAdminRoutingModule,
    NgxSpinnerModule,
    HttpClientModule,
    NgSelectModule,
    FormsModule,
    BrowserAnimationsModule,
    ToastModule.forRoot(),
    ReactiveFormsModule,
    NgbModule,

    AgGridModule.withComponents([
      GridLinkComponent,
      AdminGridCheckboxComponent,
      AdminGridTextboxComponent,
      DataElementTextboxComponent,
      SquareRenderer,
      NumericEditorComponent,
      TemplateGridHeaderComponent,
      TemplateGridTextboxComponent,
      TemplateGridLinkComponent,
      AdminGridEditButtonComponent,
      AdminGridRadioComponent,
      BatchGridLinkComponent,
      BatchGridDatePickerComponent,
      BatchGridDropdownComponent,
      DateEditorComponent,
      FloatEditorComponent,
      TextEditorComponent
    ]),
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      logOnly: environment.production
    })
  ],
  providers: [
    ModalService,
    ApiService,
    Utils,
    ToastOptions,
    VoyaDatePipe,
    { provide: NgbDateAdapter, useClass: NgbDateNativeUtcAdapterService },
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
