import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { AuthService } from '../../login/services/auth.service';

const noop = () => {};

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isLabelHidden: boolean;
  errorCount = 0;
  private _onTouchedCallback: (_: any) => void = noop;
  private _onChangeCallback: (_: any) => void = noop;
  public loginFail;
  constructor(
    private router: Router,
    private authService: AuthService,
    private toastr: ToastsManager,
    private spinner: NgxSpinnerService,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.loginForm = new FormGroup({
      username: new FormControl('SPAYNG01', Validators.required),
      password: new FormControl('VOYA12345', Validators.required),
      clientId: new FormControl('INGWIN', Validators.required),
      divisionId: new FormControl('WIN', Validators.required)
    });
  }

  onSubmit() {
    if (
      this.loginForm.value.username &&
      this.loginForm.value.password &&
      this.loginForm.value.clientId &&
      this.loginForm.value.divisionId
    ) {
      PayAdminGlobalState.loginUser = {
        userName: this.loginForm.value.username,
        password: this.loginForm.value.password,
        clientId: this.loginForm.value.clientId,
        divisionId: this.loginForm.value.divisionId
      };
      PayAdminGlobalState.loginStatus = false;
      this.login();
    } else {
      this.loginFail = true;
    }
  }

  login(): void {
    this.errorCount++;
    this.authService.doAuthenticte(PayAdminGlobalState.loginUser).subscribe(
      loginInfo => {
        if (loginInfo.status === APP_CONST.SUCCESS) {
          PayAdminGlobalState.loginStatus = true;
          // this.router.navigate(['/app']);
          this.router.navigate(['/plans']);
        } else {
          this.toastr.error(loginInfo.error.msg, loginInfo.status + ' !', {
            showCloseButton: true
          });
        }
      },
      err => {
        if (this.errorCount < 4) {
          this.login();
        } else {
          this.spinner.hide();
          this.toastr.error(
            'Error while authenticating PayAdmin. Click on Logout to try again!',
            err.error.status + ' !',
            { showCloseButton: true }
          );
        }
      }
    );
  }

  onTouched(event: any) {
    if (event.target.value === '') {
      this.isLabelHidden = true;
    }
    if (event.target.value !== '') {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus() {
    this.isLabelHidden = false;
  }
}
