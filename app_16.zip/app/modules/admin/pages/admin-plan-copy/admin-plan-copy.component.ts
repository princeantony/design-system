import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { PlanService } from 'src/app/modules/plans/services/plan.service';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';
import { AdminDataService } from '../../services/admin-data.service';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-admin-plan-copy',
  templateUrl: './admin-plan-copy.component.html',
  styleUrls: ['./admin-plan-copy.component.scss']
})
export class AdminPlanCopyComponent implements OnInit {
  hidePageTitle: boolean;
  subTitle: string;
  planNumber: string;
  planCopyColumnDefs: any;
  planCopyData: any;
  private gridApi;
  selected = true;
  errorCount = 0;

  planCopyForm = this.fb.group({
    allSegments: new FormControl(false, Validators.required),
    generalPlanInfo: new FormControl(false, Validators.required),
    planSources: new FormControl(false, Validators.required),
    planPages: new FormControl(false, Validators.required),
    planErrors: new FormControl(false, Validators.required),
    planDataElements: new FormControl(false, Validators.required)
  });
  constructor(
    private fb: FormBuilder,
    private planService: PlanService,
    private adminService: AdminService,
    private modalService: ModalService,
    private spinner: NgxSpinnerService,
    private router: Router,
    public toastr: ToastsManager,
    vcr: ViewContainerRef
  ) {
    this.planCopyColumnDefs = GRID_CONFIG.PLAN_COPY.COLUMN_DEFS_PLANS;
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.hidePageTitle = false;
    this.subTitle = 'Plan Copy';
    this.planNumber = PayAdminGlobalState.planNumber;
    this.getPlans();
  }

  onSubmit() {
    this.modalService.open('plan-copy-modal');
  }
  OnContinue() {
    console.log(this.gridApi.getSelectedRows());
    const targetPlans = [];
    this.gridApi.getSelectedRows().forEach(plan => {
      targetPlans.push(plan.planNumber);
    });
    const postObj = this.planCopyForm.value;
    postObj.targetPlans = targetPlans;
    this.adminService.putPlanCopy(this.planNumber, postObj).subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          AdminDataService.successMsg = 'Plan Information successfully Copied';
          this.router.navigate(['/admin']);
        }
      },
      err => {
        this.toastr.error(
          'Error while copying Plans. Try again!',
          err.error.status + ' !',
          { showCloseButton: true }
        );
      }
    );
  }

  gridReady(params) {
    console.log(params.api);
    this.gridApi = params.api;
  }
  getPlans(): void {
    this.planService.getPlans().subscribe(
      plans => {
        this.spinner.hide();
        if (plans.status === APP_CONST.SUCCESS) {
          this.planCopyData = plans.data;
          // PayAdminGlobalState.planListState = this.planData; // will enable if we use local state
        } else {
          this.toastr.error(plans.error.msg, plans.status + ' !', {
            showCloseButton: true
          });
        }
      },
      err => {
        this.spinner.hide();
        this.errorCount++;
        if (err.error && err.error.text) {
          if (this.errorCount < 4) {
            this.getPlans();
          }
        } else {
          this.spinner.hide();
          this.toastr.error(
            'Error while fetching Plans. Try again!',
            err.error.status + ' !',
            { showCloseButton: true }
          );
        }
      }
    );
  }
  selectAll(value: any) {
    console.log(value);
    this.planCopyForm.controls['generalPlanInfo'].setValue(value);
    this.planCopyForm.controls['planSources'].setValue(value);
    this.planCopyForm.controls['planPages'].setValue(value);
    this.planCopyForm.controls['planErrors'].setValue(value);
    this.planCopyForm.controls['planDataElements'].setValue(value);
  }
  gotoPrevious() {
    this.router.navigate(['/admin']);
  }
}
