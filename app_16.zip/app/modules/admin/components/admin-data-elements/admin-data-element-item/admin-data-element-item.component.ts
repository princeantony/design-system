import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import {
  AddEnrollmentOptions,
  BatchParticipantOptions,
  ContributionOptions,
  ParticipantOptions,
} from 'src/app/shared/config/data-element.config';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { APP_CONST } from '../../../../../shared/constants/app.constants';
import { ModalService } from '../../../../../shared/services/modal.service';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-data-element-item',
  templateUrl: './admin-data-element-item.component.html'
})

export class AdminDataElementItemComponent implements OnInit {

  hidePageTitle: boolean;
  subTitle: string;
  planNumber: string;
  selectedDataElement: any;
  participantOptions : any;
  addEnrollmentOptions: any;
  contributionOptions: any;
  isButtonDisabled = true;
  batchParticipantOptions: any;
  selectedDEId : string;
  modelId = 'deModal';
  type = 'Data Element';
  isCreate = true;
  disableAccumulate = false;
  disableUserOverride = false;
  disableAccUserOverride = false;
  showAccumulateDetails = false;

   updateOtionalDataForm = this.fb.group({
    objectID: ['', Validators.required],
    subObjectID: ['', Validators.required],
    dataElement: ['', Validators.required],
    omniName: [''],
    overrideName: [''],
    overrideFlag: [''],
    enrollmentUsageCode: ['', Validators.required],
    participantUsageCode: ['', Validators.required],
    contributionUsageCode: ['', Validators.required],
    censusUsageCode: ['', Validators.required],
    accumulate: ['', Validators.required],
    accOverFlag: [''],
    accOverName: ['']
  });
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    private modalService: ModalService,
    private adminService: AdminService){
  }
  populateForm(dataElement) {
    this.updateOtionalDataForm.controls['objectID'].setValue(dataElement.objectID);
    this.updateOtionalDataForm.controls['subObjectID'].setValue(dataElement.subObjectID);
    this.updateOtionalDataForm.controls['dataElement'].setValue(dataElement.dataElement);
    this.updateOtionalDataForm.controls['omniName'].setValue(dataElement.omniName);
    this.updateOtionalDataForm.controls['overrideName'].setValue(dataElement.overrideName);
    this.updateOtionalDataForm.controls['overrideFlag'].setValue((dataElement.overrideFlag) ? true : false);
    this.updateOtionalDataForm.controls['accumulate'].setValue(dataElement.accumulate);
    this.updateOtionalDataForm.controls['enrollmentUsageCode'].setValue(dataElement.enrollmentUsageCode);
    this.updateOtionalDataForm.controls['participantUsageCode'].setValue(dataElement.participantUsageCode);
    this.updateOtionalDataForm.controls['contributionUsageCode'].setValue(dataElement.contributionUsageCode);
    this.updateOtionalDataForm.controls['censusUsageCode'].setValue(dataElement.censusUsageCode);
    this.updateOtionalDataForm.controls['accOverFlag'].setValue(dataElement.accOverFlag);
    this.updateOtionalDataForm.controls['accOverName'].setValue(dataElement.accOverName);
  }

  ngOnInit() {
    PayAdminGlobalState.previousPage = 'admin';
    PayAdminGlobalState.currentPage = 'admin/createOrEdit';
    this.planNumber = PayAdminGlobalState.planNumber;
    this.participantOptions = ParticipantOptions;

     if (AdminDataService.dataElement && AdminDataService.dataElement.showLOA) {
       const newObj = [{'displayText': 'LOA Functionality', 'value': 'L'}]
        this.participantOptions = _.unionWith(this.participantOptions, newObj,  _.isEqual);
      }
    this.addEnrollmentOptions = AddEnrollmentOptions;
    this.contributionOptions = ContributionOptions;
    this.batchParticipantOptions = BatchParticipantOptions;
    if (AdminDataService.dataElement && AdminDataService.dataElement.optionalElementID ) {
    this.isButtonDisabled = false;
    this.isCreate = false;
    this.selectedDataElement = AdminDataService.dataElement;

    this.selectedDEId = AdminDataService.dataElement.optionalElementID;
    this.populateForm(this.selectedDataElement);
    this.selectAccumulate(this.selectedDataElement.optionalElementID);
    this.enableDisableFields(this.selectedDataElement);
    }
  }
  enableDisableFields(dataElement)
  {
      this.disableUserOverride = dataElement.overrideFlag;
      this.disableAccUserOverride = dataElement.accOverFlag;
  }
  selectAccumulate(_optionalElementID){
    if ( _.endsWith(_optionalElementID.toUpperCase(), 'PH085')  || _.endsWith(_optionalElementID.toUpperCase(), 'PH340')) {
    this.disableAccumulate = false;
     this.showAccumulateDetails = true;
   } else {
     this.disableAccumulate = true;
     this.showAccumulateDetails = false;
   }
  }
  get objectID() {
    return this.updateOtionalDataForm.get('objectID').value;
  }
  get subObjectID() {
    return this.updateOtionalDataForm.get('subObjectID').value;
  }
  get dataElement() {
    return this.updateOtionalDataForm.get('dataElement').value;
  }
  setAccOverRequired() {
    this.disableAccUserOverride = !this.disableAccUserOverride;
  }
  setOverRequired() {
    this.disableUserOverride = !this.disableUserOverride;
  }
  showAccDetails(){
    if(!this.disableAccumulate){
    this.showAccumulateDetails = !this.showAccumulateDetails;
    }
  }
  onKeyUp(event: any) {
const tempOptionalElementID = this.objectID + this.subObjectID + this.dataElement;
this.selectAccumulate(tempOptionalElementID);
  }
  onDelete() {
    this.spinner.show();
    this.adminService.deleteDE(this.planNumber, this.selectedDEId).subscribe(delRes => {
      this.spinner.hide();
      if (delRes.status === APP_CONST.SUCCESS) {
        this.router.navigate(['/admin/dataElements']);
      } else {
        console.log('Error in onDelete data element item', delRes);
        this.toastr.error(delRes.error.msg, delRes.status + ' !', { showCloseButton: true });
      }
    },
      (err => {

        this.spinner.hide();
        console.log('Error in onDelete data element item outside', err);
        this.toastr.error('Error while deleting Data Element!', err.error.status + ' !', { showCloseButton: true });

      })
    );
}
  saveDE() {
    const newDataElement = this.updateOtionalDataForm.value;
    this.adminService.saveDE(this.planNumber, newDataElement, this.selectedDEId, this.isCreate).subscribe(saveRes => {
      if (saveRes.status === APP_CONST.SUCCESS) {
        this.router.navigate(['/admin/dataElements']);
      } else {
        console.log('Error in saveDE data element item', saveRes);
        this.toastr.error(saveRes.error.msg, saveRes.status + ' !', { showCloseButton: true });
      }
    },
      (err => {

        this.spinner.hide();
        console.log('Error in saveDE data element item outside', err);
        this.toastr.error('Error while saving Data Element!', err.error.status + ' !', { showCloseButton: true });

      })
    );
  }
  showOptions() {
    this.router.navigate(['/admin/dataElements/options']);
  }
  showDeteleModal() {
    this.modalService.open(this.modelId);
  }
  gotoBack() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
  onClear() {
    this.updateOtionalDataForm.reset();
  }
}
