import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPlanCopyModalComponent } from './admin-plan-copy-modal.component';

describe('AdminPlanCopyModalComponent', () => {
  let component: AdminPlanCopyModalComponent;
  let fixture: ComponentFixture<AdminPlanCopyModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminPlanCopyModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPlanCopyModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
