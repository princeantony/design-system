import { Component, OnInit } from '@angular/core';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { APP_CONST } from '../../../../shared/constants/app.constants';
import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { BankInfoService } from '../../services/bank-info.service';
import { GridLinkComponent } from '../grid-link/grid-link.component';

@Component({
  selector: 'app-bank-list',
  templateUrl: './bank-list.component.html'
})
export class BankListComponent implements OnInit {
columnDefs: any;
subDiv: any;
bankInfoData: any;
frameworkComponents: any;
context: any;
bankSubDiv: any;
bankInfo: any;
divsubId: string;
style;
rowStyle;

  constructor(
    private modalService: ModalService,
    private router: Router,
    private route: ActivatedRoute,
    private bankInfoService: BankInfoService,
    private spinner: NgxSpinnerService) {
      PayAdminGlobalState.bankDetails = null;
      this.columnDefs = GRID_CONFIG.BANK_INFO.COLUMN_DEFS;
      this.style = {width: '85%'};
      this.rowStyle = { color: '#333333' }; // to be moved to css
    }
  ngOnInit() {

    this.frameworkComponents = {
      linkRenderer: GridLinkComponent
    };
    this.context = { componentParent: this };
    this.getDivSub();
  }

  getBankInfo(): void {
    this.bankInfoService.getBankInfo(PayAdminGlobalState.planNumber).subscribe(
      bankInfo => {
        this.spinner.hide();
        if (bankInfo.status === APP_CONST.SUCCESS) {
          PayAdminGlobalState.bankinfo = bankInfo.data;
          this.bankInfoData = bankInfo.data;
          if (this.bankInfoData.length === 1) {
            if (!this.bankInfoData[0].bankName) {
              this.router.navigate(['/bankInfo/create' ]);
            } else {
              this.router.navigate([ '/bankInfo/edit']);
            }
          } else {
            this.bindBankInfo();
this.createBankSubDiv();
          }
        }
      },
      err => {
        console.log('Error in getBankInfo', err), this.spinner.hide();
      }
    );
  }

  getDivSub(): void {
    this.spinner.show();
    this.bankInfoService.getSubDiv(PayAdminGlobalState.planNumber).subscribe(
      subDiv => {
        if (subDiv.status === APP_CONST.SUCCESS) {

          this.subDiv = subDiv.data;
          this.getBankInfo();

        }
      },
      err => {
        console.log('Error in getDivSub', err), this.spinner.hide();
      }
    );
  }
  routeTo(link) {
    const tempLink = _.split(link, '/');
    PayAdminGlobalState.divsubId = tempLink[1];

    if (tempLink[0] === 'create') {
      this.divsubId = tempLink[1];
      this.modalService.open('bankModal');
    } else {
     this.router.navigate(['/bankInfo/' + link]);
    }
 }
  bindBankInfo() {
    this.bankInfoData.forEach(element => {
      _.merge(element, _.find(this.subDiv, ['id', element.divsub]));
    });
  }
  createBankSubDiv() {
    PayAdminGlobalState.subDiv = this.bankInfoData.map(({divsub, textOnly}) => {
      return {divsub, textOnly};
  });
  }
}
