import { Component, OnInit, Input } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { Router } from '@angular/router';
import { GRID_CONFIG } from '../../../../shared/constants/grid.constants';
@Component({
  selector: 'app-subdiv-modal',
  templateUrl: './subdiv-modal.component.html'

})
export class SubDivModalComponent implements OnInit {
  @Input() divSubs;
  gridStyle: any;
  subDivColumns: any;
  constructor(private modalService: ModalService,
              private router: Router) {
                this.subDivColumns = GRID_CONFIG.SUB_DIV_INFO.COLUMN_DEFS;
                this.gridStyle = GRID_CONFIG.SUB_DIV_INFO.GRID_SIZE;
              }


  ngOnInit() {

  }

  closeModal(id: string) {
    this.modalService.close(id);
}
continueTo() {
  this.router.navigate(['bankInfo/confirm/']);
}

}


