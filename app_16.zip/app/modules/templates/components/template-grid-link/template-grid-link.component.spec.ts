import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateGridLinkComponent } from './template-grid-link.component';

describe('TemplateGridRendererLinkComponent', () => {
  let component: TemplateGridLinkComponent;
  let fixture: ComponentFixture<TemplateGridLinkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateGridLinkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateGridLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
