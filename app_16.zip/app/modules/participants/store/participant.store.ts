import { ParticipantOptionSetting } from '../model/participant.model';
import * as Participant from '../model/participant.model';

export class ParticipantStore {
  static ParticipantOptionSetting: ParticipantOptionSetting = new ParticipantOptionSetting();
  static ParticipantStatusList: Participant.Option[];
  static ParticipantData: Participant.ParticipantData = new Participant.ParticipantData();
}
