import { Injectable } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable, Subject, Subscription, of } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { PayAdminGlobalState } from '../../../shared/store/pay-admin-global.store';
import { isEmptyObject } from '../../../shared/utils/pay-admin.utils';

import { ENV } from '../../../shared/constants/app.constants';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { ParticipantOptionalFields } from '../components/participant-optional-data/participant-optional-fields';
import * as Participant from '../model/participant.model';
import { ParticipantOptionSetting } from '../model/participant.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ParticipantStore } from '../store/participant.store';
import { delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ParticipantsService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService,
    private commonService: CommonService,
    private http: HttpClient
  ) {}

  private participantData: Participant.ParticipantData = new Participant.ParticipantData();
  private ParticipantDivSubFilter: Participant.Option[] = [] as Participant.Option[];
  private participantOtherExpandedDivSub: Participant.Option[];
  private participantOptionSetting: ParticipantOptionSetting;
  private participantStatusList: Participant.Option[] = [] as Participant.Option[];
  private participantMorningStar: Participant.ParticipantMorningStar;

  private participantOtherDivSubChanged = new Subject<string>();
  private subscription: Subscription;

  setParticipantOptionSetting() {}

  getParticipantOptionSetting(): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantAdminSettingMock();
    } else {
      // 'participant/plan/{planId}/add/options'
      const url = SERVICE_URL.GET_PARTICIPANT_ADMIN_OPTIONS.replace(
        '{planId}',
        '53680K'
      );
      return this.apiService.get(
        SERVICE_URL.GET_PARTICIPANT_ADMIN_OPTIONS.replace('{planId}', '53680K')
      );
    }
  }

  getParticipantStatusFromStatusList(): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantStatusListMock();
    } else {
      return this.apiService.get(
        SERVICE_URL.GET_PARTICIAPNT_STATUS_LIST.replace('{planId}', '53680K')
      );
    }
  }

  validateAddParticipantSSN(participantSSN: string): Observable<any> {
    if (ENV.TEST) {
      const isValidSSN = {
        status: 'SUCCESS'
      };
      return of(isValidSSN).pipe(delay(2000));
    } else {
      const httpOptions = {
        headers: new HttpHeaders({
          ssn: participantSSN
        })
      };
      return this.http.get<any>(
        SERVICE_URL.GET_PARTICIPANT_VALIDATE_SSN.replace('{planId}', '53680K'),
        httpOptions
      );
    }
  }

  getParticipantList(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getparticipantListMock()
      : this.mockService.getparticipantListMock();
  }

  getParticipantBySSN$(ssn: string): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getUpdateParticipantRequiredData();
    } else {
      this.apiService.get(
        SERVICE_URL.GET_UPDATE_PARTICIPANT_REQUIRED_DATA.replace(
          '{planId}',
          '53680K'
        )
      );
    }
  }

  getParticipantListBySSN(ssn: string): Participant.ParticipantItem[] {
    let participantList: Participant.ParticipantItem[] = [];
    if (ENV.TEST) {
      let participantListByName: Participant.ParticipantItem[] = [];
      this.mockService.getparticipantListMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          participantList = result.data;
        }
      });

      participantListByName = participantList.filter(
        (value: Participant.ParticipantItem, index, array) => {
          if (value.ssn.indexOf(ssn) !== -1) {
            return true;
          }
          return false;
        }
      );
      return participantListByName;
    } else {
      return participantList;
    }
  }
  getParticipantListByLastName$(name: string): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getparticipantListMock();

      // participantListByName = participantList.filter(
      //   (value: Participant.ParticipantItem, index, array) => {
      //     if (value.name.toLowerCase().indexOf(name.toLowerCase()) !== -1) {
      //       return true;
      //     }
      //     return false;
      //   }
      // );
    } else {
      return this.apiService.get(
        SERVICE_URL.GET_PARTICIPANT_LIST_BY_NAME.replace(
          '{planId}',
          '53680K'
        ).replace('{participantName}', name)
      );
    }
  }

  getParticipantListByLastName(name: string): Participant.ParticipantItem[] {
    let participantList: Participant.ParticipantItem[] = [];
    if (ENV.TEST) {
      let participantListByName: Participant.ParticipantItem[] = [];
      this.mockService.getparticipantListMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          participantList = result.data;
        }
      });

      participantListByName = participantList.filter(
        (value: Participant.ParticipantItem, index, array) => {
          if (value.name.toLowerCase().indexOf(name.toLowerCase()) !== -1) {
            return true;
          }
          return false;
        }
      );
      return participantListByName;
    } else {
      return participantList;
    }
  }

  getParticipantMorningStarData(): Participant.ParticipantMorningStar {
    if (ENV.TEST) {
      this.mockService.getParticipantMorningStarDataMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.participantMorningStar = result.data;
        }
      });
    } else {
      // 'participant/plan/{planId}/morningstar'
      this.apiService
        .get(
          SERVICE_URL.GET_PARTICIPANT_MORINGINSTART.replace(
            '{planId}',
            '53680K'
          )
        )
        .subscribe(result => {
          debugger;
          if (result.status === 'SUCCESS') {
            this.participantMorningStar = result.data;
          }
        });
    }
    return this.participantMorningStar;
  }

  getParticipantData(): Participant.ParticipantData {
    return this.participantData;
  }

  getParticipantOptionalDataFields(): Participant.ParticipantOptionalField[] {
    if (this.participantData.optionalData.length > 0) {
      return this.participantData.optionalData;
    }
    if (ENV.TEST) {
      this.mockService
        .getParticipantOptionalDataFieldsMock()
        .subscribe(result => {
          if (result.status === 'SUCCESS') {
            this.participantData.optionalData = result.data;
          }
        });
    } else {
      this.apiService
        .get(
          SERVICE_URL.GET_PARTICIPANT_OPTIONALDATAELEMENTS.replace(
            '{planId}',
            '53680K'
          )
        )
        .subscribe(result => {
          if (result.status === 'SUCCESS') {
            this.participantData.optionalData = result.data;
          }
        });
    }
    return this.participantData.optionalData;
  }

  getParticipantContributionData(): Participant.ParticipantContribution {
    if (!isEmptyObject(this.participantData.participantContribution)) {
      return this.participantData.participantContribution;
    }
    if (ENV.TEST) {
      this.mockService
        .getParticipantContributionDataMock()
        .subscribe(result => {
          if (result.status === 'SUCCESS') {
            this.participantData.participantContribution = result.data;
          }
        });
    } else {
      debugger;
      const url = SERVICE_URL.GET_PARTICIAPNT_CONTRIBUTION_ELECTIONS.replace(
        '{planId}',
        '53680K'
      );
      this.apiService.get(url).subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.participantData.participantContribution = result.data;
        }
      });
    }
    return this.participantData.participantContribution;
  }

  getParticipantParticipantFundData(): Participant.IParticipantFundSources {
    if (
      !isEmptyObject(this.participantData.participantContributionInvestmentData)
    ) {
      return this.participantData.participantContributionInvestmentData;
    }
    if (ENV.TEST) {
      this.mockService.getParticipantParticipantFundData().subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.participantData.participantContributionInvestmentData =
            result.data;
        }
      });
    } else {
      this.apiService
        .get(
          SERVICE_URL.GET_PARTICIPANT_INVESTMENT_ELECTIONS.replace(
            '{planId}',
            '53680K'
          )
        )
        .subscribe(result => {
          if (result.status === 'SUCCESS') {
            this.participantData.participantContributionInvestmentData =
              result.data;
          }
        });
    }
    return this.participantData.participantContributionInvestmentData;
  }

  getParticipantOtherDivSub(range: string = ''): Participant.Option[] {
    const otherDivSub = this.participantOptionSetting.otherDivSub;
    if (range !== '') {
      let filterdDivSub: Participant.Option[] = [];
      let rangeCharsArray = [];
      switch (range) {
        case 'AE001':
          rangeCharsArray = ['A', 'B', 'C', 'D', 'E'];
          break;
        case 'FJ002':
          rangeCharsArray = ['F', 'G', 'H', 'I', 'J'];
          break;
        case 'KO003':
          rangeCharsArray = ['K', 'L', 'M', 'N', 'O'];
          break;
        case 'PT004':
          rangeCharsArray = ['P', 'Q', 'R', 'S', 'T'];
          break;
        case 'UZ005':
          rangeCharsArray = ['U', 'V', 'W', 'X', 'Y', 'Z'];
          break;
      }
      filterdDivSub = otherDivSub.filter(divSub => {
        let inRange = false;
        for (const curChar of rangeCharsArray) {
          const divSubDescription = this.getDivSubText(divSub.displayText);
          inRange = divSub.displayText
            .toUpperCase()
            .startsWith(curChar.toUpperCase());
          if (inRange) {
            console.log(divSubDescription);
            break;
          }
        }
        return inRange;
      });

      return filterdDivSub;
    }
    return otherDivSub;
  }

  addParticipantOptionalData(
    participantOptionalData: Participant.ParticipantOptionalField[]
  ) {
    this.participantData.optionalData = participantOptionalData;
    console.log(this.participantData);
  }

  addParticipantContributionElectionData(
    participantContributionElectionData: Participant.ParticipantContribution
  ) {
    this.participantData.participantContribution = participantContributionElectionData;
    console.log(this.participantData);
  }

  addparticipantContributionInvestmentData(
    participantContributionInvestmentData: Participant.IParticipantFundSources
  ) {
    this.participantData.participantContributionInvestmentData = participantContributionInvestmentData;
    console.log(this.participantData);
  }

  getParticipantDataToSubmit(): Participant.ParticipantSubmitData {
    const _participant: Participant.ParticipantSubmitData = {} as Participant.ParticipantSubmitData;
    _participant.participantInfo = this.getParticipantInfoSubmitData();
    _participant.optionalDataElement = this.getParticipantOptionalDataElementSubmitData();
    _participant.contributionElections = this.getContributionsSubmitData();
    _participant.catchUpContributionElections = this.getCatchupContributionsSubmitData();
    _participant.investmentElectionsList = this.getInvestmentElectionsListSubmitData();
    return _participant;
  }

  getParticipantInfoSubmitData(): Participant.ParticipantInfo {
    debugger;
    const pInfo: Participant.ParticipantInfo = {} as Participant.ParticipantInfo;
    const info = this.participantData.requiredData;
    pInfo.partSSN = info.ssn;
    pInfo.firstName = info.firstName;
    pInfo.lastName = info.lastName;
    pInfo.middleInitial = info.middleInitial;
    pInfo.address1 = info.address1;
    pInfo.address2 = info.address2;
    pInfo.city = info.city;
    pInfo.state = info.state;
    pInfo.zipCode = info.zipCode;
    pInfo.country = info.country;
    pInfo.email = info.email;
    //pInfo.statusCode = info.
    //pInfo.backupStatusCode = info
    pInfo.birthDate = info.birthDate;
    pInfo.hireDate = info.hireDate;
    //pInfo.rehireDate = info.
    pInfo.termDate = info.terminationDate;
    pInfo.termCode = info.terminationReason;
    //pInfo.defType = info
    //pInfo.catchupDefType = info
    //pInfo.planId = info
    pInfo.enrollFlag = info.enrollFlag;
    //pInfo.newDivsubUpdated = info
    //pInfo.sameAsSource = info
    pInfo.mstarFlag = info.mstarFlag;
    pInfo.qdiaFlag = info.qdiaFlag;
    return pInfo;
  }

  getParticipantOptionalDataElementSubmitData(): Participant.ParticipantCodeValue[] {
    const ODEs: Participant.ParticipantCodeValue[] = [];
    this.participantData.optionalData.forEach(
      <ParticipantOptionalField>(item) => {
        const ODEItem: Participant.ParticipantCodeValue = {
          code: '',
          value: ''
        };
        ODEItem.code = item.key;
        ODEItem.value = item.value;
        ODEs.push(ODEItem);
      }
    );
    return ODEs;
  }

  getContributionsSubmitData(): Participant.ParticipantCodeValue[] {
    const contribs: Participant.ParticipantCodeValue[] = [];
    this.participantData.participantContribution.contribElection.forEach(
      <ParticipantContributionElectionItem>(item) => {
        const contrib: Participant.ParticipantCodeValue = {
          code: '',
          value: ''
        };
        contrib.code = item.key;
        contrib.value = item.value;
        contribs.push(contrib);
      }
    );
    return contribs;
  }

  getCatchupContributionsSubmitData(): Participant.ParticipantCodeValue[] {
    const catchupContribs: Participant.ParticipantCodeValue[] = [];
    this.participantData.participantContribution.catchupContribElection.forEach(
      <ParticipantContributionElectionItem>(item) => {
        const catchupContrib: Participant.ParticipantCodeValue = {
          code: '',
          value: ''
        };
        catchupContrib.code = item.key;
        catchupContrib.value = item.value;
        catchupContribs.push(catchupContrib);
      }
    );
    return catchupContribs;
  }

  getInvestmentElectionsListSubmitData(): Participant.PariticantInvestmentElectionItemSubmit[] {
    const investments: Participant.PariticantInvestmentElectionItemSubmit[] = [];
    this.participantData.participantContributionInvestmentData.fundSources.forEach(
      fSource => {
        let fundSoures: Participant.ParticipantFundSource;
        fundSoures = fSource;
        fundSoures.percents.forEach(percent => {
          const investment: Participant.PariticantInvestmentElectionItemSubmit = {} as Participant.PariticantInvestmentElectionItemSubmit;
          investment.investmentId = percent.investmentId;
          investment.newPercent = percent.currentPercent;
          investment.sourceId = percent.sourceId;
          investments.push(investment);
        });
      }
    );

    return investments;
  }

  toFormGroup(fields: ParticipantOptionalFields<any>[]) {
    const group: any = {};

    fields.forEach(field => {
      group[field.key] = new FormControl(field.value || '');
    });
    return new FormGroup(group);
  }

  getDivSubID(divSub: string) {
    // divSub = '1234 Division Sub'
    return divSub.substring(0, divSub.indexOf(' '));
  }

  getDivSubText(divSub: string) {
    // divSub = '1234 Division Sub'
    return divSub.substr(divSub.indexOf(' ') + 1);
  }

  getParticipantStatus(statusCode: string): string {
    if (ParticipantStore.ParticipantStatusList) {
      const statusList = ParticipantStore.ParticipantStatusList;
      if (ParticipantStore.ParticipantStatusList.length > 0) {
        const statusItem: Participant.Option = statusList.find(
          item => item.value === statusCode //ParticipantStore.ParticipantOptionSetting.statusCode
        );
        if (statusItem) {
          return statusItem.displayText;
        }
      }
    }
    return '';
  }

  resetParticipantStore() {
    ParticipantStore.ParticipantOptionSetting = new ParticipantOptionSetting();
    ParticipantStore.ParticipantStatusList = [];
    ParticipantStore.ParticipantData = new Participant.ParticipantData();
  }
}
