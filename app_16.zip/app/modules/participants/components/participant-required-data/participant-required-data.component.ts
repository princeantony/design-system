import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs/Subject';
import { CommonService } from 'src/app/shared/services/common.service';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import {
  IParticipantRequiredData,
  ParticipantData,
  ParticipantOptionSetting
} from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'participant-required-data',
  templateUrl: './participant-required-data.component.html',
  styleUrls: ['./participant-required-data.component.scss']
})
export class ParticipantRequiredDataComponent implements OnInit {
  private messageList: string[] = [];
  private _editMode = false;
  private statusText: string;
  @Input()
  set EditMode(value: boolean) {
    this._editMode = value;
  }
  get EditMode(): boolean {
    return this._editMode;
  }
  countryChanged = new Subject<string>();
  participantData = new ParticipantData();
  participantOptionSetting: ParticipantOptionSetting;
  participantRequiredDataForm: FormGroup;
  requiredData: IParticipantRequiredData;

  countryList: { value: string; displayText: string }[];
  stateList: { value: string; displayText: string }[];
  // parameter to set dataofBirth start Date
  dobStartData: {};
  dohStartDate: {};
  today: number = Date.now();

  accountTypeItems: { value: string; label: string }[];

  constructor(
    private formBuilder: FormBuilder,
    private participantsService: ParticipantsService,
    private router: Router,
    private commonService: CommonService,
    private spinner: NgxSpinnerService
  ) {}
  ngOnInit() {
    debugger;
    this.today = Date.now();
    this.spinner.show();
    // Get Country List
    this.countryList = PayAdminGlobalState.countryList;
    this.stateList = PayAdminGlobalState.stateList;

    this.participantsService.getParticipantOptionSetting().subscribe(result => {
      if (result.status === 'SUCCESS') {
        this.participantOptionSetting = ParticipantStore.ParticipantOptionSetting =
          result.data;
        this.setStartDates();
        console.log(ParticipantStore.ParticipantOptionSetting);
        this.participantsService
          .getParticipantStatusFromStatusList()
          .subscribe(resStatusList => {
            if (resStatusList.status === 'SUCCESS') {
              ParticipantStore.ParticipantStatusList = resStatusList.data;
              // Initialize Form

              if (!this.EditMode) {
                this.statusText = this.participantsService.getParticipantStatus(
                  ParticipantStore.ParticipantOptionSetting.statusCode
                );
              } else {
                // Participant Update Section
                this.statusText = this.participantsService.getParticipantStatus(
                  ParticipantStore.ParticipantData.requiredData.statusCode
                );
              }
              this.initFrom();
              this.onChanges();
              this.spinner.hide();
            }
          });
      }
    });
  }

  initFrom() {
    if (this.EditMode) {
      // Note:  get Participant Required data from store which is prefilled in search participant
      this.participantData = ParticipantStore.ParticipantData;
    }
    console.log(this.participantData);
    this.participantRequiredDataForm = this.formBuilder.group({
      ssn: [this.participantData.requiredData.ssn],
      email: [this.participantData.requiredData.email],
      lastName: [this.participantData.requiredData.lastName],
      firstName: [this.participantData.requiredData.firstName],
      middleInitial: [this.participantData.requiredData.middleInitial],
      address1: [this.participantData.requiredData.address1],
      address2: [this.participantData.requiredData.address2],
      city: [this.participantData.requiredData.city],
      zipCode: [this.participantData.requiredData.zipCode],
      state: [this.participantData.requiredData.state],
      country: [this.participantData.requiredData.country],
      birthDate: [this.participantData.requiredData.birthDate],
      hireDate: [this.participantData.requiredData.hireDate],
      terminationDate: [this.participantData.requiredData.terminationDate],
      terminationReason: [this.participantData.requiredData.terminationReason],
      makeParticipantActive: [
        this.participantData.requiredData.makeParticipantActive
      ],
      absenceStartDate: [this.participantData.requiredData.absenceStartDate],
      absenceStartDateReason: [
        this.participantData.requiredData.absenceStartDateReason
      ],
      absenceEndDate: [this.participantData.requiredData.absenceEndDate],
      absenceEndDateReason: [
        this.participantData.requiredData.absenceEndDateReason
      ],
      enrollFlag: [this.participantData.requiredData.enrollFlag],
      mstarFlag: [this.participantData.requiredData.mstarFlag],
      qdiaFlag: [this.participantData.requiredData.qdiaFlag]
    });
  }

  onChanges() {
    this.participantRequiredDataForm.controls[
      'middleInitial'
    ].valueChanges.subscribe(val => {
      this.participantRequiredDataForm.controls['middleInitial'].setValue(
        val.toUpperCase(),
        { emitEvent: false }
      );
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'lastName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
    this.participantRequiredDataForm.controls[
      'firstName'
    ].valueChanges.subscribe(val => {
      this.validateNameMaxlengthExceeded();
    });
  }

  validateNameMaxlengthExceeded() {
    if (
      this.participantRequiredDataForm.controls['middleInitial'].value.length +
        this.participantRequiredDataForm.controls['firstName'].value.length +
        this.participantRequiredDataForm.controls['lastName'].value.length >
      30
    ) {
      this.participantRequiredDataForm.controls['lastName'].setErrors({
        MaxLengthExceeded: true
      });
      this.participantRequiredDataForm.setErrors({ invalid: true });
    }
  }
  setStartDates() {
    this.dobStartData = { year: new Date().getFullYear() - 19 - 9, month: 1 };
    this.dohStartDate = { year: new Date().getFullYear() - 9, month: 1 };
  }

  onSubmit() {
    if (this.validateSSN()) {
      const data: IParticipantRequiredData = this.participantRequiredDataForm
        .value;
      ParticipantStore.ParticipantData.requiredData = data;
      console.log(ParticipantStore.ParticipantData);

      if (this.participantRequiredDataForm.value.enrollFlag) {
        if (
          ParticipantStore.ParticipantOptionSetting.canLoadOptionalDataElements
        ) {
          this.router.navigate(['addParticipant/Optional']);
        } else {
          this.router.navigate(['addParticipant/ContributionElection']);
        }
      } else {
        this.router.navigate(['addParticipant/Confirmation']);
      }
    }
  }

  validateSSN(): boolean {
    this.participantsService
      .validateAddParticipantSSN(
        this.participantRequiredDataForm.controls['ssn'].value
      )
      .subscribe(res => {
        if (res.status === 'SUCCESS') {
          return true;
        } else if (res.status === 'ERROR') {
          const errors: string = res.error.msg;
          this.messageList = errors.split(',');
          return false;
        }
      });
    return true;
  }

  onStateChange(value: string) {}

  onCountryChange(value: string) {
    this.commonService.countryChanged.next(value);
  }
}
