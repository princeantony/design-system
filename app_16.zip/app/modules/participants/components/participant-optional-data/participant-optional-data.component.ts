import { Component, OnInit, AfterViewInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Utils } from 'src/app/shared/utils/pay-admin.utils';

import {
  ParticipantOptionalField,
  ParticipantOptionSetting
} from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantOptionalFieldDropDown } from './participant-optional-field-dropdown';
import { ParticipantOptionalFieldTextBox } from './participant-optional-field-textbox';
import { ParticipantOptionalFields } from './participant-optional-fields';
import {
  ODE_DIVSUB_CODE,
  PARTICIPANT_DIVSUB_FILTER
} from './../../model/participant.const';

@Component({
  selector: 'participant-optional-data',
  templateUrl: './participant-optional-data.component.html',
  styleUrls: ['./participant-optional-data.component.scss']
})
export class ParticipantOptionalDataComponent implements OnInit {
  optionalFields: ParticipantOptionalFields<any>[] = [];
  optionalFieldsRows: ParticipantOptionalFields<any>[][];
  participantOptionalDataField: ParticipantOptionalField[];
  participantOptionalData: ParticipantOptionalField[];
  participantOptionalDataForm: FormGroup;
  participantOptionSetting: ParticipantOptionSetting;
  optionalDivSub: ParticipantOptionalFields<any>;
  optionalDivSubFilter: ParticipantOptionalFields<any>;
  optionalOtherExpandedDivSub: ParticipantOptionalFields<any>;
  divSubFilterVisible = false;

  constructor(
    private participantsService: ParticipantsService,
    private router: Router,
    private _util: Utils
  ) {}

  ngOnInit() {
    this.getParticipantOptionSetting();
    this.getOptionalDataFields();
    if (this.optionalFields.length > 0) {
      this.participantOptionalDataForm = this.participantsService.toFormGroup(
        this.optionalFields
      );
      if (this.optionalDivSub) {
        this.participantOptionalDataForm.addControl(
          this.optionalDivSub.key,
          new FormControl(this.optionalDivSub.value)
        );
      }
      this.optionalFieldsRows = this._util.chunkArray(this.optionalFields, 2);
    } else {
      this.navigateToNext();
    }
  }

  getParticipantOptionSetting() {
    this.participantsService.getParticipantOptionSetting().subscribe(result => {
      if (result.status === 'SUCCESS') {
        this.participantOptionSetting = result.data;
      }
    });
  }

  getOptionalDataFields() {
    this.participantOptionalDataField = this.participantsService.getParticipantOptionalDataFields();
    if (this.participantOptionalDataField.length > 0) {
      this.participantOptionalDataField.forEach(
        (field: ParticipantOptionalField) => {
          if (field.componentType === 'text') {
            this.optionalFields.push(
              new ParticipantOptionalFieldTextBox({
                key: field.key
                  .split(' ')
                  .join('-')
                  .toUpperCase(),
                label: field.label,
                required: field.required,
                value: field.value,
                type: field.type,
                readonly: field.readOnly,
                disabled: field.disabled,
                length: field.length
              })
            );
          }
          if (field.componentType === 'dropdown') {
            // Check for if Optional Data Elements has Div Sub Component
            if (field.key.toUpperCase() !== ODE_DIVSUB_CODE) {
              this.optionalFields.push(
                new ParticipantOptionalFieldDropDown({
                  key: field.key
                    .split(' ')
                    .join('-')
                    .toUpperCase(),
                  label: field.label,
                  required: field.required,
                  value: field.value,
                  options: field.option,
                  readonly: field.readOnly,
                  disabled: field.disabled
                })
              );
            } else {
              this.optionalDivSub = new ParticipantOptionalFieldDropDown({
                key: field.key
                  .split(' ')
                  .join('-')
                  .toUpperCase(),
                label: field.label,
                required: field.required,
                value: field.value,
                options: this.participantOptionSetting.authDivSub,
                readonly: field.readOnly,
                disabled: field.disabled
              });
            }
          }
        }
      );
    }
  }

  onDivSubSelected(value: string) {
    const isRangeDivSub: RegExp = RegExp('^([A-Z]|[a-z]){2}\\d{3}$');
    if (value === 'O!') {
      if (this.participantOptionSetting.otherDivSub.length >= 50) {
        this.divSubFilterVisible = true;
        this.optionalDivSubFilter = new ParticipantOptionalFieldDropDown({
          key: 'optionalDivSubFilter',
          label: '',
          required: true,
          value: '',
          options: PARTICIPANT_DIVSUB_FILTER,
          readonly: false,
          disabled: false
        });
        this.participantOptionalDataForm.addControl(
          this.optionalDivSubFilter.key,
          new FormControl(this.optionalDivSubFilter.value)
        );
      } else {
        this.optionalOtherExpandedDivSub = new ParticipantOptionalFieldDropDown(
          {
            key: 'optionalOtherExpandedDivSub',
            label: '',
            required: true,
            value: '',
            options: this.participantOptionSetting.otherDivSub,
            readonly: false,
            disabled: false
          }
        );
        this.participantOptionalDataForm.addControl(
          this.optionalOtherExpandedDivSub.key,
          new FormControl(this.optionalOtherExpandedDivSub.value)
        );
      }
    } else if (isRangeDivSub.test(value)) {
      this.optionalOtherExpandedDivSub = new ParticipantOptionalFieldDropDown({
        key: 'optionalOtherExpandedDivSub',
        label: '',
        required: true,
        value: '',
        options: this.participantsService.getParticipantOtherDivSub(value),
        readonly: false,
        disabled: false
      });
      this.participantOptionalDataForm.addControl(
        this.optionalOtherExpandedDivSub.key,
        new FormControl(this.optionalOtherExpandedDivSub.value)
      );
    } else {
      this.optionalDivSubFilter = <ParticipantOptionalFields<any>>{};
      this.optionalOtherExpandedDivSub = <ParticipantOptionalFields<any>>{};
      this.participantOptionalDataForm.removeControl('optionalDivSubFilter');
      this.participantOptionalDataForm.removeControl(
        'optionalOtherExpandedDivSub'
      );
    }
  }

  onSubmit() {
    this.updateModel();
    this.participantsService.addParticipantOptionalData(
      this.participantOptionalDataField
    );
    this.navigateToNext();
  }

  updateModel() {
    this.participantOptionalDataField.forEach(ODElement => {
      ODElement.value = this.participantOptionalDataForm.get(
        ODElement.key
      ).value;
    });
  }

  onBackClicked() {
    this.router.navigate(['participant']);
  }
  navigateToNext() {
    this.router.navigate(['addParticipant/ContributionElection']);
  }
}
