import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CommonService } from '../app/shared/services/common.service';
import { PayAdminGlobalState } from './shared/store/pay-admin-global.store';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  title = 'PayAdmin';
  date = new Date().toLocaleDateString();
  constructor(private commonService: CommonService, private router: Router) {}
  /* we should call all the common services as synchronize call. Below code is now writtern as asynchronize */
  ngOnInit(): void {
    if (PayAdminGlobalState.loginStatus) {
      // if (!PayAdminGlobalState.stateList) {
      //   this.commonService.getStateList().subscribe(result => {
      //     if (result.status === 'SUCCESS') {
      //       PayAdminGlobalState.stateList = result.data;
      //     }
      //   });
      // }
      // if (!PayAdminGlobalState.countryList) {
      //   this.commonService.getCountryList().subscribe(result => {
      //     if (result.status === 'SUCCESS') {
      //       PayAdminGlobalState.countryList = result.data;
      //     }
      //   });
      // }
      this.router.navigate(['/plans']);
    } else {
      this.router.navigate(['/']);
    }
  }
}

// Need to revisit this logic once we get the complete information on the websponsor - payadmin integration
