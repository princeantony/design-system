import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appDate]'
})
export class DateDirective {
  private el: any;
  private today = new Date();
  private date = {} as Date;
  constructor(private elementRef: ElementRef) {
    this.el = this.elementRef.nativeElement;
  }

  isValidMonth(month) {
    return month >= 0 && month < 12;
  }

  isValidDay(day) {
    return day > 0 && day < 32;
  }

  isValidYear(year) {
    return (
      year > this.today.getFullYear() - 115 &&
      year < this.today.getFullYear() + 115
    );
  }

  isValidDate(dateString: string) {
    // TODO: Validate date string
    return true;
    // return (
    //   this.isValidMonth(inputDate.getMonth()) &&
    //   this.isValidDay(inputDate.getDate()) &&
    //   this.isValidYear(inputDate.getFullYear())
    // );
  }
  @HostListener('blur', ['$event.target.value'])
  onBlur(value) {
    // if (value !== '') {
    //   this.el.value = formatDate(value, 'MM/dd/yyy', 'en-US');
    // }
  }

  @HostListener('keydown', ['$event', '$event.target.value'])
  onKeyDown(event, value) {
    const e = <KeyboardEvent>event;
    if (
      [46, 8, 9, 27, 13, 110, 190].indexOf(e.keyCode) !== -1 ||
      // Allow: Ctrl+A
      (e.keyCode === 65 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+C
      (e.keyCode === 67 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+V
      (e.keyCode === 86 && (e.ctrlKey || e.metaKey)) ||
      // Allow: Ctrl+X
      (e.keyCode === 88 && (e.ctrlKey || e.metaKey)) ||
      // Allow: home, end, left, right
      (e.keyCode >= 35 && e.keyCode <= 39) ||
      // Allow : / key for date format
      (e.keyCode === 191 || e.keyCode === 111)
    ) {
      // let it happen, don't do anything
      return;
    }
    // Ensure that it is a number and stop the keypress
    if (
      (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) &&
      (e.keyCode < 96 || e.keyCode > 105)
    ) {
      e.preventDefault();
    }
    if (value.length > 0) {
      if (!this.isValidDate(value)) {
        e.preventDefault();
      }
    }

    if (value.length >= 10) {
      e.preventDefault();
    }

    const pattern =
      '^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(19|20)\\d\\d$' +
      '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(19|20)\\d$' +
      '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])(19|20)$' +
      '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])[12]$' +
      '|^(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$' +
      '|^(0[1-9]|1[012])([0-3])$' +
      '|^(0[1-9]|1[012])$' +
      '|^[01]$';
    const regexp = new RegExp(pattern);
    const key = event.charCode ? event.charCode : event.keyCode;

    const character = String.fromCharCode(event.which);
    const start = value[0].selectionStart;
    const end = value[0].selectionEnd;
    const testValue = (
      value.val().slice(0, start) +
      character +
      value.val().slice(end)
    ).replace(/\s|\//g, '');
    if (!regexp.test(testValue)) {
      event.preventDefault();
    }
  }
}
