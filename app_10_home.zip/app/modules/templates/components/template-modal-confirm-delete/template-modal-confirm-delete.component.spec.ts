import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModalConfirmDeleteComponent } from './template-modal-confirm-delete.component';

describe('TemplateModalConfirmDeleteComponent', () => {
  let component: TemplateModalConfirmDeleteComponent;
  let fixture: ComponentFixture<TemplateModalConfirmDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModalConfirmDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModalConfirmDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
