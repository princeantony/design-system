import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-template-modal-confirm-delete',
  templateUrl: './template-modal-confirm-delete.component.html',
  styleUrls: ['./template-modal-confirm-delete.component.scss']
})
export class TemplateModalConfirmDeleteComponent implements OnInit {
@Output()
continue = new EventEmitter<any>();
  constructor(private modalService: ModalService) { }

  ngOnInit() {
  }
  closeModal(id) {
    this.modalService.close(id);
  }
  continueTo() {
  this.continue.emit();
  }

}
