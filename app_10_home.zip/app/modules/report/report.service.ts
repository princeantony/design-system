import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';
import { MockService } from '../../shared/services/mock.service';
import { ApiService } from '../../shared/services/api.service';
import { SERVICE_URL } from '../../shared/constants/service.constants';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService
  ) {}
  getReportNames(planNumber: string): Observable<any> {
    return (ENV.TEST)
    ? this.mockService.getReportNames()
    : this.apiService.get(SERVICE_URL.GET_REPORT_NAMES_URL + planNumber);
  }
  getReport(planNumber: string): Observable<any> {
    return (ENV.TEST)
    ? this.mockService.getReport()
    : this.apiService.get(SERVICE_URL.GET_REPORT_URL + planNumber);
    }
}
