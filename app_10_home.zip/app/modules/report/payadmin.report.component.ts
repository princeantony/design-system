import { Component, OnInit } from '@angular/core';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';

import { ActivatedRoute, Router } from '@angular/router';
import { PayAdminGlobalState } from '../../shared/store/pay-admin-global.store';
import { APP_CONST } from '../../shared/constants/app.constants';
import { ReportService } from './report.service';


@Component({
  selector: 'app-bank-list',
  templateUrl: './bank-list.component.html'
})
export class PayAdminReportComponent implements OnInit {
  reportColumns: any;
  reportData: any;
  reportNames: any;
  style;
  rowStyle;
  constructor(
private reportService: ReportService,
    private router: Router,
    private spinner: NgxSpinnerService
  ) {
    this.reportColumns = '';
    this.style = { width: '93%' };
    this.rowStyle = { color: '#333333' }; // to be moved to css
  }
  ngOnInit() {
    this.getReportNames();
  }

  getReportNames(): void {
    this.spinner.show();
    this.reportService.getReportNames(PayAdminGlobalState.planNumber).subscribe(
      names => {
        if (names.status === APP_CONST.SUCCESS) {
          this.reportNames = names.data;
          this.getReport();

        } else {
          console.log('Error in report name', names);
          this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }

  getReport(): void {
    this.reportService.getReport(PayAdminGlobalState.planNumber).subscribe(
      report => {
        this.spinner.hide();
        if (report.status === APP_CONST.SUCCESS) {
          this.reportData = report.data;

        } else {
          console.log('Error in report name', report);
          this.spinner.hide();
        }
      },
      err => {
        console.log('Error in roport name from service', err);
        this.spinner.hide();
      }
    );
  }

}
