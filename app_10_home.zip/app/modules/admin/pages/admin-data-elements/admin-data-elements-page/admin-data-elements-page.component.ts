import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr/ng2-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { DataElement } from '../../../models/data-element-model';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-data-elements-page',
  templateUrl: './admin-data-elements-page.component.html',
  styleUrls : ['./admin-data-elements-page.component.scss']
})
export class AdminDataElementsPageComponent implements OnInit {
  hidePageTitle: boolean;
  pageTitle: string;
  planNumber: string;
  dEColumnDefs: any;
  dEList: any;
  type = 'Data Element';
  modelId = 'deModal';
  selectedDE: any;
  isButtonDisabled = true;
  isEditButtonDisabled = true;
  isSaveChangesDisabled = false;
  newOrderNumber: { optionalElementID: any; order: any }[];
 // updatedDataElement : any [10];
  selectedDEId: string;
  constructor(
    private adminService: AdminService,
    private adminDataService: AdminDataService,
    private router: Router,
    private route: ActivatedRoute,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    vcr: ViewContainerRef,
    private modalService: ModalService
  ) {
    this.toastr.setRootViewContainerRef(vcr);
    this.dEColumnDefs = GRID_CONFIG.DATA_ELEMENTS.COLUMN_DEFS_ELEMENTS;
  }

  ngOnInit() {
    PayAdminGlobalState.previousPage = 'admin';
    PayAdminGlobalState.currentPage = 'admin/dataElements';
    this.hidePageTitle = false;
    this.pageTitle = 'Data Elements'; // read from const
    this.planNumber = PayAdminGlobalState.planNumber;
    this.selectedDEId = AdminDataService.dataElementId;
    this.route.url.subscribe(value => {
      const isDelete = _.find(value, ['path', 'delete']);
      if (isDelete) {
        this.onDelete();
      } else {
        AdminDataService.dataElement = new DataElement();
        this.clearSelection();
        this.getDataElementList();
      }
    });
  }
  newElementClick() {
    this.isEditButtonDisabled = false;
    this.isButtonDisabled = true;
    this.clearSelection();
  }
  clearSelection() {
    this.selectedDE = null;
    this.selectedDEId = null;
    AdminDataService.dataElementId = null;
    AdminDataService.dataElements = null;
    AdminDataService.dataElement = null;
  }
  getDataElementList() {
    this.spinner.show();
    this.adminService.getDEList(this.planNumber).subscribe(
      deList => {
        this.spinner.hide();
        if (deList.status === APP_CONST.SUCCESS) {
          this.dEList = deList.data;
          console.log("list ", this.dEList)
          if(_.size(this.dEList) === 0){
            this.isEditButtonDisabled = false;
            this.isSaveChangesDisabled = true;
          } else {
            this.isSaveChangesDisabled = false;
          this.getCustomData(deList.data);
          AdminDataService.dataElements = deList.data;
         }
          if (this.selectedDEId && this.selectedDEId.length > 0) {
            this.getSelectedDataID(this.selectedDEId);
          }
        } else {
          console.log('Error in fetching data element', deList);
          this.toastr.error(deList.error.msg, deList.status + ' !', {
            showCloseButton: true
          });
        }
      },
      err => {
        this.spinner.hide();
        console.log('Error in fetch data element outside', err);
        this.toastr.error(
          'Error while fetching Data Element !',
          err.error.status + ' !',
          { showCloseButton: true }
        );
      }
    );
  }
  getCustomData(_dataElement) {
    _.forEach(_dataElement, function(value, index) {
      if (value.defaultSortOrder === 0 || value.defaultSortOrder === 999) {
        value.defaultSortOrder = '';
      }
      value.overrideFlagChar = value.overrideFlag ? 'Y' : 'N';
      value.overrideSortOrder =
        value.overrideSortOrder === 0 ? '' : value.overrideSortOrder;
        const _tempElement = _.trim(value.dataElement);
        if (_tempElement.length === 1) {
          value.dataElement  =  '00' + _tempElement;
        } else if(_tempElement.length === 2) {
          value.dataElement  =  '0' + _tempElement;
        } else {
        value.dataElement = _tempElement;
        }
    });
  }
  getSelectedDataID(_deid: string) {
    this.isButtonDisabled = false;
    this.isEditButtonDisabled = false;
    this.selectedDE = _.filter(this.dEList, ['optionalElementID', _deid])[0];
    AdminDataService.dataElement = this.selectedDE;
    this.selectedDEId = _deid;
    AdminDataService.dataElementId = _deid;
  }
  getNewOrder(order) {
      const newOrder = [
        { optionalElementID: order.id, order: order._newOrder }
      ];
      const idIndex = _.findIndex(this.newOrderNumber, [
        'optionalElementID',
        order.id
      ]);

      if (idIndex === -1 && order._newOrder.length !== 0) {
        this.newOrderNumber = _.union(this.newOrderNumber, newOrder, _.isEqual);
      }
        else if (idIndex !== -1){
        this.newOrderNumber[idIndex] = newOrder[0];
        }
      }

  gotoBack() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
  showDeteleModal() {
    PayAdminGlobalState.currentPage = PayAdminGlobalState.previousPage;
    this.modalService.open(this.modelId);
  }
  onDelete() {
    this.spinner.show();
    this.adminService.deleteDE(this.planNumber, this.selectedDEId).subscribe(
      delRes => {
        this.spinner.hide();
        if (delRes.status === APP_CONST.SUCCESS) {
          console.log(' on delete success');
          this.clearSelection();
          this.router.navigate(['/admin/dataElements']);
          //this.getDataElementList(); // will do this logic in client side later if we have performance issue
        } else {
         this.dEList = AdminDataService.dataElements;
          console.log('Error in onDelete', delRes); // for testing
          this.toastr.error(delRes.error.msg, delRes.status + ' !', {
            showCloseButton: true
          });
        }
      },
      err => {
        this.spinner.hide();
        this.dEList = AdminDataService.dataElements;
        console.log('Error in onDelete outside', err); // for testing
        this.toastr.error(
          'Error while deleting Data Element ' + this.selectedDEId,
          err.error.status + '!',
          { showCloseButton: true }
        );
      }
    );
  }
  saveDisplayOrder() {
    AdminDataService.dataElementNewOrder = null;
    let isValidOrder = true;
    this.newOrderNumber = _.sortBy(this.newOrderNumber, ['order']);

    if(_.size(_.find(this.newOrderNumber, ['order', ''])) !== _.size(this.newOrderNumber)){
      _.forEach(this.newOrderNumber, function(value, index) {
            if(parseInt(value.order, 10) !== parseInt(index, 0) + 1) {

              isValidOrder = false;
              return false;
          } else {
          const _deToUpdateIndex = _.findIndex(AdminDataService.dataElements, ['optionalElementID', value.optionalElementID]);
            const tempOrder = [{
            'overrideSortOrder': value.order,
            'objectID': AdminDataService.dataElements[_deToUpdateIndex].objectID,
            'dataElement': AdminDataService.dataElements[_deToUpdateIndex].dataElement,
            'subObjectID': AdminDataService.dataElements[_deToUpdateIndex].subObjectID,
            'omniName': AdminDataService.dataElements[_deToUpdateIndex].omniName

            }];
            AdminDataService.dataElementNewOrder =  _.unionWith(AdminDataService.dataElementNewOrder, tempOrder);
          }
      });
    }
     if(!isValidOrder) {
      this.toastr.error('Check the new sequence number, the number may be duplicated, skipped or out of the range.' ,'Validation failed!', {
        showCloseButton: true
      });
  } else if(_.size(_.find(this.newOrderNumber, ['order', ''])) !== _.size(this.newOrderNumber)){
    this.spinner.show();
    this.adminService
      .updateOrderNumber(this.planNumber, AdminDataService.dataElementNewOrder)
      .subscribe(
        saveRes => {
          AdminDataService.dataElementNewOrder = null;
          this.spinner.hide();
          if (saveRes.status === APP_CONST.SUCCESS) {
            AdminDataService.successMsg = 'Plan Optional Data Elements successfully updated';
            this.router.navigate(['/admin']);
          } else {
            console.log('Error in save order', saveRes);
            this.toastr.error(saveRes.error.msg, saveRes.status + ' !', {
              showCloseButton: true
            });
          }
        },
        err => {
          AdminDataService.dataElementNewOrder = null;
          this.spinner.hide();
          console.log('Error in save order outside', err);
          this.toastr.error(
            'Error while saving display order !',
            err.error.status + ' !',
            { showCloseButton: true }
          );
        }
      );
  } else {
    AdminDataService.successMsg = 'Plan Optional Data Elements successfully updated';
    this.router.navigate(['/admin']);
  }

}
  showOptions() {
    this.router.navigate(['/admin/dataElements/options']);
  }
  onEdit() {
    this.router.navigate(['/admin/dataElements/createOrEdit']);
  }
}

