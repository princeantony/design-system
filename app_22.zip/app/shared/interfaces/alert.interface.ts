export class AlertMessage {
  title: string;
  content: string;
  constructor(title = 'Warning', content = '') {
    this.title = title;
    this.content = content;
  }
}
