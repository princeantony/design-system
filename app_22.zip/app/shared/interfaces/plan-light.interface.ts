export interface IPlanLight
{
	planNumber: string;
    planName: string;
}