import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { Utils } from 'src/app/shared/utils/pay-admin.utils';

import * as Participant from '../../../participants/model/participant.model';
import { ParticipantsService } from '../../../participants/service/participants.service';
import { ParticipantFundSource, ParticipantFundSourceItem } from '../../model/participant.model';
import { ParticipantStore } from '../../store/participant.store';

@Component({
  selector: 'app-participant-confirmation',
  templateUrl: './participant-confirmation.component.html',
  styleUrls: ['./participant-confirmation.component.scss']
})
export class ParticipantConfirmationComponent implements OnInit {
  private participantSubmitData: Participant.ParticipantSubmitData = {} as Participant.ParticipantSubmitData;
  private pData;
  private participantData;
  private optionalData;
  private optionalDatavalues = [];
  private isUpdate: boolean;
  private participantFundSources;
  private fundRows;
  private tableColumns;
  private enrollFlag;
  private status: string;
  constructor(
    private participantsService: ParticipantsService,
    private utils: Utils,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.pData = ParticipantStore.ParticipantData;
    console.log('------this.pData', this.pData);
    this.enrollFlag = ParticipantStore.ParticipantData.requiredData.enrollFlag;
    this.status = ParticipantStore.Status;
    // check if add or update
    this.route.url.subscribe(value => {
      console.log('---url', _.find(value, ['path', 'UpadteParticipant']));
      this.isUpdate = true ? (_.find(value, ['path', 'UpadteParticipant'])) : false;
    });

    // Get Data from Participant store, format and print the confiramtaion screen

    // this.participantSubmitData = this.participantsService.getParticipantDataToSubmit();
    this.pData.optionalData.forEach(field => {
      if (field.value !== '') {
        if (field.componentType === 'dropdown') {
          const displayText = _.find(field.option, ['value', field.value])
            .displayText;
          this.optionalDatavalues.push({
            label: field.label,
            value: displayText
          });
        } else {
          this.optionalDatavalues.push({
            label: field.label,
            value: field.value
          });
        }
      }
    });
    this.optionalData = this.utils.chunkArray(this.optionalDatavalues, 3);

    this.participantFundSources = ParticipantStore.ParticipantData.participantContributionInvestmentData;
    // column data
    const columnsList = this.participantFundSources.sourceMap;
    this.tableColumns = [];

    // Create First Default FundNameColumn
    this.tableColumns.push({
      field: 'fundName',
      headerName: 'Fund Name'
    });
    // Push one column for each Source item
    if (columnsList) {
      columnsList.forEach(column => {
        this.tableColumns.push({
          field: column.sourceId,
          headerName: column.sourceName,
        });
      });
    }


    // row data
    const fundSources: ParticipantFundSource[] = this.participantFundSources
    .fundSources;
  this.fundRows = [];
  if (fundSources) {
    fundSources.forEach(fundSrc => {
      const rowItem = Object.assign({ fundName: fundSrc.fundName });
      console.log('-----rowItem', rowItem);
      const sources: ParticipantFundSourceItem[] = fundSrc.percents;

      sources.forEach((src: ParticipantFundSourceItem) => {
        if (src.currentPercent !== '0') {
        Object.assign(rowItem, { [src.sourceId]: src.currentPercent});
      }
      });
      console.log('-----rowItem', rowItem);
      if (_.keys(rowItem).length > 1) {
        this.fundRows.push(rowItem);
      }
    });
    console.log('--------------fundrows', this.fundRows);
    console.log('---------table columns', this.tableColumns);
  }



  }
  onBackClick() {
    if (this.isUpdate) {
      if (!this.enrollFlag) {
        this.router.navigate(['UpdateParticipant']);
      } else {
        this.router.navigate(['UpdateParticipant/ContributionInvestment']);
      }
    } else {
      if (!this.enrollFlag) {
        this.router.navigate(['addParticipant']);
      }
      this.router.navigate(['addParticipant/ContributionInvestment']);
    }


  }
  onSumitClick() {

  }
}
