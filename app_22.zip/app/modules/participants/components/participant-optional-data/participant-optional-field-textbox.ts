import { ParticipantOptionalFields } from './participant-optional-fields';

export class ParticipantOptionalFieldTextBox extends ParticipantOptionalFields<
  string
> {
  componentType = 'textbox';
  type: string;
  hasMessage: boolean;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
    this.hasMessage = options['hasMessage'] || false;
  }
}
