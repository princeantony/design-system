import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';

import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';

@Injectable({
  providedIn: 'root'
})
export class BankInfoService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService
  ) {}

  getBankInfo(planNumber: string): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getBankInfo(); // to be removed before prod release
    }
    return this.apiService.get(SERVICE_URL.GET_BANK_INFO_URL + planNumber);
  }
  getSubDiv(planNumber: string): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getSubDiv();
    }
    return this.apiService.get(
      SERVICE_URL.GET_HOME_URL + planNumber + '/divsub'
    );
  }
  updateBankInfo(
    bankInfo: any,
    planNumber: string,
    divsubId: string
  ): Observable<any> {
    if (divsubId === '') {
      return this.apiService.put(
        SERVICE_URL.POST_BANK_INFO_URL + planNumber,
        bankInfo
      );
    } else {
      return this.apiService.put(
        SERVICE_URL.POST_BANK_INFO_URL + planNumber + '/divsub/' + divsubId,
        bankInfo
      );
    }
  }
  postBankInfo(
    bankInfo: any,
    planNumber: string,
    divsubId: string
  ): Observable<any> {
    if (divsubId === '') {
      return this.apiService.post(
        SERVICE_URL.POST_BANK_INFO_URL + planNumber,
        bankInfo
      );
    } else {
      return this.apiService.post(
        SERVICE_URL.POST_BANK_INFO_URL + planNumber + '/divsub/' + divsubId,
        bankInfo
      );
    }
  }
}
