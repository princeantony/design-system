import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateCreateFWComponent } from './template-create-fixed-width.component';

describe('TemplateCreateFWComponent', () => {
  let component: TemplateCreateFWComponent;
  let fixture: ComponentFixture<TemplateCreateFWComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateCreateFWComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateCreateFWComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
