import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateModalErrorComponent } from './template-modal-error.component';

describe('TemplateModalErrorComponent', () => {
  let component: TemplateModalErrorComponent;
  let fixture: ComponentFixture<TemplateModalErrorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateModalErrorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateModalErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
