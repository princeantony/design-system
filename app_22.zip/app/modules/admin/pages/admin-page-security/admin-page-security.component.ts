import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { Router } from '../../../../../../node_modules/@angular/router';
import { NgxSpinnerService } from '../../../../../../node_modules/ngx-spinner';
import { APP_CONST, ENV, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { IPageList } from '../../../../shared/interfaces/page-list.interface';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { AdminPageSetupService } from '../../services/admin-page-setup.service';


@Component({
  selector: 'app-admin-page-security',
  templateUrl: './admin-page-security.component.html',
  styleUrls: ['./admin-page-security.component.scss']
})
export class AdminPageSecurityComponent implements OnInit {
  planNumber: string;
  subTitle : string;
  pageList: Partial<IPageList>[];
  pageFlags: any;
  showPrint = false;
  pageSecurityForm: FormGroup;
  constructor(
    private pageSetupService :  AdminPageSetupService,
      private spinner: NgxSpinnerService,
      private router: Router
      ) { }

  ngOnInit() {
    PayAdminGlobalState.previousPage = 'admin';
    PayAdminGlobalState.currentPage = 'admin/pageSecurity';
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.PAGE_SECURITY;
    if(ENV.TEST)
    this.getMockPageSettings();
    else
    this.getPageSettings();
  }
  getMockPageSettings(){
    this.pageSetupService.getMockPageSettings(this.planNumber).subscribe(flags => {
      if(flags.status === APP_CONST.SUCCESS)
      {
        this.pageList = this.pageSetupService.getPageList(flags.data);
        this.pageSecurityForm = this.buildFormGroup(this.pageList);
        this.spinner.hide();
      }
    });
  }
  getPageSettings(){
    this.spinner.show();
    this.pageSetupService.getPageSettings(this.planNumber).subscribe(flags => {
      if(flags.status === APP_CONST.SUCCESS)
      {
        this.pageList = this.pageSetupService.getPageList(flags.data);
        this.pageSecurityForm = this.buildFormGroup(this.pageList);
        this.spinner.hide();
      }
    });
  }

  buildFormGroup(pageList: Partial<IPageList>[] ) {
    let group: any = {};

    pageList.forEach(page => {
      group[page.key] = new FormControl(page.value || false);
      if(page.subItems){
        page.subItems.forEach(subPage =>{
          group[subPage.key] = new FormControl(subPage.value || false);
        });
      }
    });
    return new FormGroup(group);
  }
 onMockSubmit()
 {

   PayAdminGlobalState.successMsg = 'Plan Page Security Information successfully updated ';
    this.router.navigate(['/home/success']);
 }
 // The below two methods can be writtern in generic with less line of code if the parent and child properties are having fixed pattern
 DisableChild(thisCtr) {
if(this.pageSecurityForm.controls[thisCtr.controlName].value)
{
  if( thisCtr.controlName === 'addEnrollmentPageActive') {
    this.pageSecurityForm.controls['addEnrollmentImportPageActive'].setValue(false);
  } else if( thisCtr.controlName === 'batchParticipantUpdatePageActive') {
    this.pageSecurityForm.controls['batchParticipantUpdateImportPageActive'].setValue(false);
  } else if( thisCtr.controlName === 'contributionPageActive') {
    this.pageSecurityForm.controls['contribImportPageActive'].setValue(false);
  } else  if( thisCtr.controlName === 'loanRepaymentPageActive') {
    this.pageSecurityForm.controls['loanImportPageActive'].setValue(false);
  }
}
}
disableClick(thisCtr)
{
  let importParent = false;
  if(!this.pageSecurityForm.controls['addEnrollmentPageActive'].value) {
    importParent = true;
  } else if(! this.pageSecurityForm.controls['batchParticipantUpdatePageActive'].value) {
    importParent = true;
  } else if(!this.pageSecurityForm.controls['contributionPageActive'].value) {
    importParent = true;
  } else  if(!this.pageSecurityForm.controls['loanRepaymentPageActive'].value) {
    importParent = true;
  }
  if(importParent) {
    setTimeout(() => {
      this.pageSecurityForm.controls[thisCtr.controlName].setValue(false);
    }, 1);
  }
}
  onSubmit(){
    console.log("this.pageSecurityForm.value", this.pageSecurityForm.value)
    if(ENV.TEST)
    this.onMockSubmit();
    else{
    this.spinner.show();
    this.pageSetupService.savePageSettings(this.pageSecurityForm.value,this.planNumber).subscribe(pageFlags => {
      if(pageFlags.status === APP_CONST.SUCCESS)
      {
        PayAdminGlobalState.successMsg = 'Plan Page Security Information successfully updated ';
        this.spinner.hide();
        this.router.navigate(["/home/success"]);
      }
    },(err => {console.log("Error in save page security", err);this.spinner.hide();}));

  }
  }

   gotoPrevious() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
  }
}
