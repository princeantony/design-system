import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'app-admin-update-optional',
    templateUrl: './admin-update-optional.component.html'

  })

  export class AdminUpdateOptionalComponent implements OnInit{
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;

    updateOtionalDataForm = this.fb.group({
        dataElement1: ['', Validators.required],
        dataElement2: ['', Validators.required],
        dataElement3: ['', Validators.required],
    })


    constructor( private fb: FormBuilder,){ }

    ngOnInit(){
      this.hidePageTitle = false;
      this.subTitle = 'Update Optional Data Element';
      this.planNumber ='559985';
    }
  }
