import { Component, Input, Output, OnInit, EventEmitter } from '@angular/core';

import { AdminGridRadioComponent } from '../../admin-grid-radio/admin-grid-radio.component';

@Component({
  selector: 'app-admin-options-data-grid',
  templateUrl: './admin-options-data-grid.component.html'
})
export class AdminOptionsDataGridComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
  @Output()
  getDataId = new EventEmitter<string>();
context: any;
frameworkComponents: any;
  ngOnInit() {
    this.context = {
    componentParent: this
};
  this.frameworkComponents = {
  radiobuttonRender : AdminGridRadioComponent,
  };
  }
  selectedItem(dataElementID) {
    this.getDataId.emit(dataElementID);
  }
}
