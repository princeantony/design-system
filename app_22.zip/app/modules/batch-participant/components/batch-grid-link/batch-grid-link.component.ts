import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
    selector: "app-batch-grid-link",
    templateUrl: "./batch-grid-link.component.html"
})
export class BatchGridLinkComponent implements ICellRendererAngularComp {

    private params: any;
    public link : string;

    agInit(params: any): void {
        this.params = params;       
    }

    constructor(private router: Router) { }


    public invokeRouteTo() {
        this.router.navigate(['/plans']);
    }
    refresh(): boolean {
        return false;
    }
}
