import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';
import { SERVICE_URL } from 'src/app/shared/constants/service.constants';
import { ApiService } from 'src/app/shared/services/api.service';
import { MockService } from 'src/app/shared/services/mock.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

@Injectable({
  providedIn: 'root'
})
export class BatchParticipantService {
  selectedFields: string[] = [];
  constructor(private mockService: MockService, private apiService: ApiService) { }

  getBatchParticipantField(): Observable<any> {
   
    console.log(PayAdminGlobalState.planNumber);

    return ENV.TEST ? this.mockService.getBatchParticipantFields() :
      this.apiService.get(SERVICE_URL.GET_PARTICIPANT_DATA_FIELDS.replace('{planNumber}', PayAdminGlobalState.planNumber));
  }

  getParticipantList(urlValues): Observable<any> {

    return ENV.TEST ? this.mockService.getBatchParticipantList() :
      this.apiService.get(SERVICE_URL.GET_PARTICIPANTS_DATA.replace(
        '{planNumber}', PayAdminGlobalState.planNumber) + urlValues);
  }

  postBulkParticipants(dataElements: any, urlValues: any): Observable<any> {
    console.log(dataElements);
    return ENV.TEST ? this.mockService.doAuthenticate() :
     this.apiService.put(SERVICE_URL.POST_BULK_PARTICIPANTS.replace('{planNumber}',
     PayAdminGlobalState.planNumber) + urlValues, dataElements );

  }

  setSelectedFields(_selectedFields: string[]) {
    this.selectedFields = _selectedFields;
  }

  getSelectedFields(): string[] {
    return this.selectedFields;
  }
}
