import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AgGridModule} from 'ag-grid-angular';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { PlanListComponent } from './modules/plans/components/plan-list/plan-list.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';

import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import { GridComponent } from './shared/components/form/voya-grid/grid.component';

import { PayAdminRoutingModule, PayAdminRoutingComponents } from '../app/shared/modules/pay-admin-routing.module';
import {PayAdminHomeComponent} from '../app/modules/home/pages/pay-admin-home/pay-admin-home.component'; 
import { HeaderComponent } from '../app/shared/components/layout/header/header.component';


import { TimeInfoComponent } from './shared/components/time-info/time-info.component';
import { PageTitleComponent } from './shared/components/layout/page-title/page-title.component';
import { PayAdminMenuComponent } from './modules/home/components/pay-admin-menu/pay-admin-menu.component';
import { VoyaLinkComponent } from './shared/components/form/voya-link/voya-link.component';
import { ModalService } from './shared/services/modal.service';
import { ModalComponent } from './shared/directives/modal.component';
import { BrowserInfoComponent } from './shared/components/browser-info/browser-info.component';
import {PlanReducer} from './shared/store/reducers/plan.reducer';
import { BankInformationComponent } from './modules/bank-information/bank-information.component';
import { InputTextComponent } from './shared/components/form/voya-input/input-text/input-text.component';
import HomeService from './modules/home/services/home.service';
import Utils from './shared/utils/pay-admin.utils';
import {ApiService} from './shared/services/api.service';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    PlanListComponent,
    PlanSelectionComponent,
    HeaderComponent,
    GridComponent,
    PayAdminHomeComponent,
    PayAdminRoutingComponents,
    TimeInfoComponent,
    PageTitleComponent,
    PayAdminMenuComponent,
    VoyaLinkComponent,
    ModalComponent,
    BrowserInfoComponent,
    BankInformationComponent,
    InputTextComponent
        
  ],
  imports: [
    BrowserModule,
    PayAdminRoutingModule,
    HttpClientModule,
    StoreModule.forRoot({ planList: PlanReducer }),
    StoreDevtoolsModule.instrument({maxAge: 10}),
    AgGridModule.withComponents([])
  ],
  providers: [ModalService, ApiService],
  bootstrap: [AppComponent ]
})
export class AppModule { }
