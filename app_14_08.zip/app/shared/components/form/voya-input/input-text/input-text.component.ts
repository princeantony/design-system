import { Component, OnInit, Input } from "@angular/core";

@Component({
  selector: "app-input-text",
  templateUrl: "./input-text.component.html",
  styleUrls: ["./input-text.component.scss"]
})
export class InputTextComponent implements OnInit {
  @Input() placeHolderText: string = "";
  @Input() inputType: string = "text";
  @Input() inputID: string = "";
  @Input() isRequired: boolean = false;
  @Input() isReadOnly: boolean = false;
  @Input() inputValue: string = "";
  @Input() maxLenth: Number;
  @Input() minLength: Number = 0;
  @Input() isDisabled: boolean;
  @Input() inputLabel: string = "";
  @Input() inputClass: string = "";

  constructor() {}

  ngOnInit() {
    if (!this.placeHolderText) {//This evaluates to true when value is not : null, undefined, NaN, empty string '', 0 , false
      this.placeHolderText = "First Name";
    }
    this.inputID = "fName";
    if(!this.inputLabel){//This evaluates to true when value is not : null, undefined, NaN, empty string '', 0 , false
      this.inputLabel = this.placeHolderText;
    }
    
  }
}
