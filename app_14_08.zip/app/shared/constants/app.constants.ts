export const MESSAGES=
{
    VOYA_WORKING_TIME: 'The voya office timing message',
    VOYA_APP_NAME : 'Payroll/Administration',
    SERVICE_ERROR: 'There is an error occurred while calling the service!',
    SERVICE_SUCCESS: 'Service call succeeded!',
    SERVICE_START: 'Please wait... Service call in progress!'
};

export const GRID_CONFIG = {
    LIST_PLAN: {
      GRID_SIZE : {width: 555, height: 800},
      COLUMN_DEFS : [
      { headerName: "Plan Number", field: "planNumber", width: 200 },
      { headerName: "Plan Name", field: "planName", width: 350 }
    ]}
  };
export const ACTION_TYPE =
{
	LIST_PLAN : 'LIST_PLAN'
}
export const APP_CONST = 
{
    APP_CONTEXT: '../'
}