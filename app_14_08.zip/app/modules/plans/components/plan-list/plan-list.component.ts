import { Store, State } from '@ngrx/store';
import { Component, OnInit} from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {GRID_CONFIG} from '../../../../shared/constants/app.constants';
import {PlanListAction} from '../../../plans/actions/plan-list.action';
import {MockService} from '../../../../shared/services/mock.service';
import {ListPlan} from '../../../../shared/mocks/listPlan';
import {ApiService} from '../../../../shared/services/api.service';
import {SERVICE_URL} from '../../../../shared/constants/service.constants'
import {LoginUser} from '../../../../shared/mocks/login-user.mock';
import {AppState} from '../../../../shared/store/state/app.state';
import {IPlanLight} from '../../../../shared/interfaces/plan-light.interface';
@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss']
})
@Injectable()
export class PlanListComponent implements OnInit {
columnDefs: any;
rowData: any;
width;
planListItem : any;
constructor(private store: Store<AppState>,private state: State<AppState>, private apiService: ApiService) {
  this.planListItem = this.state.getValue().planList;
  if(this.planListItem === undefined)
  {
  console.log("service");
  this.rowData=ListPlan.data; // for mock data
  this.store.dispatch(new PlanListAction({planList: this.rowData }) ); 

  }
  else
  {
  this.rowData = this.planListItem.planList;
  console.log("from state");
  }
  this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
  this.width= GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
  //this.rowData = store.select('planList');
 
}

  ngOnInit() {
    //this.login(); //for actual service 
  }
  getPlans(): void {
    this.apiService.get(SERVICE_URL.GET_LISTPLAN_URL)
    .subscribe(plans => {
      this.rowData = plans.data;
     // this.store.dispatch(new PlanListAction({planList: plans.data }) )
    });
  }
  login(): any {
    this.apiService.post(SERVICE_URL.GET_DIRECT_LOGIN_URL,LoginUser )
    .subscribe(loginInfo => { if(loginInfo.status === "SUCCESS") this.getPlans();});
  }
}
