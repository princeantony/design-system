import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayAdminMenuComponent } from './pay-admin-menu.component';

describe('PayAdminMenuComponent', () => {
  let component: PayAdminMenuComponent;
  let fixture: ComponentFixture<PayAdminMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayAdminMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayAdminMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
