import { Component, OnInit, Injectable } from '@angular/core';
import { MenuItem } from "../../../../shared/interfaces/menu-item.interface";
import { HomeService } from "../../services/home.service";
import Utils from "../../../../shared/utils/pay-admin.utils";
import {APP_CONST} from '../../../../shared/constants/app.constants';
//@Injectable()
@Component({
  selector: 'app-pay-admin-menu',
  templateUrl: './pay-admin-menu.component.html',
  styleUrls: ['./pay-admin-menu.component.scss'],
  providers: [Utils, HomeService]
})
export class PayAdminMenuComponent implements OnInit {
  
  menuItems: MenuItem[];
  menuItemRows: Array<MenuItem[]>;
  appContext =  APP_CONST.APP_CONTEXT;
  constructor(private utils: Utils, private homeService: HomeService) {}

  ngOnInit() {
    this.menuItems = this.homeService.getMenuList();
    this.menuItemRows = this.utils.chunkArray(this.menuItems, 3);
  }
}
