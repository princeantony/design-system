import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import _ from 'lodash';
import { CommonService } from 'src/app/shared/services/common.service';

import { ListPlan } from '../../../mocks/listPlan';
import { PayAdminGlobalState } from '../../../store/pay-admin-global.store';

// Usage : <app-page-title pageTitle="Add/Enroll Participant"> </app-page-title>
@Component({
  selector: 'app-page-title',
  templateUrl: './page-title.component.html'
})
export class PageTitleComponent implements OnInit {
  // Start Remove these input variables these are handled in this component not required to send as input parmeter
  @Input() hidePageTitle: boolean;
  @Input() pageTitleClass: boolean;
  @Input() changePlan: boolean;
  @Input() planNumber: string;
  @Input() colorChange: boolean;
  // End Remove

  @Input() pageTitle: string;
  selectedPlan: any;
  planTitle: string;
  planList = ListPlan.data;

  titleAsLink = false;
  canChangePlan = false;
  isPlanListingPage = false;
  hasPlanSelected = false;

  constructor(private router: Router, private commonService: CommonService) {}
  ngOnInit() {
    if (PayAdminGlobalState.planNumber) {
      this.planNumber = PayAdminGlobalState.planNumber;
      this.hasPlanSelected = true;
    }
    // Plan Page: /plans
    // Home Page: /home
    if (this.router.url.toLowerCase().indexOf('/home') >= 0) {
      this.canChangePlan = true;
      this.titleAsLink = false;
    }
    if (this.router.url.toLowerCase().indexOf('/plans') >= 0) {
      this.isPlanListingPage = true;
      this.titleAsLink = true;
      this.pageTitle = 'Plan Selection';
    }
    if (this.pageTitle) {
      this.pageTitle = '- ' + this.pageTitle;
    }
    this.selectedPlan = _.find(this.planList, ['planNumber', this.planNumber]);
    if (this.selectedPlan) {
      this.planTitle =
        '- ' + this.selectedPlan.planNumber + '-' + this.selectedPlan.planName;
    }
  }
  navToPlans() {
    PayAdminGlobalState.previousPage = '/home';
    this.router.navigate(['/plans']);
  }

  navToHome() {
    this.router.navigate(['/home']);
  }
}
