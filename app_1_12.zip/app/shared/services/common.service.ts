import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { forkJoin, Observable, Subject } from 'rxjs';

import { ENV } from '../constants/app.constants';
import { SERVICE_URL } from '../constants/service.constants';
import { ApiService } from './api.service';
import { MockService } from './mock.service';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService,
    private http: HttpClient
  ) {}

  planChanged = new Subject<string>();
  countryChanged = new Subject<string>();

  getCountryList(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getCountryListMock()
      : this.apiService.get(SERVICE_URL.GET_COUNTRY);
    // return this.mockService.getCountryListMock();
  }
  getStateList(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getCountryListMock()
      : this.apiService.get(SERVICE_URL.GET_STATE);
  }

  getCountryStateList(): Observable<any> {
    if (ENV.TEST) {
      return forkJoin(
        this.mockService.getCountryListMock(),
        this.mockService.getStateListMock()
      );
    } else {
      return forkJoin(
        this.apiService.get(SERVICE_URL.GET_COUNTRY),
        this.apiService.get(SERVICE_URL.GET_STATE)
      );
    }
  }
}
