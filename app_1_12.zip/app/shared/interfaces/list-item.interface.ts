export interface IListItem{
    displayText: string;
    value: string;
    
}