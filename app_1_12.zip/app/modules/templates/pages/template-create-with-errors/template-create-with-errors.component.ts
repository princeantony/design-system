import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import _ from 'lodash';
import { importMapping } from 'src/app/shared/config/template.config';
import { ModalService } from 'src/app/shared/services/modal.service';

import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { APP_CONST, ENV, SUB_TITLE } from '../../../../shared/constants/app.constants';
import { templateData } from '../../../../shared/mocks/template-with-error';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { TemplateGridHeaderComponent } from '../../components/template-grid-header/template-grid-header.component';
import { IcolumnList, ITemplate } from '../../model/template.model';
import { TemplatesService } from '../../services/templates.service';

@Component({
  selector: 'app-template-create-with-errors',
  templateUrl: './template-create-with-errors.component.html',
  styleUrls: ['./template-create-with-errors.component.scss']
})
export class TemplateCreateComponent implements OnInit {
  templateForm = this.fb.group({
    templateId: [],
    headerCount: ['0'],
    trailerCount: ['0']
  });
  planNumber: string;
  pageTitle: string;
  hidePageTitle = false;
  fileData: any;
  fileType: string;
  templateData: ITemplate;
  importType: string;
  headerDropdown: any;
  private rowData: any[];
  private columnDefs = [];
  gridApi: any;
  successMessage: any;
  gridColumnApi: any;
  params: any;
  frameworkComponents: any;
  isError = false;
  errorObj: any;
  singleClickEdit = false;
  defaultColDef: any;
  suppressClickEdit = true;
  columnList: IcolumnList[] = [];
  clientValidationObj = [];
  constructor(
    private fb: FormBuilder,
    private templateservice: TemplatesService,
    private router: Router,
    private modalService: ModalService
  ) {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.pageTitle = SUB_TITLE.TEMPLATE_CREATE;
    this.fileData = PayAdminGlobalState.importFileData;
    this.fileType = PayAdminGlobalState.importFileType;
    this.importType = PayAdminGlobalState.importType;
    if (ENV.TEST) {
      this.getMockColumnList();
    } else {
      this.getColumnList();
    }
  }

  getMockColumnList() {
    this.templateservice
      .getAvailableColsMock(this.planNumber, this.importType)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.headerDropdown = response.data.availableColumnList;
            this.fileData = templateData.data.fileData;
            this.createGridData();
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }

  getColumnList() {
    this.templateservice
      .getAvailableCols(this.planNumber, this.importType)
      .subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            this.headerDropdown = response.data.availableColumnList;
            this.createGridData();
          }
        },
        err => {
          console.log('Error', err);
        }
      );
  }

  createGridData() {
    console.log('---------------this.testdata', this.fileData);
    // finding the number of columns from the file data
    let noOfCols = 0;
    for (const row of this.fileData) {
      if (row.length > noOfCols) {
        noOfCols = row.length;
      }
    }
    console.log('---------------noOfCols', noOfCols);
    for (let index = 0; index < noOfCols; index++) {
      // const element = array[index];
      this.columnDefs.push({
        field: (index + 1).toString(),
        headerName: null, // (index + 1).toString(),
        editable: true,
        headerComponentParams: { options: this.headerDropdown }
      });
      this.defaultColDef = { editable: false };
    }
    const rows = this.fileData;
    this.rowData = [];
    for (let i = 0; i < rows.length; i++) {
      const obj = {};
      for (let j = 0; j < rows[i].length; j++) {
        obj[(j + 1).toString()] = rows[i][j];
      }
      this.rowData.push(obj);
    }
    // console.log("---this.rowData", this.rowData);
    // console.log("--------coldef", this.columnDefs);
    this.frameworkComponents = { agColumnHeader: TemplateGridHeaderComponent };
  }

  saveTemplate() {
    console.log('--------save template function', this.templateForm);
    console.log('------------this.gridApi', this.params);
    this.templateForm.value.
    this.columnList = [];
    this.gridApi.gridOptionsWrapper.gridOptions.columnDefs.forEach(element => {
      this.columnList.push({
        value: element.headerName,
        colNumber: element.field
      });
    });
    this.templateData = this.templateForm.value;
    this.templateData.fileType = this.fileType;
    this.templateData.isNewTemplate = true;
    this.templateData.importType = this.importType;
    this.templateData.columnList = this.columnList;

    console.log('-----------templateData', this.templateData);
    this.successMessage = '';
    if (ENV.TEST) {
      this.templateservice.saveMockTemplate().subscribe(
        response => {
          if (response.status === APP_CONST.SUCCESS) {
            console.log(response.message);
            this.successMessage = response.message;
          }
        },
        err => {
          console.log('Error', err);
        }
      );
    } else {
      this.templateservice
        .saveTemplate(this.planNumber, this.templateData)
        .subscribe(
          response => {
            if (response.status === APP_CONST.SUCCESS) {
              console.log(response.message);
              this.successMessage = response.message;
            }
          },
          err => {
            console.log('Error', err);
          }
        );
    }
  }
  saveAndCont() {
    this.gridApi.stopEditing();
   // this.saveTemplate();
     this.clientValidationObj = [];
    // validation for duplicate column selection
    this.columnList = [];
    this.gridApi.gridOptionsWrapper.gridOptions.columnDefs.forEach(element => {
      this.columnList.push({
        value: element.headerName,
        colNumber: element.field
      });
    });
    const mappedArray = this.columnList.map(function(item) {
      return item.value;
    });
    console.log('---mapped array', mappedArray);
    const duplicateCols = [];
    _.filter(mappedArray, function(item, id) {
      console.log(item);
      if (mappedArray.indexOf(item) !== id) {
        console.log(_.indexOf(duplicateCols, item));
        if (_.indexOf(duplicateCols, item) < 0) {
          duplicateCols.push(item);
        }
      }
    });
    const duplicateColNames = [];
    console.log('-------duplicateCols', duplicateCols);
    if (duplicateCols.length > 0) {
      for (let i = 0; i < duplicateCols.length; i++) {
        if (duplicateCols[i]) {
          duplicateColNames.push(
            _.find(this.headerDropdown, ['value', duplicateCols[i]]).displayText
          );
        }
      }
    }

    console.log('----duplicate col', duplicateColNames);
    if (duplicateColNames.length > 0) {
      this.clientValidationObj.push('Duplicate columns found for ' + duplicateColNames);
    }
    // validation template name
    const templateId = this.templateForm.value.templateId;
    console.log('-------templateId', templateId);
    if (!templateId) {
      this.clientValidationObj.push('Template name is required');
    }
    console.log('----------column list', this.columnList);
    // validation column selection
    const colnums = [];

    for (const col of this.columnList) {
      if (col.value === null) {
        console.log('----col number', col.colNumber);
        colnums.push('Column ' + col.colNumber + ' ');
      }


    }
    if (colnums.length > 0) {
      this.clientValidationObj.push('Select heading for ' + colnums);
    }
   const ssnCol =  _.find(this.columnList, ['value', 'ssn']);
   if (!ssnCol) {
    this.clientValidationObj.push('Please select a column for Social Security Number');
   }

    // validation ends
    if (this.clientValidationObj.length > 0) {
      // alert(duplicateColNames);
      console.log('-------------this.clientValidationObj', this.clientValidationObj);
      console.log('---------------dropdown', this.headerDropdown);
      console.log(duplicateColNames);
    } else {
      const fileData = [];
      for (let i = 0; i < this.rowData.length; i++) {
        const a = [];
        _.forEach(this.rowData[i], function(value, key) {
          a.push(value);
        });
        fileData.push(a);
      }
      console.log('---------edited file data', fileData);
      PayAdminGlobalState.importFileData = fileData;
      const templateFileData = {
        templateId: this.templateForm.value.templateId,
        importType: PayAdminGlobalState.importType,
        fileData: PayAdminGlobalState.importFileData
      };
      if (ENV.TEST) {
        this.templateservice.validateMockFileData().subscribe(
          response => {
            console.log('-------------response', response);
            if (response.status === APP_CONST.SUCCESS) {
              if (response.data.validationData) {
                this.isError = true;
                this.errorObj = response.data.validationData;
                this.singleClickEdit = true;
                this.defaultColDef.editable = true;
                console.log('-------------api', this.gridApi);
                this.gridApi.gridOptionsWrapper.gridOptions.suppressClickEdit = false;
                this.gridApi.gridOptionsWrapper.gridOptions.singleClickEdit = true;
                console.log('---rowdata', this.rowData);
                console.log('---error obj', this.errorObj);
                const ssnColumn = _.find(this.columnDefs, ['headerName', 'ssn']).field;
                this.gridApi.forEachNode(node => {
                  console.log('-----node', node);
                 if ( _.find(this.errorObj, ['ssn', node.data[ssnColumn]])) {
                  this.gridApi.startEditingCell({
                    rowIndex: node.rowIndex,
                    colKey: ssnColumn
                  });
                 }
                });

                // this.gridApi.setFocusedCell(0, 0);
                /* this.gridApi.forEachNode(node => {
                console.log('-----node', node);
                _.entries(node.data).forEach(element => {
                  console.log('-------------------element', element);
                  this.gridApi.startEditingCell({
                    rowIndex: node.rowIndex,
                    colKey: element[0]
                  });
                });
              }); */
              } else if (response.data.message === 'Success message') {
                PayAdminGlobalState.importFileData = response.data.fileData;
                console.log('-----columndes', this.columnDefs);
                console.log('-------header dd', this.headerDropdown);
                const cols = [];
                for (let i = 0; i < this.columnDefs.length; i++) {
                  cols.push({
                    field: this.columnDefs[i].headerName,
                    headerName: _.find(this.headerDropdown, [
                      'value',
                      this.columnDefs[i].headerName
                    ]).displayText
                  });
                }
                PayAdminGlobalState.importColumns = cols;
                this.router.navigate(['/template/verify']);
              }
            }
          },
          err => {
            console.log('Error', err);
          }
        );
      } else {
        const url = importMapping[this.importType]['serviceUrl'];
        this.templateservice
          .validateFileData(url, this.planNumber, templateFileData)
          .subscribe(
            response => {
              console.log('-------------response', response);
              if (response.status === APP_CONST.SUCCESS) {
                if (response.validationData) {
                  this.isError = true;
                  this.errorObj = response.data.validationData;
                  this.singleClickEdit = true;
                  this.defaultColDef.editable = true;
                  console.log('-------------api', this.gridApi);
                  this.gridApi.gridOptionsWrapper.gridOptions.suppressClickEdit = false;
                  this.gridApi.gridOptionsWrapper.gridOptions.singleClickEdit = true;
                  // this.gridApi.setFocusedCell(0, 0);
                  /* this.gridApi.forEachNode(node => {
              console.log('-----node', node);
              _.entries(node.data).forEach(element => {
                console.log('-------------------element', element);
                this.gridApi.startEditingCell({
                  rowIndex: node.rowIndex,
                  colKey: element[0]
                });
              });
            }); */
                } else if (response.data.message === 'Success message') {
                  PayAdminGlobalState.importFileData = response.data.fileData;
                  const cols = [];
                  for (let i = 0; i < this.columnDefs.length; i++) {
                    cols.push({
                      field: this.columnDefs[i].headerName,
                      headerName: _.find(this.headerDropdown, [
                        'value',
                        this.columnDefs[i].headerName
                      ]).displayText
                    });
                  }
                  PayAdminGlobalState.importColumns = cols;
                  this.router.navigate(['/template/verify']);
                }
              }
            },
            err => {
              console.log('Error', err);
            }
          );
      }
    }
  }
  onGridReady(params) {
    console.log('--------onGridReady', params);
    this.params = params;
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  openErrorModal() {
    this.modalService.open('error-modal');
  }
  gotoBack() {
    this.router.navigate(['/template/select']);
  }
}
