import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateGridHeaderComponent } from './template-grid-header.component';

describe('TemplateGridHeaderComponent', () => {
  let component: TemplateGridHeaderComponent;
  let fixture: ComponentFixture<TemplateGridHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateGridHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateGridHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
