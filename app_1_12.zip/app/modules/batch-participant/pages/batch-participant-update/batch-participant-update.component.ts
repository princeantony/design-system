import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import _ from 'lodash';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { BatchParticipantService } from '../../services/batchParticipant.service';

// import { NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';
@Component({
    selector: 'app-batch-participant-update',
    templateUrl: './batch-participant-update.component.html',
    styleUrls: ['./batch-participant-update.component.scss']
})

export class BatchParticipantUpdateComponent implements OnInit {
    slectDataColumnDefs: any;
    selectData: any;
    hidePageTitle: boolean;
    pageTitle: string;
    planNumber: string;
    participantUpdateForm: FormGroup;
    fieldList: any;
    selectedFields = [];
    btnDisabled = true;

    constructor(private fb: FormBuilder, private batchService: BatchParticipantService, private router: Router,
        private spinner: NgxSpinnerService) { }

    ngOnInit() {
        this.hidePageTitle = false;
        this.pageTitle = 'Batch Participant Update 1 Of 2';
        this.planNumber = PayAdminGlobalState.planNumber;
        this.getBatchParticipantField();

    }

    buildFormGroup(fieldList: any) {
        let group: any = {};
        fieldList.forEach(field => {
            group[field.key] = new FormControl(field.value || false);

        }
        );
        return new FormGroup(group);
    }


    getBatchParticipantField() {
        this.spinner.show();
        this.batchService.getBatchParticipantField().subscribe(flags => {

            if (flags.status === APP_CONST.SUCCESS) {
                PayAdminGlobalState.participantDiv = flags.data.divsubId;
                PayAdminGlobalState.BatchdivsubEnabled = flags.data.divsubEnabled
                this.fieldList = flags.data.fields;
                this.participantUpdateForm = this.buildFormGroup(this.fieldList);
                this.loadSelectedFieldsOnBack();

            } else {
                console.log("inside error ", flags);
                this.spinner.hide();
            }
        },
            (
                err => {
                    console.log("inside error ", err);
                    this.spinner.hide();
                }
            ));
    }

    onSubmit() {
        var value = this.participantUpdateForm.value
        for (let [key, value] of Object.entries(this.participantUpdateForm.value)) {
            if (value) {
                this.selectedFields.push(key);
            }
        }

        PayAdminGlobalState.selectedFields = this.selectedFields;

        console.log(PayAdminGlobalState.selectedFields);
        this.router.navigate(['/batchParticipant/active']);


    }

    gotoPrevious() {
        this.router.navigate(['/home']);
    }


    loadSelectedFieldsOnBack() {
        if (PayAdminGlobalState.selectedFields != '' && PayAdminGlobalState.selectedFields != undefined) {
            this.btnDisabled = false;
            for (var item of PayAdminGlobalState.selectedFields) {
                this.participantUpdateForm.controls[item].setValue(true)
            }
        }
        this.spinner.hide();

    }

    enableBtn() {
        var select = _.findKey(this.participantUpdateForm.value);
        if (select === undefined) {
            this.btnDisabled = true;
        }

        else {
            this.btnDisabled = false;
        }

    }
}

