import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { ModalService } from '../../../../../shared/services/modal.service';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
    selector: 'app-admin-options-data',
    templateUrl: './admin-options-data.component.html'
  })

export class AdminOptionsDataComponent implements OnInit{
    slectDataColumnDefs: any;
    hidePageTitle: boolean;
    pageTitle: string;
    planNumber: string;
    dataelementID: string;
    isButtonDisabled = false;
    selectedOptionId : string;
    selectedOption: any;
    dataElementOptions: any;
    type = 'Data Element Option';
    modelId = 'deOptionModal';
    navigateTo = 'options/';
    constructor(
      private adminService: AdminService,
      private route: ActivatedRoute,
      private modalService: ModalService,
      private spinner: NgxSpinnerService,
      public toastr: ToastsManager,
       private router: Router) {}
    ngOnInit(){
        this.slectDataColumnDefs = GRID_CONFIG.DATA_ELEMENTS.OPTIONS;
        this.hidePageTitle = false;
        this.pageTitle = 'Select Data Element Option';
        this.planNumber = PayAdminGlobalState.planNumber;
        this.dataelementID =  AdminDataService.dataElementId;
        this.route.url.subscribe(value => {
          const isDelete = _.find(value, ['path', 'delete']);
          if (isDelete) {
          this.onDelete();
          } else {
            PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
            PayAdminGlobalState.currentPage = 'admin/dataElements/options';
            this.selectNew();
            this.getOptions();
          }
        });
    }
    getSelectedOptionId(selectedId: string) {
      this.isButtonDisabled = false;
      this.selectedOption = _.filter(AdminDataService.dataElementOptions, ['valueCode', selectedId])[0];
      AdminDataService.dataElementOption = this.selectedOption;
      this.selectedOptionId = selectedId;
    }
    selectNew()
    {
      this.selectedOption = null;
      this.selectedOptionId = '';
      this.isButtonDisabled = false;
      AdminDataService.dataElementOption = null;
    }
    getOptions()
    {
      this.spinner.show();
      this.adminService.getDEOptions(this.planNumber, this.dataelementID).subscribe(options => {
        this.spinner.hide();
        if (options.status === APP_CONST.SUCCESS) {
          console.log('options.data', options.data)
          AdminDataService.dataElementOptions = options.data;
          this.dataElementOptions =  AdminDataService.dataElementOptions;
          } else {
            console.log('Error in get options', options);
            this.toastr.error(options.error.msg, options.status + ' !', { showCloseButton: true });
          }
        },
        (err => {
          this.spinner.hide();
          console.log('Error in get options outside', err);
          this.toastr.error('Error while fetching Data Element Optoins !', err.error.status + ' !', { showCloseButton: true });
        })
      );
      }
    showDeteleModal() {
      PayAdminGlobalState.currentPage = PayAdminGlobalState.previousPage;
      this.modalService.open('deOptionModal');
    }
    onDelete() {
      this.spinner.show();
      this.adminService.deleteDEOption(this.planNumber, this.dataelementID, AdminDataService.dataElementOption.valueCode)
      .subscribe(delRes => {
        this.spinner.hide();
        if (delRes.status === APP_CONST.SUCCESS) {
          AdminDataService.dataElementOptions = _.remove(AdminDataService.dataElementOptions, function(n) {
            return n.valueCode !== AdminDataService.dataElementOption.valueCode;
          });
          this.dataElementOptions =  AdminDataService.dataElementOptions;
          //this.getOptions(); // can be done through client logic
        } else {
          console.log('Error in deleteDE options', delRes);
          this.toastr.error(delRes.error.msg, delRes.status + ' !', { showCloseButton: true });
        }
      },
      (err => {
        this.spinner.hide();
        console.log('Error in deleteDE options outside', err);
        this.toastr.error('Error while deleting Data Element Optoin ' + this.selectedOptionId , err.error.status + ' !', { showCloseButton: true });
      })
    );
    }
    onEdit() {
      this.router.navigate(['/admin/dataElements/options/createOrEdit']);
    }
    gotoBack() {
      this.router.navigate(['/admin/dataElements']);
    }

  }
