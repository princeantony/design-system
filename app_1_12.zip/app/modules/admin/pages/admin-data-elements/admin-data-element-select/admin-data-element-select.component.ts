import { Component, OnInit } from '@angular/core';

import { PayAdminGlobalState } from '../../../../../shared/store/pay-admin-global.store';

@Component({
    selector: 'app-admin-data-element-select',
    templateUrl: './admin-data-element-select.component.html'
  })
  export class AdminDataElementSelectComponent implements OnInit{
    hidePageTitle: boolean;
    pageTitle: string;
    planNumber: string;
    ngOnInit(){
      PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
      PayAdminGlobalState.currentPage = 'admin/dataElements/createOrEdit';
      this.hidePageTitle = false;
      this.pageTitle = 'Update Optional Data Element';
      this.planNumber = PayAdminGlobalState.planNumber;

    }

  }
