import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'lodash';
import { Utils } from 'src/app/shared/utils/pay-admin.utils';

import * as Participant from '../../../participants/model/participant.model';
import { ParticipantsService } from '../../../participants/service/participants.service';
import {
  ParticipantFundSource,
  ParticipantFundSourceItem
} from '../../model/participant.model';
import { ParticipantStore } from '../../store/participant.store';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastsManager } from 'ng6-toastr';
import { PreviousRouteService } from 'src/app/shared/services/previous-route.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

@Component({
  selector: 'app-participant-confirmation',
  templateUrl: './participant-confirmation.component.html',
  styleUrls: ['./participant-confirmation.component.scss']
})
export class ParticipantConfirmationComponent implements OnInit {
  private participantSubmitData: Participant.ParticipantSubmitData = {} as Participant.ParticipantSubmitData;
  private pData;
  private participantData;
  private optionalData;
  private optionalDatavalues = [];
  private isUpdate = false;
  private participantFundSources;
  private fundRows;
  private tableColumns;
  private enrollFlag;
  private status: string;
  constructor(
    private previousRouteService: PreviousRouteService,
    private participantsService: ParticipantsService,
    private utils: Utils,
    private spinner: NgxSpinnerService,
    private router: Router,
    private route: ActivatedRoute,
    public toastr: ToastsManager,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    PayAdminGlobalState.previousPage = this.previousRouteService.getPreviousUrl();
    // Get Data from Participant store, format and print the confiramtaion screen
    this.pData = ParticipantStore.ParticipantData;
    this.enrollFlag = ParticipantStore.ParticipantData.requiredData.enrollFlag;
    this.status = ParticipantStore.Status;
    this.route.url.subscribe(value => {
      this.isUpdate = true
        ? _.find(value, ['path', 'UpadteParticipant'])
        : false;
    });

    // this.participantSubmitData = this.participantsService.getParticipantDataToSubmit();
    this.pData.optionalData.forEach(field => {
      if (field.value !== '') {
        if (field.componentType === 'dropdown') {
          const displayText = _.find(field.option, ['value', field.value])
            .displayText;
          this.optionalDatavalues.push({
            label: field.label,
            value: displayText
          });
        } else {
          this.optionalDatavalues.push({
            label: field.label,
            value: field.value
          });
        }
      }
    });
    this.optionalData = this.utils.chunkArray(this.optionalDatavalues, 3);

    this.participantFundSources =
      ParticipantStore.ParticipantData.participantContributionInvestmentData;
    // column data
    const columnsList = this.participantFundSources.sourceMap;
    this.tableColumns = [];

    // Create First Default FundNameColumn
    this.tableColumns.push({
      field: 'fundName',
      headerName: 'Fund Name'
    });
    // Push one column for each Source item
    if (columnsList) {
      columnsList.forEach(column => {
        this.tableColumns.push({
          field: column.sourceId,
          headerName: column.sourceName
        });
      });
    }

    // row data
    const fundSources: ParticipantFundSource[] = this.participantFundSources
      .fundSources;
    this.fundRows = [];
    if (fundSources) {
      fundSources.forEach(fundSrc => {
        const rowItem = Object.assign({ fundName: fundSrc.fundName });
        const sources: ParticipantFundSourceItem[] = fundSrc.percents;

        sources.forEach((src: ParticipantFundSourceItem) => {
          if (src.currentPercent !== '0') {
            Object.assign(rowItem, { [src.sourceId]: src.currentPercent });
          }
        });
        if (_.keys(rowItem).length > 1) {
          this.fundRows.push(rowItem);
        }
      });
    }
  }
  onBackClick() {
    this.router.navigate([PayAdminGlobalState.previousPage]);
    // if (this.isUpdate) {
    //   if (!this.enrollFlag) {
    //     this.router.navigate(['UpdateParticipant']);
    //   } else {
    //     this.router.navigate(['UpdateParticipant/ContributionInvestment']);
    //   }
    // } else {
    //   if (!this.enrollFlag) {
    //     this.router.navigate(['addParticipant']);
    //   }
    //   this.router.navigate(['addParticipant/ContributionInvestment']);
    // }
  }
  onSumitClick() {
    this.spinner.show();
    if (this.isUpdate) {
      this.participantsService.updateParticipant().subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.spinner.hide();
          this.router.navigate(['/home/success']);
        } else {
          this.toastr.error(result.error.msg, result.status + ' !', {
            showCloseButton: true
          });
        }
      });
    } else {
      this.participantsService.enrollParticipant().subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.spinner.hide();
          this.router.navigate(['/home/success']);
        } else {
          this.toastr.error(result.error.msg, result.status + ' !', {
            showCloseButton: true
          });
        }
      });
    }
  }
}
