import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantImportFileComponent } from './participant-import-file.component';

describe('ParticipantImportFileComponent', () => {
  let component: ParticipantImportFileComponent;
  let fixture: ComponentFixture<ParticipantImportFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantImportFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantImportFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
