import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipantUpdateInvestmentElectionComponent } from './participant-update-investment-election.component';

describe('ParticipantUpdateInvestmentElectionComponent', () => {
  let component: ParticipantUpdateInvestmentElectionComponent;
  let fixture: ComponentFixture<ParticipantUpdateInvestmentElectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipantUpdateInvestmentElectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipantUpdateInvestmentElectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
