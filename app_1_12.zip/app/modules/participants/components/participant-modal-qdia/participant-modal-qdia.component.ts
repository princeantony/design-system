import { Component, OnInit } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-participant-modal-qdia',
  templateUrl: './participant-modal-qdia.component.html'
})
export class ParticipantModalQDIAComponent implements OnInit {

  constructor(private modalService: ModalService) { }

  ngOnInit() {
  }
  closeModal(id) {
    this.modalService.close(id);
  }

}
