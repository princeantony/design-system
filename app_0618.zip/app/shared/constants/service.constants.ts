export const SERVICE_URL=
{
    //APP_URL: "http://localhost:4200/payadmin/ws/ers/service/",
    APP_URL: "https://reqres.in/api/users?delay=3",
    GET_DIRECT_LOGIN_URL: 'login/direct',
    GET_LISTPLAN_URL: 'plans',
    GET_HOME_URL: 'plans/plan/',
    GET_SUB_DIV_URL: 'divsub/plan/',
    GET_BANK_INFO_URL: 'bankinfo/plan/',
    POST_BANK_INFO_URL: 'bankinfo/plan/'
};