import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
@Component({
  selector: 'app-title-message',
  templateUrl: './title-message.component.html'
})
export class TitleMessageComponent implements OnInit {
  @Input() message;
  constructor(
              private route: ActivatedRoute,
              private router: Router) { }
  ngOnInit() {
  }
  takePrint(){
  this.route.url.subscribe(params => {
  if(params[0].path == "home"){
    this.router.navigate(["home/print"]);
  }
});}}
