import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
import {ListPlan} from '../mocks/listPlan';

import { HOME_FLAGS } from '../mocks/menuItems-mock';
import {bankInfo, divSub} from '../mocks/bankInfo-mock';
@Injectable({
  providedIn: 'root',
})

export class MockService {
constructor() { }

getListPlans(): Observable<any> {
    return of(ListPlan);
  }
  getHomeFlags(): Observable<any> {

        return of(HOME_FLAGS);
      }
  getBankInfo(): Observable<any> {
    return of(bankInfo);
  }
  getSubDiv(): Observable<any> {
    return of(divSub);
  }
  }

  