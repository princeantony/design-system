
import { Component, OnInit} from '@angular/core';
import { Injectable } from '@angular/core';
import {GRID_CONFIG,APP_CONST} from '../../../../shared/constants/app.constants';
import {LoginUser} from '../../../../shared/mocks/login-user.mock';
import { PlanService } from '../../services/plan.service';
import { AuthService } from '../../services/auth.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
@Component({
  selector: 'app-list-plans',
  templateUrl: './plan-list.component.html'
})
@Injectable()
export class PlanListComponent implements OnInit {
columnDefs: any;
rowData: any;
width;
planListItem : any;
userListItem : any;
constructor(
  private planService: PlanService,
  private authService: AuthService,
  private spinner: NgxSpinnerService) 
  {
  }

  ngOnInit() {
    this.columnDefs = GRID_CONFIG.LIST_PLAN.COLUMN_DEFS;
    this.width= GRID_CONFIG.LIST_PLAN.GRID_SIZE.width;
    this.planListItem = PayAdminGlobalState.planListState;
    if(this.planListItem === undefined)
    {
      this.spinner.show();
  //this.login(); //for actual service 

 this.getMockPlans();
    }
    else
    {
    this.rowData = this.planListItem;
    }
}
  getPlans(): void {
    this.planService.getPlans().subscribe(plans => {
      this.spinner.hide();
      if(plans.status === APP_CONST.LOGIN_SUCCESS) 
      {
        this.rowData = plans.data;
      PayAdminGlobalState.planListState = this.rowData;
      }
      
    },(err => {console.log("Error", err),this.spinner.hide();}));
  }
  login() : void{
   this.authService.doAuthenticte(LoginUser).subscribe(loginInfo => { 
    this.spinner.hide();
   if(loginInfo.status === APP_CONST.LOGIN_SUCCESS) 
   this.getPlans();
  },
   (err => {console.log("Error", err),this.spinner.hide();})
  );
  }
 
  getMockPlans() : void{
    this.planService.getMockPlans().subscribe(plans => {
      this.spinner.hide();
      if(plans.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.rowData = plans.data;
      PayAdminGlobalState.planListState = this.rowData;
      }
    });
    
  }
}
