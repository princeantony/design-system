import { Injectable } from '@angular/core';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { Observable } from 'rxjs';
import { ApiService } from '../../../shared/services/api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private apiService: ApiService) { }
  doAuthenticte(loginUser: any):Observable<any>
   {
   return this.apiService.post(SERVICE_URL.GET_DIRECT_LOGIN_URL, loginUser)
   }
}
