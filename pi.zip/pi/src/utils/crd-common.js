export let getAllCaps=(text)=>{
    return text.toUpperCase();
}