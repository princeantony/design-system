export const SERVICE_URL=
{
    GET_CRD_API_URL: 'https://crd-dev.aexp.com/crd/v1/',
    GET_CRD_NETWORK_UTIL_URL: 'https://networkutil-dev.aexp.com'
};

/*
ACTUAL URL TO CRD API
https://crd-dev.aexp.com/crd/v1/travel-document-type-reference
https://crd-dev.aexp.com/crd/v1/card-presentment-format-reference
https://crd-dev.aexp.com/crd/v1/industry-class-of-service-reference
*/