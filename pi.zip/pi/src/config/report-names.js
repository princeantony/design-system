export const CRDReports = [
    {
        key: 'additional_amount_type',
        label:'Additional amount type'
    },
    {
        key: 'travel-document-type',
        label:'T document type'
    },
    {
        key: 'card-presentment-format',
        label:'Card presentment format'
    },
    {
        key: 'industry-class-of-service',
        label:'Industry class of service'
    }
]