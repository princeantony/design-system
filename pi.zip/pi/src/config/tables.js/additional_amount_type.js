export const Headings = [
    {
        key: 'id',
        label:'ID'
    },
    {
        key: 'type',
        label:'TYPE'
    },
    {
        key: 'iso_additional_amount_type_code',
        label:'ISO ADDITIONAL AMOUNT TYPE CODE'
    },
    {
        key: 'iso_additional_amount_type_description',
        label:'ISO ADDITIONAL AMOUNT TYPE DESCRIPTION'
    },
    {
        key: 'last_update_timestamp',
        label:'LAST UPDATE TIMESTAMP'
    },
    {
        key: 'last_update_user_identifier',
        label:'LAST_UPDATE_USER_IDENTIFIER'
    }
]
