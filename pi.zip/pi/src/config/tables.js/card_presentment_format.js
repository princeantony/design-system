export const Headings = [
    {
        key: 'id',
        label:'ID'
    },
    {
        key: 'type',
        label:'TYPE'
    },
    {
        key: 'card_presentment_format_code',
        label:'CARD PRESENTMENT FORMAT CODE'
    },
    {
        key: 'card_presentment_format_description',
        label:'CAD PRESENTMENT FORMAT DESCRIPTION'
    },
    {
        key: 'effective_date',
        label:'EFFECTIVE DATE'
    },
    {
        key: 'end_date',
        label:'END DATE'
    },
    {
        key: 'create_timestamp',
        label:'CREATE TIMESTAMP'
    },
    {
        key: 'last_update_timestamp',
        label:'LAST_UPDATE_TIMESTAMP'
    },
    {
        key: 'last_update_user_identifier',
        label:'LAST_UPDATE_USER_IDENTIFIER'
    }

]
