import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class CRDReport extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div>
      
    </div>
    );
  }
}
export default CRDReport;
