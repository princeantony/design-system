import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import CRDReport from './Components/CRDReport';

ReactDOM.render(<CRDReport />, document.getElementById('root'));

