import { Injectable } from '@angular/core';
import { FormControl, ValidationErrors, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ValidatorsService {
  constructor() {}

  validateSSN(ctrl: FormControl): ValidationErrors | null {
    return Validators.compose([
      Validators.required,
      Validators.pattern('^\\d{3}-?\\d{2}-?\\d{4}$')
    ])(ctrl);
  }
}
