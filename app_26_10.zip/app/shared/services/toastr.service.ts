import { Injectable, ViewContainerRef, NgModule } from '@angular/core';

import { catchError, retry } from 'rxjs/operators';
import { ToastsManager } from 'ng6-toastr';

@Injectable({
  providedIn: "root"
})
export class ToastrService {
  constructor(public toastr: ToastsManager, vcr: ViewContainerRef) {
     this.toastr.setRootViewContainerRef(vcr);
   }
   showSuccess(message: string, title: string) {
    this.toastr.success(message, title, {showCloseButton: true});
  }

  showError(message: string, title: string) {
    this.toastr.error(message, title, {showCloseButton: true});
  }

  showWarning(message: string, title: string) {
    this.toastr.warning(message, title, {showCloseButton: true});
  }

  showInfo(message: string, title: string) {
    this.toastr.info(message, title, {showCloseButton: true});
  }
  showCustom(message: string, title: string) {
    this.toastr.custom(message, title, {enableHTML: true});
  }
}

