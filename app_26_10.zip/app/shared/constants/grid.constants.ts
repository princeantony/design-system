export const GRID_CONFIG = {
  LIST_PLAN: {
    GRID_SIZE : {width: 555, height: 800},
    COLUMN_DEFS : [
    { headerName: 'Plan Number', field: 'planNumber', width: 200 },
    { headerName: 'Plan Name', field: 'planName', width: 350 }
  ]},
  LIST_USRS: {
      GRID_SIZE : {width: 555, height: 800},
      COLUMN_DEFS : [
      { headerName: 'ID', field: 'id', width: 200 },
      { headerName: 'Name', field: 'name', width: 350 },
      {headerName: 'User Name', field: 'username', width: 350 }
    ]},

    BANK_INFO: {
    GRID_SIZE : {width: 800, height: 800},
    COLUMN_DEFS : [
    { headerName: 'Division/Location Number', field: 'divsub', width: 200 },
    { headerName: 'Division/Location Name', field: 'textOnly', width: 300 },
    { headerName: 'Bank Name', field: 'bankName', width: 150},
    { headerName: 'Account Type', field: 'accountTypeDescription', width: 125 },
    { headerName: 'Actions', field: 'actions', cellRenderer: 'linkRenderer', width: 105, suppressFilter:true }

  ]},
  PLAN_UPDATE:
  {
    GRID_SIZE : {width: 800, height: 800},
    COLUMN_DEFS_MONEY_SOURCES : [
    { headerName: 'Source Code', field: 'code', width: 120 },
    { headerName: 'Long Name', field: 'longName', width: 103 },
    { headerName: 'Short Name', field: 'shortName', width: 106},
    { headerName: 'Short Name Override', field: 'shortNameOverride', cellRenderer:'textboxRender', width: 200 },
    { headerName: 'Exclude', field: 'exclude', cellRenderer: 'checkboxRenderer', width: 100 },
    { headerName: 'Contribution Catch-Up', field: 'contributionCatchUp',cellRenderer: 'checkboxRenderer', width:166 },
    { headerName: 'Deferral Catch-Up', field: 'deferralCatchUp',cellRenderer: 'checkboxRenderer', width: 145},
    { headerName: 'Limit', field: 'limit',cellRenderer: 'checkboxRenderer', width: 75 },
    { headerName: 'Fort Account From', field: 'forfeitureAccountFrom', cellRenderer: 'checkboxRenderer', width: 150 },
    { headerName: 'Fort Account To', field: 'forfeitureAccountTo', cellRenderer: 'checkboxRenderer',  width: 150 },
    { headerName: 'Prefunded Account From', field: 'prefundedAccountFrom', cellRenderer: 'checkboxRenderer',  width: 200 },
    { headerName: 'Prefunded Account To', field: 'prefundedAccountTo', cellRenderer: 'checkboxRenderer', width: 180 }

  ],
  COLUMN_DEFS_INVESTMENTS : [
    { headerName: 'Investment Code', field: 'code', width: 135 },
    { headerName: 'Long Name', field: 'longName', width: 300 },
    { headerName: 'Long Name Override', field: 'longNameOverride', cellRenderer: 'textboxRender', width: 250 },
    { headerName: 'Exclude', field: 'exclude', cellRenderer: 'checkboxRenderer', width: 353 }
  ]
  },

  SUB_DIV_INFO: {
    GRID_SIZE : {width: 600, height: 450},
    COLUMN_DEFS : [
    { headerName: 'Division/Location Number', field: 'id', width: 200 },
    { headerName: 'Division/Location Name', field: 'textOnly', width: 560 },
  ]},

  PLAN_COPY:{
    GRID_SIZE : {width: 800, height: 800},
    COLUMN_DEFS_PLANS :[
      {headerName: 'All plans', field:'plan' ,suppressFilter: true,
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: false ,checkboxSelection: true,
       width: 120
    },
      {headerName: 'Plan number', field: 'planNumber'},
      {headerName: 'Plan name', field: 'planName'}
    ]

  }

};
