import { IListItem } from "../interfaces/list-item.interface";
export const dropdownItems: IListItem[] = [
                                {displayText:"1", value: "1"},
                                {displayText:"2", value: "2"},
                                {displayText:"3", value: "3"},
                                {displayText:"4", value: "4"},
                                {displayText:"5", value: "5"},
                                {displayText:"6", value: "6"},
                                {displayText:"7", value: "7"},
                                {displayText:"8", value: "8"},
                                {displayText:"9", value: "9"},
                            ]