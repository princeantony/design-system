export const TerminationReasonList=
{ "status": "SUCCESS",
"data": [
    {
        "ID": "1",
        "DEText": "Lay Off"
    },
    {
        "ID": "2",
        "DEText": "With Cause"
    },
    {
        "ID": "3",
        "DEText": "Deceased"
    },
    {
        "ID": "4",
        "DEText": "Voluntary"
    },
]
}