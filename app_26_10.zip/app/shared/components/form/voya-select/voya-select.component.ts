import { Component, EventEmitter, forwardRef, Input, OnInit, Output } from '@angular/core';
import {
  ControlValueAccessor,
  FormControl,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidationErrors,
  Validators,
} from '@angular/forms';

const noop = () => {};

@Component({
  selector: 'voya-select',
  templateUrl: './voya-select.component.html',
  styleUrls: ['./voya-select.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaSelectComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => VoyaSelectComponent),
      multi: true
    }
  ]
})
export class VoyaSelectComponent implements OnInit, ControlValueAccessor {
  @Input()
  control;
  @Input()
  placeHolderText: string;
  @Input()
  controlLabel: string;
  @Input()
  disabled = false;
  @Output()
  onChanged = new EventEmitter<string>();
  private _isRequired: boolean;

  @Input()
  set isRequired(value: boolean) {
    this._isRequired = value || true;
  }
  get isRequired(): boolean {
    return this._isRequired;
  }

  propagateChange = (_: any) => {};

  private _items: { value: string; displayText: string }[];
  @Input()
  set items(list: { value: string; displayText: string }[]) {
    this._items = list || [{ value: '0', displayText: 'Select ' }];
  }
  get items() {
    return this._items;
  }

  ngOnInit() {
    this.isLabelHidden = false;
    if (this._isRequired === undefined) {
      this._isRequired = true;
    }
  }

  private _value: any = null;
  get value(): any {
    return this._value;
  }
  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
    if (v === '') {
      this._value = null;
    }
  }

  //Placeholders for the callbacks
  private _onTouchedCallback: (_: any) => void = noop;
  private _onChangeCallback: (_: any) => void = noop;

  //Set touched on blur
  onTouched() {
    this._onTouchedCallback(null);
  }

  isLabelHidden: boolean;

  writeValue(value: string): void {
    this._value = value || null;
    if (this._value === null) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  onSelectedIndexChange() {
    this.showHideLabel();
    this.onChanged.emit(this.value);
  }
  showHideLabel() {
    if (this.value !== '') {
      this.isLabelHidden = false;
    } else {
      this.isLabelHidden = true;
    }
  }

  validate(ctrl: FormControl): ValidationErrors | null {
    if (this.isRequired) {
      return Validators.compose([Validators.required])(ctrl);
    } else {
      return null;
    }
  }
}
