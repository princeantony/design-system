import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from "../../../store/pay-admin-global.store";

@Component({
  selector: 'app-page-header',
  templateUrl: './page-header.component.html',
  styleUrls: ['./page-header.component.scss']
})
export class PageHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log("Plan Name");
    console.log(PayAdminGlobalState.planName);
    
  }

}
