export interface IMenuItem{
    key: string;
    menuHeading: string;
    menuSubheading: string;
    menuIcon: string;
    linkTo: string;
}