import { Component, OnInit } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-bank-submit',
  templateUrl: './bank-submit.component.html',
  styleUrls: ['./bank-submit.component.scss']
})
export class BankSubmitComponent implements OnInit {

  constructor(private modalService :  ModalService) { }

  ngOnInit() {
  }

  closeModal(id){
    
    this.modalService.close(id);

  }

}
