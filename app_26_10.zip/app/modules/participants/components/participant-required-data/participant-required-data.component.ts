import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { CommonService } from 'src/app/shared/services/common.service';

import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { IParticipantRequiredData, ParticipantAdminSetting, ParticipantData } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';

@Component({
  selector: 'participant-required-data',
  templateUrl: './participant-required-data.component.html',
  styleUrls: ['./participant-required-data.component.scss']
})
export class ParticipantRequiredDataComponent implements OnInit {
  isInEditMode: boolean;
  countryChanged = new Subject<string>();
  participantData = new ParticipantData();
  participantRequiredDataForm: FormGroup;
  participantRequiredData: IParticipantRequiredData;
  participantAdminSetting: ParticipantAdminSetting;
  model;
  ssn: string;
  fname: string;
  countryList: { value: string; displayText: string }[];
  stateList: { value: string; displayText: string }[];

  accountTypeItems: { value: string; label: string }[];
  constructor(
    private formBuilder: FormBuilder,
    private participantsService: ParticipantsService,
    private router: Router,
    private commonService: CommonService
  ) {}

  ngOnInit() {
    this.isInEditMode = false;
    // Get Admin Settings
    this.participantsService.getParticipantAdminSetting().subscribe(result => {
      if (result.status === 'SUCCESS') {
        this.participantAdminSetting = result.data;
      }
    });

    // Get Country List
    this.countryList = PayAdminGlobalState.countryList;
    this.stateList = PayAdminGlobalState.stateList;
    this.participantRequiredDataForm = this.formBuilder.group({
      ssn: [this.participantData.participantRequiredData.ssn],
      email: [this.participantData.participantRequiredData.email],
      lastName: [this.participantData.participantRequiredData.lastName],
      firstName: [this.participantData.participantRequiredData.firstName],
      mName: [this.participantData.participantRequiredData.mName],
      addressLine1: [this.participantData.participantRequiredData.addressLine1],
      addressLine2: [this.participantData.participantRequiredData.addressLine2],
      city: [this.participantData.participantRequiredData.city],
      zip: [this.participantData.participantRequiredData.zip],
      state: [this.participantData.participantRequiredData.state],
      country: [this.participantData.participantRequiredData.country],
      dateOfBirth: [this.participantData.participantRequiredData.dateOfBirth],
      dateOfHire: [this.participantData.participantRequiredData.dateOfHire],
      terminationDate: [this.participantData.participantRequiredData.terminationDate],
      terminationReason: [this.participantData.participantRequiredData.terminationReason],
      makeParticipantActive: [this.participantData.participantRequiredData.makeParticipantActive],
      absenceStartDate: [this.participantData.participantRequiredData.absenceStartDate],
      absenceStartDateReason: [this.participantData.participantRequiredData.absenceStartDateReason],
      absenceEndDate: [this.participantData.participantRequiredData.absenceEndDate],
      absenceEndDateReason: [this.participantData.participantRequiredData.absenceEndDateReason],
      enrollFlag: [this.participantData.participantRequiredData.enrollFlag],
      mstarFlag: [this.participantData.participantRequiredData.mstarFlag],
      qdiaFlag: [this.participantData.participantRequiredData.qdiaFlag]
    });
  }

  onSubmit() {
    this.setParticipantRequiredData();
    if (this.participantRequiredDataForm.value.enrollFlag) {
      this.router.navigate(['addParticipant/Optional']);
    } else {
      this.router.navigate(['addParticipant/Confirmation']);
    }
  }

  onStateChange(value: string) {
    console.log('Value changed: ' + value);
  }

  onCountryChange(value: string) {
    this.commonService.countryChanged.next(value);
  }

  setParticipantRequiredData() {
    let data: IParticipantRequiredData = this.participantRequiredDataForm.value;
    console.log(data);
    this.participantRequiredData = data;
    this.participantsService.addParticpantRequiredData(
      this.participantRequiredData
    );
  }
}
