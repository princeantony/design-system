import { Component, OnInit } from "@angular/core";
import {
  NgForm,
  FormControl,
  FormArray,
  FormGroup,
  FormBuilder
} from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { IParticipantContribution } from "../../model/participant.model";
import { ParticipantsService } from "../../service/participants.service";
import { CommonService } from "../../../../shared/services/common.service";

interface Item {
  key: string;
  label: string;
  value: string;
  readonly: boolean;
}

interface FormControlMetadata {
  checkBoxLabel: string;
  checkBoxValue: string;
  controlLabel: string;
  controlName: string;
  controlValue: string;
  controlType: string;
  isReadOnly: boolean;
  controlValueType: string;
  formSection: string;
}

@Component({
  selector: "participant-contribution-election",
  templateUrl: "./participant-contribution-election.component.html",
  styleUrls: ["./participant-contribution-election.component.scss"]
})
export class ParticipantContributionElectionComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private participantsService: ParticipantsService,
    private common: CommonService,
    private router: Router
  ) {}

  participantContributionForm: FormGroup;

  contributions: IParticipantContribution;
  contribElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  catchUpContribElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  investmentElectionMetaDataList: FormControlMetadata[] = [] as FormControlMetadata[];
  contribElectionFormArray: FormArray = this.fb.array([]);
  catchUpContribElectionFormArray: FormArray = this.fb.array([]);
  investmentElectionFromArray: FormArray = this.fb.array([]);
  ngOnInit() {
    this.participantsService.getParticipantContributionData().subscribe(result => {
      if (result.status === "SUCCESS") {
        this.contributions = result.data;
      }
    });
    //FormBuilding :Blue Print
    this.participantContributionForm = this.fb.group({
      contributionElection: this.contribElectionFormArray,
      catchUpContributionElection: this.catchUpContribElectionFormArray,
      investmentElection: this.investmentElectionFromArray
    });

    //Add items to each section FromArray
    //Add ContributionElection items to contributionElectionFormArray
    let contributionElectionItem: Item;
    this.contributions.contribElection.list.forEach(
      contributionElectionItem => {
        //Fill the metatdata to build the form
        this.contribElectionMetaDataList.push(
          this.addToFormControlMetaDataList(
            contributionElectionItem,
            this.contributions.contribElection.type,
            "contribElection",
            "text"
          )
        );
        let controlKey: string = contributionElectionItem.key;
        let control: FormControl = new FormControl(
          contributionElectionItem.value
        );
        let controlGroup: FormGroup = this.fb.group({});
        controlGroup.addControl(controlKey, control);
        this.contribElectionFormArray.push(controlGroup);
      }
    );

    let catchUpContributionElectionItem: Item;
    this.contributions.catchupContribElection.list.forEach(
      catchUpContributionElectionItem => {
        //Fill the metatdata to build the form
        this.catchUpContribElectionMetaDataList.push(
          this.addToFormControlMetaDataList(
            catchUpContributionElectionItem,
            this.contributions.catchupContribElection.type,
            "catchUpContribElection",
            "text"
          )
        );
        let controlKey: string = catchUpContributionElectionItem.key;
        let control: FormControl = new FormControl(
          catchUpContributionElectionItem.value
        );
        let controlGroup: FormGroup = this.fb.group({});
        controlGroup.addControl(controlKey, control);
        this.catchUpContribElectionFormArray.push(controlGroup);
      }
    );

    let investmentElectionItem: Item;
    this.contributions.investmentElection.list.forEach(
      investmentElectionItem => {
        //Fill the metatdata to build the form
        this.investmentElectionMetaDataList.push(
          this.addToFormControlMetaDataList(
            investmentElectionItem,
            "",
            "investmentElection",
            "checkbox"
          )
        );
        let controlKey: string = investmentElectionItem.key;
        let control: FormControl = new FormControl(
          investmentElectionItem.value
        );
        let controlGroup: FormGroup = this.fb.group({});
        controlGroup.addControl(controlKey, control);
        this.investmentElectionFromArray.push(controlGroup);
      }
    );

    console.log(this.investmentElectionMetaDataList);
  }

  get contribElections() {
    return (<FormArray>(
      this.participantContributionForm.controls["contributionElection"]
    )).controls;
  }

  get catchUpContribElections() {
    return (<FormArray>(
      this.participantContributionForm.controls["catchUpContributionElection"]
    )).controls;
  }

  get investmentElections() {    
    return (<FormArray>(
      this.participantContributionForm.controls["investmentElection"]
    )).controls;
  }


  addToFormControlMetaDataList(
    item: Item,
    valueType: string,
    section: string,
    type: string
  ): FormControlMetadata {
    let _formControlMetaData: FormControlMetadata = {} as FormControlMetadata;
    _formControlMetaData.formSection = section;
    _formControlMetaData.controlType = type;
    _formControlMetaData.isReadOnly = item.readonly;
    _formControlMetaData.controlName = item.key;
    _formControlMetaData.controlValueType = valueType;
    if (type === "text") {
      _formControlMetaData.controlLabel = item.label;
      _formControlMetaData.controlValue = item.value;
    }
    if (type === "checkbox") {
      _formControlMetaData.checkBoxLabel = item.label;
      _formControlMetaData.checkBoxValue = item.value;
    }
    return _formControlMetaData;
  }

  onContributionElectionTypeChanged(value: string) {
    this.contributions.contribElection.type = value;    
    for(let i = 0; i < this.contribElections.length; i++){
      let control = this.contribElections[i] as FormGroup;
      let controlName = this.contribElectionMetaDataList[i].controlName;
      control.get(controlName).setValue('0');
      console.log(control.get(controlName));
    }
  }
  onCatchUpContributionElectionTypeChanged(value: string) {
    this.contributions.catchupContribElection.type = value; 
    for(let i = 0; i < this.catchUpContribElections.length; i++){
      let control = this.catchUpContribElections[i] as FormGroup;
      let controlName = this.catchUpContribElectionMetaDataList[i].controlName;
      control.get(controlName).setValue('0');
      console.log(control.get(controlName));
    }
  }

  
  onSubmit(form: NgForm) {
    this.router.navigate(["addParticipant/ContributionInvestment"]);
  }
}
