import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { FormGroup } from "@angular/forms";

import { ParticipantOptionalFields } from "./participant-optional-fields";
import { IParticipantOptionalFieldsService } from "./participant-optional-data-fields.service";

import { ParticipantsService } from "../../service/participants.service";
import { IParticipantOptionalField } from "../../model/participant.model";
import { ParticipantOptionalFieldTextBox } from "./participant-optional-field-textbox";
import { ParticipantOptionalFieldDropDown } from "./participant-optional-field-dropdown";

@Component({
  selector: "participant-optional-data",
  templateUrl: "./participant-optional-data.component.html",
  styleUrls: ["./participant-optional-data.component.scss"]
})
export class ParticipantOptionalDataComponent implements OnInit {
  optionalFields: ParticipantOptionalFields<any>[] = [];
  participantOptionalDataField: IParticipantOptionalField[];
  participantOptionalData: IParticipantOptionalField[];
  participantOptionalDataForm: FormGroup;

  constructor(private participantsService: ParticipantsService, private router: Router) {}

  ngOnInit() {
    this.getOptionalDataFields();
    this.participantOptionalDataForm = this.participantsService.toFormGroup(
      this.optionalFields
    );
  }

  getOptionalDataFields() {
    this.participantsService.getParticipantOptionalDataFields().subscribe(result => {
      if (result.status === "SUCCESS") {
        this.participantOptionalDataField = result.data;
      }
    });
    this.participantOptionalDataField.forEach(
      (field: IParticipantOptionalField) => {
        if (field.controlType === "text") {
          this.optionalFields.push(
            new ParticipantOptionalFieldTextBox({
              key: field.label.split(" ").join("-"),
              label: field.label,
              required: field.required,
              value: field.value,
              type: "text"
            })
          );
        }
        if (field.controlType === "dropdown") {
          this.optionalFields.push(
            new ParticipantOptionalFieldDropDown({
              key: field.label.split(" ").join("-"),
              label: field.label,
              required: field.required,
              value: field.value,
              options: field.option
            })
          );
        }
      }
    );
  }

  onSubmit() {
    let data: IParticipantOptionalField[] = this.participantOptionalDataForm.value;
    console.log(data);
    this.participantOptionalData = data;
    this.participantsService.addParticipantOptionalData(this.participantOptionalData);
    this.router.navigate(["addParticipant/ContributionElection"]);
  }

  onDropDownChange() {
  }
}
