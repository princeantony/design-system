import { Injectable } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';

import { ENV } from '../../../shared/constants/app.constants';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { ParticipantOptionalFields } from '../components/participant-optional-data/participant-optional-fields';
import * as Participant from '../model/participant.model';

@Injectable({
  providedIn: 'root'
})
export class ParticipantsService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService,
    private commonService: CommonService
  ) {}

  private participantData: Participant.ParticipantData = {} as Participant.ParticipantData;

  getParticipantList(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getparticipantListMock()
      : this.mockService.getparticipantListMock();
  }

  getParticipantListBySSN(ssn: string): Participant.ParticipantItem[] {
    let participantList: Participant.ParticipantItem[] = [];
    if (ENV.TEST) {
      let participantListByName: Participant.ParticipantItem[] = [];
      this.mockService.getparticipantListMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          participantList = result.data;
        }
      });

      participantListByName = participantList.filter(
        (value: Participant.ParticipantItem, index, array) => {
          if (value.ssn.indexOf(ssn) !== -1) {
            return true;
          }
          return false;
        }
      );
      return participantListByName;
    } else {
      // write code to get real data through service
      return participantList;
    }
  }

  getParticipantListByLastName(name: string): Participant.ParticipantItem[] {
    let participantList: Participant.ParticipantItem[] = [];
    if (ENV.TEST) {
      let participantListByName: Participant.ParticipantItem[] = [];
      this.mockService.getparticipantListMock().subscribe(result => {
        if (result.status === 'SUCCESS') {
          participantList = result.data;
        }
      });

      participantListByName = participantList.filter(
        (value: Participant.ParticipantItem, index, array) => {
          if (value.name.toLowerCase().indexOf(name.toLowerCase()) !== -1) {
            return true;
          }
          return false;
        }
      );
      return participantListByName;
    } else {
      // write code to get real data through service
      return participantList;
    }
  }

  getParticipantData(): Participant.ParticipantData {
    return this.participantData;
  }

  getParticipantAdminSetting(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getParticipantAdminSettingMock()
      : this.mockService.getParticipantAdminSettingMock();
  }

  toFormGroup(fields: ParticipantOptionalFields<any>[]) {
    let group: any = {};

    fields.forEach(field => {
      // group[field.key] = field.required
      //   ? new FormControl(field.value || "", Validators.required)
      //   : new FormControl(field.value || "");

      group[field.key] = new FormControl(field.value || '');
    });
    return new FormGroup(group);
  }

  getParticipantOptionalDataFields(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getParticipantOptionalDataFieldsMock()
      : this.mockService.getParticipantOptionalDataFieldsMock();
  }

  getParticipantContributionData(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getParticipantContributionDataMock()
      : this.mockService.getParticipantContributionDataMock();
  }

  getParticipantParticipantFundData(): Observable<any> {
    return ENV.TEST
      ? this.mockService.getParticipantParticipantFundData()
      : this.mockService.getParticipantParticipantFundData();
  }

  addParticpantRequiredData(
    participantRequiredData: Participant.IParticipantRequiredData
  ) {
    this.participantData.participantRequiredData = participantRequiredData;
    console.log(this.participantData);
  }

  addParticipantOptionalData(
    participantOptionalData: Participant.IParticipantOptionalField[]
  ) {
    this.participantData.participantOptionalData = participantOptionalData;
    console.log(this.participantData);
  }

  addParticipantContributionElectionData(
    participantContributionElectionData: Participant.IParticipantContribution
  ) {
    this.participantData.participantContributionElectionData = participantContributionElectionData;
    console.log(this.participantData);
  }

  addparticipantContributionInvestmentData(
    participantContributionInvestmentData: Participant.IParticipantFundSources
  ) {
    this.participantData.participantContributionInvestmentData = participantContributionInvestmentData;
    console.log(this.participantData);
  }

  updateParticipantData() {}
}
