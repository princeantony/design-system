import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-update',
  templateUrl: './participant-update.component.html',
  styleUrls: ['./participant-update.component.scss']
})
export class ParticipantUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
