// Admin Settings
export class ParticipantAdminSetting {
  QDIAVisible: boolean;
  QDIAEnabled: boolean;
  statusText: string;
  morningStarVisible: boolean;
  morningStarEnabled: boolean;
  enrollParticipantVisible: boolean;
  enrollParticipantEnabled: boolean;
  emailEnabled: boolean;
}
// Participant
export interface ParticipantItem {
  ssn: string;
  name: string;
}

// Participant Required Data
export interface IParticipantRequiredData {
  ssn: string;
  email?: string;
  lastName: string;
  firstName: string;
  mName?: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  zip: string;
  state: string;
  country: string;
  dateOfBirth: string;
  dateOfHire: string;
  terminationDate?: string;
  terminationReason?: string;
  makeParticipantActive?: string;
  absenceStartDate?: string;
  absenceStartDateReason?: string;
  absenceEndDate?: string;
  absenceEndDateReason?: string;
  enrollFlag: boolean;
  mstarFlag: boolean;
  qdiaFlag: boolean;
}

// Particaipant Optional Field Data
interface option {
  displayText: string;
  label: string;
}

export interface IParticipantOptionalField {
  controlType: string;
  label: string;
  value: string;
  required: boolean;
  readonly: boolean;
  disabled: boolean;
  option: option[];
}

// Participant Contribution Screen
export interface ParticipantContributionItem {
  key: string;
  label: string;
  value: string;
  readonly: boolean;
}
export interface IParticipantContribution {
  invElectChangeAllowed: boolean;
  mstarFlag: boolean;
  contribElection: {
    type: string;
    list: ParticipantContributionItem[];
  };
  catchupContribElection: {
    type: string;
    list: ParticipantContributionItem[];
  };
  investmentElection: {
    acrossAllSourceElectionFlg: string;
    list: ParticipantContributionItem[];
  };
}

// Participant Contribution Investment Screen
export interface ParticipantFundSourceItem {
  sourceID: string;
  value: string;
  readonly: boolean;
}
export interface ParticipantFundSource {
  fundName: string;
  sources: ParticipantFundSourceItem[];
}
export interface ParticipantSourceMapItem {
  sourceID: string;
  sourceName: string;
}
export interface IParticipantFundSources {
  fundSources: ParticipantFundSource[];
  sourceMap: ParticipantSourceMapItem[];
}

export class ParticipantData {
  participantRequiredData: IParticipantRequiredData;
  participantOptionalData: IParticipantOptionalField[];
  participantContributionElectionData: IParticipantContribution;
  participantContributionInvestmentData: IParticipantFundSources;
  constructor() {
    //  Set Participant Required Data
    this.participantRequiredData = {} as IParticipantRequiredData;
    this.participantRequiredData.ssn = '';
    this.participantRequiredData.firstName = '';
    this.participantRequiredData.lastName = '';
    this.participantRequiredData.mName = '';
    this.participantRequiredData.email = '';
    this.participantRequiredData.addressLine1 = '';
    this.participantRequiredData.addressLine2 = '';
    this.participantRequiredData.city = '';
    this.participantRequiredData.state = '';
    this.participantRequiredData.zip = '';
    this.participantRequiredData.country = '';
    this.participantRequiredData.dateOfBirth = '';
    this.participantRequiredData.dateOfHire = '';
    this.participantRequiredData.enrollFlag = false;
    this.participantRequiredData.mstarFlag = false;
    this.participantRequiredData.qdiaFlag = false;
  }
}
