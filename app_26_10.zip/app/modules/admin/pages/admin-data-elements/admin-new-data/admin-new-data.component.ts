import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'app-admin-new-data',
    templateUrl: './admin-new-data.component.html',
    styleUrls: ['./admin-new-data.component.scss']
  })

  export class AdminNewDataComponent implements OnInit{
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;

    newDataForm = this.fb.group({
      optionCode: ['', Validators.required],
      optionText: ['', Validators.required],
    });

    constructor( private fb: FormBuilder){ }
    gotoPrevious(){}

    onSubmit(){console.log(this.newDataForm.value)}
    ngOnInit(){
      this.hidePageTitle = false;
      this.subTitle = 'New Data Element Option';
      this.planNumber ='559985';
  }

  }

