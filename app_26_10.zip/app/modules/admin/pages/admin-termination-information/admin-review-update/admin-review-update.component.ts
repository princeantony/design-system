import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormControl } from '@angular/forms';
import { AgGridNg2 } from 'ag-grid-angular';

@Component({
    selector: 'app-admin-review-update',
    templateUrl: './admin-review-update.component.html',
    styleUrls: ['./admin-review-update.component.scss']
  })

  export class AdminReviewUpdateComponent implements OnInit {
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;

    TerminateReasonForm = this.fb.group({
      'optionID': new FormControl('', Validators.required),
      'optionText': new FormControl('', Validators.required),
    })

    constructor( private fb: FormBuilder){}

    ngOnInit(){
      this.hidePageTitle = false;
      this.subTitle = 'Termination Information';
      this.planNumber ='559985'; 
    }

  }