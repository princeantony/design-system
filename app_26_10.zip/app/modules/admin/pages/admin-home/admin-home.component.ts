import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { SUB_TITLE } from '../../../../shared/constants/app.constants';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html'

})
export class AdminHomeComponent implements OnInit {

  hidePageTitle = false;
pageTitleClass = false;
changePlan = false;
 planNumber: string;
 subTitle:string;
 
 message: string;

  constructor() { }

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.ADMIN ;
  }

}
