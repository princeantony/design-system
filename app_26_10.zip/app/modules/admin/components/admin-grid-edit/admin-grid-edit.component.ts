import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { VoyaCheckboxComponent } from "../../../../shared/components/form/voya-checkbox/voya-checkbox.component";
import { AdminGridCheckboxComponent } from "../admin-grid-checkbox/admin-grid-checkbox.component";

@Component({
  selector: "app-admin-grid-edit",
  templateUrl: "./admin-grid-edit.component.html"  
})

export class AdminGridEditComponent implements OnInit{

    ngOnInit(){}

}