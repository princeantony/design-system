import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
const noop = () => {};

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.scss']
})


export class LoginComponent implements OnInit {
    loginForm: FormGroup;

    public loginFail;
    constructor(
        private router: Router
    ) { }


    ngOnInit() {
        this.loginForm = new FormGroup({
            'username': new FormControl('SPAYNG01', Validators.required),
            'password': new FormControl('ING12345', Validators.required),
            'clientId': new FormControl('INGWIN', Validators.required),
            'divisionId': new FormControl('WIN', Validators.required ),
        })
    }

    onSubmit() {

        if (this.loginForm.value.username &&
            this.loginForm.value.password  &&
            this.loginForm.value.clientId &&
            this.loginForm.value.divisionId
            ) {
             PayAdminGlobalState.loginUser = {
               userName: this.loginForm.value.username,
               password: this.loginForm.value.password,
               clientId: this.loginForm.value.clientId,
               divisionId: this.loginForm.value.divisionId
             }
             PayAdminGlobalState.loginStatus = false;
              this.router.navigate(['/plans']);
         }

         else {
             this.loginFail = true;
         }


    }

    isLabelHidden: boolean;
    private _onTouchedCallback: (_:any) => void = noop;
    private _onChangeCallback: (_:any) => void = noop;

 onTouched(event: any){

    if (event.target.value === "") {
      this.isLabelHidden = true;
    }
    if (event.target.value !== "") {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus(){
    this.isLabelHidden = false;
  }

}

// &&  this.loginForm.value.username === "asdf"
