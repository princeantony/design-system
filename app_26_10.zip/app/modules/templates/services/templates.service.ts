import { Injectable } from '@angular/core';
import {
  RequestOptions,
  Headers
} from '../../../../../node_modules/@angular/http';
import { ApiService } from './../../../shared/services/api.service';
import { SERVICE_URL } from './../../../shared/constants/service.constants';
import { Observable } from '../../../../../node_modules/rxjs';
import { MockService } from '../../../shared/services/mock.service';

@Injectable({
  providedIn: 'root'
})
export class TemplatesService {
  constructor(
    private apiService: ApiService,
    private mockService: MockService
  ) {}
  mockuploadFile(): Observable<any> {
    return this.mockService.postWithFile();
  }

  uploadFile(formData: FormData, planNumber: string): Observable<any> {
    return this.apiService.postWithFile(
      'common/import/plan/666006/fileType/xls/importType/E/file',
      formData
    );
  }

  getMockTemplateOptions(): Observable<any> {
    return this.mockService.getTemplateOtions();
  }
  getTemplateOptions(planNumber: string, fileType: string): Observable<any> {
    return this.apiService.get(
      // SERVICE_URL.GET_TEMPLATE_OPTIONS + planNumber + '/filetype/' + fileType
      'common/import/plan/40311K/fileType/FXW/importType/E/templates'
    );
  }
  deleteTemplate(planNumber: string, templateObj: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_TEMPLATE_DELETE + planNumber,
      templateObj
    );
  }

  getAvailableColsMock(planNumber: string, type: string): Observable<any> {
    return this.mockService.getAvailableCols();
  }
  getAvailableCols(planNumber: string, type: string): Observable<any> {
    return this.apiService.get(SERVICE_URL.GET_TEMPLATE_COLUMNLIST);
  }

  saveTemplate(planId: string, templateData: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_SAVE_TEMPLATE + planId + '/template/save',
      templateData
    );
  }

  validateMockFileData(): Observable<any> {
    return this.mockService.getValidationData();
  }
  validateFileData(planNumber: string, fileData: any): Observable<any> {
    return this.apiService.post(
      SERVICE_URL.POST_VALIDATE_FILEDATA + planNumber + '/template/validate',
      fileData
    );
  }
  getMockTemplateDetails(): Observable<any> {
    return this.mockService.getExistingTemplate();
  }
  getTemplateDetails(planNumber: string, templateObj: any): Observable<any> {
    return this.apiService.getByObject(
      SERVICE_URL.GET_TEMPLATE_DETAILS + planNumber,
      templateObj
    );
  }
}
