import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '../../../../../../node_modules/@angular/forms';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import {
  SUB_TITLE,
  ENV,
  APP_CONST
} from '../../../../shared/constants/app.constants';
import { TemplatesService } from '../../services/templates.service';
import { TemplateGridHeaderComponent } from '../../components/template-grid-header/template-grid-header.component';
import { templateData } from '../../../../shared/mocks/template-with-error';
import { ITemplate, IcolumnList } from '../../model/template.model';

@Component({
  selector: 'app-template-create-with-errors',
  templateUrl: './template-create-with-errors.component.html',
  styleUrls: ['./template-create-with-errors.component.scss']
})
export class TemplateCreateComponent implements OnInit {
  templateForm = this.fb.group({
    templateId: [],
    headerCount: ['0'],
    trailerCount: ['0']
  });
  planNumber: string;
  subTitle: string;
  hidePageTitle = false;
  fileData: any;
  fileType: string;
  templateData: ITemplate;
  headerDropdown: any;
  private rowData: any[];
  private columnDefs = [];
  gridApi: any;
  gridColumnApi: any;
  params: any;
  frameworkComponents: any;
  columnList: IcolumnList[] = [];
  constructor(
    private fb: FormBuilder,
    private templateservice: TemplatesService
  ) {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.TEMPLATE_CREATE;
    this.fileData = PayAdminGlobalState.importFileData;
    this.fileType = PayAdminGlobalState.importFileType;
    if (ENV.TEST) this.getMockColumnList();
    else this.getColumnList();
  }

  getMockColumnList() {
    this.templateservice.getAvailableColsMock(this.planNumber, 'E').subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.headerDropdown = response.data.availableColumnList;
          this.fileData = templateData.data.fileData;
          this.createGridData();
        }
      },
      err => {
        console.log('Error', err);
      }
    );
  }

  getColumnList() {
    this.templateservice.getAvailableCols(this.planNumber, 'E').subscribe(
      response => {
        if (response.status === APP_CONST.SUCCESS) {
          this.headerDropdown = response.data.availableColumnList;
          this.createGridData();
        }
      },
      err => {
        console.log('Error', err);
      }
    );
  }

  createGridData() {
    console.log('---------------this.testdata', this.fileData);
    for (let index = 0; index < this.headerDropdown.length; index++) {
      // const element = array[index];
      this.columnDefs.push({
        field: (index + 1).toString(),
        headerName: (index + 1).toString(),
        headerComponentParams: { options: this.headerDropdown }
      });
    }
    const rows = this.fileData;
    this.rowData = [];
    for (let i = 0; i < rows.length; i++) {
      const obj = {};
      for (let j = 0; j < rows[i].length; j++) {
        obj[(j + 1).toString()] = rows[i][j];
      }
      this.rowData.push(obj);
    }
    // console.log("---this.rowData", this.rowData);
    // console.log("--------coldef", this.columnDefs);
    this.frameworkComponents = { agColumnHeader: TemplateGridHeaderComponent };
  }

  saveTemplate() {
    console.log('--------save template function', this.templateForm);
    console.log('------------this.gridApi', this.params);
    this.gridApi.gridOptionsWrapper.gridOptions.columnDefs.forEach(element => {
      this.columnList.push({
        value: element.headerName,
        colNumber: element.field
      });
    });
    this.templateData = this.templateForm.value;
    this.templateData.importType = PayAdminGlobalState.importType;
    this.templateData.columnList = this.columnList;

    console.log('-----------templateData', this.templateData);
  }
  saveAndCont() {
    this.saveTemplate();
    const templateFileData = {
      templateId: this.templateForm.value.templateId,
      importType: PayAdminGlobalState.importType,
      fileData: PayAdminGlobalState.importFileData
    };
    if (ENV.TEST) {
      this.templateservice.validateMockFileData().subscribe(
        response => {
          console.log('-------------response', response);
          if (response.status === APP_CONST.SUCCESS) {
            if (response.validationData) {
            }
          }
        },
        err => {
          console.log('Error', err);
        }
      );
    } else {
      this.templateservice
        .validateFileData(this.planNumber, templateFileData)
        .subscribe(response => {
          if (response.validationData) {
          }
        });
    }
  }
  onGridReady(params) {
    console.log('--------onGridReady', params);
    this.params = params;
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
}
