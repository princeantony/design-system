import { Component, OnInit } from '@angular/core';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';
import { APP_CONST, SUB_TITLE } from 'src/app/shared/constants/app.constants';

@Component({
  selector: 'app-template-verification',
  templateUrl: './template-verification.component.html',
  styleUrls: ['./template-verification.component.scss']
})
export class TemplateVerificationComponent implements OnInit {
  hidePageTitle = false;
  planNumber: string;
  subTitle: string;
  rowData: any;
  columnDefs = [];

  constructor() {}

  ngOnInit() {
    this.planNumber = PayAdminGlobalState.planNumber;
    this.subTitle = SUB_TITLE.ENROLLMENT_AUDIT;
    this.rowData = PayAdminGlobalState.importFileData;
    this.columnDefs.push();
    console.log('--------filedata', PayAdminGlobalState.importFileData);
  }

  onGridReady(params) {


  }
}
