import { Component, OnInit } from '@angular/core';
import { templateFW } from './../../../../shared/mocks/template-fixed-width';
import { FormControl, FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { TemplateGridTextboxComponent } from '../../components/template-grid-textbox/template-grid-textbox.component';

@Component({
  selector: 'app-template-create-fixed-width',
  templateUrl: './template-create-fixed-width.component.html',
  styleUrls: ['./template-create-fixed-width.component.scss']
})
export class TemplateCreateFWComponent implements OnInit {
  rowData: any;
  columnDefs: any;
  context: any;
  rowSelection;
  fwtemplateForm: FormGroup;
  frameworkComponents: any;
  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.rowData = templateFW.data.columnList;
    console.log('------this.templateFields', this.rowData);
    this.fwtemplateForm = this.buildFormGroup();
    // console.log("------this.fwtemplateForm",this.fwtemplateForm);
    this.rowSelection = 'multiple';
    /* let textboxRenderer = function(params)
  {
    console.log("--------params", params);
    return '<input type = "text" [(ngModel)]="'+params.data.startPosition+'" placeholder ="Starting Position"></input>';
  } */
    this.context = { componentParent: this };
    this.frameworkComponents = {
      textboxRenderer: TemplateGridTextboxComponent
    };
    this.columnDefs = [
      // { headerName: '', field: 'check',  width: 100, checkboxSelection : true },
      { field: 'value', width: 300, checkboxSelection: true },
      {
        field: 'startPosition',
        width: 150,
        cellRenderer: 'textboxRenderer',
        cellRendererParams: {
          placeholder: 'Starting Position'
        }
      },
      {
        field: 'fieldWidth',
        width: 150,
        cellRenderer: 'textboxRenderer',
        cellRendererParams: {
          placeholder: 'Field Width'
        }
      }
    ];
  }
  onRowClicked(event: any) {
    console.log('--------------event', event);
  }
  onSelectionChanged(event: any) {
    console.log('--------------event', event);
  }
  onGridReady(params) {
    console.log('----------params', params);
  }
  buildFormGroup() {
    const group: any = {};
    group['templateName'] = new FormControl();
    group['headers'] = new FormControl();
    group['trailers'] = new FormControl();

    return new FormGroup(group);
  }
}
