import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { ILoadingOverlayAngularComp } from 'ag-grid-angular';
import {
  FormBuilder,
  FormGroup
} from '../../../../../../node_modules/@angular/forms';
import _ from 'lodash';

@Component({
  selector: 'app-template-grid-header',
  templateUrl: './template-grid-header.component.html',
  styleUrls: ['./template-grid-header.component.scss']
})
export class TemplateGridHeaderComponent {
  private params: any;
  options: any = [];
  headers: any = [];
  templateHeaderForm: FormGroup;
  colDefs: any;
  newColdefs = [];

  constructor(private fb: FormBuilder) {}

  agInit(params): void {
    this.params = params;

    console.log('--------------header params', this.params.column.colDef);
    this.colDefs = params.column.gridOptionsWrapper.gridOptions.columnDefs;
    console.log('-------------------options', this.options);
    this.options = params.options;
    console.log('-------------------options', this.options);
    this.templateHeaderForm = this.fb.group({
      colHeader: [this.params.column.colDef.headerName]
    });

    console.log(
      '--------params.column.gridOptionsWrapper.gridOptions',
      params.column.gridOptionsWrapper.gridOptions
    );
    console.log('-------------form', this.templateHeaderForm);
  }
  updateColHeader(params: any, e: any) {
    console.log('---------colHeader', params);
    console.log('---------event', e);

    console.log('---colDefs', this.colDefs);
  }

  selectCol(event: any) {
    console.log('------------event', event);
    console.log('--------------header params', this.params);
    /*  this.params.column.colDef.headerName = event.value;
    _.filter(this.params.column.gridOptionsWrapper.gridOptions.columnDefs, ['field', this.params.column.colDef.field]);
    console.log("------params",this.params); */
    this.params.column.gridOptionsWrapper.gridOptions.columnDefs.forEach(
      element => {
        console.log('------element', element);
        if (element.field === this.params.column.colDef.field) {
          element.headerName = event.value;
        }
      }
    );
    console.log('------params', this.params);
  }
}
