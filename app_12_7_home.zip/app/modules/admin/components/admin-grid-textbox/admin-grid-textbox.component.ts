import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import _ from 'lodash';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
@Component({
  selector: 'app-admin-grid-textbox',
  templateUrl: './admin-grid-textbox.component.html'
})
export class AdminGridTextboxComponent implements ICellRendererAngularComp {
  constructor() {}
  public params: any;
  controlName: string;
  value: string;
  parent: string;
  agInit(params: any): void {
    this.params = params;
    this.controlName = params.colDef.field + '_' + params.rowIndex;
    this.value = params.value;
    this.parent = (_.has(params.data, 'deferralCatchUp') ? 'money' : 'investment');
    this.controlName = this.parent + '_' + params.colDef.field + '_' + params.rowIndex;

  }
  onBlur(event: any) {
    const id = _.split(event.target.id, '_');
    const gridName = id[0];
    const name = id[1];
    const index = id[2];
    const item = {};
    item[name] = event.target.value;
    if (gridName === 'money') {
   Object.assign(PayAdminGlobalState.moneySource[index], item);
    } else {
    Object.assign(PayAdminGlobalState.investments[index], item);
    }
  }
  refresh(): boolean {
    return false;
  }
}
