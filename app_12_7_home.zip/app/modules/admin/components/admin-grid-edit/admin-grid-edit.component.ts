import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { AdminGridEditButtonComponent } from "../admin-grid-edit-button/admin-grid-edit-button.component";

@Component({
  selector: "app-admin-grid-edit",
  templateUrl: "./admin-grid-edit.component.html"
})
export class AdminGridEditComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
  @Output() onGridReady = new EventEmitter<any>();
  @Output() validateClick = new EventEmitter<any>();
  context = {
    componentParent: this
  };
  style;
  editType;

  frameworkComponents: any;
  constructor() {
    this.style = { width: "83%" };
  }

  ngOnInit() {
    this.frameworkComponents = {
      checkboxRenderer: AdminGridEditButtonComponent,
    }
    this.editType= "fullRow";
  }
  doValidateClick(item: any)
  {
this.validateClick.emit(item);
  }
  gridReady(params){
    console.log("inside grid component", params)
    this.onGridReady.emit(params);

  }
}
