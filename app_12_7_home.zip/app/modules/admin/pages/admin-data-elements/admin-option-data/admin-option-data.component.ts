import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastsManager } from 'ng6-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { ModalService } from '../../../../../shared/services/modal.service';
import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
    selector: 'app-admin-option-data',
    templateUrl: './admin-option-data.component.html'
  })

  export class AdminOptionDataComponent implements OnInit{
    hidePageTitle: boolean;
    pageTitle: string;
    planNumber: string;
    selectedDEOption: any;
    isCreate = true;
    isButtonDisabled = false;
    type = 'Data Element Option';
    modelId = 'deOptionModal';
    navigateTo = 'options/';
    optionForm = this.fb.group({
      valueCode: ['', Validators.required],
      value: ['', Validators.required],
    });

    constructor(
      private fb: FormBuilder,
      private adminService: AdminService,
      private route: ActivatedRoute,
      private modalService : ModalService,
       private router: Router,
       private spinner: NgxSpinnerService,
       public toastr: ToastsManager,
    ){ }

    ngOnInit(){
      this.hidePageTitle = false;
      this.pageTitle = 'Update Data Element Option ';
      this.planNumber = PayAdminGlobalState.planNumber;
      if(AdminDataService.dataElementOption) {
        this.isCreate = false;
      this.selectedDEOption = AdminDataService.dataElementOption;
      this.populateForm(this.selectedDEOption);
      PayAdminGlobalState.previousPage = 'admin/dataElements/options';
      PayAdminGlobalState.currentPage = 'admin/dataElements/options/createOrEdit';
      }
  }
  populateForm(optionElement) {
    this.optionForm.controls['valueCode'].setValue(optionElement.valueCode);
    this.optionForm.controls['value'].setValue(optionElement.value);
  }
  gotoBack() {
    this.router.navigate(['/admin/dataElements/options']);
  }
  showDeteleModal() {
    PayAdminGlobalState.currentPage = PayAdminGlobalState.previousPage;
    this.modalService.open('deOptionModal');
  }
  onSaveOption() {
    this.spinner.show();
    const newDEOption = this.optionForm.value;
    if(!this.isCreate) {
      newDEOption['initialCode'] = AdminDataService.dataElementOption.valueCode;
    }
    console.log('new opt', newDEOption );
    this.adminService.saveDEOption(this.planNumber, newDEOption, AdminDataService.dataElementId, this.isCreate).subscribe(saveRes => {
      this.spinner.hide();
      if (saveRes.status === APP_CONST.SUCCESS) {
        this.router.navigate(['/admin/dataElements/options']);
      } else {
        console.log('Error in save option', saveRes);
        this.toastr.error(saveRes.error.msg, saveRes.status + ' !', { showCloseButton: true });
      }
    },
    (err => {
      this.spinner.hide();
      console.log('Error in save option outside', err);
      this.toastr.error('Error while saving Data Element Optoin !', err.error.status + ' !', { showCloseButton: true });

    })
  );
  }
}


