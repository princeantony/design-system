import { Injectable } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable, Subject, Subscription, of } from 'rxjs';
import { CommonService } from 'src/app/shared/services/common.service';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { PayAdminGlobalState } from '../../../shared/store/pay-admin-global.store';
import { isEmptyObject } from '../../../shared/utils/pay-admin.utils';

import { ENV } from '../../../shared/constants/app.constants';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { ParticipantOptionalFields } from '../components/participant-optional-data/participant-optional-fields';
import * as Participant from '../model/participant.model';
import { ParticipantOptionSetting } from '../model/participant.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ParticipantStore } from '../store/participant.store';
import { delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ParticipantsService {
  constructor(
    private mockService: MockService,
    private apiService: ApiService,
    private commonService: CommonService,
    private http: HttpClient
  ) {}

  private participantData: Participant.ParticipantData = new Participant.ParticipantData();
  private ParticipantDivSubFilter: Participant.Option[] = [] as Participant.Option[];
  private participantOtherExpandedDivSub: Participant.Option[];
  private participantOptionSetting: ParticipantOptionSetting;
  private participantStatusList: Participant.Option[] = [] as Participant.Option[];
  private participantMorningStar: Participant.ParticipantMorningStar;

  private participantOtherDivSubChanged = new Subject<string>();
  private subscription: Subscription;

  setParticipantOptionSetting() {}
  apiParticipantGet(
    editMode = false,
    url,
    paramList: { key: string; value: string }[] = [],
    headerList: { key: string; value: string }[] = []
  ): Observable<any> {
    if (editMode) {
      paramList.push({ key: 'update', value: 'true' });
    }
    return this.apiService.getByParam(
      url,
      paramList.length > 0 ? paramList : [],
      headerList.length > 0 ? headerList : []
    );
  }

  getParticipantOptionSetting(editMode: boolean = false): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantAdminSettingMock();
    } else {
      // 'participant/plan/{planId}/add/options'
      const url = SERVICE_URL.GET_PARTICIPANT_ADMIN_OPTIONS.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiParticipantGet(editMode, url);
    }
  }

  getParticipantStatusFromStatusList(
    editMode: boolean = false
  ): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantStatusListMock();
    } else {
      const url = SERVICE_URL.GET_PARTICIAPNT_STATUS_LIST.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiParticipantGet(editMode, url);
    }
  }

  validateAddParticipantSSN(participantSSN: string): Observable<any> {
    if (ENV.TEST) {
      const isValidSSN = {
        status: 'SUCCESS'
      };
      return of(isValidSSN).pipe(delay(2000));
    } else {
      const url = SERVICE_URL.GET_PARTICIPANT_VALIDATE_SSN.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      const headersList: { key: string; value: string }[] = [];
      headersList.push({ key: 'ssn', value: participantSSN });

      return this.apiParticipantGet(false, url, [], headersList);
    }
  }

  validateUpdateParticipantSSN(participantSSN: string): Observable<any> {
    if (ENV.TEST) {
      const isValidSSN = {
        status: 'SUCCESS'
      };
      return of(isValidSSN).pipe(delay(2000));
    } else {
      const headersList: { key: string; value: string }[] = [];
      headersList.push({ key: 'ssn', value: participantSSN });
      const url = SERVICE_URL.GET_UPDATE_PARTICIPANT_VALIDATE_SSN.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );

      return this.apiParticipantGet(false, url, [], headersList);
    }
  }

  getParticipantBySSN$(ssn: string): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getUpdateParticipantRequiredData();
    } else {
      const url = SERVICE_URL.GET_UPDATE_PARTICIPANT_REQUIRED_DATA.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      const headersList: { key: string; value: string }[] = [];
      headersList.push({ key: 'ssn', value: ssn });
      return this.apiParticipantGet(false, url, [], headersList);
    }
  }

  getParticipantListByLastName$(name: string): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getparticipantListMock();
    } else {
      const url = SERVICE_URL.GET_PARTICIPANT_LIST_BY_NAME.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      ).replace('{participantName}', name);
      return this.apiParticipantGet(false, url, [], []);
    }
  }

  getParticipantMorningStarData(editMode: boolean = false): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantMorningStarDataMock();
    } else {
      // 'participant/plan/{planId}/morningstar'

      const url = SERVICE_URL.GET_PARTICIPANT_MORINGINSTART.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );

      return this.apiParticipantGet(editMode, url, [], []);
    }
  }

  getParticipantTerminationReason() {
    // if (ENV.TEST) {
    //   return this.mockService.getParticipantTerminationReason();
    // } else {
    //   const url = SERVICE_URL.GET_PARTICIPANT_MORINGINSTART.replace(
    //     '{planId}',
    //     PayAdminGlobalState.planNumber
    //   );

    //   return this.apiParticipantGet(false, url, [], []);
    // }
    return this.mockService.getParticipantTerminationReason();
  }

  getParticipantOptionalDataFields$(
    editMode: boolean = false
  ): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantOptionalDataFieldsMock();
    } else {
      const url = SERVICE_URL.GET_PARTICIPANT_OPTIONALDATAELEMENTS.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiParticipantGet(editMode, url, [], []);
    }
  }

  getParticipantContributionData$(editMode: boolean = false): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantContributionDataMock();
    } else {
      const url = SERVICE_URL.GET_PARTICIAPNT_CONTRIBUTION_ELECTIONS.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiParticipantGet(editMode, url, [], []);
    }
  }

  getParticipantParticipantFundData$(
    ssn: string,
    dob: string,
    sources: string,
    sameAsSource: string,
    editMode: boolean = false
  ): Observable<any> {
    if (ENV.TEST) {
      return this.mockService.getParticipantParticipantFundData();
    } else {
      // participant/plan/{planId}/investmentelections?sources={sources}&sameAsSource={sameAsSource}
      const url = SERVICE_URL.GET_PARTICIPANT_INVESTMENT_ELECTIONS.slice(
        0,
        SERVICE_URL.GET_PARTICIPANT_INVESTMENT_ELECTIONS.indexOf('?')
      ).replace('{planId}', PayAdminGlobalState.planNumber);

      const paramList: { key: string; value: string }[] = [];
      paramList.push({ key: 'sources', value: sources });
      paramList.push({ key: 'sameAsSource', value: sameAsSource });

      return this.apiParticipantGet(editMode, url, paramList, []);
    }
  }

  getParticipantOtherDivSub(range: string = ''): Participant.Option[] {
    const otherDivSub = ParticipantStore.ParticipantOptionSetting.otherDivSub;
    if (range !== '') {
      let filterdDivSub: Participant.Option[] = [];
      let rangeCharsArray = [];
      switch (range) {
        case 'AE001':
          rangeCharsArray = ['A', 'B', 'C', 'D', 'E'];
          break;
        case 'FJ002':
          rangeCharsArray = ['F', 'G', 'H', 'I', 'J'];
          break;
        case 'KO003':
          rangeCharsArray = ['K', 'L', 'M', 'N', 'O'];
          break;
        case 'PT004':
          rangeCharsArray = ['P', 'Q', 'R', 'S', 'T'];
          break;
        case 'UZ005':
          rangeCharsArray = ['U', 'V', 'W', 'X', 'Y', 'Z'];
          break;
      }
      filterdDivSub = otherDivSub.filter(divSub => {
        let inRange = false;
        for (const curChar of rangeCharsArray) {
          const divSubDescription = this.getDivSubText(divSub.displayText);
          inRange = divSub.displayText
            .toUpperCase()
            .startsWith(curChar.toUpperCase());
          if (inRange) {
            console.log(divSubDescription);
            break;
          }
        }
        return inRange;
      });

      return filterdDivSub;
    }
    return otherDivSub;
  }

  enrollParticipant(): Observable<any> {
    if (ENV.TEST) {
      const pDate: Participant.ParticipantSubmitData = this.getParticipantDataToSubmit();
      console.log('Participant Submit Data', pDate);
      return of({
        status: 'SUCCESS',
        messages: ['Participant enrolled successfully']
      });
    } else {
      const pDate: Participant.ParticipantSubmitData = this.getParticipantDataToSubmit();
      const url = SERVICE_URL.POST_ENROLL_PARTICIPANT.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiService.post(url, pDate);
    }
  }

  updateParticipant(): Observable<any> {
    if (ENV.TEST) {
      const pDate: Participant.ParticipantSubmitData = this.getParticipantDataToSubmit();
      console.log('Participant Submit Data', pDate);

      return of({
        status: 'SUCCESS',
        messages: ['Participant enrolled successfully']
      });
    } else {
      const pDate: Participant.ParticipantSubmitData = this.getParticipantDataToSubmit();
      const url = SERVICE_URL.POST_UPDATE_PARTICIPANT.replace(
        '{planId}',
        PayAdminGlobalState.planNumber
      );
      return this.apiService.put(url, pDate);
    }
  }

  getParticipantDataToSubmit(): Participant.ParticipantSubmitData {
    const _participant: Participant.ParticipantSubmitData = {} as Participant.ParticipantSubmitData;

    _participant.participantInfo = this.getParticipantInfoSubmitData();
    _participant.optionalDataElement = this.getParticipantOptionalDataElementSubmitData();
    _participant.contributionElections = this.getContributionsSubmitData();
    _participant.catchUpContributionElections = this.getCatchupContributionsSubmitData();
    _participant.investmentElectionsList = this.getInvestmentElectionsListSubmitData();
    return _participant;
  }

  getParticipantInfoSubmitData(): Participant.ParticipantInfo {
    const pInfo: Participant.ParticipantInfo = {} as Participant.ParticipantInfo;
    const info = ParticipantStore.ParticipantData.requiredData;
    pInfo.partSSN = info.ssn;
    pInfo.firstName = info.firstName;
    pInfo.lastName = info.lastName;
    pInfo.middleInitial = info.middleInitial;
    pInfo.address1 = info.address1;
    pInfo.address2 = info.address2;
    pInfo.city = info.city;
    pInfo.state = info.state;
    pInfo.zipCode = info.zipCode;
    pInfo.country = info.country;
    pInfo.email = info.email;
    pInfo.statusCode = info.statusCode;
    pInfo.birthDate = info.birthDate;
    pInfo.hireDate = info.hireDate;
    pInfo.rehireDate = info.rehireDate;
    pInfo.termDate = info.termDate;
    pInfo.termCode = info.termCode;
    pInfo.defType =
      ParticipantStore.ParticipantData.participantContribution.contribDeferralType;
    pInfo.catchupDefType =
      ParticipantStore.ParticipantData.participantContribution.catchupDeferralType;
    // pInfo.planId =
    pInfo.enrollFlag = info.enrollFlag;
    // pInfo.newDivsubUpdated = ParticipantStore.ParticipantData
    // pInfo.sameAsSource = info
    pInfo.mstarFlag = info.mstarFlag;
    pInfo.qdiaFlag = info.qdiaFlag;

    return pInfo;
  }

  getParticipantOptionalDataElementSubmitData(): Participant.ParticipantCodeValue[] {
    const ODEs: Participant.ParticipantCodeValue[] = [];
    if (ParticipantStore.ParticipantData.optionalData) {
      ParticipantStore.ParticipantData.optionalData.forEach(
        <ParticipantOptionalField>(item) => {
          const ODEItem: Participant.ParticipantCodeValue = {
            code: '',
            value: ''
          };
          ODEItem.code = item.key;
          ODEItem.value = item.value;
          ODEs.push(ODEItem);
        }
      );
    }

    return ODEs;
  }

  getContributionsSubmitData(): Participant.ParticipantCodeValue[] {
    const contribs: Participant.ParticipantCodeValue[] = [];
    if (
      ParticipantStore.ParticipantData.participantContribution.contribElection
    ) {
      ParticipantStore.ParticipantData.participantContribution.contribElection.forEach(
        <ParticipantContributionElectionItem>(item) => {
          const contrib: Participant.ParticipantCodeValue = {
            code: '',
            value: ''
          };
          contrib.code = item.key;
          contrib.value = item.value;
          contribs.push(contrib);
        }
      );
    }
    return contribs;
  }

  getCatchupContributionsSubmitData(): Participant.ParticipantCodeValue[] {
    const catchupContribs: Participant.ParticipantCodeValue[] = [];
    if (
      ParticipantStore.ParticipantData.participantContribution
        .catchupContribElection
    ) {
      ParticipantStore.ParticipantData.participantContribution.catchupContribElection.forEach(
        <ParticipantContributionElectionItem>(item) => {
          const catchupContrib: Participant.ParticipantCodeValue = {
            code: '',
            value: ''
          };
          catchupContrib.code = item.key;
          catchupContrib.value = item.value;
          catchupContribs.push(catchupContrib);
        }
      );
    }

    return catchupContribs;
  }

  getInvestmentElectionsListSubmitData(): Participant.PariticantInvestmentElectionItemSubmit[] {
    const investments: Participant.PariticantInvestmentElectionItemSubmit[] = [];
    if (
      ParticipantStore.ParticipantData.participantContributionInvestmentData
        .fundSources
    ) {
      ParticipantStore.ParticipantData.participantContributionInvestmentData.fundSources.forEach(
        fSource => {
          let fundSoures: Participant.ParticipantFundSource;
          fundSoures = fSource;
          if (fundSoures.percents) {
            fundSoures.percents.forEach(percent => {
              const investment: Participant.PariticantInvestmentElectionItemSubmit = {} as Participant.PariticantInvestmentElectionItemSubmit;
              investment.investmentId = percent.investmentId;
              investment.newPercent = percent.currentPercent;
              investment.sourceId = percent.sourceId;
              investments.push(investment);
            });
          }
        }
      );
    }

    return investments;
  }

  toFormGroup(fields: ParticipantOptionalFields<any>[]) {
    const group: any = {};

    fields.forEach(field => {
      group[field.key] = new FormControl(field.value || '');
    });
    return new FormGroup(group);
  }

  getDivSubID(divSub: string) {
    // divSub = '1234 Division Sub'
    return divSub.substring(0, divSub.indexOf(' '));
  }

  getDivSubText(divSub: string) {
    // divSub = '1234 Division Sub'
    return divSub.substr(divSub.indexOf(' ') + 1);
  }

  getParticipantStatus(statusCode: string): string {
    if (ParticipantStore.ParticipantStatusList) {
      const statusList = ParticipantStore.ParticipantStatusList;
      if (ParticipantStore.ParticipantStatusList.length > 0) {
        const statusItem: Participant.Option = statusList.find(
          item => item.value === statusCode // ParticipantStore.ParticipantOptionSetting.statusCode
        );
        if (statusItem) {
          return statusItem.displayText;
        }
      }
    }
    return '';
  }

  resetParticipantStore() {
    ParticipantStore.Active = false;
    ParticipantStore.PlanID = '';
    ParticipantStore.Divsub = '';
    ParticipantStore.StatusCode = '';
    ParticipantStore.Status = '';
    ParticipantStore.ParticipantOptionSetting = new ParticipantOptionSetting();
    ParticipantStore.ParticipantStatusList = [];
    ParticipantStore.ParticipantData = new Participant.ParticipantData();
  }
}
