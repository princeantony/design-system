import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GridOptions } from 'ag-grid-community';
import { SSNDirective } from 'src/app/shared/directives/voya-ssn.directive';
import { VoyaSSNPipe } from 'src/app/shared/pipes/voya-SSN.pipe';
import { NgxSpinnerService } from 'ngx-spinner';
import { ValidatorsService } from 'src/app/shared/services/validators.service';

import { ParticipantItem } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantStore } from '../../store/participant.store';
import { ToastsManager } from 'ng6-toastr';

enum ParticipantSearchType {
  SSN = 'Search By SSN',
  NAME = 'Search By Last Name'
}
@Component({
  selector: 'app-participant-search',
  templateUrl: './participant-search.component.html',
  styleUrls: ['./participant-search.component.scss'],
  providers: [VoyaSSNPipe, SSNDirective]
})
export class ParticipantSearchComponent implements OnInit {
  private SearchType = ParticipantSearchType;
  private participantSearchTypeList = [];
  private participantSearchForm: FormGroup = new FormGroup({});
  constructor(
    private participantService: ParticipantsService,
    private router: Router,
    private spinner: NgxSpinnerService,
    public toastr: ToastsManager,
    private validatorService: ValidatorsService,
    vcr: ViewContainerRef
  ) {
    this.toastr.setRootViewContainerRef(vcr);
  }
  private participantList: ParticipantItem[] = [] as ParticipantItem[];
  private participantSSN: string;
  private participantLastName: string;
  private participantSearchType: string;
  public gridOptions: GridOptions;
  private messageList: string[] = [];
  private onLoadDisable = true;
  ngOnInit() {
    this.participantSearchTypeList = [
      { displayText: 'Search By SSN', value: 'SSN' },
      { displayText: 'Search By Last Name', value: 'NAME' }
    ];
    this.participantSSN = this.participantLastName = '';
    this.participantSearchType = 'SSN';

    this.participantSearchForm = new FormGroup(
      {
        searchSSNInput: new FormControl(this.participantSSN, [
          Validators.required
        ]),
        searchLastNameInput: new FormControl(this.participantLastName),
        searchType: new FormControl(this.participantSearchType)
      },
      { updateOn: 'blur' }
    );

    this.gridOptions = <GridOptions>{
      rowData: this.participantList,
      columnDefs: [
        {
          field: 'ssn',
          headerName: 'Social Security Number',
          valueFormatter: this.ssnFormatter,
          width: 150
        },
        {
          field: 'name',
          headerName: 'Participant Name'
        }
      ],
      context: { componentParent: this },
      rowHeight: 32
    };
  }

  ssnFormatter(params) {
    const separator = '-';
    let value = params.value;
    let pipedSSN: string = value;
    if (value && value.replace(separator, '').length === 9) {
      value = value.replace(/-/g, ''); // value = 123456789
      pipedSSN =
        value.slice(0, 3) +
        separator +
        value.slice(3, 5) +
        separator +
        value.slice(5);
    }
    return pipedSSN;
  }

  onParticipantSearch() {
    this.onLoadDisable = false;
    // Clear store on selecting a participant
    this.participantService.resetParticipantStore();
    this.spinner.show();
    const searchType = this.participantSearchForm.controls['searchType'].value;
    if (searchType === 'SSN') {
      this.participantService
        .getParticipantBySSN$(
          this.participantSearchForm.controls['searchSSNInput'].value
            .split('-')
            .join('')
        )
        .subscribe(
          res => {
            if (res.status === 'SUCCESS') {
              ParticipantStore.ParticipantData.requiredData = res.data;
              ParticipantStore.ParticipantData.requiredData.ssn = this.participantSearchForm.controls[
                'searchSSNInput'
              ].value;
              this.spinner.hide();
              this.router.navigate(['UpdateParticipant']);
            }
          },
          err => {
            try {
              if (err.error.error.msg.length > 0) {
                this.messageList.push(err.error.error.msg);
                this.resetForm();
                this.spinner.hide();
              }
            } catch (Error) {
              console.log(Error);
            }
          }
        );
    } else if (searchType === 'NAME') {
      this.spinner.show();
      this.participantService
        .getParticipantListByLastName$(
          this.participantSearchForm.controls['searchLastNameInput'].value
        )
        .subscribe(
          res => {
            if (res.status === 'SUCCESS') {
              this.participantList = res.data;
            }
            this.spinner.hide();
            this.resetForm();

            this.gridOptions.rowData = this.participantList;
          },
          err => {
            if (err.error.error.msg.length > 0) {
              this.messageList.push(err.error.error.msg);
              this.resetForm();
              this.spinner.hide();
            }
          }
        );
    }
  }

  resetForm() {
    this.participantSearchForm.controls['searchSSNInput'].setValue('');
    this.participantSearchForm.controls['searchLastNameInput'].setValue('');
    this.participantSearchForm.controls['searchType'].setValue('SSN');
    this.participantSearchType = 'SSN';
  }

  onParticipantSelect(params) {
    // Clear store on selecting a participant
    this.participantService.resetParticipantStore();
    console.log(params.data.ssn);
    this.participantService.getParticipantBySSN$(params.data.ssn).subscribe(
      res => {
        if (res.status === 'SUCCESS') {
          ParticipantStore.ParticipantData.requiredData = res.data;
          ParticipantStore.ParticipantData.requiredData.ssn = params.data.ssn;
          this.router.navigate(['UpdateParticipant']);
        }
      },
      err => {
        if (err.error.error.msg.length > 0) {
          this.messageList.push(err.error.error.msg);
          this.resetForm();
          this.spinner.hide();
        }
      }
    );
  }

  onParticipantSearchByChange(value) {
    this.onLoadDisable = false;
    this.participantSearchType = value;
    this.participantSearchForm.controls['searchSSNInput'].setValue('');
    this.participantSearchForm.controls['searchLastNameInput'].setValue('');
  }

  onBackClicked() {
    if (this.participantList.length > 0) {
      this.participantList = [];
      this.participantSearchForm.reset();
    }
  }

  onGridReady(params) {
    params.api.sizeColumnsToFit();
  }
}
