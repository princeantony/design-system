import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { HomeMenuItems } from '../../../shared/config/home.config';
import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { IApiResponse } from '../../../shared/interfaces/api-response.interface';
import { IMenuItem } from '../../../shared/interfaces/menu-item.interface';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { Utils } from '../../../shared/utils/pay-admin.utils';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  menuItemsFlag : IApiResponse
  menuItemRows: any;
  constructor(
    private apiService: ApiService,
    private utils : Utils,
    private mockService: MockService) {
  }

  getMenuList(planNumber: string) : Observable<any>{
    return this.apiService.get(SERVICE_URL.GET_HOME_URL+planNumber)
  }
  getDelayedResponse() : Observable<any>{
    return this.apiService.get("")
  }
  getMockMenuList(planNumber: string) : Observable<any>{
     return this.mockService.getHomeFlags();
  }
  getMenuItemRows(menuItemsFlag : any)
  {
    console.log('HomeMenuItems', HomeMenuItems)
    let menuItemsToBind: IMenuItem[] = [];
    HomeMenuItems.forEach(menuItem => {
      if (menuItemsFlag[menuItem.key]) {
        menuItemsToBind.push(menuItem);

      }
    });
    return this.utils.chunkArray(menuItemsToBind, 3)
  }
}
