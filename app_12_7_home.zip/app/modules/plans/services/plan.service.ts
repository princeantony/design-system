import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';

import { SERVICE_URL } from '../../../shared/constants/service.constants';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';

@Injectable({
  providedIn: 'root'
})
export class PlanService {
  constructor(private apiService: ApiService, private mockService: MockService) {
   }
   getPlans(): Observable<any> {
    return ENV.TEST ? this.mockService.getListPlans() : this.apiService.get(SERVICE_URL.GET_LISTPLAN_URL);
   }
}
