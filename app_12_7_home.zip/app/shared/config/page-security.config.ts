import { IPageList } from '../interfaces/page-list.interface';

    export const PageListItems: Partial<IPageList>[] = [
        {
            key: 'addEnrollmentPageActive',
            label:'Add/Enrollment',
            value: false,
            isDisabled: false,
            subItems:[{
                key: 'addEnrollmentImportPageActive',
                label: 'Add/Enrollment Import',
                value: false

            }]
        },
        {
            key: 'participantUpdatePageActive',
            label: 'Participant Update',
            value: false,
            isDisabled: false,

        },
        {
            key: 'batchParticipantUpdatePageActive',
            label: 'Batch Participant Update',
            value: false,
            isDisabled: false,
            subItems:
            [{
                key:'batchParticipantUpdateImportPageActive',
                label: 'Batch Participant Update Import',
                value: false
            }]

        },
        {
            key: 'contributionPageActive',
            label: 'Contribution',
            value: false,
            isDisabled: false,
            subItems:[{
                key: 'contribImportPageActive',
                label:'Contribution Import',
                value: false
            }]
        },
        {
            key: 'loanRepaymentPageActive',
            label: 'Loan Repayment',
            value: false,
            isDisabled: false,
            subItems:[{
                key: 'loanImportPageActive',
                label:'Loan Repayment Import',
                value: false
            }]
        }
    ];
