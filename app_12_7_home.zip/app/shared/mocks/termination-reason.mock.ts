export const TerminationReasonList=
{ "status": "SUCCESS",
"data": [
    {
        "ID": "1",
        "DEText": "Lay Off",
        "link" : ""
    },
    {
        "ID": "2",
        "DEText": "With Cause",
        "link" : ""

    },
    {
        "ID": "3",
        "DEText": "Deceased",
        "link" : ""
    },
    {
        "ID": "4",
        "DEText": "Voluntary",
        "link" : ""
    },
]
}
