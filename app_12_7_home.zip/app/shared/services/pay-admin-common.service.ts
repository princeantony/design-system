export class  PayAdminCommonService
{

}