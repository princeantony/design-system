export interface MenuItem{
    menuHeading: string;
    menuSubheading: string;
}