
export const MESSAGES=
{
    VOYA_WORKING_TIME: 'The voya office timing message',
    VOYA_APP_NAME : 'Payroll/Administration',
    SERVICE_ERROR: 'There is an error occurred while calling the service!',
    SERVICE_SUCCESS: 'Service call succeeded!',
    SERVICE_START: 'Please wait... Service call in progress!'
};
export const COLUMN_DEFS=
{
    LIST_PLAN: [
        {headerName: "Plan Number", field: "planId"},
        {headerName: "Plan Name",field: "planName"}
    ]
};