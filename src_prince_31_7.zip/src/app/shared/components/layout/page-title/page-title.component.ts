import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-page-title',
  templateUrl: './page-title.component.html',
  styleUrls: ['./page-title.component.css']
})
export class PageTitleComponent implements OnInit {
 
  
  @Input() hidePageTitle: boolean;
  appTitle: string;
  planTitle: string;
  pageTitle: string;
  linkText: string;
  
  constructor() {  
    
    this.appTitle = 'Payroll/Administration';
    this.planTitle = '559985 - ING September 2010 Release';
    this.pageTitle = 'Bank Information';
    this.linkText = "Change Plan";
    this.inc();
  }
  inc()
  {
    console.log(this.hidePageTitle,"34534")
  }
  ngOnInit() {
  }
  

}
