import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-voya-link',
  templateUrl: './voya-link.component.html',
  styleUrls: ['./voya-link.component.css']
})
export class VoyaLinkComponent implements OnInit {
@Input() text: string;
  constructor() {
    console.log("text", this.text)
   }
  component = "/";
  ngOnInit() {
  }

}
