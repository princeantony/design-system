import { Component, OnInit, Input } from '@angular/core';
import {GridOptions} from "ag-grid";
import {COLUMN_DEFS} from '../../../constants/app.constants';
@Component({
  selector: 'voya-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {
  @Input() rowData:any;
  public gridOptions: GridOptions;
  constructor() {
    this.gridOptions = <GridOptions>{
      //rowData: GridComponent.createRowData(),
      //columnDefs: GridComponent.createColumnDefs()
  };
}

    columnDefs = COLUMN_DEFS.LIST_PLAN;


  ngOnInit() {
  }

}
