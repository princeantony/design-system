import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {AgGridModule} from 'ag-grid-angular';
import { AppComponent } from './app.component';
import { FooterComponent } from './shared/components/layout/footer/footer.component';
import { ListPlansComponent } from './modules/plans/components/list-plans/list-plans.component';
import { PlanSelectionComponent } from './modules/plans/pages/plan-selection/plan-selection.component';

import { VoyaTextboxComponent } from './shared/components/form/voya-textbox/voya-textbox.component';
import { VoyaLabelComponent } from './shared/components/form/voya-label/voya-label.component';
import { VoyaButtonComponent } from './shared/components/form/voya-button/voya-button.component';
import { GridComponent } from './shared/components/form/voya-grid/grid.component';

import { PayAdminRoutingModule, PayAdminRoutingComponents } from '../app/shared/modules/pay-admin-routing.module';
import {PayAdminHomeComponent} from '../app/modules/home/pages/pay-admin-home/pay-admin-home.component'; 
import { HeaderComponent } from '../app/shared/components/layout/header/header.component';


import { TimeInfoComponent } from './shared/components/time-info/time-info.component';
import { PageTitleComponent } from './shared/components/layout/page-title/page-title.component';
import { PayAdminMenuComponent } from './modules/home/components/pay-admin-menu/pay-admin-menu.component';
import { VoyaLinkComponent } from './shared/components/form/voya-link/voya-link.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    ListPlansComponent,
    PlanSelectionComponent,
    HeaderComponent,
    VoyaTextboxComponent,
    VoyaLabelComponent,
    VoyaButtonComponent,
    GridComponent,
    PayAdminHomeComponent,
    PayAdminRoutingComponents,
    TimeInfoComponent,
    PageTitleComponent,
    PayAdminMenuComponent,
    VoyaLinkComponent
    
  ],
  imports: [
    BrowserModule,
    PayAdminRoutingModule,
    AgGridModule.withComponents(
      [
        AppComponent, GridComponent,PlanSelectionComponent,ListPlansComponent
          
      ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
