import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-plan-selection',
  templateUrl: './plan-selection.component.html',
  styleUrls: ['./plan-selection.component.css']
})
export class PlanSelectionComponent implements OnInit {
  hidePageTitle:boolean = true;
  constructor() {
   }
  ngOnInit() {
  }
}
