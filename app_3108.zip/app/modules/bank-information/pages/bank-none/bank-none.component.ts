import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-none',
  templateUrl: './bank-none.component.html'

})
export class BankNoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
