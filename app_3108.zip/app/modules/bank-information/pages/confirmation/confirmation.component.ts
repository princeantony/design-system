import { Component, OnInit } from '@angular/core';
import { BankInfoService } from '../../services/bank-info.service';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html'

})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub : any;
  updateTime: any;
  updateDate: any;
  payAdminGlobalState: PayAdminGlobalState;
  
  constructor(private bankInfoService: BankInfoService, 
              private route: ActivatedRoute, 
              private router : Router,
              private modalService: ModalService) { }

  ngOnInit() {
   this.bankInfo =  this.bankInfoService.getBankInfo();
   
  }

  onSubmit(){
    let planId = PayAdminGlobalState.planNumber;

    this.updateDate = new Date().toLocaleDateString();
    this.updateTime = new Date().toLocaleTimeString();
    
    PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
    
    this.router.navigate(["/home/" + planId +"/success"]);
    
    

  }

  onEdit(){
    this.router.navigate(["bankInfo/editorcreate"]);
    

  }
 

  

}
