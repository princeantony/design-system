import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { BankInfoService } from '../../services/bank-info.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
//import { BankStates } from "../../../../shared/config/state.config";


@Component({
  selector: 'app-bank-edit-or-create',
  templateUrl: './bank-edit-or-create.component.html'

})
export class BankEditOrCreateComponent implements OnInit {
sub: any;
formData:any;
//states = BankStates; 
  constructor(private route: ActivatedRoute, 
              private router: Router, 
              private fb: FormBuilder, 
              private bankInfoService: BankInfoService ) { }

  ngOnInit() {
  }

  bankInfoForm = this.fb.group({
    name:[''],
    divLoc: [''],
    bankName: [''],
    bankCity: [''],
    bankState: [''],
    bankZip: [''],
    bankAdd:[''],
    routingNo:[''],
    conRountingNo:[''],
    accNo:[''],
    conAccNo:[''],
    accType:['']
    

  
    /* lastName: [''],
    address: this.fb.group({
      street: [''],
      city: [''],
      state: [''],
      zip: ['']
    }), */
  });

  

  onSubmit(){
    console.log(this.bankInfoForm.value);
    this.formData = this.bankInfoForm.value;
    this.bankInfoService.setBankInfo(this.formData);
   
      
         
      //let planId = PayAdminGlobalState.planNumber;
      this.router.navigate(["bankInfo/confirm/"]);
      
     
      
      
  }

}
