import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from "ag-grid-angular";
import { ActivatedRoute } from '../../../../../../node_modules/@angular/router';



@Component({
  selector: 'app-grid-link',
  templateUrl: './grid-link.component.html'
})
export class GridLinkComponent implements ICellRendererAngularComp {

  constructor() { }

  public params: any;
  public link : string;
  public navigatn : string;
  planNumber;
private sub: any;
    agInit(params: any): void {     
        this.params = params;
        if(this.params.data){
          if(!this.params.data.bankName){
            this.link = "Add Bank";
          

          }
          else{
            this.link = "Edit";
            
          }
        }
    }

    public invokeRouteTo(navigatn) {
      this.params.context.componentParent.routeTo(navigatn);
  }
  
    refresh(): boolean {
        return false;
    }

}
