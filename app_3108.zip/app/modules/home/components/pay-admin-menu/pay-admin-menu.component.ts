import { Component, OnInit, Input } from '@angular/core';
import { IMenuItem } from "../../../../shared/interfaces/menu-item.interface";
import { HomeService } from "../../services/home.service";
import {APP_CONST} from '../../../../shared/constants/app.constants';
import { NgxSpinnerService } from 'ngx-spinner';
import {  ActivatedRoute } from '@angular/router';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
@Component({
  selector: 'app-pay-admin-menu',
  templateUrl: './pay-admin-menu.component.html'

})
export class PayAdminMenuComponent implements OnInit {
  @Input() planNumber: string;
  menuItemRows: Array<IMenuItem[]>;
  appContext =  APP_CONST.APP_CONTEXT;
  homeFlag : any;
  message:string;
  payAdminGlobalState : PayAdminGlobalState
  private sub: any;
  constructor(
    private homeService: HomeService,
    private spinner: NgxSpinnerService,
    private route: ActivatedRoute
  ) {}
  ngOnInit() {

    
    this.planNumber = PayAdminGlobalState.planNumber;
    this.menuItemRows =  PayAdminGlobalState.homeFlagState;
    //if(this.menuItemRows === undefined)
    this.getMockMenuList();
    /*
    if(this.homeFlag === undefined)
    {
      this.getMockMenuList();
      this.spinner.show();
      //this.getMenuList();
      this.getMockMenuList();
    }
 else{
  console.log("from state home");
  console.log("this.homeFlag",this.homeFlag);
  //this.menuItemRows = this.homeFlag;
 }
 */

//this.message =  PayAdminGlobalState.successMsg;

}
  getMenuList()
  {
    this.homeService.getMenuList(this.planNumber).subscribe(flags => {
      this.spinner.hide();
      if(flags.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.menuItemRows = this.homeService.getMenuItemRows(flags);
      PayAdminGlobalState.homeFlagState = this.menuItemRows;
      }
    });
  }
  getMockMenuList()
  {
    this.homeService.getMockMenuList(this.planNumber).subscribe(flags => {
      this.spinner.hide();
      if(flags.status === APP_CONST.LOGIN_SUCCESS) 
      {
      this.menuItemRows = this.homeService.getMenuItemRows(flags.data);
      PayAdminGlobalState.homeFlagState = this.menuItemRows;
      }
    });
  }
}
