import { IApiResponse } from "../interfaces/api-response.interface";

export const HOME_FLAGS: IApiResponse =
{
  "status": "SUCCESS",
  "data": {
    "addEnrollmentFlag": true,
    "addEnrollmentImportFlag": false,
    "paricipantFlag": true,
    "batchParticipantFlag": false,
    "contributionFlag": true,
    "loanRepaymentFlag": true,
    "bankInfoFlag": true,
    "adminFlag": false,
    "pendingBatchFlag": false
  }
}
