import { IPlanLight } from "../interfaces/plan-light.interface";

export  class  PayAdminGlobalState{
    static planNumber: string;
    static planName: string;
    static successMsg: string;
    static planListState: IPlanLight;
    static homeFlagState: any;
}