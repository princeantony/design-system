import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-title-message',
  templateUrl: './title-message.component.html'
})
export class TitleMessageComponent implements OnInit {
  @Input() message;

  constructor() { }

  ngOnInit() {
    
  }
  takePrint(){
    
  }

}
