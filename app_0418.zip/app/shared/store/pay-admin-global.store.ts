import { IPlanLight } from "../interfaces/plan-light.interface";
import { IBankInfo } from "../interfaces/bank.interface";

export  class  PayAdminGlobalState{
    static planNumber: string;
    static planName: string;
    static successMsg: string;
    static planListState: IPlanLight;
    static homeFlagState: any;
    static bankinfo : any;
    static subDiv : any;
    static bankDetails :IBankInfo;
}