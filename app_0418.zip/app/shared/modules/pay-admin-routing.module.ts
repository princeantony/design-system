import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlanSelectionComponent } from '../../modules/plans/pages/plan-selection/plan-selection.component';
import { PayAdminHomeComponent } from '../../modules/home/pages/pay-admin-home/pay-admin-home.component';
import { BankAvailableComponent } from '../../modules/bank-information/pages/bank-available/bank-available.component';
import { EditComponent } from '../../modules/bank-information/pages/edit/edit.component';
import { BankModalComponent } from '../../modules/bank-information/components/bank-modal/bank-modal.component';
import { ConfirmationComponent } from '../../modules/bank-information/pages/confirmation/confirmation.component';
import { CreateComponent } from '../../modules/bank-information/pages/create/create.component';

const payAdmiinRoutes: Routes = [
  {
    path: 'plans',
    component: PlanSelectionComponent,
    data: { title: 'Plan List' }
  },
  {
    path: 'home',
    component: PayAdminHomeComponent
  },
  {
    path: 'home/success',
    component: PayAdminHomeComponent
  },
  {
    path : 'home/print',
    component: ConfirmationComponent
  },
  
  {
    path: 'bankInfo/edit/:addressId',
    component: EditComponent
  },
  {
    path: 'bankInfo/create',
    component: CreateComponent
  },
  {
    path: 'bankInfo',
    component: BankAvailableComponent
  },
  {
    path : 'bankInfo/confirm',
    component: ConfirmationComponent
  },

  { 
    path: '**',
     component: PayAdminHomeComponent 
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(payAdmiinRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    
    
  ]
})
export class PayAdminRoutingModule { }
export const PayAdminRoutingComponents = [PlanSelectionComponent, PayAdminHomeComponent, BankAvailableComponent];