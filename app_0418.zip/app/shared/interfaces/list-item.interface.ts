export interface IListItem{
    code: string;
    description: string;
    
}