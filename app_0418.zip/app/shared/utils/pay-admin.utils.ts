export  class Utils {
  constructor(){}
  chunkArray<T>(arr: Array<T>, chunkSize: number): Array<Array<T>> {
    return arr.reduce(
      (prevVal: any, currVal: any, currIndx: number, array: Array<T>) =>
        !(currIndx % chunkSize)
          ? prevVal.concat([array.slice(currIndx, currIndx + chunkSize)])
          : prevVal,
      []
    );
  }
}
