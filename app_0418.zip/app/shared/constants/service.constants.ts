export const SERVICE_URL=
{
    APP_URL: "http://localhost:4200/payadmin/ws/ers/service/",
    GET_DIRECT_LOGIN_URL: 'login/direct',
    GET_LISTPLAN_URL: 'plans',
    GET_HOME_URL: 'plans/plan/'
};