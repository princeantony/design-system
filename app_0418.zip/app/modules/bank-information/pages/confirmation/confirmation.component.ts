import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { IBankInfo } from '../../../../shared/interfaces/bank.interface';
import _ from 'lodash';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html'

})
export class ConfirmationComponent implements OnInit {
  bankInfo: any;
  sub : any;
  updateTime: any;
  updateDate: any;
  bankDetails: IBankInfo;
  accType: string;
  divSubs : any;
  divSub: string;
  hidePageTitle:boolean;
  print:boolean = false;
  subTitle:string;
  planNumber:string;
  payAdminGlobalState: PayAdminGlobalState;
  
  
  constructor( 
              private route: ActivatedRoute, 
              private router : Router,
              private modalService: ModalService) { }

  ngOnInit() {

    this.hidePageTitle = false;
   this.subTitle = "Bank Information";
  this.planNumber =  PayAdminGlobalState.planNumber; 
  
   this.bankDetails = PayAdminGlobalState.bankDetails;
   console.log("-------------this.bankDetails", this.bankDetails);
   this.divSubs = PayAdminGlobalState.subDiv;
   this.divSub =_.filter(this.divSubs, ['id', this.bankDetails.divsub])[0].text;
   
   if(this.bankDetails.accountType == "C"){
     this.accType = "Checking";

   }
   else{
     this.accType = "Savings";
   }

   this.route.url.subscribe(params => {
    if(params[1].path == "print"){
      this.print = true;
  
    }
    
  
  });
   
  }

  onSubmit(){
    let planId = PayAdminGlobalState.planNumber;

    this.updateDate = new Date().toLocaleDateString();
    this.updateTime = new Date().toLocaleTimeString();
    
    PayAdminGlobalState.successMsg = "Bank Information successfully updated on "+this.updateDate+" at "+this.updateTime+". For more information,"
    
    this.router.navigate(["/home/" + planId +"/success"]);
    
    

  }

  onEdit(){
    this.router.navigate(["bankInfo/editorcreate"]);
    

  }
 

  

}
