import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '../../../../../../node_modules/@angular/forms';
import { IBankInfo } from '../../../../shared/interfaces/bank.interface';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { Router } from '../../../../../../node_modules/@angular/router';
import { BankStates } from "../../../../shared/config/state.config";
import _ from 'lodash';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html'

})
export class CreateComponent implements OnInit {
  updateInfo: IBankInfo;
  bankStates: any;
  bankInfo:any;
  divSubs: any;
  bankNames:any;
  bankInfoForm = this.fb.group({
   
    divsub: [''],
    divsubcopy: [''],
    bankName: ['', Validators.required],
    city: ['', Validators.required],
    state: ['', Validators.required],
    zipcode: ['', Validators.required],
    address1:[''],
    abaNumber:['', Validators.required],
    confirmAbaNumber:[''],
    acctNumber:['', Validators.required],
    confirmAcctNumber:[''],
    accountType:['', Validators.required]
    
  
  });
  hidePageTitle:boolean;
  subTitle: string;
  planNumber:string;
  emptyBanknames:any;

  constructor(private fb: FormBuilder,
              private router: Router) { }

              get bankName() { return this.bankInfoForm.get('bankName'); }


  ngOnInit() {

    this.hidePageTitle = false;
   this.subTitle = "Bank Information";
  this.planNumber =  PayAdminGlobalState.planNumber; 

    this.bankStates = BankStates;
    this.bankInfo = PayAdminGlobalState.bankinfo;
    this.divSubs = PayAdminGlobalState.subDiv;
    this.bankNames = _.filter(this.bankInfo, 'bankName');
    this.emptyBanknames = _.filter(this.bankInfo, ['valid', false]);
    console.log("---------------this.bankInfo", this.bankInfo);
    console.log("---------------this.emptyBanknames", this.emptyBanknames);
    
  }

  onSelect(value){
    
    let bankInfoTemp = _.filter(this.bankNames, ['id', value ])[0];
    

    this.bankInfoForm.controls['bankName'].setValue(bankInfoTemp.bankName);
        this.bankInfoForm.controls['address1'].setValue(bankInfoTemp.address1);
        this.bankInfoForm.controls['city'].setValue(bankInfoTemp.city);
        this.bankInfoForm.controls['state'].setValue(bankInfoTemp.state);
        this.bankInfoForm.controls['zipcode'].setValue(bankInfoTemp.zipcode);
        this.bankInfoForm.controls['acctNumber'].setValue(bankInfoTemp.acctNumber);
        this.bankInfoForm.controls['confirmAcctNumber'].setValue(bankInfoTemp.acctNumber);
        this.bankInfoForm.controls['accountType'].setValue( _.split(bankInfoTemp.accountType, " ")[0]);
        this.bankInfoForm.controls['abaNumber'].setValue(bankInfoTemp.abaNumber);
        this.bankInfoForm.controls['confirmAbaNumber'].setValue(bankInfoTemp.abaNumber);
  }

  onSubmit(){
    
    /* this.updateInfo = this.editInfo;
    _.merge(this.updateInfo, this.bankInfoForm.value); */
    
    
    this.updateInfo = this.bankInfoForm.value;
    
    /* this.updateInfo.addressId = this.editInfo.addressId;
    this.updateInfo.valid = this.editInfo.valid;
    
    this.updateInfo.divsub = this.editInfo.divsub; */
    this.updateInfo.planNumber = PayAdminGlobalState.planNumber;
    PayAdminGlobalState.bankDetails = this.updateInfo;
    
    
    
    
      this.router.navigate(["bankInfo/confirm/"]);
      
     
      
      
  }

}
