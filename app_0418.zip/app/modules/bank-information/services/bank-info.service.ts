import { Injectable } from '@angular/core';
import * as Rx from "rxjs";
import { MockService } from '../../../shared/services/mock.service';
import { Observable } from 'rxjs';
const subject = new Rx.BehaviorSubject("");

@Injectable({
  providedIn: 'root'
})
export class BankInfoService {
form : any;

  constructor(private mockService : MockService) { }

  

  setBankInfo(formData){

  subject.next(formData);
}
getBankInfo(){
  subject.subscribe((data) => {
    console.log('Subscriber B:', data);
    this.form = data;
});
return this.form;
}


getBankInfoMock():Observable<any>
{
return this.mockService.getBankInfo();
}


getSubDivMock():Observable<any>
{
return this.mockService.getSubDiv();
}
}
