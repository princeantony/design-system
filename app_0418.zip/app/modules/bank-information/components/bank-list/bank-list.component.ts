import { Store, State } from '@ngrx/store';
import { Component, OnInit} from '@angular/core';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import _ from 'lodash';

import {GRID_CONFIG,APP_CONST, ROUTER_CONST} from '../../../../shared/constants/app.constants';
import { GridLinkComponent } from '../grid-link/grid-link.component';
import { ActivatedRoute, Router } from '../../../../../../node_modules/@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
import { BankInfoService } from '../../services/bank-info.service';
import { BankInfo } from '../../../../shared/models/bank-info.model';
import { NgxSpinnerService } from 'ngx-spinner';

import {IBankSubDiv, IBankInfo} from '../../../../shared/interfaces/bank.interface';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
@Component({
  selector: 'app-bank-list',
  templateUrl: './bank-list.component.html',
  styleUrls: ['./bank-list.component.scss']
})
export class BankListComponent implements OnInit {
columnDefs: any;
subDiv: any;
bankInfoData: any;
frameworkComponents: any;
context:any;
bankSubDiv: any;
bankInfo : any;
//bankNames:any;
  constructor(
    private modalService: ModalService,
    private router : Router,
    private route: ActivatedRoute,
    private bankInfoService: BankInfoService,
    private spinner: NgxSpinnerService) {}
   routeTo(link) {
     if(link ==="create"){
       this.modalService.open('bankModal');
     }
     else {
      this.router.navigate(["/bankInfo/"+link]);
     }
   
  }
  ngOnInit() {

    this.spinner.show();
    this.getMockDivSub();
    /*
    if(this.bankSubDiv ===  undefined)
    {
    this.spinner.show();
    this.getMockDivSub();
    }
    else
    {
      this.bankInfoData = this.bankInfo;
    }*/
    this.columnDefs = this.columnDefs = GRID_CONFIG.BANK_INFO.COLUMN_DEFS;
    this.frameworkComponents = {
      linkRenderer: GridLinkComponent
    }
    this.context = { componentParent: this };
  }
  getMockBankInfo() : void{
    this.bankInfoService.getBankInfoMock().subscribe(bankInfo => {
      this.spinner.hide();
      if(bankInfo.status === APP_CONST.LOGIN_SUCCESS) 
      {
      PayAdminGlobalState.bankinfo =  bankInfo.data;
     this.bankInfoData = bankInfo.data;
     
    

     
     
      if(this.bankInfoData.length === 1){
        this.router.navigate(["/bankInfo/editorcreate" ]);
      }
      else{
        this.bindBankInfo();
      }
     
     
      }
    })};
    getMockDivSub() : void{
      this.bankInfoService.getSubDivMock().subscribe(subDiv => {
        if(subDiv.status === APP_CONST.LOGIN_SUCCESS) 
        {
        PayAdminGlobalState.subDiv = subDiv.data;
        this.subDiv = subDiv.data;
        
        this.getMockBankInfo();

        }
    })};
    bindBankInfo()
      {
        this.bankInfoData.forEach(element => {
          _.merge(element, _.find(this.subDiv, ['id', element.divsub]));
         });
      }


      
      
}
