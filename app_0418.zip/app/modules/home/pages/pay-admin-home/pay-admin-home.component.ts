import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {ListPlan} from '../../../../shared/mocks/listPlan';
import _ from 'lodash';
import { PayAdminGlobalState } from '../../../../shared/store/pay-admin-global.store';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-pay-admin-home',
  templateUrl: './pay-admin-home.component.html'
 
})
export class PayAdminHomeComponent implements OnDestroy {
hidePageTitle = false;
changePlan = true;
 planNumber: string;
 private sub: any;
 planList = ListPlan.data;
 selectedPlan : any;
 planTitle : string;
 message: string;
 hasModel = false;

  constructor(private route: ActivatedRoute, private modalService: ModalService) {}

ngOnInit(params) {
  this.planNumber = PayAdminGlobalState.planNumber;
  this.message =  PayAdminGlobalState.successMsg;
  
   
  }
  ngAfterViewChecked()
  {
    
    this.sub = this.route.url.subscribe(params => {
     
     
        if(params[2] && params[2].path == "success"){
        
       
          if( !this.hasModel)
          {
            
            this.modalService.open('bankSubmit');
          }
     
        this.hasModel = true;
       
      }
      
  
      });
    
  }
   ngOnDestroy() {
   
    this.sub.unsubscribe();
  }

}
