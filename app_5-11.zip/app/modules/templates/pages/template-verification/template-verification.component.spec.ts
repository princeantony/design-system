import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateVerificationComponent } from './template-verification.component';

describe('TemplateVerificationComponent', () => {
  let component: TemplateVerificationComponent;
  let fixture: ComponentFixture<TemplateVerificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateVerificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
