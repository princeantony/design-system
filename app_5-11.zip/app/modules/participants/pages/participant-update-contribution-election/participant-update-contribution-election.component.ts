import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-participant-update-contribution-election',
  templateUrl: './participant-update-contribution-election.component.html',
  styleUrls: ['./participant-update-contribution-election.component.scss']
})
export class ParticipantUpdateContributionElectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
