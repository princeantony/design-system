import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Utils } from 'src/app/shared/utils/pay-admin.utils';

import { ParticipantOptionalField } from '../../model/participant.model';
import { ParticipantsService } from '../../service/participants.service';
import { ParticipantOptionalFieldDropDown } from './participant-optional-field-dropdown';
import { ParticipantOptionalFieldTextBox } from './participant-optional-field-textbox';
import { ParticipantOptionalFields } from './participant-optional-fields';

@Component({
  selector: 'participant-optional-data',
  templateUrl: './participant-optional-data.component.html',
  styleUrls: ['./participant-optional-data.component.scss']
})
export class ParticipantOptionalDataComponent implements OnInit {
  optionalFields: ParticipantOptionalFields<any>[] = [];
  optionalFieldsRows: ParticipantOptionalFields<any>[][];
  participantOptionalDataField: ParticipantOptionalField[];
  participantOptionalData: ParticipantOptionalField[];
  participantOptionalDataForm: FormGroup;

  constructor(
    private participantsService: ParticipantsService,
    private router: Router,
    private _util: Utils
  ) {}

  ngOnInit() {
    this.getOptionalDataFields();

    this.participantOptionalDataForm = this.participantsService.toFormGroup(
      this.optionalFields
    );
    this.optionalFieldsRows = this._util.chunkArray(this.optionalFields, 2);
    console.log(this.participantOptionalDataForm);
  }

  getOptionalDataFields() {
    this.participantsService
      .getParticipantOptionalDataFields()
      .subscribe(result => {
        if (result.status === 'SUCCESS') {
          this.participantOptionalDataField = result.data;
        }
      });
    this.participantOptionalDataField.forEach(
      (field: ParticipantOptionalField) => {
        if (field.componentType === 'text') {
          this.optionalFields.push(
            new ParticipantOptionalFieldTextBox({
              key: field.key
                .split(' ')
                .join('-')
                .toUpperCase(),
              label: field.label,
              required: field.required,
              value: field.value,
              type: field.type,
              readonly: field.readOnly,
              disabled: field.disabled,
              length: field.length
            })
          );
        }
        if (field.componentType === 'dropdown') {
          this.optionalFields.push(
            new ParticipantOptionalFieldDropDown({
              key: field.key
                .split(' ')
                .join('-')
                .toUpperCase(),
              label: field.label,
              required: field.required,
              value: field.value,
              options: field.option,
              readonly: field.readOnly,
              disabled: field.disabled
            })
          );
        }
      }
    );
  }

  onSubmit() {
    let data: ParticipantOptionalField[] = this.participantOptionalDataForm
      .value;
    console.log(data);
    this.participantOptionalData = data;
    this.participantsService.addParticipantOptionalData(
      this.participantOptionalData
    );
    this.router.navigate(['addParticipant/ContributionElection']);
  }

  onBackClicked() {
    this.router.navigate(['participant']);
  }

  onDropDownChange() {}
}
