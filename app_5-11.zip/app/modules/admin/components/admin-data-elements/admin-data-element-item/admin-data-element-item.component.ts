import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {
  AddEnrollmentOptions,
  BatchParticipantOptions,
  ContributionOptions,
  ParticipantOptions,
} from 'src/app/shared/config/data-element.config';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

@Component({
  selector: 'app-admin-data-element-item',
  templateUrl: './admin-data-element-item.component.html'
})

export class AdminDataElementItemComponent implements OnInit {

  hidePageTitle: boolean;
  subTitle: string;
  planNumber: string;
  selectedDataElement: any;
  participantOptions : any;
  addEnrollmentOptions: any;
  contributionOptions: any;

  batchParticipantOptions: any;
   updateOtionalDataForm = this.fb.group({
    dataElement1: ['', Validators.required],
    dataElement2: ['', Validators.required],
    dataElement3: ['', Validators.required],
    omniName: ['', Validators.required],
    overrideName: ['', Validators.required],
    addEnrollment: ['', Validators.required],
    userOverride: ['', Validators.required],
    accuUserOverride: ['', Validators.required],
    participant: ['', Validators.required],
    contribution: ['', Validators.required],
    batchParticipant: ['', Validators.required],
  });
  constructor(private fb: FormBuilder)
  {

  }
  populateForm(dataElement) {

    this.updateOtionalDataForm.controls['dataElement1'].setValue(dataElement.dataElement1);
    this.updateOtionalDataForm.controls['dataElement2'].setValue(dataElement.dataElement2);
    this.updateOtionalDataForm.controls['dataElement3'].setValue(dataElement.dataElement3);
    this.updateOtionalDataForm.controls['omniName'].setValue(dataElement.omniName);
    this.updateOtionalDataForm.controls['overrideName'].setValue(dataElement.overrideName);
    this.updateOtionalDataForm.controls['userOverride'].setValue(dataElement.userOverride);
    this.updateOtionalDataForm.controls['accuUserOverride'].setValue(dataElement.accuUserOverride);
    this.updateOtionalDataForm.controls['addEnrollment'].setValue(dataElement.addEnrollment);
    this.updateOtionalDataForm.controls['participant'].setValue(dataElement.participant);
    this.updateOtionalDataForm.controls['contribution'].setValue(dataElement.contribution);
    this.updateOtionalDataForm.controls['batchParticipant'].setValue(dataElement.batchParticipant);
  }
  onStateChange(value: string) {
    console.log("value changed"  + value);
  }
  ngOnInit() {

    this.participantOptions = ParticipantOptions;
    this.addEnrollmentOptions = AddEnrollmentOptions;
    this.contributionOptions = ContributionOptions;
    this.batchParticipantOptions = BatchParticipantOptions;
    this.selectedDataElement = PayAdminGlobalState.dataElement;
    console.log("this.selectedDataElement222", this.selectedDataElement);
    this.populateForm(this.selectedDataElement);

  }
/*
  get dataElement1() {
    return this.updateOtionalDataForm.get('dataElement1');
  }
  get dataElement2() {
    return this.updateOtionalDataForm.get('dataElement2');
  }
  get dataElement3() {
    return this.updateOtionalDataForm.get('dataElement3');
  }
  get omniName() {
    return this.updateOtionalDataForm.get('omniName');
  }
  get overrideName() {
    return this.updateOtionalDataForm.get('overrideName');
  }
  get Enrollment() {
    return this.updateOtionalDataForm.get('Enrollment');
  }
  get Participant() {
    return this.updateOtionalDataForm.get('Participant');
  }
  get Contribution() {
    return this.updateOtionalDataForm.get('Contribution');
  }
  get batchParticipant() {
    return this.updateOtionalDataForm.get('batchParticipant');
  }*/
}
