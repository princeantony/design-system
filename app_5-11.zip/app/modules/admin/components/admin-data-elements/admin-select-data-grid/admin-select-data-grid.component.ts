import { Component, Input, OnInit } from '@angular/core';

import { AdminGridRadioComponent } from '../../admin-grid-radio/admin-grid-radio.component';

@Component({
  selector: 'app-admin-select-data-grid',
  templateUrl: './admin-select-data-grid.component.html'
})
export class AdminSelectDataGridComponent implements OnInit {
  @Input() rowData;
  @Input() columnDefs;
context: any;
frameworkComponents: any;
  ngOnInit() {
    this.context = {
    componentParent: this
};
  this.frameworkComponents = {
  radiobuttonRender : AdminGridRadioComponent,
  };
  }
}
