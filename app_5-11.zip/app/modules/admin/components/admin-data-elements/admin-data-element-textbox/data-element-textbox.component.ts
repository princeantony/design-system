import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-data-element-textbox',
  templateUrl: './data-element-textbox.component.html'
})
export class DataElementTextboxComponent implements ICellRendererAngularComp {
  constructor() {}
  public params: any;
  controlName: string;
  value: string;

  agInit(params: any): void {
    this.params = params;
    this.controlName = params.colDef.field + '_' + params.rowIndex;
    this.value = params.value;
  }

    onBlur(event: any) {

      const order = event.target.value;
      console.log("order", order);
    }
  refresh(): boolean {
    return false;
  }
}
