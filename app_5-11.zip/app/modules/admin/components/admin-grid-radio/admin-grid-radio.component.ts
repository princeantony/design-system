import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular/main';

import { AdminDataService } from '../../services/admin-data.service';

@Component({
  selector: "app-admin-grid-radio",
  templateUrl: "./admin-grid-radio.component.html",
  // styleUrls: ["./admin-grid-radio-button.component.scss"]
})

export class AdminGridRadioComponent implements ICellRendererAngularComp {

  private params: any;

  agInit(params: any): void {
    this.params = params;

  }

  refresh(params): boolean {
    return false;
  }

  handleChange(value) {

    //this.params.node.setSelected(!this.params.node.selected);
    try{
      console.log(value);
    AdminDataService.dataElementId = this.params.data.dataElement;
    this.params.context.componentParent.methodFromParent(AdminDataService.dataElementId);
    } catch (ex) {}

  }
}

