import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-de-modal',
  templateUrl: './de-modal.component.html'

})
export class DEModalComponent implements OnInit {
  @Input() deId;
  @Input() type;
  constructor(private modalService: ModalService,
              private router: Router) { }

  ngOnInit() {
  }

  closeModal(id: string) {
    this.modalService.close(id);
}
continueTo(id: string) {
  this.modalService.close(id);
  this.router.navigate(['/admin/dataElements/delete']);
}

}


