import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ENV } from 'src/app/shared/constants/app.constants';
import { SERVICE_URL } from 'src/app/shared/constants/service.constants';

import { AdminMenuItems } from '../../../shared/config/admin.config';
import { IMenuItem } from '../../../shared/interfaces/menu-item.interface';
import { ApiService } from '../../../shared/services/api.service';
import { MockService } from '../../../shared/services/mock.service';
import { Utils } from '../../../shared/utils/pay-admin.utils';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  constructor(private mockService: MockService, private utils: Utils, private apiService: ApiService) {}

  getMockMenuList(planNumber: string): Observable<any> {
    return this.mockService.getAdminFlags();
  }
  getMenuItemRows(menuItemsFlag: any) {
    const menuItemsToBind: IMenuItem[] = [];
    AdminMenuItems.forEach(menuItem => {
      if (menuItemsFlag[menuItem.key]) {
        menuItemsToBind.push(menuItem);
      }
    });
    return this.utils.chunkArray(menuItemsToBind, 3);
  }

  getMockTerminationList(): Observable<any> {
    return this.mockService.getTerminationReason();
  }

  getDEList(planNumber: string): Observable<any> {
    if(ENV.TEST)
    return this.mockService.getDataElements();
    return this.apiService.get(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber);

  }
  getDEOptions(planNumber: string, dataelementID: string )
  {
    if(ENV.TEST)
    return this.mockService.getDEOptions();
    return this.apiService.get(SERVICE_URL.GET_OPTIONAL_DE_URL + planNumber + '/optionaldes/' + dataelementID + '/value');
  }
}
