export class AdminDataService {
  static dataElementId: string;
  static dataElementNewOrder: string;

}
