import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import _ from 'lodash';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { ModalService } from 'src/app/shared/services/modal.service';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { AdminService } from '../../../services/admin.service';

@Component({
    selector: 'app-admin-data-elements-page',
    templateUrl: './admin-data-elements-page.component.html'
})

export class AdminDataElementsPageComponent implements OnInit {
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    dEColumnDefs: any;
    dEList: any;
    deId = 'PHPT';
    type = 'Data Element';
    selectedDEId: string;
    isDisabled = true;
    constructor(
      private adminService: AdminService,
      private router: Router,
      private modalService: ModalService) {
        this.dEColumnDefs = GRID_CONFIG.DATA_ELEMENTS.COLUMN_DEFS_ELEMENTS;
    }

    ngOnInit() {
      PayAdminGlobalState.previousPage = PayAdminGlobalState.currentPage;
      PayAdminGlobalState.currentPage = 'admin/dataElements';
        this.hidePageTitle = false;
        this.subTitle = 'Select Data Element Option'; // read from const
        this.planNumber = PayAdminGlobalState.planNumber;
        this.getDataElementList();
        console.log("header" + this.dEColumnDefs + "Row Data" + this.dEList);
    }

    handleChange() {
      this.selectedDEId = '';
      this.isDisabled = false;
        console.log("New DE selected");
    }

    getDataElementList() {
        this.adminService.getDEList(this.planNumber).subscribe(flags => {
            if (flags.status === APP_CONST.SUCCESS) {
                this.dEList = flags.data;
                PayAdminGlobalState.dataElements = flags.data;
            }
        });
    }
    getSelectedDataID(_deid: string)
    {
      this.isDisabled = false;
      this.selectedDEId = _.filter(this.dEList, ['dataElement', _deid])[0];
      PayAdminGlobalState.dataElement = this.selectedDEId;
      console.log("this.selectedDEId", this.selectedDEId);
    }
    gotoBack() {
      this.router.navigate([PayAdminGlobalState.previousPage]);
    }
    showDeteleModal(){
      this.modalService.open('deModal');
    }
    onDelete() {

    }
    saveDisplayOrder()
    {

    }
    showOptions() {
      this.router.navigate(['/admin/dataElements/options']);
    }
    onEdit() {
      this.router.navigate(['/admin/dataElements/createOrEdit']);
    }
}

