import { Component, OnInit } from '@angular/core';
import { APP_CONST } from 'src/app/shared/constants/app.constants';
import { GRID_CONFIG } from 'src/app/shared/constants/grid.constants';
import { PayAdminGlobalState } from 'src/app/shared/store/pay-admin-global.store';

import { AdminDataService } from '../../../services/admin-data.service';
import { AdminService } from '../../../services/admin.service';

@Component({
    selector: 'app-admin-options-data',
    templateUrl: './admin-options-data.component.html'
  })

export class AdminOptionsDataComponent implements OnInit{
    slectDataColumnDefs: any;
    selectData: any;
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;
    dataelementID: string;
    constructor(private adminService: AdminService){}
    ngOnInit(){
        this.slectDataColumnDefs = GRID_CONFIG.DATA_ELEMENTS.OPTIONS;
        this.hidePageTitle = false;
        this.subTitle = 'Select Data Element Option';
        this.planNumber = PayAdminGlobalState.planNumber;
        this.dataelementID =  AdminDataService.dataElementId;
        this.getOptions();
    }
    selectNew()
    {

    }
    getOptions()
    {
      this.adminService.getDEOptions(this.planNumber, this.dataelementID).subscribe(options => {
        if (options.status === APP_CONST.SUCCESS) {
            this.selectData = options.data;
        }
    });
    }
  }
