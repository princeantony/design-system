import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
    selector: 'app-admin-data-element-select',
    templateUrl: './admin-data-element-select.component.html'

  })

  export class AdminDataElementSelectComponent implements OnInit{
    hidePageTitle: boolean;
    subTitle: string;
    planNumber: string;

    updateOtionalDataForm = this.fb.group({
        dataElement1: ['', Validators.required],
        dataElement2: ['', Validators.required],
        dataElement3: ['', Validators.required],
    })


    constructor( private fb: FormBuilder,private router: Router){ }

    ngOnInit(){
      this.hidePageTitle = false;
      this.subTitle = 'Update Optional Data Element';
      this.planNumber ='559985';
    }
    showOptions() {
      this.router.navigate(['/admin/dataElements/options']);
    }
  }
