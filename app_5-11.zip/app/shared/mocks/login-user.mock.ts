
export const LoginUser=
{
  "userName": "SPAYNG01",
  "password": "ING12345",
  "clientId": "INGWIN",
  "divisionId": "WIN"
}

/*
export const LoginUser=
{
"userName":"_20180906_00006",
"password":"000139954506928",
"clientId":"INGWIN",
"divisionId":"WIN"
 }
*/
/*
export const LoginUser=
{
"userName":"20180628_00001",
 "password":"000116558087371",
 "clientId":"INGWIN",
 "divisionId":"WIN"

 }

*/
