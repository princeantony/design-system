export const StateListMock = {
  status: 'SUCCESS',
  data: [
    {
      value: 'AB',
      displayText: 'ALBERTA'
    },
    {
      value: 'AK',
      displayText: 'ALASKA'
    },
    {
      value: 'AL',
      displayText: 'ALABAMA'
    },
    {
      value: 'AR',
      displayText: 'ARKANSAS'
    },
    {
      value: 'AS',
      displayText: 'AMERICAN SAMOA'
    },
    {
      value: 'AZ',
      displayText: 'ARIZONA'
    }
  ]
};

export const CountryListMock = {
  status: 'SUCCESS',
  data: [
    {
      value: 'USA',
      displayText: 'USA'
    },
    {
      value: 'CA',
      displayText: 'CANADA'
    },
    {
      value: 'AFG',
      displayText: 'AFGHANISTAN'
    },
    {
      value: 'ALB',
      displayText: 'ALBANIA'
    },
    {
      value: 'DZA',
      displayText: 'ALGERIA'
    }
  ]
};


export const MockSuccessResponse = {
  status: 'SUCCESS',
  data: [
    {
      status: 'Good'
    }
  ]
};

