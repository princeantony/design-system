import { IPlanLight } from '../interfaces/plan-light.interface';

export  class  PayAdminGlobalState{
    static planNumber: string;
    static planName: string;
    static successMsg: string;
    static planListState: IPlanLight;
    static homeFlagState: any;
    static bankinfo: any;
    static subDiv: any;
    static bankDetails: any;
    static previousPage: string;
    static currentPage: string;
    static divsubId: string;
    static isCatchUp: boolean;
    static stateList: {value: string, displayText: string}[];
    static countryList: {value: string, displayText: string}[];
    static importFileData: any;
    static importFileType: string;
    static importColumns: any;
    static moneySource: any;
    static investments: any;
    static importType  = 'E';
    static loginStatus = false;
    static loginUser: {userName: string, password: string, clientId: string, divisionId: string};
    static dataElements: any[];
    static dataElement: any;
    static ClearAll()
    {
      // to be clear all local states

    }
}
