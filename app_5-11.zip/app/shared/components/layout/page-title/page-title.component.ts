import { Router } from "@angular/router";
import { Component, OnInit, Input } from "@angular/core";
import {ListPlan} from '../../../mocks/listPlan';
import { SUB_TITLE } from "../../../constants/app.constants";
import _ from 'lodash';

import { PayAdminGlobalState } from "../../../store/pay-admin-global.store";
@Component({
  selector: "app-page-title",
  templateUrl: "./page-title.component.html"
})
export class PageTitleComponent implements OnInit {
  @Input() hidePageTitle: boolean;
  @Input() pageTitleClass: boolean;
  @Input() pageTitle: string;
  @Input() changePlan: boolean;
  @Input() planNumber : string;
  @Input() subTitle: string;
  @Input() colorChange: boolean;
   selectedPlan : any;
   planTitle: string;
   planList = ListPlan.data;
  appTitle = SUB_TITLE.APP_TITLE;
  linkText = "Change Plan";
  
  constructor(private router: Router) { }
 ngOnInit() {

       if(this.subTitle !== undefined)
          this.subTitle = " - "+this.subTitle;
      this.selectedPlan = _.find(this.planList, ['planNumber', this.planNumber]);
      if(this.selectedPlan){
        this.planTitle = "- " +this.selectedPlan.planNumber + "-" + this.selectedPlan.planName;
      }  

      
}
  navToPlans() {
    if (!this.hidePageTitle) {
      PayAdminGlobalState.previousPage = "/home";
      this.router.navigate(['/plans']);
    }
  }
  
 
  navToHome(){
    
    this.router.navigate(['/home']);
  }
}
