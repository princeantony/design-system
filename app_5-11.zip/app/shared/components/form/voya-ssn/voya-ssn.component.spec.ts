import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoyaSsnComponent } from './voya-ssn.component';

describe('VoyaSsnComponent', () => {
  let component: VoyaSsnComponent;
  let fixture: ComponentFixture<VoyaSsnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoyaSsnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoyaSsnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
