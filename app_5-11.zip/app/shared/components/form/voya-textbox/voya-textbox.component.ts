import { Component, forwardRef, Input, OnInit } from '@angular/core';
import {
  ControlValueAccessor,
  FormControl,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidationErrors,
  Validator,
  Validators,
} from '@angular/forms';

import { BaseInputComponent } from '../base-input/base-input.component';

const noop = () => {};

@Component({
  selector: 'voya-textbox',
  templateUrl: './voya-textbox.component.html',
  styleUrls: ['./voya-textbox.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => VoyaTextboxComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => VoyaTextboxComponent),
      multi: true
    }
  ]
})
export class VoyaTextboxComponent extends BaseInputComponent
  implements OnInit, ControlValueAccessor, Validator {
  // The internal data model
  private _value: any = '';
  private _type = 'string'; // string, float, integer
  private isLabelHidden: boolean;
  @Input()
  get type(): string {
    return this._type;
  }
  set type(value: string) {
    this._type = value || 'string';
  }

  ngOnInit() {
    this.isLabelHidden = false;
  }

  // get accessor
  get value(): any {
    return this._value;
  }
  // set accessor including call the onchange callback
  set value(v: any) {
    if (v !== this._value) {
      this._value = v;
      this._onChangeCallback(v);
    }
  }

  // Set touched on blur
  onTouched(event: any) {
    if (event.target.value === '') {
      this.isLabelHidden = true;
    }
    if (event.target.value !== '') {
      this.isLabelHidden = false;
    }
    this._onTouchedCallback(null);
  }
  onFocus() {
    this.isLabelHidden = false;
  }

  writeValue(value: string): void {
    this._value = value || '';
    if (this._value.length > 0) {
      this.isLabelHidden = false;
    }
    if (this._value.length === 0) {
      this.isLabelHidden = true;
    }
  }

  registerOnChange(fn: any): void {
    this._onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {}

  validate(ctrl: FormControl): ValidationErrors | null {
    if (this.isRequired) {
      return Validators.compose([Validators.required])(ctrl);
    } else {
      return null;
    }
  }
}
